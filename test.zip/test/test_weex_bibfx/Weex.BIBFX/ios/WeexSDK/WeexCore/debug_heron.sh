sh debug.sh
cp sdk/build/intermediates/cmake/debug/obj/armeabi-v7a/libweexcore.so   ../../heron/third_party/weex_core/libs/armeabi-v7a/libweexcore.so
cd ..
cd weex_core
cp Source/render/target/render_target.h  ../../heron/third_party/weex_core/render/target/render_target.h
