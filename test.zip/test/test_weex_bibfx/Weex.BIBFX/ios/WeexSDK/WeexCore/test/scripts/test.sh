cd out 
make test