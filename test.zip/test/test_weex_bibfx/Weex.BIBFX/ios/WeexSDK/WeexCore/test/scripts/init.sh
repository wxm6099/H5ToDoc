rm -rf out
mkdir out
cd out 
cmake ../