cd out
make