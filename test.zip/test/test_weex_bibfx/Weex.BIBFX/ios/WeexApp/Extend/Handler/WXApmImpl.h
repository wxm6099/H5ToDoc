#import <Foundation/Foundation.h>
#import "WXApmProtocol.h"

@interface WXApmImpl : NSObject <WXApmProtocol>

@end
