#import <Foundation/Foundation.h>
#import "WXApmProtocol.h"

@interface WXApmGeneratorImpl : NSObject <WXApmGeneratorProtocol>

@end
