/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

#import <WeexSDK/WeexSDK.h>
#import "WXNavigationHandlerImpl.h"
#import "LandscapeViewController.h"
@implementation WXNavigationHandlerImpl



- (void)clearNavigationItemWithParam:(NSDictionary *)param position:(WXNavigationItemPosition)position completion:(WXNavigationResultBlock)block withContainer:(UIViewController *)container {
    
}

- (id)navigationControllerOfContainer:(UIViewController *)container {
    return container.navigationController;
}

- (void)popViewControllerWithParam:(NSDictionary *)param completion:(WXNavigationResultBlock)block withContainer:(UIViewController *)container {
    BOOL animated = YES;
    id obj = [param objectForKey:@"animated"];
    if (obj) {
        animated = [WXConvert BOOL:obj];
    }
    if ([param objectForKey:@"url"]) {
        for (UIViewController *vc in container.navigationController.viewControllers) {
            if ([vc isKindOfClass:[WXBaseViewController class]]) {
                WXBaseViewController *baseVC = (WXBaseViewController *)vc;
                if ([baseVC.sourceURL.absoluteString isEqualToString:[param objectForKey:@"url"]]) {
                    [container.navigationController popToViewController:vc animated:NO];
                }
            }else if ([vc isKindOfClass:[LandscapeViewController class]]){
                LandscapeViewController *landVC = (LandscapeViewController *)vc;
                if ([landVC.sourceURL.absoluteString isEqualToString:[param objectForKey:@"url"]]) {
                    [container.navigationController popToViewController:vc animated:NO];
                }
            }
        }
    }else{
        [container.navigationController popViewControllerAnimated:animated];
    }
}

- (void)pushViewControllerWithParam:(NSDictionary *)param completion:(WXNavigationResultBlock)block withContainer:(UIViewController *)container {
    if (0 == [param count] || !param[@"url"] || !container) {
        [self callback:block code:MSG_PARAM_ERR data:nil];
        return;
    }
    
    BOOL animated = YES;
    NSString *obj = [[param objectForKey:@"animated"] lowercaseString];
    if (obj && [obj isEqualToString:@"false"]) {
        animated = NO;
    }
    
    UIViewController *vc = nil;
    NSString *orientation = [[param objectForKey:@"orientation"] lowercaseString];
    if (orientation && [orientation isEqualToString:@"horizontal"]) {
        vc = [[LandscapeViewController alloc]initWithSourceURL:[NSURL URLWithString:param[@"url"]]];
        LandscapeViewController *landVC = (LandscapeViewController *)vc;
        NSString *panLandEnable = [[param objectForKey:@"disableBackPan"] lowercaseString];
        if (panLandEnable && [panLandEnable isEqualToString:@"true"]) {
            landVC.isDisableBackPan = YES;
        }else{
            landVC.isDisableBackPan = NO;
        }
    }else{
        vc = [[WXBaseViewController alloc]initWithSourceURL:[NSURL URLWithString:param[@"url"]]];
        WXBaseViewController *baseVC = (WXBaseViewController *)vc;
        NSString *panEnable = [[param objectForKey:@"disableBackPan"] lowercaseString];
        if (panEnable && [panEnable isEqualToString:@"true"]) {
            baseVC.isDisableBackPan = YES;
        }else{
            baseVC.isDisableBackPan = NO;
        }
    }
    
    vc.hidesBottomBarWhenPushed = YES;
    [container.navigationController pushViewController:vc animated:animated];
    [self callback:block code:MSG_SUCCESS data:nil];
}

- (void)setNavigationBackgroundColor:(UIColor *)backgroundColor withContainer:(UIViewController *)container {
    
}

- (void)setNavigationBarHidden:(BOOL)hidden animated:(BOOL)animated withContainer:(UIViewController *)container {
    if (![container isKindOfClass:[WXBaseViewController class]]) {
        return;
    }
    
    container.navigationController.navigationBarHidden = hidden;
}

- (void)setNavigationItemWithParam:(NSDictionary *)param position:(WXNavigationItemPosition)position completion:(WXNavigationResultBlock)block withContainer:(UIViewController *)container {
    
}
- (void)callback:(WXNavigationResultBlock)block code:(NSString *)code data:(NSDictionary *)reposonData
{
    if (block) {
        block(code, reposonData);
    }
}
@end
