//
//  MediaComponnent.h
//  WeexApp
//
//  Created by Richard on 2018/4/13.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WXComponent.h>
#import <NodeMediaClient/NodeMediaClient.h>

@interface MediaComponnent : WXComponent<NodePlayerDelegate>

@end
