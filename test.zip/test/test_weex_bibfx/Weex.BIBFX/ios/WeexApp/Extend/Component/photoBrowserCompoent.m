//
//  photoBrowserCompoent.m
//  Acetop
//
//  Created by blts on 2019/7/23.
//  Copyright © 2019 Acetop. All rights reserved.
//

#import "photoBrowserCompoent.h"
#import "UIView+Extension.h"
#import "NSString+CODEC.h"

@interface photoBrowserCompoent()<UIScrollViewDelegate>

@property(nonatomic,strong)UIScrollView *photoScroll;//
@property(nonatomic,strong)UIImageView *photoImageView;//
@property(nonatomic,strong)UIImage *photoImage;//
@property(nonatomic,strong)NSString *imageUrl;//

@end

@implementation photoBrowserCompoent

- (instancetype)initWithRef:(NSString *)ref type:(NSString *)type styles:(NSDictionary *)styles attributes:(NSDictionary *)attributes events:(NSArray *)events weexInstance:(WXSDKInstance *)weexInstance
{
    if (self = [super initWithRef:ref type:type styles:styles attributes:attributes events:events weexInstance:weexInstance]) {
        if (![NSString isBlankString:attributes[@"src"]]) {
            self.imageUrl = attributes[@"src"];
        }
    }
    return self;
}

-(void)viewDidLoad
{
    [self.view addSubview:self.photoScroll];
    [self.photoScroll addSubview:self.photoImageView];
    self.photoScroll.frame = self.view.bounds;
    self.photoScroll.minimumZoomScale = 0.5;
    self.photoScroll.maximumZoomScale = 2.0;
//    self.photoImage = [UIImage imageNamed:@"chat_face_red"];//可加loading图
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:self.imageUrl]]];
        dispatch_async(dispatch_get_main_queue(),^{
            if (image == nil) {
                NSLog(@"查看大图 加载失败");
            }else{
                self.photoImage = image;
            }
        });
    });
}

- (void)setPhotoImage:(UIImage *)photoImage
{
    _photoImage = photoImage;
    self.photoImageView.image = photoImage;
    CGFloat phoneX = 0;
    CGFloat phoneY = 0;
    CGFloat phoneW = 0;
    CGFloat phoneH = 0;
    if (photoImage.size.width>self.photoScroll.bounds.size.width && photoImage.size.height>self.photoScroll.bounds.size.height) {
        phoneW = self.photoScroll.bounds.size.width*0.8;
        phoneH = photoImage.size.height*phoneW/photoImage.size.width;
        phoneX = self.photoScroll.bounds.size.width*0.1;
        phoneY = (self.photoScroll.bounds.size.height-phoneH)*0.5;
    }else if (photoImage.size.width <= self.photoScroll.bounds.size.width && photoImage.size.height>self.photoScroll.bounds.size.height) {
        phoneH = self.photoScroll.bounds.size.height*0.8;
        phoneW = photoImage.size.width*phoneH/photoImage.size.height;
        phoneX = (self.photoScroll.bounds.size.width-phoneW)*0.5;
        phoneY = self.photoScroll.bounds.size.height*0.1;
    }else if (photoImage.size.width > self.photoScroll.bounds.size.width && photoImage.size.height<=self.photoScroll.bounds.size.height) {
        phoneW = self.photoScroll.bounds.size.width*0.8;
        phoneH = photoImage.size.height*phoneW/photoImage.size.width;
        phoneX = self.photoScroll.bounds.size.width*0.1;
        phoneY = (self.photoScroll.bounds.size.height-phoneH)*0.5;
    }else{
        phoneW = photoImage.size.width;
        phoneH = photoImage.size.height;
        phoneX = (self.photoScroll.bounds.size.width-phoneW)*0.5;
        phoneY = (self.photoScroll.bounds.size.height-phoneH)*0.5;
    }
    self.photoImageView.frame = CGRectMake(0, 0, phoneW, phoneH);
    self.photoScroll.contentInset = UIEdgeInsetsMake(phoneY, phoneX, phoneY, phoneX);
    self.photoScroll.contentSize = CGSizeMake(phoneW, phoneH);
}

#pragma mark - UIScrollViewDelegate

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return self.photoImageView;
}

- (void)scrollViewDidEndZooming:(UIScrollView *)scrollView withView:(UIView *)view atScale:(CGFloat)scale
{
    CGFloat offsetX = (scrollView.width - view.width) * 0.5;
    CGFloat offsetY = (scrollView.height - view.height) * 0.5;
    
    offsetX = offsetX > 0 ? offsetX : 0;
    offsetY = offsetY > 0 ? offsetY : 0;
    view.x = 0;
    view.y = 0;
    scrollView.contentInset = UIEdgeInsetsMake(offsetY, offsetX, offsetY, offsetX);
}

- (void)scrollViewDidZoom:(UIScrollView *)scrollView
{
    CGFloat offsetX = (scrollView.width - self.photoImageView.width) * 0.5;
    CGFloat offsetY = (scrollView.height - self.photoImageView.height) * 0.5;
    
    offsetX = offsetX > 0 ? offsetX : 0;
    offsetY = offsetY > 0 ? offsetY : 0;
    scrollView.contentInset = UIEdgeInsetsMake(offsetY, offsetX, offsetY, offsetX);
}

- (UIScrollView *)photoScroll
{
    if (!_photoScroll) {
        _photoScroll = [[UIScrollView alloc] init];
        _photoScroll.delegate = self;
    }
    return _photoScroll;
}

- (UIImageView *)photoImageView
{
    if (!_photoImageView) {
        _photoImageView = [[UIImageView alloc] init];
        _photoImageView.userInteractionEnabled = YES;
    }
    return _photoImageView;
}
@end
