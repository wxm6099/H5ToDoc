//
//  BIBKlineChartComponent.m
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "BIBKlineChartComponent.h"
#import "WXUtility.h"
#import "BIBKLineCandleView.h"
#import "BIBChartPriceView.h"
#import "BIBIndexTypeView.h"
#import "BIBMACDLineView.h"
#import "BIBRSILineView.h"
#import "BIBKDJLineView.h"
#import "BIBBOLLLineView.h"
#import "BIBMALineView.h"
#import "BIBOSMALineView.h"
#import "Masonry.h"
#import "BIBKLineCandleModel.h"
#import "NSString+Extension.h"
#import "AppDelegate.h"


#define IPHONE_WIDTH [UIScreen mainScreen].bounds.size.width
#define SizeScaleW (IPHONE_WIDTH/375)  //屏幕宽的缩放比例

#define IPHONE_HEIGHT [UIScreen mainScreen].bounds.size.height
#define SizeScaleH (IPHONE_HEIGHT/667)  //屏幕高的缩放比例

#define SizeScale_Height (SizeScaleW == 1 ? 1 : IPHONE_HEIGHT/667)  //屏幕高的缩放比例(iphone X屏幕宽的缩放比例为1时，高的缩放比例也为1，不随SizeScaleH的改变而改变）
#define UpColor (@"30b700")
#define DownColor (@"eb403e")
#define CurrentColor (@"2e74e9")

#define TimeLayerHeight 20 //指标图底部时间和日期区域的高度
#define IndexChartHeight 90 //指标图的高度
#define IndexTypeHeight 28 //指标图分类类型的高度
#define ScreenCandleNumber 45 //蜡烛图的个数
typedef enum
{
    MACD = 1,
    RSI,
    KDJ,
    BOLL,
    MA,
    OSMA
}IndexLineType;

@interface BIBKlineChartComponent()<BIBKLineCandleViewProtocol,BIBIndexTypeViewDelegate>

@property(nonatomic,strong)UIView *view_bg;//主背景view

@property(nonatomic,strong)UIScrollView *scrollView_quoteChart;//
@property(nonatomic,strong)BIBKLineCandleView *view_candleChart;//蜡烛图的主view
@property(nonatomic,strong)UIView *view_box_candle;//蜡烛图的覆盖层
@property(nonatomic,strong)BIBChartPriceView *view_price_candle;//蜡烛图的右侧价格
@property(nonatomic,strong)UIView *view_bg_indexType;//指标分类的背景
@property(nonatomic,strong)BIBIndexTypeView *view_indexType;//指标分类
@property(nonatomic,strong)UIView *view_bg_index;//指标的背景层
@property(nonatomic,strong)UIView *view_box_index;//指标图的覆盖层
@property(nonatomic,strong)UILabel *label_indexTitle;//指标的参数title
@property(nonatomic,strong)BIBChartPriceView *view_price_index;//指标的右侧价格
@property(nonatomic,strong)BIBMACDLineView *view_macd;//macd指标
@property(nonatomic,strong)BIBRSILineView *view_rsi;//rsi指标
@property(nonatomic,strong)BIBKDJLineView *view_kdj;//kdj指标
@property(nonatomic,strong)BIBBOLLLineView *view_boll;//boll指标
@property(nonatomic,strong)BIBMALineView *view_ma;//ma指标
@property(nonatomic,strong)BIBOSMALineView *view_osma;//osma指标

@property (nonatomic,strong) UILongPressGestureRecognizer *longPressGesture;//长按十字线
@property (nonatomic,strong) UIView *verticalView;//十字竖线
@property (nonatomic,strong) UIView *leavView;//十字横线
@property (nonatomic,strong) UILabel *label_cross;//十字线的日期值
@property (nonatomic,assign) NSInteger kLineNumber;//屏幕中可看见的k线下标

@property (nonatomic,strong) UIView *currentView;//实时线
@property (nonatomic,strong) UILabel *label_current;//实时报价
@property (nonatomic,assign) CGFloat currentQuote;//当前报价
@property (nonatomic,strong) NSString* currentColor;//当前报价色值
@property (nonatomic,copy) NSString* dropColor;//下跌颜色
@property (nonatomic,copy) NSString* riseColor;//上涨颜色
@property (nonatomic,assign) NSInteger screenCandleNumber;//每屏蜡烛图的个数

@property (nonatomic,assign) IndexLineType indexType;//选中的指标分类
@property (nonatomic,strong) NSMutableDictionary *dic_tecnnical;//存储指标title的数据值的字典
@property (nonatomic,strong) NSMutableArray *dataSource;//k线的数据集
@property (nonatomic,strong) NSMutableArray *macdSource;//指标图macd的数据集
@property (nonatomic,strong) NSMutableArray *rsiSource;//指标图rsi的数据集
@property (nonatomic,strong) NSMutableArray *kdjSource;//指标图kdj的数据集
@property (nonatomic,strong) NSMutableArray *bollSource;//指标图boll的数据集
@property (nonatomic,strong) NSMutableArray *maSource;//指标图ma的数据集
@property (nonatomic,strong) NSMutableArray *osmaSource;//指标图osma的数据集
@property (nonatomic,assign) NSInteger kLineType;//k线图的分类
@property (nonatomic,strong) NSMutableDictionary *dic_weex;//接收weex传过来的指标数据
@property (nonatomic,strong) NSMutableArray *arr_weex;//接收weex传过来的k线数据
//@property (nonatomic,assign) BOOL isWeexEvent;//weex的component自定义事件
@property (nonatomic,assign) BOOL isScrollRightMove;//是否k线右滑加载更多历史数据

@end

@implementation BIBKlineChartComponent
WX_EXPORT_METHOD(@selector(setQuoteData:)); // 暴露该方法给js
//WX_EXPORT_METHOD(@selector(getTheQuoteData:)); // 暴露该方法给js
WX_EXPORT_METHOD(@selector(rotationLive));
WX_EXPORT_METHOD(@selector(setloadMoreData:));


- (instancetype)initWithRef:(NSString *)ref type:(NSString *)type styles:(NSDictionary *)styles attributes:(NSDictionary *)attributes events:(NSArray *)events weexInstance:(WXSDKInstance *)weexInstance
{
    if (self = [super initWithRef:ref type:type styles:styles attributes:attributes events:events weexInstance:weexInstance]) {
        // handle your attributes
        // handle your styles
        _kLineType = 0;
        _isScrollRightMove = NO;
        _indexType = MACD;
        self.riseColor = attributes[@"riseColor"] ? [WXConvert NSString:attributes[@"riseColor"]] : UpColor;
        self.dropColor = attributes[@"dropColor"] ? [WXConvert NSString:attributes[@"dropColor"]] : DownColor;
        self.currentColor = attributes[@"currentColor"] ? [WXConvert NSString:attributes[@"currentColor"]] : CurrentColor;
        self.screenCandleNumber = attributes[@"CandleNumber"] ?  [attributes[@"CandleNumber"] integerValue]:ScreenCandleNumber;
    }
    return self;
}
-(void)rotationLive{
    
}
-(void)setQuoteData:(NSArray*)quoteData{
    if (quoteData == nil || quoteData == NULL) {
        return;
    }
    if (self.dataSource && self.dataSource.count>0) {
        if (self.isScrollRightMove) {
            NSMutableArray *arr = [NSMutableArray arrayWithArray:self.dataSource];
            [self.dataSource removeAllObjects];
            [self.dataSource addObjectsFromArray:quoteData];
            [self.dataSource addObjectsFromArray:arr];
        }else{
            [self.dataSource removeAllObjects];
            [self.dataSource addObjectsFromArray:quoteData];
        }
    }else if (self.dataSource && self.dataSource.count==0) {
        [self.dataSource addObjectsFromArray:quoteData];
    }
    [self loadData];
}

-(void)setloadMoreData:(NSArray *)array{
    if (array && self.dataSource) {
        [self.dataSource addObjectsFromArray:array];
        [self loadData];
    }
}
- (void)updateAttributes:(NSDictionary *)attributes
{
    if (attributes[@"typeChannelIndex"]) {
        _kLineType = [attributes[@"typeChannelIndex"] integerValue];
        _isScrollRightMove = NO;
    }
    if (attributes[@"quoteData"]) {
        NSMutableArray *arr_result = attributes[@"quoteData"];
        if (self.dataSource && self.dataSource.count>0) {
            if (self.isScrollRightMove) {
                NSMutableArray *arr = [NSMutableArray arrayWithArray:self.dataSource];
                [self.dataSource removeAllObjects];
                [self.dataSource addObjectsFromArray:arr_result];
                [self.dataSource addObjectsFromArray:arr];
            }else{
                [self.dataSource removeAllObjects];
                [self.dataSource addObjectsFromArray:arr_result];
            }
        }else if (self.dataSource && self.dataSource.count==0) {
            [self.dataSource addObjectsFromArray:arr_result];
        }
        [self loadData];
    }
    
    if (attributes[@"socketBid"]) {
        self.currentQuote = [attributes[@"socketBid"] floatValue];
        [self showQuoteLine];
    } else if (attributes[@"socketLine"]) {
        self.currentQuote = [attributes[@"socketLine"] floatValue];
        [self showQuoteLine];
    }
}
//处理特殊时间值 /Date(1233243523+0800)/
-(NSString *)solveTheDateString:(NSString *)date
{
    date = [date stringByReplacingOccurrencesOfString:@"/" withString:@""];
    date = [date stringByReplacingOccurrencesOfString:@"Date(" withString:@""];
    date = [date stringByReplacingOccurrencesOfString:@")" withString:@""];
    if ([date hasSuffix:@"+0800"]) {
        date = [date stringByReplacingOccurrencesOfString:@"+0800" withString:@""];
    }
    if ([date hasSuffix:@"-0000"]) {
        date = [date stringByReplacingOccurrencesOfString:@"-0000" withString:@""];
    }
    return date;
}
#pragma mark --   指标数据和蜡烛图数据的初始化  Method   ------
-(void)finishIndexChart:(IndexLineType)indexType
{
    switch (indexType) {
        case MACD:
            //macd数据处理
            if (self.dataSource.count > 0) {
                NSMutableArray *macdData = [[NSMutableArray alloc] init];
                for (int i = 0; i<self.dataSource.count; i++) {
                    NSDictionary *dic_macd = self.dataSource[i];
                    NSString *date = dic_macd[@"DateTime"];
                    if (![NSString isBlankString:date]) {
                        date = [self solveTheDateString:date];
                        if (_kLineType == 1 || _kLineType == 2 || _kLineType == 3) {
                            date = [NSString getTheDateStringByTimeStamp:date withFormat:@"YYYY-MM-dd"];
                        }else{
                            date = [NSString getTheDateStringByTimeStamp:date withFormat:@"MM-dd HH:mm"];
                        }
                    }
                    NSString *macd = dic_macd[@"macd_Macd"];
                    NSString *signal = dic_macd[@"macd_Signal"];
                    if (![NSString isBlankString:macd] || ![NSString isBlankString:signal]) {
                        BIBMacdModel *model = [[BIBMacdModel alloc] initWithDea:[signal doubleValue] diff:[signal doubleValue] macd:[macd doubleValue] date:date];
                        [macdData addObject:model];
                    }
                }
                if (macdData.count>0) {
                    BIBMacdModel *model_macd = macdData[macdData.count-1];
                    NSString *str_diff = @"0.000";
                    if (model_macd.diff) {
                        str_diff = [self reviseString:model_macd.diff];
                    }
                    [self.dic_tecnnical setObject:str_diff forKey:@"MACD_DIFF"];
                    NSString *str_dea = @"0.000";
                    if (model_macd.macd) {
                        str_dea = [self reviseString:model_macd.macd];
                    }
                    [self.dic_tecnnical setObject:str_dea forKey:@"MACD_MACD"];
                }
                _view_macd.dataArray = macdData;
            }
            break;
        case RSI:
            //rsi数据处理
            if (self.dataSource.count>0) {
                NSMutableArray *arr_rsi14 = [[NSMutableArray alloc] init];
                for (int k = 0; k<self.dataSource.count; k++) {
                    NSDictionary *dic_rsi = self.dataSource[k];
                    NSString *date = dic_rsi[@"DateTime"];
                    if (![NSString isBlankString:date]) {
                        date = [self solveTheDateString:date];
                        if (_kLineType == 1 || _kLineType == 2 || _kLineType == 3) {
                            date = [NSString getTheDateStringByTimeStamp:date withFormat:@"YYYY-MM-dd"];
                        }else{
                            date = [NSString getTheDateStringByTimeStamp:date withFormat:@"MM-dd HH:mm"];
                        }
                    }
                    NSString *rsi = dic_rsi[@"rsi_RSI"];
                    //指标model
                    if (![NSString isBlankString:rsi]) {
                        [arr_rsi14 addObject:[[BIBLineUntil alloc] initWithValue:[rsi doubleValue] date:date]];
                    }
                }
                //处理指标的划线
                BIBLineData *line_rsi14 = [[BIBLineData alloc] init];
                line_rsi14.data = arr_rsi14;
                line_rsi14.color = [UIColor blueColor];
                line_rsi14.title = @"RSI14";
                NSMutableArray *rsiData = [[NSMutableArray alloc] init];
                [rsiData addObject:line_rsi14];
                if (arr_rsi14.count>0) {
                    BIBLineUntil *until_rsi_14 = arr_rsi14[arr_rsi14.count-1];
                    NSString *str_rsi14 = @"0.000";
                    if (until_rsi_14.value) {
                        str_rsi14 = [self reviseString:until_rsi_14.value];
                    }
                    [self.dic_tecnnical setObject:str_rsi14 forKey:@"RSI_14"];
                }
                _view_rsi.dataArray = rsiData;
            }
            break;
        case KDJ:
            //kdj数据处理
            if (self.dataSource.count > 0) {
                NSMutableArray *slowKLineData = [[NSMutableArray alloc] init];
                NSMutableArray *slowDLineData = [[NSMutableArray alloc] init];
                for (int k = 0; k<self.dataSource.count; k++) {
                    NSDictionary *dic_kdj = self.dataSource[k];
                    NSString *date = dic_kdj[@"DateTime"];
                    if (![NSString isBlankString:date]) {
                        date = [self solveTheDateString:date];
                        if (_kLineType == 1 || _kLineType == 2 || _kLineType == 3) {
                            date = [NSString getTheDateStringByTimeStamp:date withFormat:@"YYYY-MM-dd"];
                        }else{
                            date = [NSString getTheDateStringByTimeStamp:date withFormat:@"MM-dd HH:mm"];
                        }
                    }
                    NSString *Main = dic_kdj[@"kdj_Main"];
                    NSString *Signal = dic_kdj[@"kdj_Signal"];
                    if (![NSString isBlankString:Main] || ![NSString isBlankString:Signal]) {
                        //指标model
                        [slowKLineData addObject:[[BIBLineUntil alloc] initWithValue:[Main doubleValue] date:date]];
                        [slowDLineData addObject:[[BIBLineUntil alloc] initWithValue:[Signal doubleValue] date:date]];
                    }
                }
                //处理指标的划线
                BIBLineData *slowKLine = [[BIBLineData alloc] init];
                slowKLine.data = slowKLineData;
                slowKLine.color = [UIColor blueColor];
                slowKLine.title = @"K";
                if (slowKLineData.count>0) {
                    BIBLineUntil *until_kdj_k = slowKLineData[slowKLineData.count-1];
                    NSString *str_kdj_k = @"0.000";
                    if (until_kdj_k.value) {
                        str_kdj_k = [self reviseString:until_kdj_k.value];
                    }
                    [self.dic_tecnnical setObject:str_kdj_k forKey:@"KDJ_K"];
                }
                
                BIBLineData *slowDLine = [[BIBLineData alloc] init];
                slowDLine.data = slowDLineData;
                slowDLine.color = [UIColor orangeColor];
                slowDLine.title = @"D";
                if (slowDLineData.count>0) {
                    BIBLineUntil *until_kdj_d = slowDLineData[slowDLineData.count-1];
                    NSString *str_kdj_d = @"0.000";
                    if (until_kdj_d.value) {
                        str_kdj_d = [self reviseString:until_kdj_d.value];
                    }
                    [self.dic_tecnnical setObject:str_kdj_d forKey:@"KDJ_D"];
                }
                
                NSMutableArray *kdjData = [[NSMutableArray alloc] init];
                [kdjData addObject:slowKLine];
                [kdjData addObject:slowDLine];
                _view_kdj.dataArray = kdjData;
            }
            break;
            case BOLL:
            //BOLL数据处理
            if (self.dataSource.count > 0) {
                NSMutableArray *slowULineData = [[NSMutableArray alloc] init];
                NSMutableArray *slowMLineData = [[NSMutableArray alloc] init];
                NSMutableArray *slowLLineData = [[NSMutableArray alloc] init];
                for (int k = 0; k<self.dataSource.count; k++) {
                    NSDictionary *dic_boll = self.dataSource[k];
                    NSString *date = dic_boll[@"DateTime"];
                    if (![NSString isBlankString:date]) {
                        date = [self solveTheDateString:date];
                        if (_kLineType == 1 || _kLineType == 2 || _kLineType == 3) {
                            date = [NSString getTheDateStringByTimeStamp:date withFormat:@"YYYY-MM-dd"];
                        }else{
                            date = [NSString getTheDateStringByTimeStamp:date withFormat:@"MM-dd HH:mm"];
                        }
                    }
                    NSString *Upper = dic_boll[@"boll_Upper"];
                    NSString *Moving = dic_boll[@"boll_Moving"];
                    NSString *Lower = dic_boll[@"boll_Lower"];
                    //指标model
                    [slowULineData addObject:[[BIBLineUntil alloc] initWithValue:[Upper doubleValue] date:date]];
                    [slowMLineData addObject:[[BIBLineUntil alloc] initWithValue:[Moving doubleValue] date:date]];
                    [slowLLineData addObject:[[BIBLineUntil alloc] initWithValue:[Lower doubleValue] date:date]];
                }
                //处理指标的划线
                BIBLineData *ULine = [[BIBLineData alloc] init];
                ULine.data = slowULineData;
                ULine.color = [UIColor colorWithStr:@"ffffab40"];
                ULine.title = @"U";
                BIBLineUntil *until_Upper = slowULineData[slowULineData.count-1];
                NSString *str_Upper = @"0.000";
                if (until_Upper.value) {
                    str_Upper = [self reviseString:until_Upper.value];
                }
                [_dic_tecnnical setObject:str_Upper forKey:@"BOLL_U"];
                
                BIBLineData *MLine = [[BIBLineData alloc] init];
                MLine.data = slowMLineData;
                MLine.color = [UIColor colorWithStr:@"ff82b1ff"];
                MLine.title = @"M";
                BIBLineUntil *until_Moving = slowMLineData[slowMLineData.count-1];
                NSString *str_Moving = @"0.000";
                if (until_Moving.value) {
                    str_Moving = [self reviseString:until_Moving.value];
                }
                [_dic_tecnnical setObject:str_Moving forKey:@"BOLL_M"];
                
                BIBLineData *LLine = [[BIBLineData alloc] init];
                LLine.data = slowLLineData;
                LLine.color = [UIColor colorWithStr:@"fff06292"];
                LLine.title = @"L";
                BIBLineUntil *until_Lower = slowLLineData[slowLLineData.count-1];
                NSString *str_Lower = @"0.000";
                if (until_Lower.value) {
                    str_Lower = [self reviseString:until_Lower.value];
                }
                [_dic_tecnnical setObject:str_Lower forKey:@"BOLL_L"];
                
                NSMutableArray *bollData = [[NSMutableArray alloc] init];
                [bollData addObject:ULine];
                [bollData addObject:MLine];
                [bollData addObject:LLine];
                _view_boll.dataArray = bollData;
            }
            break;
            case MA:
            //MA数据处理
            if (self.dataSource.count > 0) {
                NSMutableArray *slowKLineData = [[NSMutableArray alloc] init];
                for (int k = 0; k<self.dataSource.count; k++) {
                    NSDictionary *dic_ma = self.dataSource[k];
                    NSString *date = dic_ma[@"DateTime"];
                    if (![NSString isBlankString:date]) {
                        date = [self solveTheDateString:date];
                        if (_kLineType == 1 || _kLineType == 2 || _kLineType == 3) {
                            date = [NSString getTheDateStringByTimeStamp:date withFormat:@"YYYY-MM-dd"];
                        }else{
                            date = [NSString getTheDateStringByTimeStamp:date withFormat:@"MM-dd HH:mm"];
                        }
                    }
                    NSString *Line = dic_ma[@"ma_Line"];
                    //指标model
                    [slowKLineData addObject:[[BIBLineUntil alloc] initWithValue:[Line doubleValue] date:date]];
                }
                //处理指标的划线
                BIBLineData *slowKLine = [[BIBLineData alloc] init];
                slowKLine.data = slowKLineData;
                slowKLine.color = [UIColor blueColor];
                slowKLine.title = @"Line";
                BIBLineUntil *until_ma_line = slowKLineData[slowKLineData.count-1];
                NSString *str_ma_line = @"";
                if (until_ma_line.value) {
                    str_ma_line = [self reviseString:until_ma_line.value];
                }
                [_dic_tecnnical setObject:str_ma_line forKey:@"MA_LINE"];
                NSMutableArray *maData = [[NSMutableArray alloc] init];
                [maData addObject:slowKLine];
                _view_ma.dataArray = maData;
            }
            break;
            case OSMA:
            //OSMA数据处理
            if (self.dataSource.count > 0) {
                NSMutableArray *osmaData = [[NSMutableArray alloc] init];
                for (int i = 0; i<self.dataSource.count; i++) {
                    NSDictionary *dic_osma = self.dataSource[i];
                    NSString *date = dic_osma[@"DateTime"];
                    if (![NSString isBlankString:date]) {
                        date = [self solveTheDateString:date];
                        if (_kLineType == 1 || _kLineType == 2 || _kLineType == 3) {
                            date = [NSString getTheDateStringByTimeStamp:date withFormat:@"YYYY-MM-dd"];
                        }else{
                            date = [NSString getTheDateStringByTimeStamp:date withFormat:@"MM-dd HH:mm"];
                        }
                    }
                    NSString *Osma = dic_osma[@"osma_Osma"];
                    NSString *signal = dic_osma[@"osma_Signal"];
                    BIBMacdModel *model = [[BIBMacdModel alloc] initWithDea:[signal doubleValue] diff:[signal doubleValue] macd:[Osma doubleValue] date:date];
                    [osmaData addObject:model];
                }
                BIBMacdModel *model_osma = osmaData[osmaData.count-1];
                NSString *str_diff = @"0.000";
                if (model_osma.macd) {
                    str_diff = [self reviseString:model_osma.macd];
                }
                [_dic_tecnnical setObject:str_diff forKey:@"OSMA_OSMA"];
                _view_osma.dataArray = osmaData;
            }
            break;
            
        default:
            break;
    }
}

/*!
 @brief 修正浮点型精度丢失
 @param floatNum 传入接口取到的数据
 @return 修正精度后的数据
 */
-(NSString *)reviseString:(CGFloat)floatNum
{
    //直接传入精度丢失有问题的Double类型
    NSString *str_float = [NSString stringWithFormat:@"%f",floatNum];
    double conversionValue = [str_float doubleValue];
    NSString *doubleString = [NSString stringWithFormat:@"%lf", conversionValue];
    NSDecimalNumber *decNumber = [NSDecimalNumber decimalNumberWithString:doubleString];
    NSString *number = [decNumber stringValue];
    
    NSArray  *array = [number componentsSeparatedByString:@"."];
    if (array.count == 2) {
        NSString *st = array[1];
        NSInteger len = st.length;
        if (len > 5) {
            return [NSString stringWithFormat:@"%.5f",conversionValue];
        }else{
            return number;
        }
    }else{
        return number;
    }
}
-(void)loadData
{
    NSMutableArray *arr_model = [NSMutableArray array];
    for (NSInteger i = 0; i < self.dataSource.count; i++) {
        BIBKLineCandleModel *candle = [[BIBKLineCandleModel alloc] init];
        NSMutableDictionary *dic = self.dataSource[i];
        candle.open = [[dic objectForKey:@"Open"] floatValue];
        candle.high = [[dic objectForKey:@"High"] floatValue];
        candle.low =  [[dic objectForKey:@"Low"] floatValue];
        candle.close = [[dic objectForKey:@"Close"] floatValue];
        if (![NSString isBlankString:[dic objectForKey:@"DateTime"]]) {
            candle.date = [dic objectForKey:@"DateTime"];
        }
        if (![NSString isBlankString:candle.date]) {
            candle.date = [self solveTheDateString:candle.date];
            if (_kLineType == 1 || _kLineType == 2 || _kLineType == 3) {
                candle.date = [NSString getTheDateStringByTimeStamp:candle.date withFormat:@"YYYY-MM-dd"];
            }else{
                candle.date = [NSString getTheDateStringByTimeStamp:candle.date withFormat:@"MM-dd HH:mm"];
            }
        }
        [arr_model addObject:candle];
    }
    if (arr_model && arr_model.count > 0) {
        [self reloadData:arr_model reload:_isScrollRightMove];
    }
}

- (void)reloadData:(NSMutableArray*)array reload:(BOOL)reload
{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        [self finishIndexChart:self.indexType];//加载指标数据
        
        for (NSInteger i = 0;i<array.count;i++)
        {
            BIBKLineCandleModel *model = array[i];
            //设置多少个点画一条竖线（时间线）根据显示的K线个数displayCount和时间线的比值
            self.view_candleChart.displayCount = self.screenCandleNumber > self.dataSource.count ? self.dataSource.count : self.screenCandleNumber;
            NSInteger num = self.view_candleChart.displayCount/4;
            num = num < 1 ? 2 : num;
            if (i % num == 0)
            {
                model.isDrawDate = YES;
            }
            else
            {
                model.isDrawDate = NO;
            }
        }
        self.view_candleChart.dataArray = array;
        dispatch_async(dispatch_get_main_queue(), ^{
            if (reload)
            {
                [self.view_candleChart reload];
            }
            else
            {
                [self.view_candleChart stockFill];
            }
        });
    });
}


- (UIView *)loadView {
    _view_bg = [[UIView alloc] init];
    return _view_bg;
}

-(void)viewDidLoad
{
    [self.view addSubview:self.scrollView_quoteChart];
    [self.scrollView_quoteChart addSubview:self.view_candleChart];
    [self.view addSubview:self.view_box_candle];
    [self.view_box_candle addSubview:self.view_price_candle];
    [self.view_box_candle addSubview:self.currentView];//实时线
    [self.view_box_candle addSubview:self.label_current];//实时报价
    [self.view addSubview:self.view_bg_indexType];
    [self.view_bg_indexType addSubview:self.view_indexType];
    [self.scrollView_quoteChart addSubview:self.view_bg_index];
    [self.view addSubview:self.view_box_index];
    [self.view_box_index addSubview:self.label_indexTitle];
    [self.view_box_index addSubview:self.view_price_index];
    [self.view_bg_index addSubview:self.view_macd];
    [self.view_bg_index addSubview:self.view_rsi];
    [self.view_bg_index addSubview:self.view_kdj];
    [self.view_bg_index addSubview:self.view_boll];
    [self.view_bg_index addSubview:self.view_ma];
    [self.view_bg_index addSubview:self.view_osma];
    
    [self setLayout];
    
    //初始化十字线和长安手势
    _longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(finishLongPressGesture:)];
    [self.view_candleChart addGestureRecognizer:_longPressGesture];
    [self initCrossLine];
}


-(void)setLayout
{
    [_scrollView_quoteChart mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_top).offset(5);
        make.left.equalTo(self.view.mas_left).offset(10);
        make.right.equalTo(self.view.mas_right).offset(-50);
        make.bottom.equalTo(self.view.mas_bottom).offset(0);
    }];
    
    //蜡烛主图
    [_view_candleChart mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.scrollView_quoteChart);
        make.left.equalTo(self.scrollView_quoteChart);
        make.right.equalTo(self.scrollView_quoteChart);
//        make.bottom.equalTo(self.view.mas_bottom).offset(-IndexChartHeight-IndexTypeHeight-20);
        make.height.equalTo(self.scrollView_quoteChart).multipliedBy(0.60);
    }];
    //蜡烛覆盖图片
    [_view_box_candle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view_candleChart.mas_top).offset(0);
        make.left.equalTo(self.view.mas_left).offset(10);
        make.right.equalTo(self.view.mas_right).offset(-10);
        make.bottom.equalTo(self.view_candleChart);
    }];
    //蜡烛覆盖图片，右则报价
    [_view_price_candle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view_box_candle.mas_top).offset(0);
        make.right.equalTo(self.view_box_candle.mas_right).offset(0);
        make.width.equalTo(@(80));
        make.bottom.equalTo(self.view_box_candle.mas_bottom).offset(0);
    }];
    
    
    [_label_current mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view_box_candle.mas_right).offset(-2);
        //make.centerX.equalTo(self.view_box_candle.mas_centerX);
        //make.width.equalTo(@(80));
    }];
    
    [_currentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view_box_candle.mas_left).offset(0);
        make.right.equalTo(self.label_current.mas_left).offset(0);
        make.height.equalTo(@(1));
    }];

    
    //指标图的高度68
    [_view_bg_index mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(_view_bg_indexType.mas_bottom).offset(0);
        make.left.right.equalTo(self.view_candleChart);
        make.height.equalTo(self.scrollView_quoteChart).multipliedBy(0.30);
        make.bottom.equalTo(self.view.mas_bottom);
    }];
    //指标类型高度为20  指标类型距离k线图的底部20
    [_view_bg_indexType mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view_box_candle.mas_bottom).offset(20);
        make.bottom.equalTo(self.view_bg_index.mas_top).offset(0);
        make.left.equalTo(self.view).offset(10);
        make.right.equalTo(self.view).offset(-10);
        //        make.left.right.equalTo(_view_box_candle);//必须是_view_box_candle不能是_view_candle
//        make.height.equalTo(self.scrollView_quoteChart).multipliedBy(0.10);
    }];
    [_view_indexType mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view_bg_indexType.mas_top).offset(0);
        make.left.equalTo(self.view_bg_indexType);
        make.right.equalTo(self.view_bg_indexType);
        make.bottom.equalTo(self.view_bg_indexType);
//        make.height.equalTo(@(28));
    }];
    [_view_bg_index layoutIfNeeded];
    [_view_box_index mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view_bg_index.mas_top).offset(0);
        make.left.equalTo(self.view.mas_left).offset(10);
        make.right.equalTo(self.view.mas_right).offset(-10);
        make.bottom.equalTo(self.view_bg_index.mas_bottom).offset(0);
    }];
    [_label_indexTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view_bg_index.mas_top).offset(4);
        make.left.equalTo(self.view.mas_left).offset(15);
        make.right.equalTo(self.view.mas_right).offset(-10);
        make.height.equalTo(@(12));
    }];
    [_view_price_index mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view_box_index.mas_top).offset(0);
        make.bottom.equalTo(self.view_box_index.mas_bottom).offset(0);
        make.right.equalTo(self.view_box_index.mas_right).offset(0);
        make.width.equalTo(@(80));
    }];

    [_view_macd mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view_bg_index.mas_top).offset(16);
        make.bottom.equalTo(self.view_bg_index.mas_bottom).offset(-4);
        make.left.right.equalTo(self.view_bg_index);
    }];
    [_view_rsi mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view_bg_index.mas_top).offset(16);
        make.bottom.equalTo(self.view_bg_index.mas_bottom).offset(-4);
        make.left.right.equalTo(self.view_bg_index);
    }];
    [_view_kdj mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view_bg_index.mas_top).offset(16);
        make.bottom.equalTo(self.view_bg_index.mas_bottom).offset(-4);
        make.left.right.equalTo(self.view_bg_index);
    }];
    [_view_boll mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view_bg_index.mas_top).offset(16);
        make.bottom.equalTo(self.view_bg_index.mas_bottom).offset(-4);
        make.left.right.equalTo(self.view_bg_index);
    }];
    [_view_ma mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view_bg_index.mas_top).offset(16);
        make.bottom.equalTo(self.view_bg_index.mas_bottom).offset(-4);
        make.left.right.equalTo(self.view_bg_index);
    }];
    [_view_osma mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view_bg_index.mas_top).offset(16);
        make.bottom.equalTo(self.view_bg_index.mas_bottom).offset(-4);
        make.left.right.equalTo(self.view_bg_index);
    }];
}

#pragma mark 长按十字线方法的实现  Method
-(void)initCrossLine
{
    //十字竖线
    self.verticalView = [UIView new];
    self.verticalView.clipsToBounds = YES;
    [self.scrollView_quoteChart addSubview:self.verticalView];
    self.verticalView.backgroundColor = [UIColor grayColor];
    [self.verticalView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view_box_candle);
        make.width.equalTo(@(self.view_candleChart.lineWidth));
        make.bottom.equalTo(self.view_macd);
        make.left.equalTo(@(0));
    }];
    //十字横线
    self.leavView = [UIView new];
    self.leavView.clipsToBounds = YES;
    [self.scrollView_quoteChart addSubview:self.leavView];
    self.leavView.backgroundColor = [UIColor grayColor];
    [self.leavView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@(0));
        make.left.equalTo(self.view);
        make.right.equalTo(self.view_candleChart);
        make.height.equalTo(@(self.view_candleChart.lineWidth));
    }];
    //十字线顶部的日期
    self.label_cross = [[UILabel alloc] init];
    self.label_cross.textAlignment = NSTextAlignmentCenter;
    self.label_cross.font = [UIFont systemFontOfSize:8.0];
    self.label_cross.layer.borderColor = [UIColor grayColor].CGColor;
    self.label_cross.layer.borderWidth = 1;
    self.label_cross.backgroundColor = [UIColor whiteColor];
    [self.scrollView_quoteChart addSubview:self.label_cross];
    [self.label_cross mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view_box_candle);
        make.left.equalTo(self.verticalView.mas_left).offset(-27);
        make.width.equalTo(@(54));
        make.height.equalTo(@(12));
    }];
    
    self.leavView.hidden = YES;
    self.verticalView.hidden = YES;
    self.label_cross.hidden = YES;
}
-(void)finishLongPressGesture:(UILongPressGestureRecognizer*)longPress
{
    static CGFloat oldPositionX = 0;
    if(UIGestureRecognizerStateChanged == longPress.state || UIGestureRecognizerStateBegan == longPress.state)
    {
        CGPoint location = [longPress locationInView:self.view_candleChart];
        if(ABS(oldPositionX - location.x) < (self.view_candleChart.candleWidth + self.view_candleChart.candleSpace)/2)
        {
            return;
        }
        self.scrollView_quoteChart.scrollEnabled = NO;
        oldPositionX = location.x;
        CGPoint point = [self.view_candleChart getLongPressModelPostionWithXPostion:location.x];
        CGFloat xPositoin = point.x + (self.view_candleChart.candleWidth)/2.f - self.view_candleChart.candleSpace/2.f ;
        CGFloat yPositoin = point.y +self.view_candleChart.topMargin;
        [self.verticalView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@(xPositoin+0.5));
        }];
        //修改十字线的日期的位置
        if (0 <= self.kLineNumber && self.kLineNumber < 3) {//0  1  2
            [self.label_cross mas_updateConstraints:^(MASConstraintMaker *make) {
                make.left.equalTo(self.verticalView.mas_left).offset(0);
            }];
        }else if(self.kLineNumber <self.screenCandleNumber && self.kLineNumber >self.screenCandleNumber-4){
            [self.label_cross mas_updateConstraints:^(MASConstraintMaker *make) {
                make.left.equalTo(self.verticalView.mas_left).offset(-54);
            }];
        }else{
            [self.label_cross mas_updateConstraints:^(MASConstraintMaker *make) {
                make.left.equalTo(self.verticalView.mas_left).offset(-27);
            }];
        }
//        [_quotaView layoutIfNeeded];
        [self.leavView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(yPositoin);
        }];
        self.verticalView.hidden = NO;
        self.leavView.hidden = NO;
        self.label_cross.hidden = NO;
    }
    
    if(longPress.state == UIGestureRecognizerStateEnded)
    {
        if(self.verticalView)
        {
            self.verticalView.hidden = YES;
        }
        if(self.leavView)
        {
            self.leavView.hidden = YES;
        }
        if(self.label_cross)
        {
            self.label_cross.hidden = YES;
        }
        oldPositionX = 0;
        self.scrollView_quoteChart.scrollEnabled = YES;
    }
}

-(void)showQuoteLine
{
    if (self.currentQuote>10) {
        self.label_current.text = [NSString stringWithFormat:@"%.02f",self.currentQuote];
    }else{
        self.label_current.text = [NSString stringWithFormat:@"%.04f",self.currentQuote];
    }
    if (self.view_candleChart.maxY <= 0 || self.view_candleChart.minY<=0 || self.view_candleChart.minY >= self.view_candleChart.maxY) {
        return;
    }
    
    float scaleY = (self.view_candleChart.maxY - self.currentQuote)/(self.view_candleChart.maxY-self.view_candleChart.minY);
    if (scaleY<=0) {
        scaleY = 0;
    }else if(scaleY>=1){
        scaleY = 1;
    }
     CGFloat yPositoin = CGRectGetHeight(self.view_box_candle.bounds)*scaleY;
    dispatch_async(dispatch_get_main_queue(), ^{
        self.currentView.centerY = yPositoin;
        self.label_current.centerY = yPositoin;
    });
}
#pragma mark IGoldCandleChartViewProtocol  蜡烛图的代理  Method

- (void)displayLastModel:(BIBKLineCandleModel *)kLineModel
{
    //取当前屏幕最后一根k线model  数据显示在顶部view
    //    _view_top.model = kLineModel;
}
- (void)longPressCandleViewWithIndex:(NSInteger)kLineModeIndex kLineModel:(BIBKLineCandleModel *)kLineModel
{
    self.kLineNumber = kLineModeIndex;
    //长按手势 取长按的那根k线model  数据显示在顶部view
    if (self.label_cross) {
        self.label_cross.text = kLineModel.date;
    }
}
- (void)displayScreenleftPostion:(CGFloat)leftPostion startIndex:(NSInteger)index count:(NSInteger)count
{
    [self showIndexLineView:leftPostion startIndex:index count:count];
}
- (void)showIndexLineView:(CGFloat)leftPostion startIndex:(NSInteger)index count:(NSInteger)count
{
    //k线图右侧的price数据
    CGFloat max_y = self.view_candleChart.maxY;
    CGFloat min_y = self.view_candleChart.minY;
    _view_price_candle.maxPriceLabel.text = [NSString stringWithFormat:@"%.4f",max_y];
    _view_price_candle.smallMaxPriceLabel.text = [NSString stringWithFormat:@"%.4f",(max_y-min_y)*3/4+min_y];
    _view_price_candle.middlePriceLabel.text = [NSString stringWithFormat:@"%.4f",(max_y - min_y)/2 + min_y];
    _view_price_candle.bigMinPriceLabel.text = [NSString stringWithFormat:@"%.4f",(max_y - min_y)/4 + min_y];
    _view_price_candle.minPriceLabel.text = [NSString stringWithFormat:@"%.4f",min_y];
    if (max_y>10) {
        _view_price_candle.maxPriceLabel.text = [NSString stringWithFormat:@"%.2f",max_y];
        _view_price_candle.smallMaxPriceLabel.text = [NSString stringWithFormat:@"%.2f",(max_y-min_y)*3/4+min_y];
        _view_price_candle.middlePriceLabel.text = [NSString stringWithFormat:@"%.2f",(max_y - min_y)/2 + min_y];
        _view_price_candle.bigMinPriceLabel.text = [NSString stringWithFormat:@"%.2f",(max_y - min_y)/4 + min_y];
        _view_price_candle.minPriceLabel.text = [NSString stringWithFormat:@"%.2f",min_y];
    }
    
    [self updateTecnnicalValue];//显示指标的参数数据
    [self showQuoteLine]; //显示实时线的位置
    
    _view_price_index.maxPriceLabel.text = @"";
    _view_price_index.middlePriceLabel.text = @"";
    _view_price_index.minPriceLabel.text = @"";
    //指标右侧的price数据
    if (_indexType == MACD){
        [_view_macd setHidden:NO];
        [_view_rsi setHidden:YES];
        [_view_kdj setHidden:YES];
        [_view_boll setHidden:YES];
        [_view_ma setHidden:YES];
        [_view_osma setHidden:YES];
        
        _view_macd.candleSpace = _view_candleChart.candleSpace;
        _view_macd.candleWidth = _view_candleChart.candleWidth;
        _view_macd.leftPostion = leftPostion;
        _view_macd.startIndex = index;
        _view_macd.displayCount = count;
        [_view_macd stockFill];
        if (self.view_macd.maxY<10) {
            _view_price_index.maxPriceLabel.text = [NSString stringWithFormat:@"%.4f",self.view_macd.maxY];
        }else{
            _view_price_index.maxPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_macd.maxY];
        }
//        _view_price_index.middlePriceLabel.text = [NSString stringWithFormat:@"%.2f",(self.view_macd.maxY - self.view_macd.minY)/2 + self.view_macd.minY];
        if (self.view_macd.minY< -10) {
            _view_price_index.minPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_macd.minY];
        }else{
            _view_price_index.minPriceLabel.text = [NSString stringWithFormat:@"%.4f",self.view_macd.minY];
        }
    }
    else  if (_indexType == RSI)
    {
        [_view_macd setHidden:YES];
        [_view_rsi setHidden:NO];
        [_view_kdj setHidden:YES];
        [_view_boll setHidden:YES];
        [_view_ma setHidden:YES];
        [_view_osma setHidden:YES];
        _view_rsi.candleSpace = _view_candleChart.candleSpace;
        _view_rsi.candleWidth = _view_candleChart.candleWidth;
        _view_rsi.leftPostion = leftPostion;
        _view_rsi.startIndex = index;
        _view_rsi.displayCount = count;
        [_view_rsi stockFill];
        if (self.view_rsi.maxY<10) {
            _view_price_index.maxPriceLabel.text = [NSString stringWithFormat:@"%.4f",self.view_rsi.maxY];
        }else{
            _view_price_index.maxPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_rsi.maxY];
        }
//        _view_price_index.middlePriceLabel.text = [NSString stringWithFormat:@"%.2f",(self.view_rsi.maxY - self.view_rsi.minY)/2 + self.view_rsi.minY];
        if (self.view_rsi.minY< -10) {
            _view_price_index.minPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_rsi.minY];
        }else{
            _view_price_index.minPriceLabel.text = [NSString stringWithFormat:@"%.4f",self.view_rsi.minY];
        }
    }
    else if(_indexType == KDJ)
    {
        [_view_macd setHidden:YES];
        [_view_rsi setHidden:YES];
        [_view_kdj setHidden:NO];
        [_view_boll setHidden:YES];
        [_view_ma setHidden:YES];
        [_view_osma setHidden:YES];
        _view_kdj.candleSpace = _view_candleChart.candleSpace;
        _view_kdj.candleWidth = _view_candleChart.candleWidth;
        _view_kdj.leftPostion = leftPostion;
        _view_kdj.startIndex = index;
        _view_kdj.displayCount = count;
        [_view_kdj stockFill];
        if (self.view_kdj.maxY<10) {
            _view_price_index.maxPriceLabel.text = [NSString stringWithFormat:@"%.4f",self.view_kdj.maxY];
        }else{
            _view_price_index.maxPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_kdj.maxY];
        }
//        _view_price_index.middlePriceLabel.text = [NSString stringWithFormat:@"%.2f",(self.view_kdj.maxY - self.view_kdj.minY)/2 + self.view_kdj.minY];
        if (self.view_kdj.minY< -10) {
            _view_price_index.minPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_kdj.minY];
        }else{
            _view_price_index.minPriceLabel.text = [NSString stringWithFormat:@"%.4f",self.view_kdj.minY];
        }
    }
    else if(_indexType == BOLL)
    {
        [_view_macd setHidden:YES];
        [_view_rsi setHidden:YES];
        [_view_kdj setHidden:YES];
        [_view_boll setHidden:NO];
        [_view_ma setHidden:YES];
        [_view_osma setHidden:YES];
        _view_boll.candleSpace = _view_candleChart.candleSpace;
        _view_boll.candleWidth = _view_candleChart.candleWidth;
        _view_boll.leftPostion = leftPostion;
        _view_boll.startIndex = index;
        _view_boll.displayCount = count;
        [_view_boll stockFill];
        if (self.view_boll.maxY<10) {
            _view_price_index.maxPriceLabel.text = [NSString stringWithFormat:@"%.4f",self.view_boll.maxY];
        }else{
            _view_price_index.maxPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_boll.maxY];
        }
//        _view_price_index.middlePriceLabel.text = [NSString stringWithFormat:@"%.2f",(self.view_boll.maxY - self.view_boll.minY)/2 + self.view_boll.minY];
        if (self.view_boll.minY< -10) {
            _view_price_index.minPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_boll.minY];
        }else{
            _view_price_index.minPriceLabel.text = [NSString stringWithFormat:@"%.4f",self.view_boll.minY];
        }
    }
    else if(_indexType == MA)
    {
        [_view_macd setHidden:YES];
        [_view_rsi setHidden:YES];
        [_view_kdj setHidden:YES];
        [_view_boll setHidden:YES];
        [_view_ma setHidden:NO];
        [_view_osma setHidden:YES];
        _view_ma.candleSpace = _view_candleChart.candleSpace;
        _view_ma.candleWidth = _view_candleChart.candleWidth;
        _view_ma.leftPostion = leftPostion;
        _view_ma.startIndex = index;
        _view_ma.displayCount = count;
        [_view_ma stockFill];
        if (self.view_ma.maxY<10) {
            _view_price_index.maxPriceLabel.text = [NSString stringWithFormat:@"%.4f",self.view_ma.maxY];
        }else{
            _view_price_index.maxPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_ma.maxY];
        }
//        _view_price_index.middlePriceLabel.text = [NSString stringWithFormat:@"%.2f",(self.view_ma.maxY - self.view_ma.minY)/2 + self.view_ma.minY];
        if (self.view_ma.minY< -10) {
            _view_price_index.minPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_ma.minY];
        }else{
            _view_price_index.minPriceLabel.text = [NSString stringWithFormat:@"%.4f",self.view_ma.minY];
        }
    }
    else if(_indexType == OSMA)
    {
        [_view_macd setHidden:YES];
        [_view_rsi setHidden:YES];
        [_view_kdj setHidden:YES];
        [_view_boll setHidden:YES];
        [_view_ma setHidden:YES];
        [_view_osma setHidden:NO];
        _view_osma.candleSpace = _view_candleChart.candleSpace;
        _view_osma.candleWidth = _view_candleChart.candleWidth;
        _view_osma.leftPostion = leftPostion;
        _view_osma.startIndex = index;
        _view_osma.displayCount = count;
        [_view_osma stockFill];
        if (self.view_osma.maxY<10) {
            _view_price_index.maxPriceLabel.text = [NSString stringWithFormat:@"%.4f",self.view_osma.maxY];
        }else{
            _view_price_index.maxPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_osma.maxY];
        }
        //        _view_price_index.middlePriceLabel.text = [NSString stringWithFormat:@"%.2f",(self.view_osma.maxY - self.view_macd.minY)/2 + self.view_macd.minY];
        if (self.view_osma.minY< -10) {
            _view_price_index.minPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_osma.minY];
        }else{
            _view_price_index.minPriceLabel.text = [NSString stringWithFormat:@"%.4f",self.view_osma.minY];
        }
    }
}

//k线图右滑加载更多数据
-(void)displayMoreData:(BOOL)isRightMove
{
    _isScrollRightMove = isRightMove;
    [self.weexInstance fireGlobalEvent:@"ScrollKlineChart" params:@{@"isRight":[NSNumber numberWithBool:isRightMove]}];
}
#pragma mark --   IGoldTecnnicalTypeViewDelegate 切换指标图的代理 Method   ------
- (void)didSelectButton:(UIButton*)button index:(NSInteger)index
{
    if (index == 1)
    {
        _indexType = MACD;
    }
    else if (index == 2)
    {
        _indexType = RSI;
    }
    else if (index == 3)
    {
        _indexType = KDJ;
    }
    else if (index == 4)
    {
        _indexType = BOLL;
    }
    else if (index == 5)
    {
        _indexType = MA;
    }
    else if (index == 6)
    {
        _indexType = OSMA;
    }
    [self finishIndexChart:_indexType];//加载指标数据
    [self showIndexLineView:self.view_candleChart.leftPostion startIndex:self.view_candleChart.currentStartIndex count:self.view_candleChart.displayCount];
    [self fireEvent:@"indexChange" params:@{@"index":@(index-1)}];
}
//设置指标的最后一个数据
-(void)updateTecnnicalValue
{
    NSString *str_MACD_DIFF = [_dic_tecnnical objectForKey:@"MACD_DIFF"] == nil ? @"0.0" : [_dic_tecnnical objectForKey:@"MACD_DIFF"];
    NSString *str_MACD_MACD = [_dic_tecnnical objectForKey:@"MACD_MACD"] == nil ? @"0.0" : [_dic_tecnnical objectForKey:@"MACD_MACD"];
    NSString *str_macd = [NSString stringWithFormat:@"%@%@%@%@",@"MACD(12,26,9)  ",str_MACD_DIFF,@"  ",str_MACD_MACD];
    
    NSString *str_RSI_14 = [_dic_tecnnical objectForKey:@"RSI_14"] == nil ? @"0.0" : [_dic_tecnnical objectForKey:@"RSI_14"];
    NSString *str_rsi = [NSString stringWithFormat:@"%@%@",@"RSI(14)  ",str_RSI_14];
    
    NSString *str_KDJ_K = [_dic_tecnnical objectForKey:@"KDJ_K"] == nil ? @"0.0" : [_dic_tecnnical objectForKey:@"KDJ_K"];
    NSString *str_KDJ_D = [_dic_tecnnical objectForKey:@"KDJ_D"] == nil ? @"0.0" : [_dic_tecnnical objectForKey:@"KDJ_D"];
    NSString *str_kdj = [NSString stringWithFormat:@"%@%@%@%@",@"Stoch(5,3,3)  ",str_KDJ_K,@"  ",str_KDJ_D];
    
    NSString *str_BOLL_U = [_dic_tecnnical objectForKey:@"BOLL_U"] == nil ? @"0.0" : [_dic_tecnnical objectForKey:@"BOLL_U"];
    NSString *str_BOLL_M = [_dic_tecnnical objectForKey:@"BOLL_M"] == nil ? @"0.0" : [_dic_tecnnical objectForKey:@"BOLL_M"];
    NSString *str_BOLL_L = [_dic_tecnnical objectForKey:@"BOLL_L"] == nil ? @"0.0" : [_dic_tecnnical objectForKey:@"BOLL_L"];
    NSString *str_boll = [NSString stringWithFormat:@"%@%@%@%@%@%@",@"Bands(20,0,2)  ",str_BOLL_U,@"  ",str_BOLL_M,@"  ",str_BOLL_L];
    
    NSString *str_MA_14 = [_dic_tecnnical objectForKey:@"MA_LINE"] == nil ? @"0.0" : [_dic_tecnnical objectForKey:@"MA_LINE"];
    NSString *str_ma = [NSString stringWithFormat:@"%@%@",@"MA(13)  ",str_MA_14];
    
    NSString *str_OSMA_OSMA = [_dic_tecnnical objectForKey:@"OSMA_OSMA"] == nil ? @"0.0" : [_dic_tecnnical objectForKey:@"OSMA_OSMA"];
    NSString *str_osma = [NSString stringWithFormat:@"%@%@",@"OSMA(12,26,9)  ",str_OSMA_OSMA];
    
    switch (_indexType) {
        case MACD:
            _label_indexTitle.text = str_macd;
            break;
        case RSI:
            _label_indexTitle.text = str_rsi;
            break;
        case KDJ:
            _label_indexTitle.text = str_kdj;
            break;
        case BOLL:
            _label_indexTitle.text = str_boll;
            break;
        case MA:
            _label_indexTitle.text = str_ma;
            break;
        case OSMA:
            _label_indexTitle.text = str_osma;
            break;
            
        default:
            break;
    }
}

#pragma mark Private Methods
-(UIScrollView *)scrollView_quoteChart
{
    if (!_scrollView_quoteChart) {
        _scrollView_quoteChart = [UIScrollView new];
        _scrollView_quoteChart.scrollEnabled = YES;
        _scrollView_quoteChart.bounces = YES;
        _scrollView_quoteChart.alwaysBounceHorizontal = YES;
        _scrollView_quoteChart.showsHorizontalScrollIndicator = NO;
        _scrollView_quoteChart.backgroundColor = [UIColor whiteColor];
    }
    return _scrollView_quoteChart;
}
-(BIBKLineCandleView *)view_candleChart
{
    if (!_view_candleChart) {
        _view_candleChart = [BIBKLineCandleView new];
        _view_candleChart.delegate = self;
        _view_candleChart.candleSpace = 2;//蜡烛图的间距
        _view_candleChart.displayCount = self.screenCandleNumber;//蜡烛图的个数
        _view_candleChart.lineWidth = 0.5*SizeScaleW;//蜡烛图中线的宽
        _view_candleChart.leftMargin = 2;
        _view_candleChart.rightMargin = 2;
        _view_candleChart.topMargin = 17;
        _view_candleChart.bottomMargin = 17;
        _view_candleChart.minHeight = 0.5;
        _view_candleChart.timeLayerHeight = TimeLayerHeight;
        _view_candleChart.riseColor = self.riseColor;
        _view_candleChart.dropColor = self.dropColor;
    }
    return _view_candleChart;
}
-(UIView *)view_box_candle
{
    if (!_view_box_candle) {
        _view_box_candle = [UIView new];
        _view_box_candle.userInteractionEnabled = NO;
        _view_box_candle.layer.borderWidth = 0.5*SizeScaleW;
        _view_box_candle.layer.borderColor = [UIColor colorWithStr:@"e5e5e5"].CGColor;
    }
    return _view_box_candle;
}
-(BIBChartPriceView *)view_price_candle
{
    if (!_view_price_candle) {
        _view_price_candle = [BIBChartPriceView new];
        _view_price_candle.textColor = [UIColor colorWithStr:@"9ba1ab"];
        _view_price_candle.textFont = [UIFont systemFontOfSize:12.0];
    }
    return _view_price_candle;
}
-(UIView *)currentView{
    if (!_currentView) {
        _currentView = [[UIView alloc] init];
        _currentView.backgroundColor = [UIColor colorWithStr:@"518deb"];
    }
    return _currentView;
}
-(UILabel *)label_current{
    if (!_label_current) {
        _label_current = [[UILabel alloc] init];
        _label_current.textAlignment = NSTextAlignmentRight;
        _label_current.textColor = [UIColor colorWithStr:self.currentColor];
        _label_current.font = [UIFont boldSystemFontOfSize:12.0];
        _label_current.text = @"";
        _label_current.backgroundColor = [UIColor clearColor];
    }
    return _label_current;
}

-(UIView *)view_bg_indexType
{
    if (!_view_bg_indexType) {
        _view_bg_indexType = [UIView new];
        _view_bg_indexType.backgroundColor = [UIColor whiteColor];
    }
    return _view_bg_indexType;
}
-(BIBIndexTypeView *)view_indexType
{
    if (!_view_indexType) {
        _view_indexType = [BIBIndexTypeView new];
        _view_indexType.array_data = [NSMutableArray arrayWithObjects:@"MACD",@"RSI",@"KDJ",@"BOLL",@"MA",@"OSMA", nil];
        _view_indexType.delagate = self;
    }
    return _view_indexType;
}
-(UIView *)view_bg_index
{
    if (!_view_bg_index) {
        _view_bg_index = [UIView new];
    }
    return _view_bg_index;
}
-(UIView *)view_box_index
{
    if (!_view_box_index) {
        _view_box_index = [UIView new];
        _view_box_index.userInteractionEnabled = NO;
        _view_box_index.layer.borderWidth = 0.5*SizeScaleW;
        _view_box_index.layer.borderColor = [UIColor colorWithStr:@"e5e5e5"].CGColor;
    }
    return _view_box_index;
}
-(UILabel *)label_indexTitle
{
    if (!_label_indexTitle) {
        _label_indexTitle = [[UILabel alloc] initWithFrame:CGRectZero];
        _label_indexTitle.textAlignment = NSTextAlignmentLeft;
        _label_indexTitle.textColor = [UIColor colorWithStr:@"61656b"];
        _label_indexTitle.font = [UIFont systemFontOfSize:10.0];//20px
        //        _label_tecnnicalTitle.numberOfLines = 0;
        _label_indexTitle.text = [NSString stringWithFormat:@"MACD(12,26,9)"];
        _label_indexTitle.backgroundColor = [UIColor clearColor];
    }
    return _label_indexTitle;
}
-(BIBChartPriceView *)view_price_index
{
    if (!_view_price_index) {
        _view_price_index = [BIBChartPriceView new];
        _view_price_index.textColor = [UIColor colorWithStr:@"61656b"];
        _view_price_index.textFont = [UIFont systemFontOfSize:12.0];
    }
    return _view_price_index;
}
-(BIBMACDLineView *)view_macd
{
    if (!_view_macd) {
        _view_macd = [BIBMACDLineView new];
        _view_macd.lineWidth = 0.5*SizeScaleW;
    }
    return _view_macd;
}
-(BIBRSILineView *)view_rsi
{
    if (!_view_rsi) {
        _view_rsi = [BIBRSILineView new];
        _view_rsi.lineWidth = 0.5*SizeScaleW;
        _view_rsi.hidden = YES;
    }
    return _view_rsi;
}
-(BIBKDJLineView *)view_kdj
{
    if (!_view_kdj) {
        _view_kdj = [BIBKDJLineView new];
        _view_kdj.lineWidth = 0.5*SizeScaleW;
        _view_kdj.hidden = YES;
    }
    return _view_kdj;
}
-(BIBBOLLLineView *)view_boll
{
    if (!_view_boll) {
        _view_boll = [BIBBOLLLineView new];
        _view_boll.lineWidth = 0.5*SizeScaleW;
        _view_boll.hidden = YES;
    }
    return _view_boll;
}
-(BIBMALineView *)view_ma
{
    if (!_view_ma) {
        _view_ma = [BIBMALineView new];
        _view_ma.lineWidth = 0.5*SizeScaleW;
        _view_ma.hidden = YES;
    }
    return _view_ma;
}
-(BIBOSMALineView *)view_osma
{
    if (!_view_osma) {
        _view_osma = [BIBOSMALineView new];
        _view_osma.lineWidth = 0.5*SizeScaleW;
        _view_osma.hidden = YES;
    }
    return _view_osma;
}
-(NSMutableArray *)dataSource
{
    if (!_dataSource) {
        _dataSource = [[NSMutableArray alloc] init];
    }
    return _dataSource;
}
-(NSMutableArray *)macdSource
{
    if (!_macdSource) {
        _macdSource = [[NSMutableArray alloc] init];
    }
    return _macdSource;
}
-(NSMutableArray *)rsiSource
{
    if (!_rsiSource) {
        _rsiSource = [[NSMutableArray alloc] init];
    }
    return _rsiSource;
}
-(NSMutableArray *)kdjSource
{
    if (!_kdjSource) {
        _kdjSource = [[NSMutableArray alloc] init];
    }
    return _kdjSource;
}
-(NSMutableArray *)bollSource
{
    if (!_bollSource) {
        _bollSource = [[NSMutableArray alloc] init];
    }
    return _bollSource;
}
-(NSMutableArray *)maSource
{
    if (!_maSource) {
        _maSource = [[NSMutableArray alloc] init];
    }
    return _maSource;
}
-(NSMutableArray *)osmaSource
{
    if (!_osmaSource) {
        _osmaSource = [[NSMutableArray alloc] init];
    }
    return _osmaSource;
}
-(NSMutableDictionary *)dic_tecnnical
{
    if (!_dic_tecnnical) {
        _dic_tecnnical = [[NSMutableDictionary alloc] init];
    }
    return _dic_tecnnical;
}

@end
