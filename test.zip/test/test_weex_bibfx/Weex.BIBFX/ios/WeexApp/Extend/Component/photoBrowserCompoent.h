//
//  photoBrowserCompoent.h
//  Acetop
//
//  Created by blts on 2019/7/23.
//  Copyright © 2019 Acetop. All rights reserved.
//

#import <WeexSDK/WeexSDK.h>
#import <UIKit/UIKit.h>
#import <WeexSDK/WXComponent.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface photoBrowserCompoent : WXAComponent

@end

NS_ASSUME_NONNULL_END
