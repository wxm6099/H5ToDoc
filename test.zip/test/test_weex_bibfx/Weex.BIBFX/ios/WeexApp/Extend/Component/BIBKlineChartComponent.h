//
//  BIBKlineChartComponent.h
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WeexSDK/WeexSDK.h>
#import <WeexSDK/WXComponent.h>
#import <Foundation/Foundation.h>

@interface BIBKlineChartComponent : WXComponent

@end
