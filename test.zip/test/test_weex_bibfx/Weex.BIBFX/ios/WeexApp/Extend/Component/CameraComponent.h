//
//  CameraComponent.h
//  BibGold
//
//  Created by Richard on 2019/1/3.
//  Copyright © 2019年 Fantasy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WeexSDK.h>
NS_ASSUME_NONNULL_BEGIN

@interface CameraComponent : WXComponent<UIAlertViewDelegate>
- (void)startCamera;
- (void)stopCamera;
- (BOOL)isOpenFlash;
@end

NS_ASSUME_NONNULL_END
