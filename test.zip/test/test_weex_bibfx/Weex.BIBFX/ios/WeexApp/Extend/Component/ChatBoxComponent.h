//
//  ChatBoxComponent.h
//  Acetop
//
//  Created by Richard on 2019/3/4.
//  Copyright © 2019年 Acetop. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "WXComponent.h"
#import "UITextView+Placeholder.h"
#import "UIView+Extension.h"
#import "ICChatServerDefs.h"
#import "UIColor+IGColor.h"
#import "EmojiTextAttachment.h"

NS_ASSUME_NONNULL_BEGIN

@interface ChatBoxComponent : WXComponent
@property (nonatomic, strong) NSString *placeholderString;
@property (nonatomic, strong) UIColor *placeholderColor;

@property (nonatomic, assign) BOOL disabled;
@property (nonatomic, assign) BOOL keyboardShow;

@property (nonatomic, assign) CGFloat marginTop;
@property (nonatomic, assign) CGFloat marginBottom;
@property (nonatomic, assign) CGFloat maxLineNum;
@property (nonatomic, strong) UIColor *textColor;
@property (nonatomic, strong) UIColor *atTextColor;
@end

NS_ASSUME_NONNULL_END
