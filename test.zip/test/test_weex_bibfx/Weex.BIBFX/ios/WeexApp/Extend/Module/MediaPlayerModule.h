//
//  MediaPlayerModule.h
//  BibGold
//
//  Created by Richard on 2018/9/17.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WXModuleProtocol.h"
#import <NodeMediaClient/NodeMediaClient.h>
#import "WMPlayer.h"

@interface MediaPlayerModule : NSObject<WXModuleProtocol,WMPlayerDelegate>

//-(void)wmplayer:(WMPlayer *)wmplayer clickedCloseButton:(UIButton *)closeBtn;
////点击全屏按钮代理方法
//-(void)wmplayer:(WMPlayer *)wmplayer clickedFullScreenButton:(UIButton *)fullScreenBtn;
@end
