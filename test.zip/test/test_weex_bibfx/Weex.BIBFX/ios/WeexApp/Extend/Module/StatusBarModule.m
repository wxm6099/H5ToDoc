//
//  StatusBarModule.m
//  WeexApp
//
//  Created by Richard on 2018/3/27.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "StatusBarModule.h"

@implementation StatusBarModule
@synthesize weexInstance;

WX_EXPORT_METHOD(@selector(setStatusBarStyle:))
WX_EXPORT_METHOD(@selector(showStatusBar:))//隐藏/显示状态栏
//WX_EXPORT_METHOD_SYNC(@selector(setStatusBarStyle:))

-(void)callService:(NSString*)tel
{
    if (tel && tel.length>1) {
        NSString*str=[[NSString alloc] initWithFormat:@"tel://%@",[tel stringByReplacingOccurrencesOfString:@" " withString:@""]];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
    }
}

-(void)setStatusBarStyle:(int)statusBarStyle
{
    if (statusBarStyle <= 3) {
        [[UIApplication sharedApplication] setStatusBarStyle:statusBarStyle];
    }
    else{
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}

- (void)showStatusBar:(BOOL)show
{
    if (show) {
        [[UIApplication sharedApplication] setStatusBarHidden:false];
    }else{
        [[UIApplication sharedApplication] setStatusBarHidden:true];
    }
    
}
@end
