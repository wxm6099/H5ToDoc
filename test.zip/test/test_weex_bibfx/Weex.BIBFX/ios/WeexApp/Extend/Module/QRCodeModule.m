//
//  QRCodeModule.m
//  BibGold
//
//  Created by Richard on 2019/3/25.
//  Copyright © 2019年 Fantasy. All rights reserved.
//

#import "QRCodeModule.h"
#import "ScannerVC.h"

@interface QRCodeModule ()
{
    ScannerVC* scanner;
}
@property (nonatomic,copy) WXModuleCallback scanResultCallback;//扫描结果回调
@property (nonatomic,copy) WXModuleCallback generateCallback;//生成结果回调
@end

@implementation QRCodeModule
@synthesize weexInstance;

WX_EXPORT_METHOD(@selector(start:))
- (void)start:(WXModuleCallback)callback
{
    _scanResultCallback =callback;
    if (nil == scanner) {
        scanner = [[ScannerVC alloc]init];
    }
    scanner.delegate = self;
    UINavigationController * nVC = [[UINavigationController alloc]initWithRootViewController:scanner];
    [self.weexInstance.viewController presentViewController:nVC animated:YES completion:^{}];
}

- (void)stop
{
}


- (void)readerScanResult:(NSString *)result
{
    [scanner dismissViewControllerAnimated:NO completion:^{
        self->_scanResultCallback(@{@"result":@"success",@"data":result});
    }];
}

- (void)accordingQcode:(NSString *)str
{
    UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"扫描结果" message:str delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertView show];
}
@end
