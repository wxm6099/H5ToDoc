//
//  CookieStorageModule.m
//  BibGold
//
//  Created by Richard on 2018/5/9.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "CookieStorageModule.h"
#import <WebKit/WebKit.h>

@implementation CookieStorageModule
@synthesize weexInstance;

WX_EXPORT_METHOD(@selector(setCookie:))
WX_EXPORT_METHOD_SYNC(@selector(getCookie:))
WX_EXPORT_METHOD(@selector(deleteCookie:))

WX_EXPORT_METHOD(@selector(loadCookie:))
WX_EXPORT_METHOD(@selector(saveCookie:domain:))
//WX_EXPORT_METHOD_SYNC(@selector(resetCookie:))

//写入cookie
- (void)setCookie:(NSDictionary *)cookie{
    NSMutableDictionary *cookieProperties = [NSMutableDictionary dictionary];
    if(cookie[@"name"]){
        [cookieProperties setObject:cookie[@"name"] forKey:NSHTTPCookieName];
    }
    if(cookie[@"value"]){
        [cookieProperties setObject:cookie[@"value"] forKey:NSHTTPCookieValue];
    }
    if(cookie[@"domain"]){
        [cookieProperties setObject:cookie[@"domain"] forKey:NSHTTPCookieDomain];
    }
    if(cookie[@"path"]){
        [cookieProperties setObject:cookie[@"path"] forKey:NSHTTPCookiePath];
    }
    if (cookieProperties.count>0) {
        NSHTTPCookie *cookieuser = [NSHTTPCookie cookieWithProperties:cookieProperties];
        [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookieuser];
    }
    cookieProperties = nil;
}

-(NSArray*)getCookie:(NSString*)domain{
    NSArray *nCookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookiesForURL:[NSURL URLWithString:domain]];
    NSMutableArray*cookies = [[NSMutableArray alloc] init];
    for (NSHTTPCookie *cookie in nCookies){
        if ([cookie isKindOfClass:[NSHTTPCookie class]]){
            NSNumber *sessionOnly =[NSNumber numberWithBool:cookie.sessionOnly];
            NSNumber *isSecure = [NSNumber numberWithBool:cookie.isSecure];
            NSArray *_cookies = [NSArray arrayWithObjects:cookie.name, cookie.value, cookie.domain, cookie.path, sessionOnly,isSecure, nil];
            [cookies addObject:_cookies];
        }
    }
    return  cookies;
}

//删除cookie
- (void)deleteCookie:(NSString *)domain{
    if (@available(iOS 9.0, *)) {
        NSSet* set= [WKWebsiteDataStore allWebsiteDataTypes];
        NSDate *dateFrom = [NSDate dateWithTimeIntervalSince1970:0];
        [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:set modifiedSince:dateFrom completionHandler:^{
        
        }];
    } else {
        // Fallback on earlier versions
        NSArray *nCookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookies];
        for (NSHTTPCookie *cookie in nCookies){
            if ([cookie.domain isEqualToString:domain] || (domain && domain.length ==0)) {
                [[NSHTTPCookieStorage sharedHTTPCookieStorage] deleteCookie:cookie];
            }
        }
    }
}

//加载持久化cookies
- (BOOL)loadCookie:(NSString *)name
{
    [self deleteCookie:@""];
    NSArray *cookies =[[NSUserDefaults standardUserDefaults] objectForKey:name];
    if (cookies.count >0) {
        for (int i=0; i<cookies.count; i++) {
            NSArray*cookie =[cookies objectAtIndex:i];
            if (cookie && cookie.count>=4) {
                NSMutableDictionary *cookieProperties = [NSMutableDictionary dictionary];
                [cookieProperties setObject:[cookie objectAtIndex:0] forKey:NSHTTPCookieName];
                [cookieProperties setObject:[cookie objectAtIndex:1] forKey:NSHTTPCookieValue];
                [cookieProperties setObject:[cookie objectAtIndex:2] forKey:NSHTTPCookieDomain];
                [cookieProperties setObject:[cookie objectAtIndex:3] forKey:NSHTTPCookiePath];
                NSHTTPCookie *cookieuser = [NSHTTPCookie cookieWithProperties:cookieProperties];
                [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookieuser];
            }
        }
        return true;
    }
    return false;
}

//持久化cookies
-(void)saveCookie:(NSString*)name domain:(NSString*)domain
{
    if (nil == domain || 0==domain.length) {
        return;
    }
    NSArray *nCookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookiesForURL:[NSURL URLWithString:domain]];
    NSMutableArray*cookies = [[NSMutableArray alloc] init];
    for (NSHTTPCookie *cookie in nCookies){
        if ([cookie isKindOfClass:[NSHTTPCookie class]]){
            NSNumber *sessionOnly =[NSNumber numberWithBool:cookie.sessionOnly];
            NSNumber *isSecure = [NSNumber numberWithBool:cookie.isSecure];
            NSArray *_cookies = [NSArray arrayWithObjects:cookie.name, cookie.value, cookie.domain, cookie.path, sessionOnly,isSecure, nil];
            [cookies addObject:_cookies];
        }
    }
    if (cookies && [cookies count]>0 && name && name.length>0) {
        [[NSUserDefaults standardUserDefaults] setObject:cookies forKey:name];
    }
    [self deleteCookie:@""];
}

@end
