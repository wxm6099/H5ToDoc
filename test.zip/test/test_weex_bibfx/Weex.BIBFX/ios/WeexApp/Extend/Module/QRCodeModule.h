//
//  QRCodeModule.h
//  BibGold
//
//  Created by Richard on 2019/3/25.
//  Copyright © 2019年 Fantasy. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <WeexSDK/WXModuleProtocol.h>
#import "ScannerVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface QRCodeModule : NSObject<WXModuleProtocol,QRCodeReaderViewDelegate>

@end

NS_ASSUME_NONNULL_END
