//
//  JPushModule.h
//  BibGold
//
//  Created by Fantasy on 9/8/18.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WeexSDK.h>

@interface JPushModule : NSObject<WXModuleProtocol>

@end
