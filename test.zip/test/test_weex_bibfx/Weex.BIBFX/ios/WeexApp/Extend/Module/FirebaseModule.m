//
//  FirebaseModule.m
//  BibGold
//
//  Created by Richard on 2018/6/5.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "FirebaseModule.h"
#import "AppDefine.h"

#ifdef GoogleAnalytics
#import <GoogleAnalytics/GAI.h>
#import <GoogleAnalytics/GAIDictionaryBuilder.h>
#import <GoogleAnalytics/GAIFields.h>
#endif

#ifdef UMAnalytics
#import <UMAnalytics/MobClick.h>
#endif

@implementation FirebaseModule
WX_EXPORT_METHOD(@selector(logEventWithName:))
WX_EXPORT_METHOD(@selector(setScreenName:))
WX_EXPORT_METHOD(@selector(setUserID:))
WX_EXPORT_METHOD(@selector(setUserProperty:value:))

-(void)logEventWithName:(NSString*)eventName{
#ifdef FIREBASE
    [FIRAnalytics logEventWithName:eventName parameters:@{@"channel":CHANNEL}];
#endif
#ifdef GoogleAnalytics
    id tracker = [[GAI sharedInstance] defaultTracker];
    if (tracker) {
        GAIDictionaryBuilder*builder = [GAIDictionaryBuilder createEventWithCategory:eventName
                                                                              action:@"touch"
                                                                               label:CHANNEL
                                                                               value:nil];
        [tracker set:kGAICampaignSource value:CHANNEL];
        [tracker set:[GAIFields customDimensionForIndex:1] value:CHANNEL];
        [tracker send:[builder build]];
    }
#endif
    
#ifdef UMAnalytics
    [MobClick event:eventName label:CHANNEL];
#endif
}

-(void)setScreenName:(NSString*)screenName{
#ifdef FIREBASE
    [FIRAnalytics setScreenName:screenName screenClass:screenName];
#endif
}

- (void)setUserID:(nullable NSString *)userID;
{
#ifdef FIREBASE
    [FIRAnalytics setUserID:userID];
#endif
}

- (void)resetAnalyticsData{
#ifdef FIREBASE
     [FIRAnalytics resetAnalyticsData];
#endif
}

- (void)setUserProperty:(NSString*)name value:(NSString*)value{
#ifdef FIREBASE
    if (name && value) {
        [FIRAnalytics setUserPropertyString:value forName:name];
    }
#endif
}


@end
