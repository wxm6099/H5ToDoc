//
//  MediaPlayerModule.m
//  BibGold
//
//  Created by Richard on 2018/9/17.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "MediaPlayerModule.h"
#import <WeexSDK/WXSDKManager.h>
#import <WeexSDK/WXUtility.h>

static MediaPlayerModule* _sharedInstance = nil;
static float bottomBarHeight = 0;
@interface MediaPlayerModule()
@property (nonatomic, assign)  BOOL disableClick;
@property (nonatomic, strong)  UIWindow*keyWindow;
@property (nonatomic, strong) WMPlayer *wmPlayer ;
@end

@implementation MediaPlayerModule
@synthesize weexInstance;

WX_EXPORT_METHOD(@selector(show))
WX_EXPORT_METHOD(@selector(hide))
WX_EXPORT_METHOD(@selector(setUrl:))
WX_EXPORT_METHOD(@selector(play))
WX_EXPORT_METHOD(@selector(stop))
WX_EXPORT_METHOD_SYNC(@selector(setViewSize:))
WX_EXPORT_METHOD_SYNC(@selector(setAudioEnable:))
//- (instancetype) init{
//    if (self = [super init]) {
//        [self initPlayer];
//    }
//    return self;
//}

- (instancetype) init{
    
    static dispatch_once_t once;
    
    dispatch_once(&once, ^{
        _sharedInstance = [super init];
        [_sharedInstance initPlayer];
    });
    
    return _sharedInstance;
}



-(void) initPlayer{
    dispatch_sync(dispatch_get_main_queue(), ^{
        self.keyWindow =  [UIApplication sharedApplication].keyWindow;
        self.wmPlayer = [self.keyWindow viewWithTag:9999];
        if (self.wmPlayer == nil) {
            self.wmPlayer = [[WMPlayer alloc] initWithFrame:CGRectMake(74, 556, 578, 162)];
            [self.keyWindow addSubview:self.wmPlayer];
            [self.keyWindow  bringSubviewToFront:self.wmPlayer];
            self.wmPlayer.tag = 9999;
            self.wmPlayer.layer.cornerRadius = 6;
            self.wmPlayer.clipsToBounds = YES;
        }
    });
    self.wmPlayer.delegate = self;
}

-(void)setViewSize:(int)index{
    
    CGFloat width = 578;
    CGFloat height = 324;
    
    switch (index) {
        case 0:
            width = 406*self.weexInstance.pixelScaleFactor;
            height = 228*self.weexInstance.pixelScaleFactor;
            break;
        case 1:
            width = 578*self.weexInstance.pixelScaleFactor;
            height = 324*self.weexInstance.pixelScaleFactor;
            break;
        case 2:
            width = 680*self.weexInstance.pixelScaleFactor;
            height = 381*self.weexInstance.pixelScaleFactor;
            break;
        default:
            width = 578*self.weexInstance.pixelScaleFactor;
            height = 324*self.weexInstance.pixelScaleFactor;
            break;
    }
    
    if (bottomBarHeight<=0) {
        NSString* deviceName = [WXUtility deviceName];
        if ([deviceName hasPrefix:@"iPhone11"] || [deviceName isEqualToString:@"iPhone10,3"] || [deviceName isEqualToString:@"iPhone10,6"]) {
            bottomBarHeight = 144;
        }else{
            bottomBarHeight = 110;
        }
        
    }

    dispatch_sync(dispatch_get_main_queue(), ^{
        CGFloat x = CGRectGetMaxX(self.keyWindow.bounds) - width - (24*self.weexInstance.pixelScaleFactor);
        CGFloat y = CGRectGetMaxY(self.keyWindow.bounds) - height - (bottomBarHeight*self.weexInstance.pixelScaleFactor);
        self.wmPlayer.frame = CGRectMake(x, y, width, height);
        [self.wmPlayer resetWMPlayer];
    });

}

-(void)setAudioEnable:(BOOL)enable{
    if (self.wmPlayer) {
        [self.wmPlayer.player setAudioEnable:enable];
    }
}

-(void)show{
    self.wmPlayer.hidden = NO;
    self.disableClick = NO;
    [self.keyWindow bringSubviewToFront:self.wmPlayer];
}

-(void)hide{
    self.wmPlayer.hidden = YES;
}

-(void)setUrl:(NSString*)url{
    if (url && url.length>4) {
        [self.wmPlayer setURLString:url];
    }
}

-(void)play{
   [self.wmPlayer play];
    [self show];
}

-(void)stop{
    [self.wmPlayer pause];
    [self hide];
}

-(void)wmplayer:(WMPlayer *)wmplayer clickedCloseButton:(UIButton *)closeBtn{
    [self stop];
}

-(void)wmplayer:(WMPlayer *)wmplayer clickedFullScreenButton:(UIButton *)fullScreenBtn{
    if (self.disableClick == YES) {
        return;
    }
    self.disableClick = YES;
    [[WXSDKManager instanceForID:@"2"] fireGlobalEvent:@"showView" params:@{@"data":@"live"}];
}
@end
