//
//  SessionModule.h
//  BibGold
//
//  Created by Fantasy on 6/9/18.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WeexSDK.h>
@interface SessionModule : NSObject<WXModuleProtocol>
-(void)download:(NSString*)strUrl callback:(WXModuleKeepAliveCallback)callback;
@end
