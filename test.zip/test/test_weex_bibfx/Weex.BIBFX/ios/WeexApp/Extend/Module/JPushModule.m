//
//  JPushModule.m
//  BibGold
//
//  Created by Fantasy on 9/8/18.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "JPushModule.h"
#import <JPush/JPUSHService.h>
@interface JPushModule()
{
    NSInteger getTagsSeq;
    NSInteger setTagsSeq;
}
@end

@implementation JPushModule

WX_EXPORT_METHOD(@selector(getAllTags:))
WX_EXPORT_METHOD(@selector(setTags::))
WX_EXPORT_METHOD(@selector(deleteTags::))

-(void)getAllTags:(WXModuleCallback)callback{
    getTagsSeq++;
    [JPUSHService getAllTags:^(NSInteger iResCode, NSSet *iTags, NSInteger seq) {
        if (callback && seq == self->getTagsSeq){
            if (0 == iResCode) {
                callback(@{@"code":@(iResCode),@"tags":iTags?[iTags allObjects]:@""});
            }else{
                callback(@{@"code":@(iResCode)});
            }
        }
    } seq: getTagsSeq];
}

-(void)setTags:(NSArray*)tags :(WXModuleCallback)callback{
    setTagsSeq++;
    if (tags && tags.count>0) {
        NSSet* set = [NSSet setWithArray:tags];
        [JPUSHService setTags:set completion:^(NSInteger iResCode, NSSet *iTags, NSInteger seq){
            if (callback && seq == self->setTagsSeq) {
                callback(@{@"code":@(iResCode),@"tags":iTags?[iTags allObjects]:@""});
            }
        } seq:setTagsSeq];
    }else{
        [JPUSHService cleanTags:^(NSInteger iResCode, NSSet *iTags, NSInteger seq){
            if (callback && seq == self->setTagsSeq) {
                callback(@{@"code":@(iResCode),@"tags":iTags?[iTags allObjects]:@""});
            }
        } seq:setTagsSeq];
    }
}

-(void)deleteTags:(NSArray*)tags :(WXModuleCallback)callback{
    if (tags && tags.count>0) {
        NSSet* set = [NSSet setWithArray:tags];
        [JPUSHService deleteTags:set completion:^(NSInteger iResCode, NSSet *iTags, NSInteger seq){
            callback(@{@"code":@(iResCode)});
        } seq:0];
    } else {
        callback(@{@"code":@(0)});
    }
}
@end
