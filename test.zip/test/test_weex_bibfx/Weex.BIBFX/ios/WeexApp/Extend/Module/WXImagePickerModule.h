//
//  WXImagePickerModule.h
//  Acetop
//
//  Created by Richard on 2019/3/7.
//  Copyright © 2019年 Acetop. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <WeexSDK/WeexSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface WXImagePickerModule : NSObject<WXModuleProtocol,UINavigationControllerDelegate,UIImagePickerControllerDelegate>

@end

NS_ASSUME_NONNULL_END
