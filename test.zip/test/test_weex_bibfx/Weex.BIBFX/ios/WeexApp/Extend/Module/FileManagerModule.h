//
//  FileManagerModule.h
//  BibGold
//
//  Created by Richard on 2019/4/12.
//  Copyright © 2019年 Fantasy. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <WeexSDK/WXModuleProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface FileManagerModule : NSObject <WXModuleProtocol>
- (NSString*) docDir;
//文件的MD5加密
-(NSString*)fileMD5:(NSString*)path;
- (BOOL)removeItemAtPath:(NSString *)path;
- (BOOL)moveItemAtPath:(NSString *)srcPath toPath:(NSString *)dstPath;
@end

NS_ASSUME_NONNULL_END
