//
//  WXImagePickerModule.m
//  Acetop
//
//  Created by Richard on 2019/3/7.
//  Copyright © 2019年 Acetop. All rights reserved.
//
#import <AssetsLibrary/AssetsLibrary.h>
#import "WXImagePickerModule.h"
#import <AVFoundation/AVCaptureDevice.h>
#import "UIImage+Color.h"

@interface WXImagePickerModule()
@property(nonatomic,copy)WXModuleCallback callback;
@end

@implementation WXImagePickerModule
@synthesize weexInstance;
WX_EXPORT_METHOD(@selector(takePhoto:))

-(BOOL)isPhotoLibraryAvailable
{
    return [UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary];
}

-(void)takePhoto:(WXModuleCallback)callback
{
    ALAuthorizationStatus status = [ALAssetsLibrary authorizationStatus];
    if (status == ALAuthorizationStatusRestricted || status ==ALAuthorizationStatusDenied){
        //无权限
        UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:@"未获得授权访问相册" message:@"" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"去设置", nil];
        [alertView show];
        return;
    }
    
    self.callback = callback;
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.modalPresentationStyle = UIModalPresentationCustom;
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePicker.delegate = self;
    
    [self.weexInstance.viewController.navigationController presentViewController:imagePicker animated:YES completion:nil];
    imagePicker = nil;
    
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey, id> *)info{
    
    UIImage *orgImage = info[UIImagePickerControllerOriginalImage];
    orgImage = [UIImage imageFixOrientation:orgImage];
    NSString*name = [NSString stringWithFormat:@"%u.png",arc4random()];
    NSString *fullPath = [NSTemporaryDirectory() stringByAppendingPathComponent:name];
     [UIImagePNGRepresentation(orgImage) writeToFile:fullPath atomically:YES];

    if (self.callback) {
        NSDictionary* dic =@{ @"result": @"success",@"path":fullPath};
        self.callback(dic);
    }
    [picker dismissViewControllerAnimated:NO completion:nil];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    if (self.callback) {
        NSDictionary* dic =@{ @"result": @"cancel"};
        self.callback(dic);
    }
     [picker dismissViewControllerAnimated:NO completion:nil];
}

#pragma mark - ActionSheet Delegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 2) {
        return;
    }
    
    if (buttonIndex == 0) {
        ALAuthorizationStatus author = [ALAssetsLibrary authorizationStatus];
        if (author == ALAuthorizationStatusRestricted || author ==ALAuthorizationStatusDenied){
            //无权限
            UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:@"未获得授权访问相册" message:@"" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"去设置", nil];
            [alertView show];
            return;
        }
    }else if (buttonIndex == 1) {
        AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        if (authStatus == AVAuthorizationStatusRestricted || authStatus ==AVAuthorizationStatusDenied)
        {
            //无权限
            UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:@"未获得授权使用摄像头" message:@"" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"去设置", nil];
            [alertView show];
            return;
        }
    }
    
    
    
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate      = self;
    imagePicker.allowsEditing = YES;
    if (buttonIndex == 0) {
        imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    } else {
        imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    }
    [self.weexInstance.viewController.navigationController presentViewController:imagePicker animated:YES completion:nil];
    
}

#pragma mark - UIAlertView Delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
    }
}

@end
