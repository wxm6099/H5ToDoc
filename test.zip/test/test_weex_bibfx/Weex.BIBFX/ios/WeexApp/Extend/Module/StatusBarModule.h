//
//  StatusBarModule.h
//  WeexApp
//
//  Created by Richard on 2018/3/27.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Foundation/Foundation.h>
#import <WeexSDK/WeexSDK.h>

@interface StatusBarModule : NSObject<WXModuleProtocol>

@end
