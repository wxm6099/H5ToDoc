//
//  TripleDESModule.h
//  BibGold
//
//  Created by Richard on 2018/6/14.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WeexSDK/WeexSDK.h>

@interface TripleDESModule : NSObject<WXModuleProtocol>

@end
