//
//  WXApplicationModule.h
//  Acetop
//
//  Created by Richard on 2019/1/15.
//  Copyright © 2019年 Acetop. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <WeexSDK/WeexSDK.h>
#import "AppDefine.h"

NS_ASSUME_NONNULL_BEGIN

@interface WXApplicationModule : NSObject<WXModuleProtocol>

@end

NS_ASSUME_NONNULL_END
