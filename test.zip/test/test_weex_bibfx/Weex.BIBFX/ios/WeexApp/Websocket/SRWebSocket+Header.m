//
//  SRWebSocket+Header.m
//  BIBFX
//
//  Created by Richard on 2019/11/25.
//  Copyright © 2019 taobao. All rights reserved.
//

#import "SRWebSocket+Header.h"

@implementation SRWebSocket (Header)
- (id)initWithURL:(NSURL *)url protocols:(NSArray *)protocols header:(NSDictionary*)header;
{
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    for (NSString * name in header) {
        NSString* obj = [header valueForKey:name];
        [request setValue:obj forHTTPHeaderField:name];
    }
    return [self initWithURLRequest:request protocols:protocols];
}
@end
