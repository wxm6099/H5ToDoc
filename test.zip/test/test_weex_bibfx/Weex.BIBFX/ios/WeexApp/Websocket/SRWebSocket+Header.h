//
//  SRWebSocket+Header.h
//  BIBFX
//
//  Created by Richard on 2019/11/25.
//  Copyright © 2019 taobao. All rights reserved.
//
#import "SRWebSocket.h"

NS_ASSUME_NONNULL_BEGIN

@interface SRWebSocket (Header)
- (id)initWithURL:(NSURL *)url protocols:(NSArray *)protocols header:(NSDictionary*)header;
@end

NS_ASSUME_NONNULL_END
