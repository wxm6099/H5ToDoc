//
//  WMPlayer.m
//  BibGold
//
//  Created by Richard on 2018/9/18.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "WMPlayer.h"
#import "Masonry.h"
#define WMPlayerSrcName(file) [@"WMPlayer.bundle" stringByAppendingPathComponent:file]

@interface WMPlayer () <UIGestureRecognizerDelegate>
@property (nonatomic,assign)CGPoint firstPoint;
@property (nonatomic,assign)CGPoint secondPoint;
@property (nonatomic, strong)NSDateFormatter *dateFormatter;
//监听播放起状态的监听者
@property (nonatomic ,strong) id playbackTimeObserver;

//视频进度条的单击事件
@property (nonatomic, strong) UITapGestureRecognizer *tap;
@property (nonatomic, assign) CGPoint originalPoint;
@property (nonatomic, assign) BOOL isDragingSlider;//是否点击了按钮的响应事件
/**
 *  显示播放时间的UILabel
 */
@property (nonatomic,strong) UILabel        *leftTimeLabel;
@property (nonatomic,strong) UILabel        *rightTimeLabel;



/**
 * 亮度的进度条
 */
@property (nonatomic,strong) UISlider       *lightSlider;
@property (nonatomic,strong) UISlider       *progressSlider;
@property (nonatomic,strong) UISlider       *volumeSlider;


@property (nonatomic,strong) UIProgressView *loadingProgress;


@end

@implementation WMPlayer
{
    UISlider *systemSlider;
    UITapGestureRecognizer* singleTap;
}

#pragma mark - 初始化
/**
 *  alloc init的初始化方法
 */
- (instancetype)init{
    self = [super init];
    if (self){
        [self initWMPlayer];
    }
    return self;
}
/**
 *  storyboard、xib的初始化方法
 */
- (void)awakeFromNib
{
    [super awakeFromNib];
    [self initWMPlayer];
}
/**
 *  initWithFrame的初始化方法
 */
-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initWMPlayer];
    }
    return self;
}
/**
 *  初始化WMPlayer的控件，添加手势，添加通知，添加kvo等
 */
-(void)initWMPlayer{
    [self setupPlayer];

    self.backgroundColor = [UIColor blackColor];
    [self setAutoresizesSubviews:NO];
    
//    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
//    [button addTarget:self action:@selector(fullScreenAction:) forControlEvents:UIControlEventTouchUpInside];
//    [self addSubview:button];
//    [button mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.equalTo(self);
//        make.top.equalTo(self);
//        make.right.equalTo(self);
//        make.bottom.equalTo(self);
//    }];
//    button.backgroundColor = [UIColor clearColor];
//    button.showsTouchWhenHighlighted = YES;
    
    //_fullScreenBtn
    self.fullScreenBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.fullScreenBtn.showsTouchWhenHighlighted = YES;
    [self.fullScreenBtn addTarget:self action:@selector(fullScreenAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.fullScreenBtn setImage:[UIImage imageNamed:@"fullscreen"] forState:UIControlStateNormal];
    [self.fullScreenBtn setImage:[UIImage imageNamed:@"fullscreen"] forState:UIControlStateSelected];
    [self addSubview:self.fullScreenBtn];
    [self.fullScreenBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self).with.offset(-5);
        make.height.mas_equalTo(30);
        make.top.equalTo(self).with.offset(5);
        make.width.mas_equalTo(30);
        
    }];

    //_closeBtn
    _closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _closeBtn.showsTouchWhenHighlighted = YES;
    [_closeBtn addTarget:self action:@selector(colseTheVideo:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_closeBtn];
    
    [self.closeBtn setImage:[UIImage imageNamed:@"play_close"] forState:UIControlStateNormal];
    [self.closeBtn setImage:[UIImage imageNamed:@"play_close"] forState:UIControlStateSelected];
    [self.closeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).with.offset(5);
        make.height.mas_equalTo(30);
        make.top.equalTo(self).with.offset(5);
        make.width.mas_equalTo(30);
        
    }];
    
    UITapGestureRecognizer *tapGesturRecognizer=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(fullScreenAction:)];
    [tapGesturRecognizer setNumberOfTapsRequired:1];
    [self addGestureRecognizer:tapGesturRecognizer];
}

-(void)setupPlayer{
    self.player = [[NodePlayer alloc ] initWithPremium:@"W4hUJuvX60T3yOfFkFpE3OGMVfiDgfBfaZCQ0SJ5V0pi95FnbR+MK5VdjeldTpMC5VdNH2cQnQUzkrR35+PNMA=="];
//    [_np setNodePlayerDelegate:self];//设置事件代理
    [_player setBufferTime:300];//设置首屏启动缓冲时长,不是实际等待时间,而是缓冲区存放的时长,建议100-500毫秒
    [_player setMaxBufferTime:1000];//设置缓冲区最大时长,该值与最大延迟有直接关系.因GOP缓冲\网络抖动\来电等因素引起的延迟,会根据该值的大小自动抛弃过期数据.建议1000-2000毫秒
    [_player setPlayerView:self];//设置视频播放视图
    [_player setContentMode:UIViewContentModeScaleAspectFit];//设置画面填充模式.
    [_player setHwEnable:YES];//设置开启硬解码,默认已开启,可以不调用.系统版本不支持或硬解码器初始化失败,自动转为软解.
    [_player setSubscribe:YES];
}


//视频进度条的点击事件
- (void)actionTapGesture:(UITapGestureRecognizer *)sender {

}

- (void)updateSystemVolumeValue:(UISlider *)slider{
    systemSlider.value = slider.value;
}

#pragma mark - 全屏按钮点击func
-(void)fullScreenAction:(UIButton *)sender{
//    sender.selected = !sender.selected;
    if (self.delegate&&[self.delegate respondsToSelector:@selector(wmplayer:clickedFullScreenButton:)]) {
        [self.delegate wmplayer:self clickedFullScreenButton:sender];
    }
}

#pragma mark - 关闭按钮点击func
-(void)colseTheVideo:(UIButton *)sender{
    if (self.delegate&&[self.delegate respondsToSelector:@selector(wmplayer:clickedCloseButton:)]) {
        [self.delegate wmplayer:self clickedCloseButton:sender];
    }
}


#pragma mark - PlayOrPause

///播放
-(void)play{
    if (self.player && false == self.player.isPlaying) {
       [self.player start];
    }
     [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
}

///暂停
-(void)pause{
    if (self.player && self.player.isPlaying) {
        [self.player stop];
    }
    [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
}
#pragma mark - 单击手势方法
- (void)handleSingleTap:(UITapGestureRecognizer *)sender{

}

#pragma mark - 双击手势方法
- (void)handleDoubleTap:(UITapGestureRecognizer *)doubleTap{

}

/**
 *  重写URLString的setter方法，处理自己的逻辑，
 */
- (void)setURLString:(NSString *)URLString{
    _URLString = URLString;
    [self.player setInputUrl:_URLString];
}

- (void)moviePlayDidEnd:(NSNotification *)notification {

}

-(void)dealloc{

    [[NSNotificationCenter defaultCenter] removeObserver:self];
    if (self.player) {
        [self.player stop];
    }
    self.delegate = nil;
    
    self.player = nil;
    
}

- (void )resetWMPlayer{
    if(_player){
        [_player setPlayerView:self];
    }
}

- (NSString *)version{
    return @"2.0.0";
}
@end
