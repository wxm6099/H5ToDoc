//
//  UIColor+IGColor.h
//  IGold
//
//  Created by blts on 2017/6/12.
//  Copyright © 2017年 Richard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (IGColor)

+ (UIColor *)colorWithRGBHex:(UInt32)hex;

+(UIColor *)colorWithStr:(NSString *)colorStr;

+(UIColor *)colorWithStr:(NSString *)colorStr WithAlpha:(CGFloat)alpha;

+ (UIImage *)imageWithColor:(UIColor *)color;
@end
