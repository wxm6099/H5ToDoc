//
//  UIImage+Color.h
//  IGold
//
//  Created by blts on 2018/12/25.
//  Copyright © 2018年 Richard. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (Color)
//  颜色转换为背景图片
+ (UIImage *)imageWithColor:(UIColor *)color;
//  颜色转换为背景图片
+ (UIImage *)imageFixOrientation:(UIImage *)image;
@end

NS_ASSUME_NONNULL_END
