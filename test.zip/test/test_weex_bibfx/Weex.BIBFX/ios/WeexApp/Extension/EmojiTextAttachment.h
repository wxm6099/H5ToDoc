//
//  EmojiTextAttachment.h
//  IGold
//
//  Created by blts on 2018/11/12.
//  Copyright © 2018年 Richard. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface EmojiTextAttachment : NSTextAttachment
@property(strong, nonatomic) NSString *emojiTag;//保存表情的text文本
@property(assign, nonatomic) CGSize emojiSize;  //For emoji image size
@end

NS_ASSUME_NONNULL_END
