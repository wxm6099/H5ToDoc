#import <UIKit/UIKit.h>

@interface NSString (CODEC)

//MD5加密
- (NSString *)MD5String;

//SHA1加密
- (NSString *)SHA1String;

//UTF-8编码
- (NSString *)URLEncodedString;
//UTF-8解码
- (NSString *)URLDecodedString;

+ (NSString * )encodeBase64:(NSString * )input;

+ (NSString * )decodeBase64:(NSString * )input;

//判断某字符串是否为空 （yes：空  no：非空）
+ (BOOL) isBlankString:(NSString *)string;

/**
 *  判断某字符串是否为空，1 开头，第二位大于2 并且是11位 就算是合法手机号
 *
 *  @param string 手机号码
 **/
+(BOOL)isPhoneNumber:(NSString *)string;
/**
 *  判断日期（时间戳）是否是今天或明天或昨天或在本周内
 *
 *  @param timeStamp 日期类型为时间戳
 *  @param isDateIn 今天（isToday） 明天（isTomorrow）昨天（isYesterday）在本周内（isWeekend）
 **/
+ (BOOL )checkTheDate:(NSString *)timeStamp withIsDateIn:(NSString *)isDateIn;
//得到当前时间的时区值(小时)
+(NSInteger )getTheUTCByDateTime:(NSDate *)date;
//获得特定格式的日期时间值(参数为时间戳值)
+(NSString *)getTheDateStringByTimeStamp:(NSString *)timeStamp withFormat:(NSString *)format;

//根据给定的日期date值获得特定格式的字符串日期时间值
+(NSString *)getTheDateStringBydate:(NSDate *)date withFormat:(NSString *)format;

/**
 *  k线图中分时间段请求数据时的不同时间段的计算
 *
 *  @param date 其实日期值
 *
 *  @param change 时间跨度（单位：天 正值是未来的时间负值是过去的时间）
 **/
+(NSString *)changeDate:(NSDate *)date change:(NSInteger)change;

//自适应高
+ (CGFloat)getHeightByWidth:(CGFloat)width title:(NSString *)title font:(UIFont*)font;
//自适应宽
+ (CGFloat)getWidthWithTitle:(NSString *)title font:(UIFont *)font;
//正则表达式   将{}和里面的内容替换成*****
+(NSString *)getStringByRegularExpression:(NSString *)string;
//正则表达式匹配特定字符
+(NSArray *)getArrayStringsByRegularExpression:(NSString *)expression withContent:(NSString *)content;

/**
 *  不四舍五入的将double数据转成字符串
 *
 *  @param number   需要转换的double数据
 *  @param position 保留小数点后几位
 */
+(NSString *)savePointPrecisionNotRoundNumber:(double)number afterPoint:(int)position;
/**
 *  获取随机字符串
 *
 *  @param len   随机字符串的长度
 *  @param letters 指定随机字符串  默认26个字母  不区分大小写
 */
+(NSString *)randomStringWithLength:(NSInteger)len String:(NSString *)letters;
@end
