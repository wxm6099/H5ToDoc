//
//  Emotion.m
//  Acetop
//
//  Created by Richard on 2019/3/5.
//  Copyright © 2019年 Acetop. All rights reserved.
//

#import "Emotion.h"

@implementation Emotion
- (BOOL)isEqual:(Emotion *)emotion
{
    return [self.face_text isEqualToString:emotion.face_text] || [self.face_name isEqualToString:emotion.face_name] || [self.code isEqualToString:emotion.code];
}

@end
