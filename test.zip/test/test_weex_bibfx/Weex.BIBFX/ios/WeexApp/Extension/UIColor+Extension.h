//
//  UIColor+Extension.h
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (Extension)

+ (UIColor *)colorWithHexString:(NSString *)color;

+(UIColor *)colorWithStr:(NSString *)colorStr;

+(UIColor *)colorWithStr:(NSString *)colorStr WithAlpha:(CGFloat)alpha;
@end
