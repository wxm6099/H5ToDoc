//
//  Emotion.h
//  Acetop
//
//  Created by Richard on 2019/3/5.
//  Copyright © 2019年 Acetop. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Emotion : NSObject
@property (nonatomic, copy) NSString *face_name;

@property (nonatomic, copy) NSString *face_id;

@property (nonatomic, copy) NSString *face_text;

@property (nonatomic, copy) NSString *code;
@end

NS_ASSUME_NONNULL_END
