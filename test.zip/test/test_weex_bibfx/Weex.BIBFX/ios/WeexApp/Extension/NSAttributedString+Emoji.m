//
//  NSAttributedString+Emoji.m
//  IGold
//
//  Created by blts on 2018/11/12.
//  Copyright © 2018年 Richard. All rights reserved.
//

#import "NSAttributedString+Emoji.h"
#import "EmojiTextAttachment.h"

@implementation NSAttributedString (Emoji)
- (NSString *)getPlainString {
    NSMutableString *plainString = [NSMutableString stringWithString:self.string];
    __block NSUInteger base = 0;
    
    [self enumerateAttribute:NSAttachmentAttributeName inRange:NSMakeRange(0, self.length)
                     options:0
                  usingBlock:^(id value, NSRange range, BOOL *stop) {
                      if (value && [value isKindOfClass:[EmojiTextAttachment class]]) {
                          [plainString replaceCharactersInRange:NSMakeRange(range.location + base, range.length)
                                                     withString:((EmojiTextAttachment *) value).emojiTag];
                          base += ((EmojiTextAttachment *) value).emojiTag.length - 1;
                      }
                  }];
    
    return plainString;
}
@end
