//
//  EmojiTextAttachment.m
//  IGold
//
//  Created by blts on 2018/11/12.
//  Copyright © 2018年 Richard. All rights reserved.
//

#import "EmojiTextAttachment.h"

@implementation EmojiTextAttachment
- (CGRect)attachmentBoundsForTextContainer:(NSTextContainer *)textContainer proposedLineFragment:(CGRect)lineFrag glyphPosition:(CGPoint)position characterIndex:(NSUInteger)charIndex {
    return CGRectMake(0, -4, _emojiSize.width, _emojiSize.height);
}
@end
