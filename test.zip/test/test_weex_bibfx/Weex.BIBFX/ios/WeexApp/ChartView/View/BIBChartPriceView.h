//
//  BIBChartPriceView.h
//  WeexApp
//
//  Created by blts on 2018/4/2.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIBChartPriceView : UIView

@property (nonatomic,strong) UILabel *maxPriceLabel;
@property (nonatomic,strong) UILabel *smallMaxPriceLabel;
@property (nonatomic,strong) UILabel *middlePriceLabel;
@property (nonatomic,strong) UILabel *bigMinPriceLabel;
@property (nonatomic,strong) UILabel *minPriceLabel;
@property (nonatomic,strong) UIColor *textColor;
@property (nonatomic,strong) UIFont *textFont;

@end
