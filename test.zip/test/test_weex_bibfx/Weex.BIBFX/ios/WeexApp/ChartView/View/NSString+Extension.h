//
//  NSString+Extension.h
//  WeexApp
//
//  Created by blts on 2018/4/16.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSString (Extension)
//判断某字符串是否为空 （yes：空  no：非空）
+ (BOOL) isBlankString:(NSString *)string;
//获得特定格式的日期时间值(参数为时间戳值)
+(NSString *)getTheDateStringByTimeStamp:(NSString *)timeStamp withFormat:(NSString *)format;

//根据给定的日期date值获得特定格式的字符串日期时间值
+(NSString *)getTheDateStringBydate:(NSDate *)date withFormat:(NSString *)format;

/**
 *  k线图中分时间段请求数据时的不同时间段的计算
 *
 *  @param date 其实日期值
 *
 *  @param change 时间跨度（单位：天 正值是未来的时间负值是过去的时间）
 **/
+(NSString *)changeDate:(NSDate *)date change:(NSInteger)change;
//自适应高
+ (CGFloat)getHeightByWidth:(CGFloat)width title:(NSString *)title font:(UIFont*)font;
//自适应宽
+ (CGFloat)getWidthWithTitle:(NSString *)title font:(UIFont *)font;

@end
