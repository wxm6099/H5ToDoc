//
//  BIBIndexTypeView.h
//  WeexApp
//
//  Created by blts on 2018/4/2.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol BIBIndexTypeViewDelegate <NSObject>

- (void)didSelectButton:(UIButton*)button index:(NSInteger)index;
@end

@interface BIBIndexTypeView : UIView

@property (nonatomic,strong) NSMutableArray *array_data;

@property (nonatomic,  weak) id <BIBIndexTypeViewDelegate> delagate;

@end
