//
//  BIBChartScrollView.m
//  WeexApp
//
//  Created by blts on 2018/4/2.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "BIBChartScrollView.h"
#import "BIBKLineCandleView.h"
#import "BIBChartPriceView.h"
#import "BIBIndexTypeView.h"
#import "BIBMACDLineView.h"
#import "BIBRSILineView.h"
#import "BIBKDJLineView.h"
#import "BIBBOLLLineView.h"
#import "BIBMALineView.h"
#import "BIBOSMALineView.h"
#import "Masonry.h"
#import "BIBKLineCandleModel.h"

#define IPHONE_WIDTH [UIScreen mainScreen].bounds.size.width
#define SizeScaleW (IPHONE_WIDTH/375)  //屏幕宽的缩放比例

#define IPHONE_HEIGHT [UIScreen mainScreen].bounds.size.height
#define SizeScaleH (IPHONE_HEIGHT/667)  //屏幕高的缩放比例

#define SizeScale_Height (SizeScaleW == 1 ? 1 : IPHONE_HEIGHT/667)  //屏幕高的缩放比例(iphone X屏幕宽的缩放比例为1时，高的缩放比例也为1，不随SizeScaleH的改变而改变）

#define TimeLayerHeight 22 //指标图底部时间和日期区域的高度
typedef enum
{
    MACD = 1,
    RSI,
    KDJ,
    BOLL,
    MA,
    OSMA
}IndexLineType;

@interface BIBChartScrollView()<BIBKLineCandleViewProtocol,BIBIndexTypeViewDelegate>

@property(nonatomic,strong)BIBKLineCandleView *view_candleChart;//蜡烛图的主view
@property(nonatomic,strong)UIView *view_box_candle;//蜡烛图的覆盖层
@property(nonatomic,strong)BIBChartPriceView *view_price_candle;//蜡烛图的右侧价格
@property(nonatomic,strong)UIView *view_bg_indexType;//指标分类的背景
@property(nonatomic,strong)BIBIndexTypeView *view_indexType;//指标分类
@property(nonatomic,strong)UIView *view_bg_index;//指标的背景层
@property(nonatomic,strong)UIView *view_box_index;//指标图的覆盖层
@property(nonatomic,strong)UILabel *label_indexTitle;//指标的参数title
@property(nonatomic,strong)BIBChartPriceView *view_price_index;//指标的右侧价格
@property(nonatomic,strong)BIBMACDLineView *view_macd;//macd指标
@property(nonatomic,strong)BIBRSILineView *view_rsi;//rsi指标
@property(nonatomic,strong)BIBKDJLineView *view_kdj;//kdj指标
@property(nonatomic,strong)BIBBOLLLineView *view_boll;//boll指标
@property(nonatomic,strong)BIBMALineView *view_ma;//ma指标
@property(nonatomic,strong)BIBOSMALineView *view_osma;//osma指标

@property (nonatomic,assign) IndexLineType indexType;//选中的指标分类

@end

@implementation BIBChartScrollView

-(void)initView
{
    [self addSubview:self.view_candleChart];
    [self.superview addSubview:self.view_box_candle];
    [self.view_box_candle addSubview:self.view_price_candle];
    [self.superview addSubview:self.view_bg_indexType];
    [self.view_bg_indexType addSubview:self.view_indexType];
    [self addSubview:self.view_bg_index];
    [self.superview addSubview:self.view_box_index];
    [self.view_box_index addSubview:self.label_indexTitle];
    [self.view_box_index addSubview:self.view_price_index];
    [self.view_bg_index addSubview:self.view_macd];
    [self.view_bg_index addSubview:self.view_rsi];
    [self.view_bg_index addSubview:self.view_kdj];
    
    [self setLayout];
}
-(void)setLayout
{
    [_view_candleChart mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).mas_offset(1);
        make.left.equalTo(self).mas_offset(5);
        make.right.equalTo(self).mas_offset(-5);
        make.height.equalTo(@(self.height*0.7));
    }];
    [_view_box_candle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_view_candleChart.mas_top).offset(0);
        make.left.equalTo(_view_candleChart.mas_left).offset(0);
        make.right.equalTo(_view_candleChart.mas_right).offset(0);
        make.height.equalTo(@(self.height*0.7));
    }];
    [_view_price_candle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_view_box_candle.mas_top).offset(0);
        make.right.equalTo(_view_box_candle.mas_right).offset(0);
        make.width.equalTo(@(80));
        make.bottom.equalTo(_view_box_candle.mas_bottom).offset(0);
    }];
    
    [_view_bg_indexType mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_view_box_candle.mas_bottom).offset(1);
        make.left.right.equalTo(_view_box_candle);//必须是_view_circle_candle不能是_view_candle
        make.height.equalTo(@(self.height*0.1));
    }];
    [_view_indexType mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_view_bg_indexType.mas_top).offset(6);
        make.left.equalTo(_view_bg_indexType);
        make.right.equalTo(_view_bg_indexType);
        make.height.equalTo(@(self.height*0.1-12));
    }];
    [_view_bg_index mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_view_bg_indexType.mas_bottom).offset(0);
        make.left.right.equalTo(_view_candleChart);
        make.height.equalTo(@(self.height*0.2));
    }];
    [_view_bg_index layoutIfNeeded];
    
    [_view_box_index mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_view_bg_index.mas_top).offset(0);
        make.left.equalTo(_view_bg_index.mas_left).offset(0);
        make.right.equalTo(_view_bg_index.mas_right).offset(0);
        make.height.equalTo(@(self.height*0.2));
    }];
    [_label_indexTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_view_bg_index.mas_top).offset(0);
        make.left.equalTo(self.mas_left).offset(12);
        make.right.equalTo(self.mas_right).offset(0);
        make.height.equalTo(@(12*SizeScale_Height));
    }];
    [_view_price_index mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.equalTo(_view_box_index).offset(0);
        make.right.equalTo(_view_box_index).offset(0);
        make.width.equalTo(@(80));
    }];
    
    [_view_macd mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.equalTo(_view_bg_index);
        make.left.right.equalTo(_view_bg_index);
    }];
    [_view_rsi mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.equalTo(_view_bg_index);
        make.left.right.equalTo(_view_bg_index);
    }];
    [_view_kdj mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.equalTo(_view_bg_index);
        make.left.right.equalTo(_view_bg_index);
    }];
}









#pragma mark IGoldCandleChartViewProtocol  蜡烛图的代理  Method

- (void)displayLastModel:(BIBKLineCandleModel *)kLineModel
{
    //取当前屏幕最后一根k线model  数据显示在顶部view
    //    _view_top.model = kLineModel;
}
- (void)longPressCandleViewWithIndex:(NSInteger)kLineModeIndex kLineModel:(BIBKLineCandleModel *)kLineModel
{
    //长按手势 取长按的那根k线model  数据显示在顶部view
    //    _view_top.model = kLineModel;
}
- (void)displayScreenleftPostion:(CGFloat)leftPostion startIndex:(NSInteger)index count:(NSInteger)count
{
    [self showIndexLineView:leftPostion startIndex:index count:count];
}
- (void)showIndexLineView:(CGFloat)leftPostion startIndex:(NSInteger)index count:(NSInteger)count
{
    //k线图右侧的price数据
    CGFloat max_y = self.view_candleChart.maxY;
    CGFloat min_y = self.view_candleChart.minY;
    _view_price_candle.maxPriceLabel.text = [NSString stringWithFormat:@"%.2f",max_y];
    _view_price_candle.smallMaxPriceLabel.text = [NSString stringWithFormat:@"%.2f",(max_y-min_y)*3/4+min_y];
    _view_price_candle.middlePriceLabel.text = [NSString stringWithFormat:@"%.2f",(max_y - min_y)/2 + min_y];
    _view_price_candle.bigMinPriceLabel.text = [NSString stringWithFormat:@"%.2f",(max_y - min_y)/4 + min_y];
    _view_price_candle.minPriceLabel.text = [NSString stringWithFormat:@"%.2f",min_y];
    
    //指标右侧的price数据
    if (_indexType == MACD)
    {
        [_view_kdj setHidden:YES];
        [_view_rsi setHidden:YES];
        [_view_macd setHidden:NO];
        _view_macd.candleSpace = _view_candleChart.candleSpace;
        _view_macd.candleWidth = _view_candleChart.candleWidth;
        _view_macd.leftPostion = leftPostion;
        _view_macd.startIndex = index;
        _view_macd.displayCount = count;
        [_view_macd stockFill];
        
        _view_price_index.maxPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_macd.maxY];
        _view_price_index.middlePriceLabel.text = [NSString stringWithFormat:@"%.2f",(self.view_macd.maxY - self.view_macd.minY)/2 + self.view_macd.minY];
        _view_price_index.minPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_macd.minY];
    }
    
    else  if (_indexType == RSI)
    {
        [_view_kdj setHidden:YES];
        [_view_macd setHidden:YES];
        [_view_rsi setHidden:NO];
//        _view_rsi.candleSpace = _view_candleChart.candleSpace;
//        _view_rsi.candleWidth = _view_candleChart.candleWidth;
//        _view_rsi.leftPostion = leftPostion;
//        _view_rsi.startIndex = index;
//        _view_rsi.displayCount = count;
//        [_view_rsi stockFill];
        
        _view_price_index.maxPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_rsi.maxY];
        _view_price_index.middlePriceLabel.text = [NSString stringWithFormat:@"%.2f",(self.view_rsi.maxY - self.view_rsi.minY)/2 + self.view_rsi.minY];
        _view_price_index.minPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_rsi.minY];
    }
    
    else if(_indexType == KDJ)
    {
        [_view_kdj setHidden:NO];
        [_view_macd setHidden:YES];
        [_view_rsi setHidden:YES];
        _view_kdj.candleSpace = _view_candleChart.candleSpace;
        _view_kdj.candleWidth = _view_candleChart.candleWidth;
        _view_kdj.leftPostion = leftPostion;
        _view_kdj.startIndex = index;
        _view_kdj.displayCount = count;
        [_view_kdj stockFill];
        
        _view_price_index.maxPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_kdj.maxY];
        _view_price_index.middlePriceLabel.text = [NSString stringWithFormat:@"%.2f",(self.view_kdj.maxY - self.view_kdj.minY)/2 + self.view_kdj.minY];
        _view_price_index.minPriceLabel.text = [NSString stringWithFormat:@"%.2f",self.view_kdj.minY];
    }
}
#pragma mark --   IGoldTecnnicalTypeViewDelegate 切换指标图的代理 Method   ------
- (void)didSelectButton:(UIButton*)button index:(NSInteger)index
{
    if (index == 1)
    {
        _indexType = MACD;
    }
    else if (index == 2)
    {
        _indexType = RSI;
    }
    else if (index == 3)
    {
        _indexType = KDJ;
    }
    else if (index == 4)
    {
        _indexType = BOLL;
    }
    else if (index == 5)
    {
        _indexType = MA;
    }
    else if (index == 6)
    {
        _indexType = OSMA;
    }
    
    [self updateTecnnicalValue];
    [self showIndexLineView:self.view_candleChart.leftPostion startIndex:self.view_candleChart.currentStartIndex count:self.view_candleChart.displayCount];
}
//设置指标的最后一个数据
-(void)updateTecnnicalValue
{
    NSString *str_MACD_DIFF = [_dic_tecnnical objectForKey:@"MACD_DIFF"] == nil ? @"0.0" : [_dic_tecnnical objectForKey:@"MACD_DIFF"];
    NSString *str_MACD_DEA = [_dic_tecnnical objectForKey:@"MACD_DEA"] == nil ? @"0.0" : [_dic_tecnnical objectForKey:@"MACD_DEA"];
    NSString *str_macd = [NSString stringWithFormat:@"%@%@%@%@",@"MACD(12,26,9)  ",str_MACD_DIFF,@"  ",str_MACD_DEA];
    
    NSString *str_RSI_14 = [_dic_tecnnical objectForKey:@"RSI_14"] == nil ? @"0.0" : [_dic_tecnnical objectForKey:@"RSI_14"];
    NSString *str_rsi = [NSString stringWithFormat:@"%@%@",@"RSI(14)  ",str_RSI_14];
    
    NSString *str_KDJ_K = [_dic_tecnnical objectForKey:@"KDJ_K"] == nil ? @"0.0" : [_dic_tecnnical objectForKey:@"KDJ_K"];
    NSString *str_KDJ_D = [_dic_tecnnical objectForKey:@"KDJ_D"] == nil ? @"0.0" : [_dic_tecnnical objectForKey:@"KDJ_D"];
    NSString *str_kdj = [NSString stringWithFormat:@"%@%@%@%@",@"Stoch(5,3,3)  ",str_KDJ_K,@"  ",str_KDJ_D];
    
    switch (_indexType) {
        case MACD:
            _label_indexTitle.text = str_macd;
            break;
        case RSI:
            _label_indexTitle.text = str_rsi;
            break;
        case KDJ:
            _label_indexTitle.text = str_kdj;
            break;
        case BOLL:
            _label_indexTitle.text = str_kdj;
            break;
        case MA:
            _label_indexTitle.text = str_kdj;
            break;
        case OSMA:
            _label_indexTitle.text = str_kdj;
            break;
            
        default:
            break;
    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(BIBKLineCandleView *)view_candleChart
{
    if (!_view_candleChart) {
        _view_candleChart = [BIBKLineCandleView new];
        _view_candleChart.delegate = self;
        _view_candleChart.candleSpace = 2;//蜡烛图的间距
        //    _candleChartView.displayCount = 25;
        _view_candleChart.displayCount = 60;//蜡烛图的个数
        _view_candleChart.lineWidth = 1*SizeScaleW;//蜡烛图中线的宽
        _view_candleChart.leftMargin = 2;
        _view_candleChart.rightMargin = 2;
        _view_candleChart.topMargin = 20;
        _view_candleChart.bottomMargin = 0;
        _view_candleChart.minHeight = 1;
        _view_candleChart.timeLayerHeight = TimeLayerHeight;
    }
    return _view_candleChart;
}
-(UIView *)view_box_candle
{
    if (!_view_box_candle) {
        _view_box_candle = [UIView new];
        _view_box_candle.userInteractionEnabled = NO;
        _view_box_candle.layer.borderWidth = 0.5*SizeScaleW;
        _view_box_candle.layer.borderColor = [UIColor colorWithStr:@"e6e6e6"].CGColor;
    }
    return _view_box_candle;
}
-(BIBChartPriceView *)view_price_candle
{
    if (!_view_price_candle) {
        _view_price_candle = [BIBChartPriceView new];
    }
    return _view_price_candle;
}
-(UIView *)view_bg_indexType
{
    if (!_view_bg_indexType) {
        _view_bg_indexType = [UIView new];
        _view_bg_indexType.backgroundColor = [UIColor whiteColor];
    }
    return _view_bg_indexType;
}
-(BIBIndexTypeView *)view_indexType
{
    if (!_view_indexType) {
        _view_indexType = [BIBIndexTypeView new];
        _view_indexType.array_data = [NSMutableArray arrayWithObjects:@"MACD",@"RSI",@"KDJ", nil];
        _view_indexType.delagate = self;
        _view_indexType.backgroundColor = [UIColor whiteColor];
    }
    return _view_indexType;
}
-(UIView *)view_bg_index
{
    if (!_view_bg_index) {
        _view_bg_index = [UIView new];
    }
    return _view_bg_index;
}
-(UIView *)view_box_index
{
    if (!_view_box_index) {
        _view_box_index = [UIView new];
        _view_box_index.userInteractionEnabled = NO;
        _view_box_index.layer.borderWidth = 0.5*SizeScaleW;
        _view_box_index.layer.borderColor = [UIColor colorWithStr:@"e6e6e6"].CGColor;
    }
    return _view_box_index;
}
-(UILabel *)label_indexTitle
{
    if (!_label_indexTitle) {
        _label_indexTitle = [[UILabel alloc] initWithFrame:CGRectZero];
        _label_indexTitle.textAlignment = NSTextAlignmentLeft;
        _label_indexTitle.textColor = [UIColor colorWithStr:@"676767"];
        _label_indexTitle.font = [UIFont systemFontOfSize:9.0*SizeScale_Height];//18px
        //        _label_tecnnicalTitle.numberOfLines = 0;
        _label_indexTitle.text = [NSString stringWithFormat:@"MACD(12,26,9)"];
        _label_indexTitle.backgroundColor = [UIColor clearColor];
    }
    return _label_indexTitle;
}
-(BIBChartPriceView *)view_price_index
{
    if (!_view_price_index) {
        _view_price_index = [BIBChartPriceView new];
    }
    return _view_price_index;
}
-(BIBMACDLineView *)view_macd
{
    if (!_view_macd) {
        _view_macd = [BIBMACDLineView new];
        _view_macd.lineWidth = 1*SizeScaleW;
    }
    return _view_macd;
}
-(BIBRSILineView *)view_rsi
{
    if (!_view_rsi) {
        _view_rsi = [BIBRSILineView new];
        _view_rsi.lineWidth = 1*SizeScaleW;
        _view_rsi.hidden = YES;
    }
    return _view_rsi;
}
-(BIBKDJLineView *)view_kdj
{
    if (!_view_kdj) {
        _view_kdj = [BIBKDJLineView new];
        _view_kdj.lineWidth = 1*SizeScaleW;
        _view_kdj.hidden = YES;
    }
    return _view_kdj;
}


-(NSMutableDictionary *)dic_tecnnical
{
    if (!_dic_tecnnical) {
        _dic_tecnnical = [[NSMutableDictionary alloc] init];
    }
    return _dic_tecnnical;
}
@end
