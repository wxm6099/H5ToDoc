//
//  BIBBaseChartView.h
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIView+Extension.h"
#import "UIBezierPath+Draw.h"
#include "UIColor+Extension.h"
#import "Masonry.h"
#import "BIBLineUntil.h"
#import "BIBLineData.h"
#import "KVOController.h"
#import "BIBCalculationTool.h"

#define ContentOffSet @"contentOffset"
#define DEVICE_HEIGHT [UIScreen mainScreen].bounds.size.height
#define DEVICE_WIDTH [UIScreen mainScreen].bounds.size.width

#ifdef IGold
#define RoseColor  [UIColor colorWithHexString:@"89b4f9"]
#define DropColor  [UIColor colorWithHexString:@"FC6767"]
#else
#define RoseColor  [UIColor colorWithHexString:@"30b700"]
#define DropColor  [UIColor colorWithHexString:@"eb403e"]
#endif

#define widthradio DEVICE_WIDTH/375
#define heightradio DEVICE_HEIGHT/667




@interface BIBBaseChartView : UIView
{
    CGFloat  _maxY;
    CGFloat  _minY;
    CGFloat  _maxX;
    CGFloat  _minX;
    CGFloat  _scaleY;
    CGFloat  _scaleX;
    CGFloat  _lineWidth;
    CGFloat  _lineSpace;
    CGFloat  _leftMargin;
    CGFloat  _rightMargin;
    CGFloat  _topMargin;
    CGFloat  _bottomMargin;
    UIColor  *_lineColor;
}

@property (nonatomic,assign) CGFloat maxY;
@property (nonatomic,assign) CGFloat minY;
@property (nonatomic,assign) CGFloat maxX;
@property (nonatomic,assign) CGFloat minX;
@property (nonatomic,assign) CGFloat scaleY;//Y方向的比例尺
@property (nonatomic,assign) CGFloat scaleX;
@property (nonatomic,assign) CGFloat lineWidth;//线宽
@property (nonatomic,assign) CGFloat lineSpace;//线间距
@property (nonatomic,assign) CGFloat leftMargin;//左边距(最高的蜡烛图距离画板的左边距)
@property (nonatomic,assign) CGFloat rightMargin;
@property (nonatomic,assign) CGFloat topMargin;
@property (nonatomic,assign) CGFloat bottomMargin;
@property (nonatomic,strong) UIColor *lineColor;

@end
