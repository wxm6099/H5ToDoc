//
//  BIBChartPriceView.m
//  WeexApp
//
//  Created by blts on 2018/4/2.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "BIBChartPriceView.h"
#import "UIView+Extension.h"
#import "UIColor+Extension.h"
#import "Masonry.h"

@implementation BIBChartPriceView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(UILabel *)maxPriceLabel
{
    if (!_maxPriceLabel)
    {
        _maxPriceLabel = [self createLabel];
        [self addSubview:_maxPriceLabel];
        [_maxPriceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self);
            make.right.equalTo(self.mas_right).offset(-2);
        }];
    }
    return _maxPriceLabel;
}
-(UILabel *)smallMaxPriceLabel
{
    if (!_smallMaxPriceLabel)
    {
        _smallMaxPriceLabel = [self createLabel];
        [self addSubview:_smallMaxPriceLabel];
        [_smallMaxPriceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            //            make.top.left.equalTo(self);
            //            make.centerY.mas_equalTo(-self.centerY/4);
            make.centerY.mas_equalTo(-self.height/4);
           make.right.equalTo(self.mas_right).offset(-2);
        }];
    }
    return _smallMaxPriceLabel;
}

-(UILabel *)middlePriceLabel
{
    if (!_middlePriceLabel)
    {
        _middlePriceLabel = [self createLabel];
        [self addSubview:_middlePriceLabel];
        [_middlePriceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self);
            make.right.equalTo(self.mas_right).offset(-2);
        }];
    }
    return _middlePriceLabel;
}
-(UILabel *)bigMinPriceLabel
{
    if (!_bigMinPriceLabel)
    {
        _bigMinPriceLabel = [self createLabel];
        [self addSubview:_bigMinPriceLabel];
        [_bigMinPriceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            //            make.bottom.left.equalTo(self);
            //            make.centerY.mas_equalTo(self.centerY/4);
            make.centerY.mas_equalTo(self.height/4);
            make.right.equalTo(self.mas_right).offset(-2);
        }];
    }
    return _bigMinPriceLabel;
}

-(UILabel *)minPriceLabel
{
    if (!_minPriceLabel)
    {
        _minPriceLabel = [self createLabel];
        [self addSubview:_minPriceLabel];
        [_minPriceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self);
            make.right.equalTo(self.mas_right).offset(-2);
        }];
    }
    return _minPriceLabel;
}


-(UILabel*)createLabel
{
    UILabel *label = [UILabel new];
//    label.textColor = [UIColor colorWithStr:@"9ba1ab"];
    label.textColor = self.textColor;
//    label.font = [UIFont systemFontOfSize:12.0];
    label.font = self.textFont;
    label.textAlignment = NSTextAlignmentRight;
    return label;
}
@end
