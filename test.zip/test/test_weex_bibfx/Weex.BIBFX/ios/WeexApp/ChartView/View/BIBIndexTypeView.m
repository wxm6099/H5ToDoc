//
//  BIBIndexTypeView.m
//  WeexApp
//
//  Created by blts on 2018/4/2.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "BIBIndexTypeView.h"
#import "UIColor+Extension.h"
#import "NSString+Extension.h"
#import "Masonry.h"

#define CONSTANT_TAG 100                                 //需要使用tag时添加的常量

@interface BIBIndexTypeView ()

@property (nonatomic,assign) NSInteger currentButtonTag;//选中的第几个按钮

@property (nonatomic,strong) UIScrollView *scrollView_type;
@property (nonatomic,strong) UIView *view_container;//scrollView中内容的辅助view

@end

@implementation BIBIndexTypeView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor colorWithStr:@"e5e5e5"];
        _currentButtonTag = 1 + CONSTANT_TAG;
        [self addSubview:self.scrollView_type];
        [self.scrollView_type addSubview:self.view_container];
    }
    return self;
}
-(void)layoutSubviews
{
    [super layoutSubviews];
    
    [_scrollView_type mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self).insets(UIEdgeInsetsMake(0.5, 0.5, 0, 0.5));
//        make.top.equalTo(self.mas_top).offset(0.5);
//        make.right.equalTo(self).offset(-0.5);
//        make.left.equalTo(self).offset(0.5);
//        make.bottom.equalTo(self).offset(0);
    }];
    [_view_container mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(_scrollView_type);
        make.height.equalTo(_scrollView_type);
    }];
}

-(void)setArray_data:(NSMutableArray *)array_data
{
    _array_data = array_data;
    UIButton *lastbtn = nil;
    for (NSInteger i = 0; i < _array_data.count; i++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.tag = CONSTANT_TAG + i + 1;
        [button setTitle:_array_data[i] forState:UIControlStateNormal];
        [button.titleLabel setFont:[UIFont systemFontOfSize:14.0]];
        [button setTitleColor:[UIColor colorWithStr:@"454950"] forState:UIControlStateNormal];
        if (_currentButtonTag == button.tag) {
            [button setTitleColor:[UIColor colorWithStr:@"e9302e"] forState:UIControlStateNormal];
        }
        [button addTarget:self action:@selector(didClickTheButton:) forControlEvents:UIControlEventTouchUpInside];
        [self.view_container addSubview:button];
        CGFloat titileWidth = [NSString getWidthWithTitle:button.titleLabel.text font:button.titleLabel.font];
        [button mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(self);
            if (lastbtn) {
                make.left.mas_equalTo(lastbtn.mas_right).offset(20);
            }else{
                make.left.mas_equalTo(self.view_container.mas_left).offset(8);
            }
//            make.left.equalTo(self.mas_left).offset(40*i+14*i);
            make.width.equalTo(@(titileWidth));
        }];
        lastbtn = button;
    }
    [_view_container mas_updateConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(lastbtn.mas_right);
    }];
}

#pragma mark private

- (void)didClickTheButton:(UIButton*)button
{
    if (_currentButtonTag == button.tag)
    {
        return;
    }
    button.selected = !button.selected;
    UIButton *prevButton = [self viewWithTag:_currentButtonTag];
    [prevButton setTitleColor:[UIColor colorWithStr:@"454950"] forState:UIControlStateNormal];
    prevButton.selected = NO;
    [button setTitleColor:[UIColor colorWithStr:@"e9302e"] forState:UIControlStateNormal];
    _currentButtonTag = button.tag;
    
    if (self.delagate && [self.delagate respondsToSelector:@selector(didSelectButton:index:)])
    {
        [self.delagate didSelectButton:button index:button.tag - CONSTANT_TAG];
    }
}
-(UIView *)view_container
{
    if (!_view_container) {
        _view_container =[[UIView alloc] init];
        _view_container.backgroundColor = [UIColor colorWithStr:@"ffffff"];
    }
    return _view_container;
}

-(UIScrollView *)scrollView_type
{
    if (!_scrollView_type) {
        _scrollView_type = [UIScrollView new];
        _scrollView_type.scrollEnabled = YES;
        _scrollView_type.bounces = YES;
        _scrollView_type.showsHorizontalScrollIndicator = NO;
        _scrollView_type.backgroundColor = [UIColor whiteColor];
    }
    return _scrollView_type;
}
@end
