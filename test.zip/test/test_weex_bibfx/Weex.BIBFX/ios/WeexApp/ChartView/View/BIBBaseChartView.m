//
//  BIBBaseChartView.m
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "BIBBaseChartView.h"

@implementation BIBBaseChartView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
@synthesize maxY =  _maxY;
@synthesize minY =  _minY;
@synthesize maxX =  _maxX;
@synthesize minX = _minX;
@synthesize scaleY = _scaleY;
@synthesize scaleX = _scaleX;
@synthesize lineWidth = _lineWidth;
@synthesize lineSpace = _lineSpace;
@synthesize leftMargin = _leftMargin;
@synthesize rightMargin = _rightMargin;
@synthesize topMargin = _topMargin;
@synthesize bottomMargin = _bottomMargin;
@synthesize lineColor = _lineColor;

@end
