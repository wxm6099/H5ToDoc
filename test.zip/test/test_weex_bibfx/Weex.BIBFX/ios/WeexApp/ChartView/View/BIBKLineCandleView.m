//
//  BIBKLineCandleView.m
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "BIBKLineCandleView.h"
#import "BIBLineModel.h"
#import "BIBKLineCandlePositionModel.h"
#import "UIColor+Extension.h"
#import "NSString+Extension.h"

#define MINDISPLAYCOUNT 6
#ifdef IGold
#define upColor (@"24b267")
#define downColor (@"FC6767")
#else
#define upColor (@"eb403e")
#define downColor (@"30b700")
#endif
static inline bool isEqualZero(float value)
{
    return fabsf(value) <= 0.00001f;
}

@interface BIBKLineCandleView () <UIScrollViewDelegate,UIGestureRecognizerDelegate>

@property (nonatomic,strong) UIScrollView *superScrollView;
@property (nonatomic,strong) FBKVOController *KVOController;
@property (nonatomic,strong) NSMutableArray *modelArray;
@property (nonatomic,strong) NSMutableArray *modelPostionArray;
@property (nonatomic,strong) CAShapeLayer *lineChartLayer;//k线图的蜡烛线
@property (nonatomic,strong) CAShapeLayer *ma5LineLayer;
@property (nonatomic,strong) CAShapeLayer *ma10LineLayer;
@property (nonatomic,strong) CAShapeLayer *ma25LineLayer;
@property (nonatomic,strong) CAShapeLayer *timeLayer;
@property (nonatomic,strong) NSMutableArray *maPostionArray;

@end

@implementation BIBKLineCandleView

#pragma mark KVO

-(void)didMoveToSuperview
{
    [super didMoveToSuperview];
    _superScrollView = (UIScrollView*)self.superview;
    _superScrollView.delegate = self;
    UIPanGestureRecognizer *panGestureRecognizer = _superScrollView.panGestureRecognizer;
    [panGestureRecognizer addTarget:self action:@selector(panGestureRecognizer:)];
    [self addListener];
}

- (void)addListener
{
    FBKVOController *KVOController = [FBKVOController controllerWithObserver:self];
    self.KVOController = KVOController;
    __weak typeof(self) this = self;
    [self.KVOController observe:_superScrollView keyPath:ContentOffSet options:NSKeyValueObservingOptionNew block:^(id  _Nullable observer, id  _Nonnull object, NSDictionary<NSString *,id> * _Nonnull change) {
        if (self.kvoEnable)
        {
            this.contentOffset = this.superScrollView.contentOffset.x;
            [this drawKLine];
        }
    }];
}

#pragma mark privateMethod

- (void)calcuteMaxAndMinValue
{
    self.maxY = CGFLOAT_MIN;
    self.minY  = CGFLOAT_MAX;
    NSInteger idx = 0;
    for (NSInteger i = idx; i < self.currentDisplayArray.count; i++)
    {
        BIBKLineCandleModel * entity = [self.currentDisplayArray objectAtIndex:i];
        self.minY = self.minY < entity.low ? self.minY : entity.low;
        self.maxY = self.maxY > entity.high ? self.maxY : entity.high;
        
//        if (self.maxY - self.minY < 0.5)
//        {
//            self.maxY += 0.5;
//            self.minY -= 0.5;
//        }
    }
//    self.minY =self.minY - (self.maxY-self.minY)/10;
//    self.maxY = self.maxY + (self.maxY-self.minY)/10;
    self.scaleY = (self.height - self.topMargin - self.bottomMargin - self.timeLayerHeight) / (self.maxY - self.minY);
}
//计算ma线的位置
- (void)calcuteMaLinePostion
{
    [self.maPostionArray removeAllObjects];
    NSMutableArray *maLines = [[NSMutableArray alloc] init];
    NSMutableArray *array = (NSMutableArray*)[[self.currentDisplayArray reverseObjectEnumerator] allObjects];
    [maLines addObject:computeMAData(array,5)];
    [maLines addObject:computeMAData(array,10)];
    [maLines addObject:computeMAData(array,25)];
    for (NSInteger i = 0;i<maLines.count;i++)
    {
        BIBLineData *lineData = [maLines objectAtIndex:i];
        NSMutableArray *array = [NSMutableArray array];
        for (NSInteger j = 0;j <lineData.data.count; j++)
        {
            BIBLineUntil *until = lineData.data[j];
            CGFloat xPosition = self.leftPostion + ((self.candleWidth  + self.candleSpace) * j) + self.candleWidth/2;
            CGFloat yPosition = ((self.maxY - until.value) *self.scaleY) + self.topMargin;
            BIBLineModel *model = [BIBLineModel  initPositon:xPosition yPosition:yPosition color:lineData.color];
            [array addObject:model];
        }
        [self.maPostionArray addObject:array];
    }
}

#pragma mark publicMethod

- (void)setKvoEnable:(BOOL)kvoEnable
{
    _kvoEnable = kvoEnable;
}

- (NSInteger)currentStartIndex
{
    CGFloat scrollViewOffsetX = self.leftPostion < 0 ? 0 : self.leftPostion;
//    NSInteger leftArrCount = ABS(scrollViewOffsetX) / (self.candleWidth+self.candleSpace);
    CGFloat ArrCount = ABS(scrollViewOffsetX) / (self.candleWidth+self.candleSpace);
    NSInteger leftArrCount = roundf(ArrCount);
    //leftArrCount 为70.95  去的70  应该去71
    if (leftArrCount > self.dataArray.count)
    {
        _currentStartIndex = self.dataArray.count - 1;
    }
    
    else if (leftArrCount == 0)
    {
        _currentStartIndex = 0;
    }
    
    else
    {
        _currentStartIndex =  leftArrCount ;
    }
    return _currentStartIndex;
}
- (NSInteger)leftPostion
{
    CGFloat scrollViewOffsetX = _contentOffset <  0  ?  0 : _contentOffset;
    if (_contentOffset + self.superScrollView.width >= self.superScrollView.contentSize.width)
    {
        scrollViewOffsetX = self.superScrollView.contentSize.width - self.superScrollView.width;
    }
    return scrollViewOffsetX;
}

- (void)initCurrentDisplayModels
{
    NSInteger needDrawKLineCount = self.displayCount ;
    NSInteger currentStartIndex = self.currentStartIndex;
    NSInteger count = (currentStartIndex + needDrawKLineCount) >self.dataArray.count ? self.dataArray.count :currentStartIndex+needDrawKLineCount;
    [self.currentDisplayArray removeAllObjects];
    if (currentStartIndex < count)
    {
        for (NSInteger i = currentStartIndex; i <  count ; i++)
        {
            BIBKLineCandleModel *model = self.dataArray[i];
            [self.currentDisplayArray addObject:model];
        }
    }
}

- (void)initModelPositoin
{
    [self.currentPostionArray removeAllObjects];
    for (NSInteger i = 0 ; i < self.currentDisplayArray.count; i++)
    {
        BIBKLineCandleModel *entity  = [self.currentDisplayArray objectAtIndex:i];
        CGFloat open = ((self.maxY - entity.open) * self.scaleY);
        CGFloat close = ((self.maxY - entity.close) * self.scaleY);
        CGFloat high = ((self.maxY - entity.high) * self.scaleY);
        CGFloat low = ((self.maxY - entity.low) * self.scaleY);
        CGFloat left = self.leftPostion+ ((self.candleWidth + self.candleSpace) * i) + self.leftMargin;
        
        if (left >= self.superScrollView.contentSize.width)
        {
            left = self.superScrollView.contentSize.width - self.candleWidth/2.f;
        }
        
        BIBKLineCandlePositionModel *positionModel = [BIBKLineCandlePositionModel modelWithOpen:CGPointMake(left, open) close:CGPointMake(left, close) high:CGPointMake(left, high) low:CGPointMake(left,low) date:entity.date];
        positionModel.isDrawDate = entity.isDrawDate;
        [self.currentPostionArray addObject:positionModel];
    }
}

#pragma mark layer相关

- (void)removeAllSubLayers
{
    for (NSInteger i = 0 ; i < self.lineChartLayer.sublayers.count; i++)
    {
        CAShapeLayer *layer = (CAShapeLayer*)self.lineChartLayer.sublayers[i];
        [layer removeFromSuperlayer];
        layer = nil;
    }
    
    for (NSInteger i = 0 ; i < self.timeLayer.sublayers.count; i++)
    {
        id layer = self.timeLayer.sublayers[i];
        [layer removeFromSuperlayer];
        layer = nil;
    }
}

- (void)initLayer
{
    if (self.timeLayer)
    {
        [self.timeLayer removeFromSuperlayer];
        self.timeLayer = nil;
    }
    
    if (!self.timeLayer)
    {
        self.timeLayer = [CAShapeLayer layer];
        self.timeLayer.contentsScale = [UIScreen mainScreen].scale;
        self.timeLayer.strokeColor = [UIColor clearColor].CGColor;
        self.timeLayer.fillColor = [UIColor clearColor].CGColor;
    }
    [self.layer addSublayer:self.timeLayer];
    
    if (self.lineChartLayer)
    {
        [self.lineChartLayer removeFromSuperlayer];
        self.lineChartLayer = nil;
    }
    
    if (!self.lineChartLayer)
    {
        self.lineChartLayer = [CAShapeLayer layer];
        self.lineChartLayer.strokeColor = [UIColor clearColor].CGColor;
        self.lineChartLayer.fillColor = [UIColor clearColor].CGColor;
    }
    [self.layer addSublayer:self.lineChartLayer];
    

    
    //ma5
    if (self.ma5LineLayer)
    {
        [self.ma5LineLayer removeFromSuperlayer];
    }
    
    if (!self.ma5LineLayer)
    {
        self.ma5LineLayer = [CAShapeLayer layer];
        self.ma5LineLayer.lineWidth = self.lineWidth;
        self.ma5LineLayer.lineCap = kCALineCapRound;
        self.ma5LineLayer.lineJoin = kCALineJoinRound;
    }
    [self.layer addSublayer:self.ma5LineLayer];
    
    //ma10
    if (self.ma10LineLayer)
    {
        [self.ma10LineLayer removeFromSuperlayer];
    }
    
    if (!self.ma10LineLayer)
    {
        self.ma10LineLayer = [CAShapeLayer layer];
        self.ma10LineLayer.lineWidth = self.lineWidth;
        self.ma10LineLayer.lineCap = kCALineCapRound;
        self.ma10LineLayer.lineJoin = kCALineJoinRound;
    }
    [self.layer addSublayer:self.ma10LineLayer];
    
    //ma25
    if (self.ma25LineLayer)
    {
        [self.ma25LineLayer removeFromSuperlayer];
    }
    
    if (!self.ma25LineLayer)
    {
        self.ma25LineLayer = [CAShapeLayer layer];
        self.ma25LineLayer.lineWidth = self.lineWidth;
        self.ma25LineLayer.lineCap = kCALineCapRound;
        self.ma25LineLayer.lineJoin = kCALineJoinRound;
    }
    [self.layer addSublayer:self.ma25LineLayer];
}
//k线图中的蜡烛图画线
- (CAShapeLayer*)getShaperLayer:(BIBKLineCandlePositionModel* )postion
{
    CGFloat openPrice = postion.openPoint.y + self.topMargin;
    CGFloat closePrice = postion.closePoint.y + self.topMargin;
    CGFloat hightPrice = postion.highPoint.y + self.topMargin;
    CGFloat lowPrice = postion.lowPoint.y + self.topMargin;
    CGFloat x = postion.openPoint.x;
    CGFloat y = openPrice > closePrice ? (closePrice) : (openPrice);
    CGFloat height = MAX(fabs(closePrice-openPrice), self.minHeight);
    
    CGRect rect = CGRectMake(x, y, self.candleWidth, height);
    UIBezierPath *path = [UIBezierPath bezierPath];
    CAShapeLayer *subLayer = [CAShapeLayer layer];
    //绿涨（绿色30b700） 红跌（红色eb403e）开盘价和收盘价相等时红
    //计算y轴位置时 最高位置减去开盘价和收盘价的位置  相当于取反，计算的涨跌也要取反
    if (postion.openPoint.y <= postion.closePoint.y)
    {
        subLayer.strokeColor = [UIColor colorWithStr:self.dropColor].CGColor;//蜡烛图中间竖线的颜色(边框色)
        subLayer.fillColor = [UIColor colorWithStr:self.dropColor].CGColor;//k线跌的颜色(框内填充色)
        path = [UIBezierPath drawKLine:openPrice close:closePrice high:hightPrice low:lowPrice candleWidth:self.candleWidth rect:rect xPostion:x lineWidth:self.lineWidth/2 isUp:YES];
    }
    else//跌
    {
        subLayer.strokeColor = [UIColor colorWithStr:self.riseColor].CGColor;//蜡烛图中间竖线的颜色(边框色)
        subLayer.fillColor = [UIColor colorWithStr:self.riseColor].CGColor;//k线涨的颜色(框内填充色)
        path = [UIBezierPath drawKLine:openPrice close:closePrice high:hightPrice low:lowPrice candleWidth:self.candleWidth rect:rect xPostion:x lineWidth:self.lineWidth/2 isUp:NO];
    }
//    UIBezierPath *path = [UIBezierPath drawKLine:openPrice close:closePrice high:hightPrice low:lowPrice candleWidth:self.candleWidth rect:rect xPostion:x lineWidth:self.lineWidth];
//    CAShapeLayer *subLayer = [CAShapeLayer layer];
//    if (postion.openPoint.y >= postion.closePoint.y)
//    {
//        subLayer.strokeColor = RoseColor.CGColor;
//        subLayer.fillColor = RoseColor.CGColor;
//    }
//
//    else
//    {
//        subLayer.strokeColor = DropColor.CGColor;
//        subLayer.fillColor = DropColor.CGColor;
//    }
    
    subLayer.path = path.CGPath;
    subLayer.lineWidth = 0.3;
    [path removeAllPoints];
    return subLayer;
}
//日期值的设置
- (CATextLayer*)getTextLayer
{
    CATextLayer *layer = [CATextLayer layer];
    layer.contentsScale = [UIScreen mainScreen].scale;
    layer.fontSize = 10.f;
    layer.alignmentMode = kCAAlignmentCenter;
    layer.foregroundColor =[UIColor colorWithStr:@"242e3b"].CGColor;
    return layer;
}
//k线图中的时间竖线和报价横线的初始化
- (CAShapeLayer*)getAxispLayer
{
    CAShapeLayer *layer = [CAShapeLayer layer];
    layer.strokeColor = [UIColor colorWithHexString:@"e5e5e5"].CGColor;
    layer.fillColor = [[UIColor clearColor] CGColor];
    layer.contentsScale = [UIScreen mainScreen].scale;
    layer.lineDashPattern = @[@4,@2];
    return layer;
}

#pragma mark draw

- (void)drawCandleSublayers
{
    __weak typeof(self) this = self;
    [_currentPostionArray enumerateObjectsUsingBlock:^(BIBKLineCandlePositionModel *obj, NSUInteger idx, BOOL * _Nonnull stop) {
        CAShapeLayer *subLayer = [this getShaperLayer:obj];
        [this.lineChartLayer addSublayer:subLayer];
    }];
}
//k线图中的3条折线图(ma5,ma10,ma15)
- (void)drawMALineLayer
{
    NSMutableArray *pathsArray = [UIBezierPath drawLines:self.maPostionArray];
    
    BIBLineModel *ma5Model = self.maPostionArray[0][0];
    BIBLineModel *ma10Model = self.maPostionArray[1][0];
    BIBLineModel *ma25Model = self.maPostionArray[2][0];
    
    UIBezierPath *ma5Path = pathsArray[0];
    self.ma5LineLayer.path = ma5Path.CGPath;
    self.ma5LineLayer.strokeColor = ma5Model.lineColor.CGColor;
    self.ma5LineLayer.fillColor = [[UIColor clearColor] CGColor];
    self.ma5LineLayer.contentsScale = [UIScreen mainScreen].scale;
    
    UIBezierPath *ma10Path = pathsArray[1];
    self.ma10LineLayer.path = ma10Path.CGPath;
    self.ma10LineLayer.strokeColor = ma10Model.lineColor.CGColor;
    self.ma10LineLayer.fillColor = [[UIColor clearColor] CGColor];
    self.ma10LineLayer.contentsScale = [UIScreen mainScreen].scale;
    
    UIBezierPath *ma25Path = pathsArray[2];
    self.ma25LineLayer.path = ma25Path.CGPath;
    self.ma25LineLayer.strokeColor = ma25Model.lineColor.CGColor;
    self.ma25LineLayer.fillColor = [[UIColor clearColor] CGColor];
    self.ma25LineLayer.contentsScale = [UIScreen mainScreen].scale;
}

- (void)drawMALayer
{
    [self calcuteMaLinePostion];
    [self drawMALineLayer];
}
//时间线(竖线)
- (void)drawTimeLayer
{
    [self.currentPostionArray enumerateObjectsUsingBlock:^(BIBKLineCandlePositionModel *model, NSUInteger idx, BOOL * _Nonnull stop) {
        if (model.isDrawDate)
        {
            //日期时间值
            CATextLayer *layer = [self getTextLayer];
            layer.foregroundColor = [UIColor colorWithStr:@"242e3b"].CGColor;
            UIFont *font = [UIFont systemFontOfSize:10.0];
            CFStringRef fontName = (__bridge CFStringRef)font.fontName;
            CGFontRef fontRef = CGFontCreateWithFontName(fontName);
            layer.font = fontRef;
            layer.fontSize = font.pointSize;
            CGFontRelease(fontRef);
        
            layer.string = model.date;
            if (isEqualZero(model.highPoint.x)){
                //CATextLayer 没有属性设置字体内容居中 y的距离加1/3  高度值设置2/3
                layer.frame =  CGRectMake(0, self.height+self.timeLayerHeight/3, 60, self.timeLayerHeight*2/3);
            }else{
                layer.position = CGPointMake(model.highPoint.x + self.candleWidth, self.height + self.timeLayerHeight/2);
                layer.bounds = CGRectMake(0, 0, 60, self.timeLayerHeight*2/3);
            }
            [self.timeLayer addSublayer:layer];
            
            //时间线
            CAShapeLayer *lineLayer = [self getAxispLayer];
            UIBezierPath *path = [UIBezierPath bezierPath];
            path.lineWidth = self.lineWidth;
            lineLayer.lineWidth = self.lineWidth;
            
            CGFloat hightPrice = model.highPoint.y + self.topMargin;
            CGFloat lowPrice = model.lowPoint.y + self.topMargin;
            [path moveToPoint:CGPointMake(model.highPoint.x + self.candleWidth/2 - self.lineWidth/2, 1*heightradio)];//时间竖线的轨迹起点
            [path addLineToPoint:CGPointMake(model.highPoint.x + self.candleWidth/2 - self.lineWidth/2 ,hightPrice)];//时间竖线的轨迹在蜡烛图最高点结束
            
            [path moveToPoint:CGPointMake(model.highPoint.x + self.candleWidth/2 - self.lineWidth/2, lowPrice)];//时间竖线的轨迹在蜡烛图最低点再次开始
            [path addLineToPoint:CGPointMake(model.highPoint.x + self.candleWidth/2 - self.lineWidth/2 ,self.height)];//时间竖线的轨迹终点
            lineLayer.path = path.CGPath;
            [self.timeLayer addSublayer:lineLayer];
        }
    }];
}
//报价线（横线)
- (void)drawAxisLine
{
    CGFloat klineWidth = (self.dataArray.count)*self.candleWidth+self.candleSpace*(self.dataArray.count)+self.rightMargin+self.leftMargin;
//    CGFloat bottomHeight = self.height - self.bottomMargin - self.topMargin;
    CGFloat bottomHeight = self.height;//项目需求top和bottom间距保留 报价的不保留
    
    CAShapeLayer *topCentXLayer = [self getAxispLayer];
    UIBezierPath *topPath = [UIBezierPath bezierPath];
    [topPath moveToPoint:CGPointMake(0,(bottomHeight-self.centerY)/2)];
    [topPath addLineToPoint:CGPointMake(klineWidth,(bottomHeight-self.centerY)/2)];
    topCentXLayer.path = topPath.CGPath;
    topCentXLayer.lineWidth = self.lineWidth/2;
    [self.timeLayer addSublayer:topCentXLayer];
    
    CAShapeLayer *centXLayer = [self getAxispLayer];
    UIBezierPath *cPath = [UIBezierPath bezierPath];
    [cPath moveToPoint:CGPointMake(0,self.centerY)];
    [cPath addLineToPoint:CGPointMake(klineWidth,self.centerY)];
    centXLayer.path = cPath.CGPath;
    centXLayer.lineWidth = self.lineWidth/2;
    [self.timeLayer addSublayer:centXLayer];
    
    CAShapeLayer *bottomCentXLayer = [self getAxispLayer];
    UIBezierPath *bottomPath = [UIBezierPath bezierPath];
    [bottomPath moveToPoint:CGPointMake(0,(bottomHeight+self.centerY)/2)];
    [bottomPath addLineToPoint:CGPointMake(klineWidth,(bottomHeight+self.centerY)/2)];
    bottomCentXLayer.path = bottomPath.CGPath;
    bottomCentXLayer.lineWidth = self.lineWidth/2;
    [self.timeLayer addSublayer:bottomCentXLayer];
    
//    CAShapeLayer *bottomLayer = [self getAxispLayer];
//    bottomLayer.strokeColor = [UIColor redColor].CGColor;
//    bottomLayer.lineWidth = self.lineWidth;
//    UIBezierPath *bpath = [UIBezierPath bezierPath];
//    [bpath moveToPoint:CGPointMake(0, self.height - self.timeLayerHeight - self.bottomMargin)];
//    [bpath addLineToPoint:CGPointMake(self.width, self.height - self.timeLayerHeight - self.bottomMargin)];
//    bottomLayer.path = bpath.CGPath;
//    [self.timeLayer addSublayer:bottomLayer];
//
//    CAShapeLayer *centXLayer = [self getAxispLayer];
//    centXLayer.strokeColor = [UIColor blueColor].CGColor;
//    UIBezierPath *xPath = [UIBezierPath bezierPath];
//    [xPath moveToPoint:CGPointMake(0,self.centerY)];
//    [xPath addLineToPoint:CGPointMake(klineWidth,self.centerY)];
//    centXLayer.path = xPath.CGPath;
//    centXLayer.lineWidth = self.lineWidth;
//    [self.timeLayer addSublayer:centXLayer];
}

#pragma mark 绘制
//计算单个蜡烛图的宽度
- (void)calcuteCandleWidth
{
    self.candleWidth = (self.superScrollView.width - (self.displayCount - 1) * self.candleSpace - self.leftMargin - self.rightMargin) / self.displayCount;
}
//更新蜡烛图约束(宽度)
- (void)updateWidth
{
    CGFloat klineWidth = self.dataArray.count*(self.candleWidth) + (self.dataArray.count - 1 ) *self.candleSpace + self.leftMargin + self.rightMargin;
    if(klineWidth < self.superScrollView.width)
    {
        klineWidth = self.superScrollView.width;
    }
    
    [self mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@(klineWidth));
    }];
    
    self.superScrollView.contentSize = CGSizeMake(klineWidth,0);
    [self layoutIfNeeded];
    self.superScrollView.contentOffset = CGPointMake(klineWidth - self.superScrollView.width, 0);
}

-(void)initConfig
{
    if ([NSString isBlankString:[NSString stringWithFormat:@"%f",self.leftMargin]]) {
        self.leftMargin = 2;
    }
    if ([NSString isBlankString:[NSString stringWithFormat:@"%f",self.rightMargin]]) {
        self.rightMargin = 2;
    }
    if ([NSString isBlankString:[NSString stringWithFormat:@"%f",self.topMargin]]) {
        self.topMargin = 2;
    }
    if ([NSString isBlankString:[NSString stringWithFormat:@"%f",self.bottomMargin]]) {
        self.bottomMargin = 2;
    }
    if ([NSString isBlankString:[NSString stringWithFormat:@"%f",self.minHeight]]) {
        self.minHeight = 0.5;
    }
    if ([NSString isBlankString:[NSString stringWithFormat:@"%f",self.timeLayerHeight]]) {
        self.timeLayerHeight = 20;
    }
    self.kvoEnable = YES;
    
}

- (void)drawKLine
{
    [self removeAllSubLayers];
    [self initCurrentDisplayModels];
    if (self.delegate && [self.delegate respondsToSelector: @selector(displayScreenleftPostion:startIndex:count:)])
    {
        [_delegate displayScreenleftPostion:self.leftPostion startIndex:self.currentStartIndex count:self.displayCount];
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(displayLastModel:)])
    {
        BIBKLineCandleModel *lastModel = self.currentDisplayArray.lastObject;
        [_delegate displayLastModel:lastModel];
    }
    
    [self calcuteMaxAndMinValue];
    [self initLayer];
    [self initModelPositoin];
    [self drawCandleSublayers];
//    [self drawMALayer];
    [self drawTimeLayer];
    [self drawAxisLine];
}

- (void)stockFill
{
    [self initConfig];
    [self initLayer];
    [self.superScrollView layoutIfNeeded];
    [self calcuteCandleWidth];
    [self updateWidth];
    [self drawKLine];
}

- (void)reload
{
    if (self.dataArray.count == 0)
    {
        [self mas_updateConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo(@(self.superScrollView.width));
        }];
        
        self.superScrollView.contentSize = CGSizeMake(self.superScrollView.width,0);
        return;
    }
    
    CGFloat prevContentOffset = self.superScrollView.contentSize.width;
    CGFloat klineWidth = self.dataArray.count*(self.candleWidth) + (self.dataArray.count - 1) *self.candleSpace + self.leftMargin + self.rightMargin;
    if(klineWidth < self.superScrollView.width)
    {
        klineWidth = self.superScrollView.width;
    }
    
    [self mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@(klineWidth));
    }];
    
    self.superScrollView.contentSize = CGSizeMake(klineWidth,0);
    self.superScrollView.contentOffset = CGPointMake(klineWidth - prevContentOffset,0);
    [self layoutIfNeeded];
    [self drawKLine];
}

#pragma mark 长按获取坐标

-(CGPoint)getLongPressModelPostionWithXPostion:(CGFloat)xPostion
{
    CGFloat localPostion = xPostion;
    NSInteger startIndex = (NSInteger)((localPostion - self.leftPostion) / (self.candleSpace + self.candleWidth));
    NSInteger arrCount = self.currentPostionArray.count;
    for (NSInteger index = startIndex > 0 ? startIndex - 1 : 0; index < arrCount; ++index) {
        BIBKLineCandlePositionModel *kLinePositionModel = self.currentPostionArray[index];
        
        CGFloat minX = kLinePositionModel.highPoint.x - (self.candleSpace + self.candleWidth/2);
        CGFloat maxX = kLinePositionModel.highPoint.x + (self.candleSpace + self.candleWidth/2);
        
        if(localPostion > minX && localPostion < maxX)
        {
            if(self.delegate && [self.delegate respondsToSelector:@selector(longPressCandleViewWithIndex:kLineModel:)])
            {
                [self.delegate longPressCandleViewWithIndex:index kLineModel:self.currentDisplayArray[index]];
            }
            
            return CGPointMake(kLinePositionModel.highPoint.x, kLinePositionModel.openPoint.y);
        }
    }
    
    //最后一根线
    BIBKLineCandlePositionModel *lastPositionModel = self.currentPostionArray.lastObject;
    
    if (localPostion >= lastPositionModel.closePoint.x)
    {
        return CGPointMake(lastPositionModel.highPoint.x, lastPositionModel.openPoint.y);
    }
    
    //第一根线
    BIBKLineCandlePositionModel *firstPositionModel = self.currentPostionArray.firstObject;
    if (firstPositionModel.closePoint.x >= localPostion)
    {
        return CGPointMake(firstPositionModel.highPoint.x, firstPositionModel.openPoint.y);
    }
    
    return CGPointZero;
}

#pragma mark panGestureRecognizerAction

- (void)panGestureRecognizer:(UIPanGestureRecognizer*)panGestureRecognizer
{
    switch (panGestureRecognizer.state)
    {
        case UIGestureRecognizerStateBegan:
        {
            
        }break;
            
        case UIGestureRecognizerStateChanged:
        {
            
        }break;
            
        case UIGestureRecognizerStateEnded:
        {
            //滑到最右侧(即不能再向左滑动时)的偏移量，此时的偏移量就是ScrollView的宽度
            self.previousOffsetX = _superScrollView.contentSize.width  -_superScrollView.contentOffset.x;
            //可以向右刷新最新数据的临界值
            CGFloat float_right = self.previousOffsetX - _superScrollView.width;
            if (float_right <= -5) {
//                NSLog(@"向左滑动达到右侧刷新的临界值，刷新未来的最新数据");
                if (self.delegate && [self.delegate respondsToSelector:@selector(displayMoreData:)])
                {
                    //记录上一次的偏移量
                    self.previousOffsetX = _superScrollView.contentSize.width  -_superScrollView.contentOffset.x;
                    [_delegate displayMoreData:NO];
                }
            }else if (self.superScrollView.contentOffset.x <= -5)//给定一个临界初始值(负数:超过这个值就加载)
            {
//                NSLog(@"向右滑动达到左侧加载的临界值，家在过去的历史数据");
                if (self.delegate && [self.delegate respondsToSelector:@selector(displayMoreData:)])
                {
                    //记录上一次的偏移量
                    self.previousOffsetX = _superScrollView.contentSize.width  -_superScrollView.contentOffset.x;
                    [_delegate displayMoreData:YES];
                }
            }
//            //给定一个临界初始值(负数)
//            if (self.superScrollView.contentOffset.x <= -5)
//            {
//                if (self.delegate && [self.delegate respondsToSelector:@selector(displayMoreData)])
//                {
//                    //记录上一次的偏移量
//                    self.previousOffsetX = _superScrollView.contentSize.width  -_superScrollView.contentOffset.x;
//                    [_delegate displayMoreData];
//                }
//            }
        }break;
        default:
            break;
    }
}






#pragma mark setter

- (NSMutableArray*)modelPostionArray
{
    if (!_modelPostionArray)
    {
        _modelPostionArray = [NSMutableArray array];
    }
    return _modelPostionArray;
}

- (NSMutableArray*)currentDisplayArray
{
    if (!_currentDisplayArray)
    {
        _currentDisplayArray = [NSMutableArray array];
    }
    return _currentDisplayArray;
}

- (NSMutableArray*)currentPostionArray
{
    if (!_currentPostionArray)
    {
        _currentPostionArray = [NSMutableArray array];
    }
    return _currentPostionArray;
}

- (NSMutableArray*)maPostionArray
{
    if (!_maPostionArray)
    {
        _maPostionArray = [NSMutableArray array];
    }
    return _maPostionArray;
}

@end
