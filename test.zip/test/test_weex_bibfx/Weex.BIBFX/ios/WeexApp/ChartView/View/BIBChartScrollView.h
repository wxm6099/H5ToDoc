//
//  BIBChartScrollView.h
//  WeexApp
//
//  Created by blts on 2018/4/2.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIBChartScrollView : UIScrollView

@property (nonatomic,strong) NSMutableDictionary *dic_tecnnical;//存储指标title的数据值的字典

@end
