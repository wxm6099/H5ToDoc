//
//  BIBMACDLineView.h
//  WeexApp
//
//  Created by blts on 2018/4/2.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "BIBBaseChartView.h"
#import "BIBMacdModel.h"

@interface BIBMACDLineView : BIBBaseChartView

@property (nonatomic,strong) NSMutableArray <__kindof BIBMacdModel*>*dataArray;

@property (nonatomic,assign) CGFloat    leftPostion;
@property (nonatomic,assign) NSInteger startIndex;
@property (nonatomic,assign) NSInteger displayCount;
@property (nonatomic,assign) CGFloat    candleWidth;
@property (nonatomic,assign) CGFloat    candleSpace;

- (void)stockFill;

@end
