//
//  BIBKLineCandleView.h
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "BIBBaseChartView.h"
#import "BIBKLineCandleModel.h"

@protocol  BIBKLineCandleViewProtocol <NSObject>

@optional

/**
 取得当前屏幕内模型数组的开始下标以及个数
 
 @param leftPostion 当前屏幕最右边的位置
 @param index 下标
 @param count 个数
 */
- (void)displayScreenleftPostion:(CGFloat)leftPostion startIndex:(NSInteger)index count:(NSInteger)count;

/**
 长按手势获得当前k线下标以及模型
 
 @param kLineModeIndex 当前k线在可视范围数组的位置下标
 @param kLineModel   k线模型
 */
- (void)longPressCandleViewWithIndex:(NSInteger)kLineModeIndex kLineModel:(BIBKLineCandleModel *)kLineModel;

/**
 返回当前屏幕最后一根k线模型
 
 @param kLineModel k线模型
 */
- (void)displayLastModel:(BIBKLineCandleModel *)kLineModel;

/**
 **加载更多数据
 **
 ** @param isRightMove 是否是向右滑动加载更多历史数据（向左滑动刷新最新数据）
 */
- (void)displayMoreData:(BOOL)isRightMove;

@end



@interface BIBKLineCandleView : BIBBaseChartView

/**
 数据源数组 在调用绘制方法之前设置
 */
@property (nonatomic,strong) NSMutableArray<__kindof BIBKLineCandleModel*> *dataArray;

/**
 当前屏幕范围内显示的k线模型数组
 */
@property (nonatomic,strong) NSMutableArray *currentDisplayArray;

/**
 当前屏幕范围内显示的k线位置数组
 */
@property (nonatomic,strong) NSMutableArray *currentPostionArray;

/**
 可视区域显示多少根k线
 */
@property (nonatomic,assign) NSInteger displayCount;

/**
 k线之间的距离
 */
@property (nonatomic,assign) CGFloat candleSpace;

/**
 k线的宽度 根据每页k线的根数和k线之间的距离动态计算得出
 */
@property (nonatomic,assign) CGFloat candleWidth;

/**
 k线最小高度
 */
@property (nonatomic,assign) CGFloat minHeight;

/**
 当前屏幕范围内绘制起点位置
 */
@property (nonatomic,assign) NSInteger leftPostion;

/**
 当前绘制的起始下标
 */
@property (nonatomic,assign) NSInteger currentStartIndex;

/**
 滑到最右侧的偏移量
 */
@property (nonatomic,assign) CGFloat previousOffsetX;

/**
 当前偏移量
 */
@property (nonatomic,assign) CGFloat contentOffset;
/**
 是否是KVO观察者模式
 */
@property (nonatomic,assign) BOOL kvoEnable;
/**
 k线图中底部显示时间值区域的高度
 */
@property (nonatomic,assign) CGFloat timeLayerHeight;
/**
 k线图中下跌的颜色
 */
@property (nonatomic,copy) NSString* dropColor;
/**
 k线图中上涨的颜色
 */
@property (nonatomic,copy) NSString* riseColor;
/**
 长按手势返回对应model的相对位置
 
 @param xPostion 手指在屏幕的位置
 @return 距离手指位置最近的model位置
 */
- (CGPoint)getLongPressModelPostionWithXPostion:(CGFloat)xPostion;

/**
 填充
 */
- (void)stockFill;

/**
 刷新右拉加载调用
 */
- (void)reload;

/**
 宽度计算
 */
- (void)calcuteCandleWidth;

/**
 更新宽度
 */
- (void)updateWidth;

/**
 绘制主方法
 */
- (void)drawKLine;

@property (nonatomic,weak) id <BIBKLineCandleViewProtocol> delegate;

@end
