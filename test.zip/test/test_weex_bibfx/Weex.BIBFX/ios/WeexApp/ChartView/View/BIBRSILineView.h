//
//  BIBRSILineView.h
//  WeexApp
//
//  Created by blts on 2018/4/2.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "BIBBaseChartView.h"

@interface BIBRSILineView : BIBBaseChartView
@property (nonatomic,strong) NSMutableArray *dataArray;
@property (nonatomic, assign) CGFloat leftPostion;
@property (nonatomic, assign) CGFloat candleWidth;
@property (nonatomic, assign) CGFloat candleSpace;
@property (nonatomic, assign) NSInteger startIndex;
@property (nonatomic, assign) NSInteger displayCount;

- (void)stockFill;
@end
