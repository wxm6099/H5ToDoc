//
//  BIBCalculationTool.h
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "ta_libc.h"
#import "BIBLineData.h"

BIBLineData * computeMAData(NSArray *items,int period);
NSMutableArray* computeMACDData(NSArray *items);
NSMutableArray *computeKDJData(NSArray *items);
NSMutableArray *computeWRData(NSArray *items,int period);
