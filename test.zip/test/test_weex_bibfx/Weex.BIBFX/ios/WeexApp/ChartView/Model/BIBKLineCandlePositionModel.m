//
//  BIBKLineCandlePositionModel.m
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "BIBKLineCandlePositionModel.h"

@implementation BIBKLineCandlePositionModel

+ (instancetype)modelWithOpen:(CGPoint)openPoint close:(CGPoint)closePoint high:(CGPoint)highPoint low:(CGPoint)lowPoint date:(NSString *)date
{
    BIBKLineCandlePositionModel *candleModel = [BIBKLineCandlePositionModel new];
    candleModel.openPoint = openPoint;
    candleModel.closePoint = closePoint;
    candleModel.highPoint = highPoint;
    candleModel.lowPoint = lowPoint;
    candleModel.date = date;
    return candleModel;
}

@end
