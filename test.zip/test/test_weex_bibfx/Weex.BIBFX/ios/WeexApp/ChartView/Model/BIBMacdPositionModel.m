//
//  BIBMacdPositionModel.m
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "BIBMacdPositionModel.h"

@implementation BIBMacdPositionModel

+(instancetype)initPostion:(CGPoint)startPoint endPoint:(CGPoint)endPoint
{
    BIBMacdPositionModel *model = [[BIBMacdPositionModel alloc] init];
    model.startPoint = startPoint;
    model.endPoint = endPoint;
    return model;
}

@end
