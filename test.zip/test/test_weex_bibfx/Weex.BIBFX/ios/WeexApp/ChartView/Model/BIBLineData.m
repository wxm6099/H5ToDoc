//
//  BIBLineData.m
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "BIBLineData.h"

@implementation BIBLineData

- (id)initWithData:(NSMutableArray *)data color:(UIColor *)color title:(NSString *)title
{
    self = [self init];
    if (self)
    {
        self.data = data;
        self.color = color;
        self.title = title;
    }
    
    return self;
}

@end
