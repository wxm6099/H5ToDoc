//
//  BIBKLineCandlePositionModel.h
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BIBKLineCandlePositionModel : NSObject

/**
 *  开盘点位置
 */
@property (nonatomic, assign) CGPoint openPoint;

/**
 *  收盘点位置
 */
@property (nonatomic, assign) CGPoint closePoint;

/**
 *  最高点位置
 */
@property (nonatomic, assign) CGPoint highPoint;

/**
 *  最低点位置
 */
@property (nonatomic, assign) CGPoint lowPoint;

/**
 *  日期
 */
@property (nonatomic, copy) NSString *date;
/**
 *  是否画日期时间竖线
 */
@property (nonatomic,assign) BOOL isDrawDate;

+ (instancetype) modelWithOpen:(CGPoint )openPoint close:(CGPoint )closePoint high:(CGPoint )highPoint low:(CGPoint )lowPoint date:(NSString* )date;

@end
