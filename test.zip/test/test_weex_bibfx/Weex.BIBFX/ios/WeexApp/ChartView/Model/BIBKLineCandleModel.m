//
//  BIBKLineCandleModel.m
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "BIBKLineCandleModel.h"

@implementation BIBKLineCandleModel

- (instancetype)initWithDictionary:(NSDictionary *)dict

{
    
    if (self = [super init]) {
        
        [self setValuesForKeysWithDictionary:dict];
        
    }
    
    return self;
    
}

+ (instancetype)provinceWithDictionary:(NSDictionary *)dict

{
    
    return [[self alloc] initWithDictionary:dict];
    
}

-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}

@end
