//
//  BIBLineUntil.h
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BIBLineUntil : NSObject

@property(assign, nonatomic) double value;
@property(retain, nonatomic) NSString *date;

- (id)initWithValue:(double)value date:(NSString *)date;

@end
