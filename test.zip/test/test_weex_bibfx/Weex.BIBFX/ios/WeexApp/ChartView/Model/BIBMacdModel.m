//
//  BIBMacdModel.m
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import "BIBMacdModel.h"

@implementation BIBMacdModel

- (id)initWithDea:(double)dea diff:(double)diff macd:(double)macd date:(NSString *)date
{
    BIBMacdModel *model = [[BIBMacdModel alloc] init];
    model.dea = dea;
    model.diff = diff;
    model.macd = macd;
    model.date = date;
    return model;
}

@end
