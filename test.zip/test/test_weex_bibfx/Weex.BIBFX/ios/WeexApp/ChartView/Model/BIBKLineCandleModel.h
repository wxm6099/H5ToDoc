//
//  BIBKLineCandleModel.h
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BIBKLineCandleModel : NSObject

@property (assign, nonatomic) CGFloat high;
@property (assign, nonatomic) CGFloat low;
@property (assign, nonatomic) CGFloat open;
@property (assign, nonatomic) CGFloat close;
@property (copy,   nonatomic) NSString *date;
@property (assign, nonatomic) BOOL isDrawDate;

@property (copy,   nonatomic) NSString *year;
@property (copy,   nonatomic) NSString *month;
@property (copy,   nonatomic) NSString *day;
@property (copy,   nonatomic) NSString *hour;
@property (copy,   nonatomic) NSString *minute;
@property (copy,   nonatomic) NSString *modifyTime;
@property (copy,   nonatomic) NSString *dateTime;
@property (copy,   nonatomic) NSString *digits;
@property (copy,   nonatomic) NSString *priceID;
@property (copy,   nonatomic) NSString *symbolName;
@property (assign, nonatomic) CGFloat yClose;



- (instancetype)initWithDictionary:(NSDictionary *)dict;

+ (instancetype)provinceWithDictionary:(NSDictionary *)dict;








@end
