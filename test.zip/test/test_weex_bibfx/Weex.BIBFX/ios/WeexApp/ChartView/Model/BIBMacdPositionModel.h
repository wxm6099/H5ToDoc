//
//  BIBMacdPositionModel.h
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BIBMacdPositionModel : NSObject

@property (nonatomic,assign) CGPoint startPoint;
@property (nonatomic,assign) CGPoint endPoint;

+ (instancetype)initPostion:(CGPoint)startPoint endPoint:(CGPoint)endPoint;

@end
