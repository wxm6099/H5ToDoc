//
//  BIBMacdModel.h
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BIBMacdModel : NSObject

@property(assign, nonatomic) double dea;
@property(assign, nonatomic) double diff;
@property(assign, nonatomic) double macd;
@property(copy,   nonatomic) NSString *date;

- (id)initWithDea:(double)dea diff:(double)diff macd:(double)macd date:(NSString *)date;

@end
