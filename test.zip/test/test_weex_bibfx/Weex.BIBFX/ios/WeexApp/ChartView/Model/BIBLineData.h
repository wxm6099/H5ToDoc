//
//  BIBLineData.h
//  WeexApp
//
//  Created by blts on 2018/3/30.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BIBLineData : NSObject

@property (nonatomic,copy) NSArray *data;
@property (nonatomic,copy)   NSString *title;
@property (nonatomic,strong) UIColor *color;

- (id)initWithData:(NSMutableArray *)data color:(UIColor *)color title:(NSString *)title;

@end
