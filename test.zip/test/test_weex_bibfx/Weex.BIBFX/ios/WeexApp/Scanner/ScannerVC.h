//
//  ScannerVC.h
//  BibGold
//
//  Created by Richard on 2019/3/25.
//  Copyright © 2019年 Fantasy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "QRCodeReaderView.h"
#import "AppDefine.h"
NS_ASSUME_NONNULL_BEGIN

@interface ScannerVC :  UIViewController <AVCaptureMetadataOutputObjectsDelegate>
@property (nonatomic, weak) id<QRCodeReaderViewDelegate> delegate;

// 开启关闭扫描
- (void)start;
- (void)stop;
@end

NS_ASSUME_NONNULL_END
