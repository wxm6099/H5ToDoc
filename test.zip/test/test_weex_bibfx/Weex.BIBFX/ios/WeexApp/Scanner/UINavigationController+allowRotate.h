//
//  UINavigationController+allowRotate.h
//  Acetop
//
//  Created by Fantasy on 2019/6/19.
//  Copyright © 2019 Acetop. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UINavigationController (allowRotate)

@end

NS_ASSUME_NONNULL_END
