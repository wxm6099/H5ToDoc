//
//  UINavigationController+allowRotate.m
//  Acetop
//
//  Created by Fantasy on 2019/6/19.
//  Copyright © 2019 Acetop. All rights reserved.
//

#import "UINavigationController+allowRotate.h"

@implementation UINavigationController (allowRotate)

- (BOOL)shouldAutorotate{
    return self.topViewController.shouldAutorotate;
}
- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return self.topViewController.supportedInterfaceOrientations;
}

//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
//{
//    return UIInterfaceOrientationPortrait;
//}


@end
