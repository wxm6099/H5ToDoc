/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

#import "AppDelegate.h"
#import "SessionModule.h"
#import "FileManagerModule.h"
#import "WXImgLoaderDefaultImpl.h"
#import "AppDefine.h"
#import "UIView+UIThreadCheck.h"
#import <WeexSDK/WeexSDK.h>
#import <WeexSDK/WXStorageModule.h>
#import <AVFoundation/AVFoundation.h>
#import "WXConfigCenterProtocol.h"
#import "WXConfigCenterDefaultImpl.h"
#import "WXNavigationHandlerImpl.h"
#import "WXApmGeneratorImpl.h"
#import "WXWebSocketDefaultImpl.h"
#import <SSZipArchive.h>
#import <WebKit/WebKit.h>
#import <Firebase/Firebase.h>
#import "Reachability.h"
#import "NSString+CODEC.h"

#ifdef UMAnalytics
#import <UMCommon/UMCommon.h>
#endif
// 引入JPush功能所需头文件
#import "JPUSHService.h"
// iOS10注册APNs所需头文件
#ifdef NSFoundationVersionNumber_iOS_9_x_Max
#import <UserNotifications/UserNotifications.h>
#endif

// 如果需要使用idfa功能所需要引入的头文件（可选）
#import <AdSupport/AdSupport.h>
#import "UncaughtExceptionHandler.h"

@interface AppDelegate ()<JPUSHRegisterDelegate>
@property (nonatomic, assign) bool background;//  进入后台标记
@property (nonatomic, copy) NSString* docPath;
@property (nonatomic, copy) NSString* appNetWork;
@property (nonatomic) Reachability *hostReachability;
@end

@implementation AppDelegate

#pragma mark
#pragma mark application

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [self setNetWork];
    [self initWeexSDK];
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];
    self.docPath = [WXUtility documentDirectory];
    
    [self checkUpdate];
#ifdef DEBUG
    self.window.rootViewController = [[WXRootViewController alloc] initWithSourceURL:[NSURL URLWithString:BUNDLE_URL]];
#else
    NSString *filePath = [self.docPath stringByAppendingPathComponent:INDEX];
    if([[NSFileManager defaultManager] fileExistsAtPath:filePath]){
        self.window.rootViewController = [[WXRootViewController alloc] initWithSourceURL:[NSURL fileURLWithPath:filePath]];
    }else{
        self.window.rootViewController = [[WXRootViewController alloc] initWithSourceURL:[NSURL URLWithString:BUNDLE_URL]];
    }
#endif

    [self.window makeKeyAndVisible];
    [self setUserAgent];
    
    //后台音乐播放
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
    [audioSession setCategory:AVAudioSessionCategoryPlayback error:nil];
    [audioSession setActive:YES error:nil];

    if (![[NSUserDefaults standardUserDefaults] boolForKey: @"initial"]) {
        [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"initial"];
        dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW,(int64_t)(10 * NSEC_PER_SEC));
        dispatch_after(time, dispatch_get_main_queue(),^{
            [self registJpush:launchOptions];
        });
    }else{
        [self registJpush:launchOptions];
    }
    
#ifdef FIREBASE
     //谷歌firebase设置
    [FIRApp configure];
    [FIRAnalytics setUserPropertyString:CHANNEL forName:@"channel"];
#endif
    
#ifdef UMAnalytics
    [UMConfigure initWithAppkey:kUMKEY channel:CHANNEL];
#endif
#ifdef DEBUG
    NSLog(@"UUID:%@",[[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString]);
#endif
    return YES;
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey, id> *)options{
    return YES;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kReachabilityChangedNotification object:nil];
}
-(void)setNetWork
{
    /*
     Observe the kNetworkReachabilityChangedNotification. When that notification is posted, the method reachabilityChanged will be called.
     */
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reachabilityChanged:) name:kReachabilityChangedNotification object:nil];
    //Change the host name here to change the server you want to monitor.
    self.hostReachability = [Reachability reachabilityWithHostName:@"www.baidu.com"];
    [self.hostReachability startNotifier];
    [self updateInterfaceWithReachability:self.hostReachability];
}
/*!
 * Called by Reachability whenever status changes.
 */
- (void) reachabilityChanged:(NSNotification *)note
{
    Reachability* curReach = [note object];
    NSParameterAssert([curReach isKindOfClass:[Reachability class]]);
    [self updateInterfaceWithReachability:curReach];
}
- (void)updateInterfaceWithReachability:(Reachability *)reachability
{
    NSString *status = @"NONE";
    if (![NSString isBlankString:self.appNetWork]) {
        status = self.appNetWork;
    }
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    [dic setObject:status forKey:@"oldStatus"];
    if (reachability == self.hostReachability){
        NetworkStatus netStatus = [reachability currentReachabilityStatus];
        switch (netStatus)
        {
            case NotReachable:        {
                status = @"NONE";
                break;
            }
            case ReachableViaWWAN:    {
                status = @"WWAN";
                break;
            }
            case ReachableViaWiFi:    {
                status = @"WIFI";
                break;
            }
        }
        self.appNetWork = status;
        [dic setObject:self.appNetWork forKey:@"netStatus"];
        [[NSUserDefaults standardUserDefaults] setObject:dic forKey:@"netWorkStatus"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        WXBaseViewController* controller =  [[(WXRootViewController*)self.window.rootViewController viewControllers] lastObject];
        if ([controller respondsToSelector:@selector(fireGlobalEvent:params:)]) {
            [controller fireGlobalEvent:@"netWorkStatus" params:dic];
        }
    }
}
#pragma mark-  init weex
- (void)initWeexSDK
{
    [WXAppConfiguration setAppGroup:@"Fantasy"];
    [WXAppConfiguration setAppName:@"BIBFX"];
    [WXAppConfiguration setExternalUserAgent:UserAgent];
    
    [WXSDKEngine initSDKEnvironment];
    if (UI_USER_INTERFACE_IDIOM()== UIUserInterfaceIdiomPad) {
        [WXSDKEngine setCustomEnvironment:@{@"deviceName":@"iPad"}];
    }else{
        [WXSDKEngine setCustomEnvironment:@{@"deviceName":@"iPhone"}];
    }
    
    [WXSDKEngine registerHandler:[WXImgLoaderDefaultImpl new] withProtocol:@protocol(WXImgLoaderProtocol)];
    [WXSDKEngine registerHandler:[WXConfigCenterDefaultImpl new] withProtocol:@protocol(WXConfigCenterProtocol)];
    [WXSDKEngine registerHandler:[WXNavigationHandlerImpl new] withProtocol:@protocol(WXNavigationProtocol)];
    [WXSDKEngine registerHandler:[WXApmGeneratorImpl new] withProtocol:@protocol(WXApmGeneratorProtocol)];
    [WXSDKEngine registerHandler:[WXWebSocketDefaultImpl new] withProtocol:@protocol(WXWebSocketHandler)];
    
    [WXSDKEngine registerComponent:@"select" withClass:NSClassFromString(@"WXSelectComponent")];
    [WXSDKEngine registerComponent:@"media" withClass:NSClassFromString(@"MediaComponnent")];
    [WXSDKEngine registerComponent:@"mediaPlayer" withClass:NSClassFromString(@"MediaComponnent")];
    [WXSDKEngine registerComponent:@"fullChart" withClass:NSClassFromString(@"BIBFullChartComponent")];
    [WXSDKEngine registerComponent:@"quoteKLineChart" withClass:NSClassFromString(@"BIBKlineChartComponent")];
    [WXSDKEngine registerComponent:@"proviewImg" withClass:NSClassFromString(@"photoBrowserCompoent")];
    [WXSDKEngine registerComponent:@"camera" withClass:NSClassFromString(@"CameraComponent")];
    [WXSDKEngine registerComponent:@"chatBox" withClass:NSClassFromString(@"ChatBoxComponent")];
    
    [WXSDKEngine registerModule:@"app" withClass:NSClassFromString(@"WXApplicationModule")];
    [WXSDKEngine registerModule:@"cookieStorage" withClass:NSClassFromString(@"CookieStorageModule")];
    [WXSDKEngine registerModule:@"tripleDes" withClass:NSClassFromString(@"TripleDESModule")];
    [WXSDKEngine registerModule:@"firebase" withClass:NSClassFromString(@"FirebaseModule")];
    [WXSDKEngine registerModule:@"jpush" withClass:NSClassFromString(@"JPushModule")];
    [WXSDKEngine registerModule:@"mediaplayer" withClass:NSClassFromString(@"MediaPlayerModule")];
    [WXSDKEngine registerModule:@"QRCodeModule" withClass: NSClassFromString(@"QRCodeModule")];
    [WXSDKEngine registerModule:@"imagePicker" withClass:NSClassFromString(@"WXImagePickerModule")];
    [WXSDKEngine registerModule:@"transfer" withClass:NSClassFromString(@"WXTransferModule")];
    
//    [WPRegister registerPlugins];
    
#ifdef DEBUG
    [WXDebugTool setDebug:YES];
    [WXLog setLogLevel:WXLogLevelLog];
#else
    [WXDebugTool setDebug:NO];
    [WXLog setLogLevel:WXLogLevelError];
#endif
}

-(BOOL)unzipBundleFile:(NSString*)path toPath:(NSString*)destPath{
    BOOL success = false;
    if ([[NSFileManager defaultManager] fileExistsAtPath:path]) {
        success = [SSZipArchive unzipFileAtPath:path toDestination:destPath overwrite:YES password:DESKEY error:nil delegate:nil];
    }
    return success;
}

//清空本地资源文件
- (void)removeBundle{
    NSString*images = [self.docPath stringByAppendingPathComponent:@"images"];
    NSString*bundlejs = [self.docPath stringByAppendingPathComponent:@"bundlejs"];
    [[NSFileManager defaultManager] removeItemAtPath:images error:nil];
    [[NSFileManager defaultManager] removeItemAtPath:bundlejs error:nil];
}

- (void)checkUpdate {
    //每次运行都需要检查是否有新资源需要解压
    NSString *zipPath = [self.docPath stringByAppendingPathComponent:bundleName];
    NSFileManager* manager = [NSFileManager defaultManager];
    if( [manager fileExistsAtPath:zipPath]){
        [self removeBundle];
        BOOL success = [self unzipBundleFile:zipPath toPath:self.docPath];//解压资源文件
        if(success){
            //解压成功，删除下载包
            [manager removeItemAtPath:zipPath error:nil];
        }else{
            //解压失败，清空解压出来的文件
            [self removeBundle];
        }
    }

    NSString* bunldeVersion = [[NSUserDefaults standardUserDefaults] stringForKey:@"bunldeVersion"];//下载到本地的资源版本号

    NSComparisonResult result = [BuildVersion compare:bunldeVersion options:NSNumericSearch];
    
    if (result == NSOrderedDescending) {
        //安装包中资源版本 > 本地资源版本 ，则清空本地版本，加载安装包资源
        [self removeBundle];
        [[NSUserDefaults standardUserDefaults] setValue:BuildVersion forKey:@"bunldeVersion"];
        bunldeVersion = BuildVersion;
    }
    
    WXStorageModule * storageModule = [[WXStorageModule alloc] init];
    
    NSDictionary* commonUrl = [storageModule getItemSync:@"commonUrl"];
    NSDictionary* contentId = [storageModule getItemSync:@"contentIdList"];
    
    if (![@"success" isEqualToString:contentId[@"result"]]) {
        contentId = [storageModule getItemSync:@"contentId"];
    }
    
    if(![@"success" isEqualToString:commonUrl[@"result"]] || ![@"success" isEqualToString:contentId[@"result"]]){
        [self performSelector:@selector(checkUpdate) withObject:nil afterDelay:15];
        return;
    }
    
    NSDictionary *commonDic = [WXUtility objectFromJSON:commonUrl[@"data"]];
    NSDictionary *contentIdDic = [WXUtility objectFromJSON:contentId[@"data"]];
    if (nil == commonDic || nil == contentIdDic) {
        [self performSelector:@selector(checkUpdate) withObject:nil afterDelay:15];
        return;
    }
    
    NSString* cmsApiHost = commonDic[@"cmsApi"]; //接口基址
    NSString* versionId = contentIdDic[@"iosVersionUpdate"]; //content id
    
    if ([WXUtility isBlankString:cmsApiHost]) {
        cmsApiHost = commonDic[@"cmsApiHost"];
    }
    if([WXUtility isBlankString:versionId]){
        versionId = contentIdDic[@"iosUpdate"];
    }
    
    if(nil == cmsApiHost || nil == versionId){
        [self performSelector:@selector(checkUpdate) withObject:nil afterDelay:15];
        return;
    }
    
    NSString *URL = [NSString stringWithFormat:@"%@/ContentUnion/Site?format=json&id=%@",cmsApiHost,versionId];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
        [request setURL:[NSURL URLWithString:URL]];
        [request setHTTPMethod:@"GET"];
        
        NSHTTPURLResponse *urlResponse = nil;
        NSError *error = nil;
        NSData *recervedData = [NSURLConnection sendSynchronousRequest:request returningResponse:&urlResponse error:&error];
        NSString *results = [[NSString alloc] initWithBytes:[recervedData bytes] length:[recervedData length] encoding:NSUTF8StringEncoding];
        
        NSDictionary *dic = [WXUtility objectFromJSON:results];
        NSArray *infoArray = [dic objectForKey:@"Results"];
        if(nil == infoArray || ![infoArray isKindOfClass:[NSArray class]] || infoArray.count <=0){
            return;
        }
        NSString * fileUrl = infoArray[0][@"FileUrl"];    //文件下载地址
        NSString * fileMd5 = infoArray[0][@"Summary"];    //文件md5检验码
        NSString * fileVersion = infoArray[0][@"Source"]; //文件版本号
        
        if([WXUtility isBlankString:fileUrl] || [WXUtility isBlankString:fileMd5] || [WXUtility isBlankString:fileVersion]){
            return;
        }
        
        NSComparisonResult result = [bunldeVersion compare:fileVersion options:NSNumericSearch];
        if (result != NSOrderedAscending) {
            return;
        }
        
//        if([[NSUserDefaults standardUserDefaults] boolForKey:fileVersion]){
//            return;
//        }
        
        SessionModule* downloader = [[SessionModule alloc] init];
        [downloader download:fileUrl callback:^(id result, BOOL keepAlive){
            NSDictionary* info =result;
            NSString*filePath = info[@"path"];
            if(nil == filePath){
                return;
            }
            FileManagerModule* fileManager = [[FileManagerModule alloc] init];
            NSString * md5Str = [fileManager fileMD5:filePath];
            NSLog(@"\nmd5Str:%@ \nfileMd5:%@",md5Str,fileMd5);
            if([md5Str isEqualToString:fileMd5])
            {
                NSString*dstPath = [self.docPath stringByAppendingPathComponent:bundleName];
                if([fileManager moveItemAtPath:filePath toPath:dstPath]){
//                    [[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:fileVersion];
                    [[NSUserDefaults standardUserDefaults] setValue:fileVersion forKey:@"bunldeVersion"];
                }else{
                    [fileManager removeItemAtPath:dstPath];
                }
                [fileManager removeItemAtPath:filePath];
            }
        }];
    });
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}

//按Home键使App进入后台
- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    self.background = YES;
    [self clearBadge];
//    [application cancelAllLocalNotifications];
}

//点击App图标，使App从后台恢复至前台
- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
//    [JPUSHService setBadge:0];
//    [application setApplicationIconBadgeNumber:0];
//    [application cancelAllLocalNotifications];
     [self clearBadge];
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    self.background = NO;
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    /// Required - 注册 DeviceToken
    [JPUSHService registerDeviceToken:deviceToken];
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    //Optional
    NSLog(@"did Fail To Register For Remote Notifications With Error: %@", error);
}

-(void)clearBadge{
    [JPUSHService setBadge:0];
    UIApplication*application = [UIApplication sharedApplication];
    
    if ([application applicationIconBadgeNumber] !=0 ) {
        [application setApplicationIconBadgeNumber:0];
    }else{
        [application setApplicationIconBadgeNumber:-1];
    }
//    [application setApplicationIconBadgeNumber:0];
}

- (void)setUserAgent{
    WKWebView *webView = [[WKWebView alloc] initWithFrame:CGRectZero];
    [webView evaluateJavaScript:@"navigator.userAgent" completionHandler:^(id result, NSError *error) {
        NSString *userAgent = result;
        NSString *newUserAgent = [userAgent stringByAppendingFormat:@" %@",UserAgent];
        NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:newUserAgent, @"UserAgent", nil];
        [[NSUserDefaults standardUserDefaults] registerDefaults:dictionary];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if (@available(iOS 9.0, *)) {
            [webView setCustomUserAgent:newUserAgent];
        } else {
            // Fallback on earlier versions
        }
    }];
}

- (void)registJpush:(NSDictionary*)launchOptions{
    JPUSHRegisterEntity * entity = [[JPUSHRegisterEntity alloc] init];
    entity.types = JPAuthorizationOptionAlert|JPAuthorizationOptionBadge|JPAuthorizationOptionSound;
    if ([[UIDevice currentDevice].systemVersion floatValue] >= 8.0) {
        // 可以添加自定义categories
        // NSSet<UNNotificationCategory *> *categories for iOS10 or later
        // NSSet<UIUserNotificationCategory *> *categories for iOS8 and iOS9
        
    }
    [JPUSHService registerForRemoteNotificationConfig:entity delegate:self];
    
    [JPUSHService setupWithOption:launchOptions appKey:JPUSHKEY channel:CHANNEL apsForProduction:YES];
    //2.1.9版本新增获取registration id block接口。
    [JPUSHService registrationIDCompletionHandler:^(int resCode, NSString *registrationID) {
        if(resCode == 0){
            NSLog(@"registrationID获取成功：%@",registrationID);
        }
        else{
            NSLog(@"registrationID获取失败，code：%d",resCode);
        }
    }];
}

#pragma mark- JPUSHRegisterDelegate

// iOS 10 Support 程序在运行时收到通知，点击通知栏进入app
- (void)jpushNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(NSInteger))completionHandler  API_AVAILABLE(ios(10.0)){
    // Required
    NSDictionary * userInfo = notification.request.content.userInfo;
    if([notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        [JPUSHService handleRemoteNotification:userInfo];
    }
    [self fireGlobalEvent:userInfo];
    
//    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
//    [JPUSHService setBadge:0];
    // 需要执行这个方法，选择是否提醒用户，有Badge、Sound、Alert三种类型可以选择设置
    completionHandler(UNNotificationPresentationOptionSound);
}

// iOS 10 Support 程序在后台时收到通知，点击通知栏进入app
- (void)jpushNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void(^)(void))completionHandler{
        // Required
        NSDictionary * userInfo = response.notification.request.content.userInfo;
        if([response.notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
            [JPUSHService handleRemoteNotification:userInfo];
        }
        
    //    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    //    [JPUSHService setBadge:0];
        
        if (self.background) {
             [self fireGlobalEvent:userInfo];
        }else{
            dispatch_time_t time = dispatch_time(DISPATCH_TIME_NOW,(int64_t)(9 * NSEC_PER_SEC));
            dispatch_after(time, dispatch_get_main_queue(), ^(void){
                [self fireGlobalEvent:userInfo];
            });
        }
        completionHandler();  // 系统要求执行这个方法
}

- (void) fireGlobalEvent:(NSDictionary*) info{
    WXBaseViewController* controller =  [[(WXRootViewController*)self.window.rootViewController viewControllers] lastObject];
    if ([controller respondsToSelector:@selector(fireGlobalEvent:params:)]) {
        [controller fireGlobalEvent:@"notification" params:info];
    }
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {
    [JPUSHService handleRemoteNotification:userInfo];
    
    if ([[UIDevice currentDevice].systemVersion floatValue]<10.0 || application.applicationState>0) {
        [self fireGlobalEvent:userInfo];
    }
    completionHandler(UIBackgroundFetchResultNewData);
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    
    // Required,For systems with less than or equal to iOS6
    [JPUSHService handleRemoteNotification:userInfo];
}
@end
