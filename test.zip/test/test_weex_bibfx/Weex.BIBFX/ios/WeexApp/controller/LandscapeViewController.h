//
//  LandscapeViewController.h
//  BibGold
//
//  Created by Richard on 2018/5/8.
//  Copyright © 2018年 Fantasy. All rights reserved.
//

#import <WeexSDK/WeexSDK.h>

@interface LandscapeViewController : UIViewController<UIGestureRecognizerDelegate>
@property(nonatomic,assign)BOOL edgePop;//边缘返回手势
@property(nonatomic,assign)BOOL isDisableBackPan;//横屏下是否禁用返回手势
@property (nonatomic, strong) NSURL *sourceURL;
/**
 * @abstract initializes the viewcontroller with bundle url.
 *
 * @param sourceURL The url of bundle rendered to a weex view.
 *
 * @return a object the class of WXBaseViewController.
 *
 */
- (instancetype)initWithSourceURL:(NSURL *)sourceURL;
- (void)fireGlobalEvent:(NSString *)eventName params:(NSDictionary *)params;
/**
 * @abstract refreshes the weex view in controller.
 */
- (void)refreshWeex;
- (void)addSwipePop;
- (void)addEdgePop;
@end
