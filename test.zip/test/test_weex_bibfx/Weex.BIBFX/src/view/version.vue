<template>
<div v-if="update" class="container" @click="maskClick">
  <div class="content">
    <div class="title">
      <text class="color title-size"> {{title}} </text>
    </div>
    <div class="margin">
      <text class="color text-size">{{versionName}}</text>
    </div>
    <div class="margin">
      <text class="color text-size">{{tips.title}}</text>
    </div>
    <div class="margin">
      <text class="color text-size lines">{{tips.detail}}</text>
    </div>
    <div class="footer">
      <div v-if="updateType <=1 " class="footer-btn border" @click="cancel">
        <text class="btn-text cancel"> {{cancelTitle}} </text>
      </div>
      <div class="footer-btn" @click="confirm">
        <text class="btn-text confirm"> {{okTitle}} </text>
      </div>
    </div>
    <div v-if="updateType <=1 " class="close" @click="close">
      <image class="close-icon" :src="assets+'close.png'"></image>
    </div>
  </div>
</div>
</template>

<script >
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
const localBundleVersion = require('../include/base-url.js').bundleVersion;
var storage = require('../include/storage.js');
var http = require('../include/http.js');
var app = weex.requireModule('app');
var utils = require('../include/utils.js');
var firebase = weex.requireModule('firebase');
var transfer = weex.requireModule('transfer');
// var fileManager = weex.requireModule('fileManager');

module.exports = {
  components: {
    wxcOverlay: require('../components/wxc-overlay.vue'),
  },
  computed: {
    platform: function() {
      const {
        platform
      } = weex.config.env;
      return platform.toLowerCase() || 'common';
    },
  },
  data: function() {
    return {
      assets: assetsUrl,
      currentVersion:'',//本地版本
      newVersion:'',//服务器最新版本
      minVersion:'',//最低版本，低于此版本需要强制升级
      update:false,//需要提示升级
      updateType: 0,
      tips: {},
      cancelTitle:'',
      okTitle:'',
      download : '',
      bundleMD5 :''
    }
  },
  created: function() {
    let that = this;
    that.currentVersion = app.bundleVersion();
    that.channelName = app.channelName();
    storage.getItem('commonUrl',function(value) {
      if ('' == value || value == undefined || value.length <= 2) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.cmsApiHost = commonUrl.cmsApi; //接口基址
        that.imageBaseUrl = commonUrl.imageBaseUrl; //图片基址
        that.contentBaseUrl = commonUrl.contentBaseUrl; //文章基址
        storage.getItem('contentIdList', function(list) {
          if ('' == list || list == undefined || list.length <= 2) {
            return
          }
          var contentIdList = JSON.parse(list);
          if ('ios' == that.platform) {
            that.versionId = contentIdList.iosUpdate;
          }else {
            that.versionId = contentIdList.androidUpdate;
          }
          that.checkUpdate();
        });
      }
    });
  },
  methods: {
    checkUpdate: function() {
      var that = this;
      if (that.cmsApiHost && that.cmsApiHost.length > 0) {
        var url = that.cmsApiHost + '/ContentUnion/Site?format=json&id=' + that.versionId;
        http.get(url, function(resp) {
          if (resp.ok && resp.data && resp.data.Results && resp.data.Results.length > 0) {
            var result = resp.data.Results[0];
              that.title = result.SubTitle; //新版本提示标题
              that.versionName = result.inertitle;//当前新版本提示信息
              that.newVersion = result.Description || '';//最新版本号
              that.minVersion = result.Keyword || '';//最小版本号
              that.bundleUrl  = result.FileUrl; //最新bundle资源路径
              that.bundleVersion =  result.Source;////最新bundle版本号
              that.bundleMD5 = result.Summary; //资源文件md5检验码

              that.tips.title = "";
              if (result.ContentNoHtmlTag && result.ContentNoHtmlTag.length>0) {
                that.tips.detail = result.ContentNoHtmlTag.replace(/\\n/g,"\n");
              }else {
                that.tips.detail = "";
              }

              if(result.headermenudes){
                that.okTitle = result.headermenudes;
              }else {
                that.okTitle = result.headerMenuDes;
              }

              if (result.headermenutit) {
                that.cancelTitle = result.headermenutit;
              } else {
                that.cancelTitle = result.headerMenuTit;
              }

              that.download = result.LinkUrl; //下载地址
              if (utils.compareVersion(that.minVersion,that.currentVersion)) {
                that.updateType = 2;
                that.update = true;
              }else if (utils.compareVersion(that.newVersion,that.currentVersion)) {
                that.updateType = 1;
                that.update = true;
              }else if (utils.compareVersion(that.bundleVersion,localBundleVersion)){
                // that.updateBundle();//后台更新
              }
              storage.setItem('bundleVersion',that.bundleVersion);
          } else {
              storage.setItem('bundleVersion','');
          }

        });
      }
    },
    // updateBundle:function(){
    //   var that = this;
    //   transfer.onmessage(callback=>{
    //     if (callback.result == 'success' && callback.path) {
    //       let md5Str = fileManager.fileMD5(callback.path);
    //       if (that.bundleMD5 && "" != that.bundleMD5 && that.bundleMD5 == md5Str) {
    //         let filePath = fileManager.docDir()+"/bundle.zip"
    //         fileManager.moveItemAtPath(callback.path,filePath);
    //       }else {
    //         fileManager.removeItemAtPath(callback.path);
    //       }
    //     }
    //   })
    //   if (/^http/.test(this.bundleUrl)) {
    //     transfer.download(this.bundleUrl);
    //   }
    // },
    logEvent:function(name){
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    close: function() {
      this.logEvent('Version_hints_close');
      this.update = false;
    },
    cancel: function() {
      this.logEvent('Version_hints_postponed');
      this.update = false;
    },
    confirm: function() {
      var that =this;
      that.logEvent('Version_hints_update');
      if (that.updateType <=1) {
        that.update = false;
      }

      if (that.download) {
        if ('ios' == that.platform) {
          app.openURL(that.download);
        }else {
          var apkName = 'Android_APP.apk';
          if ('' != that.channelName && 'Android' != that.channelName && 'android' != that.channelName) {
            apkName = "Android_APP_"+that.channelName+".apk";
          }

         var  downloadUrl = that.download+'/'+apkName;
          app.isCheckStorgePermission(function (value) {
              if (value){
                  app.downloadApp(downloadUrl);
                  that.download = '';
              }
          })
        }
      }
    },
    maskClick:function(){

    }
  }
}
</script>

<style scoped>
.container {
  position: fixed;
  left: 0px;
  top: 0px;
  right: 0px;
  bottom: 0px;
  /*兼容H5异常*/
  z-index: 99999;
  justify-content: center;
  align-items: center;
  background-color: rgba(0, 0, 0, 0.6);
}

.content {
  width: 500px;
  background-color: #FFFFFF;
  padding-top: 20px;
  border-radius: 10px;
}

.title {
    margin-top: 25px;
    margin-bottom: 10px;
    justify-content: center;
    align-items: center;
    margin-left: 36px;
    margin-right: 36px;
}

.title-size {
    font-size: 32px;
    line-height: 48px;
    lines:3;
}

.margin {
    margin-top: 10px;
    margin-left: 36px;
    margin-right: 36px;
}

.version {
  flex: 1;
  height: 68px;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
}

.color {
  color: #454950;
}

.text-size {
  font-size: 28px;
  line-height: 42px;
  text-align: left;
}

.lines {
  lines: 15;
  text-overflow: ellipsis;
}

.footer {
  width: 500px;
  flex-direction: row;
  align-items: center;
  border-top-color: #F3F3F3;
  border-top-width: 1px;
  margin-top: 20px;
}

.footer-btn {
  flex-direction: row;
  align-items: center;
  justify-content: center;
  flex: 1;
  height: 88px;
}

.border {
  border-right-color: #F3F3F3;
  border-right-width: 1px;
}

.cancel {
  color: #9ba1ab;
}

.confirm {
  color: #2e74e9;
}

.btn-text {
  font-size: 28px;
  text-align: center;
}

.close {
  position: absolute;
  top: 0px;
  right: 0px;
  width: 100px;
  height: 80px;
  flex-direction: row;
  justify-content: flex-end;
}

.close-icon {
  width: 38px;
  height: 38px;
  margin-top: 14px;
  margin-right: 14px;
}
</style>
