<template>
<div >
  <status backgroundColor="#FFFFFF"></status>
  <navigation :title="title" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="goBack"></navigation>
  <!-- <div class="navbar">
    <text class="navbar-title"> {{title}} </text>
    <div @click="goBack" class="goback">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div>
  </div> -->
  <div style="flex-direction:row;marginTop:34px;marginBottom:34px;">
      <template v-for="item in statusData">
        <div style="align-items:center;flex:1">
          <div class="item-row">
            <div v-if="item.lineLeft == 0" class="whiteline"></div>
            <div v-if="item.lineLeft == 1" class="grayline"></div>
            <div v-if="item.lineLeft == 2" class="line"></div>
            <div v-if="item.lineRight == 0" class="whiteline"></div>
            <div v-if="item.lineRight == 1" class="grayline"></div>
            <div v-if="item.lineRight == 2" class="line"></div>
          </div>
          <div class="circle">
            <div :class="['innerCircle',(item.circle == 0) ? 'gray' : '']">
              <text class="font20 text-item" style=" text-align: center;">{{item.num}}</text>
            </div>
          </div>
          <text :class="['font30', (item.circle == 0) ? 'gray-text' : 'gold-text']" style="text-align: center;">{{item.text}}</text>
        </div>
      </template>
    </div>
    <div style="margin: 0px;height: 20px;background-color: #F1F1F1;"></div>
  <scroller alwaysScrollableVertical="false" style="width:750px;flex:1;" show-scrollbar="false">
    <div style="width:750px;paddingLeft:25px;paddingRight:25px;paddingTop:30px;padding-bottom: 30px;">
      <text class="font28" style="color: #454950;">完善资料</text>
      <text class="font26" style="color: #9BA1AB;margin-top: 12px;">为了能提供更完善的会员服务，请补充以下会员信息。</text>
    </div>
    <div class="align" style="background-color: #f1f1f1;height: 1px;"></div>
    <div class="margin flexV" style="margin-bottom: 50px;">

      <div class="flexH infoItem">
        <div class="flexH">
          <text class="font24 color32">*</text>
          <text class="font24 text" style="margin-right:42px">邮</text>
          <text class="font24 text" style="margin-right:5px">箱</text>
        </div>
        <div class="input flexH">
          <input class="input-size" allowCopyPaste="true" :value="emailValue" type="email" :disabled="emailDisabled" maxlength=40 placeholder="请填写您的邮箱地址" @change="onchangememberemail" @input="inputemail" />
        </div>
      </div>
      <div class="flexH infoItem">
        <div class="flexH">
          <text class="font24 color32">*</text>
          <text class="font24 text" style="margin-right:42px">地</text>
          <text class="font24 text" style="margin-right:5px">址</text>
        </div>
        <div class="flexH input-view">
          <div class="input-auto flexH" v-on:click="onclickbranchBank()">
            <text class="font24 text" style="margin-left: 20px;">{{branchAddress.province}}</text>
            <div class="input-down-select">
              <image style="width:15px;height:12px" :src="assets+'auth/selectdown.png'"></image>
            </div>
          </div>
          <div v-if="branchAddress.province!='其他'" class="input-auto flexH" style="align-items: center;justify-content: space-between;" v-on:click="onclickbranchBankTwo()">
            <text class="font24 text" style="margin-left: 20px;">{{branchTwoAddress.city}}</text>
            <div class="input-down-select">
              <image style="width:15px;height:12px" :src="assets+'auth/selectdown.png'"></image>
            </div>
          </div>
          <div v-if="branchAddress.province!='其他'" class="input-auto flexH" style="align-items: center;justify-content: space-between;" v-on:click="onclickbranchBankThree()">
            <text class="font24 text" style="margin-left: 20px;">{{branchThreeAddress.area}}</text>
            <div class="input-down-select">
              <image style="width:15px;height:12px" :src="assets+'auth/selectdown.png'"></image>
            </div>
          </div>

<!--          <div v-if="branchAddress.province!='其他'" class="flexH input-view-w">-->
<!--            <div class="input-auto flexH" v-on:click="onclickbranchBankTwo()">-->
<!--              <text class="font24" style="margin-left: 20px;">{{branchTwoAddress.city}}</text>-->
<!--              <div class="input-down-select">-->
<!--                <image style="width:15px;height:12px" :src="assets+'auth/selectdown.png'"></image>-->
<!--              </div>-->
<!--            </div>-->
<!--            <div class="input-auto flexH" v-on:click="onclickbranchBankThree()">-->
<!--              <text class="font24" style="margin-left: 20px;">{{branchThreeAddress.area}}</text>-->
<!--              <div class="input-down-select">-->
<!--                <image style="width:15px;height:12px" :src="assets+'auth/selectdown.png'"></image>-->
<!--              </div>-->
<!--            </div>-->
<!--          </div>-->
        </div>
      </div>
      <div class="flexH infoItem-branch">
        <div class="flexH">
          <text class="font24 text" style="backgroundColor:gray"></text>
        </div>
        <div class="input">
          <input class="input-size" allowCopyPaste="true" :value="addressDetail" :disabled="addressDetailDisabled" placeholder="详细地址" type="text" maxlength=100 @change="onchangAddressDetail" @input="inputAddressDetail"></input>
        </div>
      </div>
    </div>
    <div style="margin: 0px;height: 20px;background-color: #F1F1F1;"></div>
    <div class="align" style="paddingTop:30px;padding-bottom: 30px;">
      <text class="font28" style="color: #454950;">安全设置（为了您的账号安全，请设置以下信息）</text>
      <text class="font26" style="color: #9BA1AB;margin-top: 12px;">为了保证贵宾的账户隐私安全，系统只接受8~15位英文字母和数字的组合作为密码，且英文字母有大写小写之分，请留意。</text>
    </div>
    <div class="align" style="background-color: #f1f1f1;height: 1px;"></div>

    <div class="margin flexV" style="margin-bottom:78px;">
      <div class="flexH infoItem">
        <div class="flexH">
          <text class="font24 color3">* </text>
          <text class="font24 text">密保问题</text>
        </div>
        <div class="input flexH" style="align-items: center;justify-content: space-between;" v-on:click="onclickselectquestion()">
          <text class="font24 text" style="margin-left: 20px;">{{memberQuestion}}</text>
          <div class="input-down-select">
            <image style="width:15px;height:12px" :src="assets+'auth/selectdown.png'"></image>
          </div>
        </div>
      </div>
      <div class="flexH infoItem" v-if="isOtherQuestion">
        <div class="flexH">
          <text class="font24 text" style="backgroundColor:gray"></text>
        </div>
        <div class="input">
          <input class="input-size" allowCopyPaste="true" type="text" :disabled="answerDisabled" :value="memberOtherQuestion" maxlength=50 @change="onchangwritequestion" @input="inputwritequestion"></input>
        </div>
      </div>
      <div class="flexH infoItem">
        <div class="flexH">
          <text class="font24 color32">*</text>
          <text class="font24 text" style="margin-right:42px">答</text>
          <text class="font24 text" style="margin-right:5px">案</text>
        </div>
        <div class="input">
          <input class="input-size" allowCopyPaste="true" type="text" :disabled="answerDisabled" :value="safeQuestionAnswer" maxlength=50 @change="onchangememberanswer" @input="inputanswer"></input>
        </div>
      </div>

      <div class="flexH infoItem">
        <div class="flexH">
          <text class="font24 color32">*</text>
          <text class="font24 text">设定密码</text>
        </div>
        <div class="input flexH" style="align-items: center;">
          <input class="input-size" allowCopyPaste="false" placeholder="8至15位数字与字母组合" type="password" maxlength=15 @change="onchangememberpwd" :value="mainPassword" :disabled="passwordDisabled" @input="inputpwd"></input>
        </div>
      </div>
      <div class="flexH infoItem">
        <div class="flexH">
          <text class="font24 color32">*</text>
          <text class="font24 text">确定密码</text>
        </div>
        <div class="input flexH" style="align-items: center;">
          <input class="input-size" allowCopyPaste="false" placeholder="请再次输入您的交易密码" type="password" maxlength=15 @change="onchangemembersurepwd" :value="mainPassword" :disabled="passwordDisabled" @input="inputsurepwd"></input>
        </div>
      </div>
    </div>
    <!--<div :class="['button',isSubmitBtnClick?'button-gray':'button-normal']" v-on:click="onclicknext()">-->
      <!--<text class="font32 text-select">提交</text>-->
    <!--</div>-->
  </scroller>
  <div :class="['button',isSubmitBtnClick?'button-gray':'button-normal']" v-on:click="onclicknext()">
    <text class="font32 text-select">提交</text>
  </div>
  <div v-if="isShowAlert" class="alert-show">
    <div class="alert-modul">
      <text style="color:#FFFFFF;font-size:28px;"> {{alertTips}} </text>
    </div>
  </div>
  <dialog :show="showDialogBack" title="温馨提示" content="您尚未提交资料，返回后将清空内容，请确认是否继续退出？" confirm="继续填写" cancel="退出"
          @confirm="dialogLeftBtnClickBack" @cancel="dialogRightBtnClickBack" @close="dialogCloseBtnClickBack">
  </dialog>
  <!--<dialog :show="showDialogBack" title="提示" content="返回后，可登陆用户中心查看个人信息和审核状态！" confirm="确认返回" cancel="取消" @confirm="dialogRightBtnClickBack" @cancel="dialogLeftBtnClickBack" @close="dialogCloseBtnClickBack"></dialog>-->
  <dialog :show="showSuccess" title="成功提示" content="为确保您的账号安全，请勿告知他人并妥善保管密码，并登陆邮箱进行验证。" confirm="确认" single="true" @confirm="dialogRightBtnClick" @close="dialogCloseBtnClick"></dialog>
</div>
</template>

<script scoped>
var allArea = require('../chainArea.json');
var appbasedata = require('../survey.json');
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var app = weex.requireModule('app');
var webview = weex.requireModule('webview');
var storage = require('../include/storage.js');
var http = require('../include/http.js');
const picker = weex.requireModule('picker');
var firebase = weex.requireModule('firebase');
var utils = require('../include/utils.js');

module.exports = {
  components: {
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'dialog': require('../components/dialog.vue'),
  },
  data: function() {
    return {
      errorCodes:appbasedata.fileErrorCodes,//错误码
      isAndroid: utils.isAndroid(),
      assets: assetsUrl,
      title: '开户完成',
      userId: '', //提交基本资料的用户id（前一个页面的参数）
      userToken: '', //提交基本资料的用户登陆token（前一个页面的参数）
      isOpenIn: false, //是否是开户第一步进入
      bibApi: '', //网络请求基地址
      protocolUrl: '', //协议地址
      serviceUrl: '', //客服url
      // isShowProtocol:false,
      isShowAlert: false,
      alertTips: '', //弹窗提示语
      userName: '',
      selectedSexImg: assetsUrl + 'radio/checked.png',
      unselectedSexImg: assetsUrl + 'radio/unchecked.png',
      isShowSexMan: false,
      isShowSexWoman: false,
      isShowSexOther: false,
      memberSex: -1, //选择的性别（默认 空  1:男  2:女 3:其他）
      certTypes: [],
      certTypeTitle: '', //证件类型
      certTypeIndex: 0,
      certTypeNumber: 1, //证件的编号
      userIDCardCode: '',
      accountName: '',
      bankCode: '',
      bankNames: [],
      bankNamesCodes: appbasedata.bankName,
      bankName: '建、工、招、农行取款2小时到账',
      bankOtherName: '',
      bankNameIndex: -1,
      isOtherBankName: false,
      branchAddressAreas: ['请选择'],
      branchAddressAreasCode: [{
        "province": '请选择',
        "code": 'none'
      }],
      branchAddress: {
        "province": '请选择',
        "code": 'none'
      },
      branchAddressIndex: 0,
      branchTwoAddressAreas: ['请选择'],
      branchTwoAddressAreasCode: [{
        "city": '请选择',
        "code": 'none'
      }],
      branchTwoAddress: {
        "city": '请选择',
        "code": 'none'
      },
      branchTwoAddressIndex: 0,
      branchThreeAddressAreas: ['请选择'],
      branchThreeAddressAreasCode: [{
        "area": '请选择',
        "code": 'none'
      }],
      branchThreeAddress: {
        "area": '请选择',
        "code": 'none'
      },
      branchThreeAddressIndex: 0,
      branchBankName: '',
      passwordDisabled: false,
      answerDisabled: false,
      emailDisabled: false,
      addressDetailDisabled: false,
      isSubmitBtnClick: false, //是否点击提交(下一步)按钮
      showDialogBack: false, //返回提示弹窗
      openAccountFrom: '', //从哪里进入开户步骤
      addressDetail: '',
      safeQuestionAnswer: '',
      emailValue: '',
      mainPassword: '',
      server:'',
      tradeId:'',
      sexTypeIndex: 0,
      sexTypeNumber: 1, //证件的编号
      statusData: [{
          num: '01',
          text: '填写资料',
          lineLeft: 0,
          lineRight: 2,
          circle: 1
        },
        {
          num: '02',
          text: '身份验证',
          lineLeft: 2,
          lineRight: 2,
          circle: 1
        },
        {
          num: '03',
          text: '调查问卷',
          lineLeft: 2,
          lineRight: 2,
          circle: 1
        },
        {
          num: '04',
          text: '存款激活',
          lineLeft: 2,
          lineRight: 2,
          circle: 1
        },
        {
          num: '05',
          text: '交易密码',
          lineLeft: 2,
          lineRight: 0,
          circle: 1
        },
      ],
      selectQuestions: [], //密保问题的数组
      memberQuestion: '',
      memberOtherQuestion: '', //自定义密保问题
      memberQuestionIndex: 0, //密保问题的数组下标
      memberQuestionNumber: 0, //密保问题的编号
      isOtherQuestion: false, //密保问题是否选择了"其他"
      memberAnswer: '',
      memberQuestionCode: '',
      showSuccess: false
    }
  },
  created: function() {
    var that = this;
    storage.getItem('commonUrl', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return;
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.bibApi = commonUrl.cmsApi;
        that.serviceUrl = commonUrl.feedback;
      }
    });
    storage.getItem('memberCenter', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var memberCenter = JSON.parse(value);
      if (memberCenter) {
        that.protocolUrl = memberCenter.protocolUrl;
      }
    });
    storage.getItem('userInfo', function(value) {
      if (value) {
        let data = JSON.parse(value);
        that.setDisableValue(data);
        that.server = data.server;
        that.tradeId = data.tradeId;
      }
    });
    storage.getItem('user-logintoken-id', function(value) {
      if (value) {
        var data = JSON.parse(value);
        that.userId = data.userId;
        that.userToken = data.token;
        that.isOpenIn = data.isOpen;
      }
    });
    storage.getItem('user_openaccount_from', function(value) {
      if (value) {
        that.openAccountFrom = value;
      }
    });
    //银行名称的列表数据
    for (var i = 0; i < appbasedata.bankName.length; i++) {
      that.bankNames.push(appbasedata.bankName[i].bank); //电话区号
    }
    //省份的列表数据(大陆省份)
    for (var code in allArea.mainland) {
      if (allArea.mainland.hasOwnProperty(code)) {
        that.branchAddressAreas.push(allArea.cityArea[code]);
        var pro = {
          "province": allArea.cityArea[code],
          "code": code
        };
        that.branchAddressAreasCode.push(pro);
      }
    }
    //省份的列表数据(海外省份)
    for (var code in allArea.outerSea) {
      if (allArea.outerSea.hasOwnProperty(code)) {
        that.branchAddressAreas.push(allArea.cityArea[code]);
        var pro = {
          "province": allArea.cityArea[code],
          "code": code
        };
        that.branchAddressAreasCode.push(pro);
      }
    }
    for (var i = 0; i < appbasedata.secretQuestion.length; i++) {
      that.selectQuestions.push(appbasedata.secretQuestion[i].question); //密保问题数组
    }
    that.memberQuestion = that.selectQuestions[that.memberQuestionIndex];
    that.memberQuestionNumber = appbasedata.secretQuestion[that.memberQuestionIndex].number;
    that.memberQuestionCode = appbasedata.secretQuestion[that.memberQuestionIndex].code;

    //证件类型的类表数据
    for (var i = 0; i < appbasedata.certType.length; i++) {
      that.certTypes.push(appbasedata.certType[i].certtype); //电话区号
    }
    that.certTypeTitle = that.certTypes[that.certTypeIndex];
    that.certTypeNumber = appbasedata.certType[that.certTypeIndex].number;
  },
  methods: {
    //埋点追踪方法(在input事件里面执行)
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    setDisableValue: function(data) {
      if (data.mainPassword) {
        this.mainPassword = data.mainPassword;
        this.passwordDisabled = true;
      }
      if (data.safeQuestionAnswer) {
        this.safeQuestionAnswer = this.Getquestion(data.safeQuestionAnswer);
        for (var i = 0; i < appbasedata.secretQuestion.length; i++) {
          if (appbasedata.secretQuestion[i].number == data.safeQuestion) {
            this.memberQuestion = appbasedata.secretQuestion[i].question;
            this.memberQuestionCode = appbasedata.secretQuestion[i].code;
          }
        }
        // this.memberQuestion = this.selectQuestions[data.safeQuestion];
        this.answerDisabled = true;
      }
      if (data.SafeQuestionOther) {
        // this.SafeQuestionOther = data.SafeQuestionOther;
        this.memberOtherQuestion = data.SafeQuestionOther;
        this.isOtherQuestion = true;
      }

      if (data.email) {
        this.emailValue = this.Getquestion(data.email);
        this.emailDisabled = true;
      }
      if (data.addressDetail) {
        this.getProvince(data.addressLv1)
        this.getCityName(data.addressLv2)
        this.getDistrict(data.addressLv3)
        this.addressDetail = this.Getquestion(data.addressDetail);
        this.addressDetailDisabled = true;
      }
    },
    getProvince: function(code) {
      for (let i = 0; i < this.branchAddressAreasCode.length; i++) {
        if (code == this.branchAddressAreasCode[i].code) {
          this.branchAddress.province = this.branchAddressAreasCode[i].province
          this.branchAddress.code = this.branchAddressAreasCode[i].code
          this.setBranchAddressData();
          return;
        }
      }
    },

    getCityName: function(city) {
      for (let i = 0; i < this.branchTwoAddressAreasCode.length; i++) {
        if (city == this.branchTwoAddressAreasCode[i].code) {
          this.branchTwoAddress.city = this.branchTwoAddressAreasCode[i].city
          this.branchTwoAddress.code = this.branchTwoAddressAreasCode[i].code
          this.setDistrictData();
          return;
        }
      }
    },
    setBranchAddressData: function() {
      var that = this;
      //二级市区域的列表(大陆)
      for (var code in allArea.mainland[that.branchAddress.code]) {
        if (allArea.mainland[that.branchAddress.code].hasOwnProperty(code)) {
          that.branchTwoAddressAreas.push(allArea.cityArea[code]);
          var city = {
            "city": allArea.cityArea[code],
            "code": code
          };
          that.branchTwoAddressAreasCode.push(city);
        }
      }
      //二级市区域的列表(海外)
      for (var code in allArea.outerSea[that.branchAddress.code]) {
        if (allArea.outerSea[that.branchAddress.code].hasOwnProperty(code)) {
          that.branchTwoAddressAreas.push(allArea.cityArea[code]);
          var city = {
            "city": allArea.cityArea[code],
            "code": code
          };
          that.branchTwoAddressAreasCode.push(city);
        }
      }
    },
    getDistrict: function(District) {
      for (let i = 0; i < this.branchThreeAddressAreasCode.length; i++) {
        if (District == this.branchThreeAddressAreasCode[i].code) {
          this.branchThreeAddress.area = this.branchThreeAddressAreasCode[i].area
          this.branchThreeAddress.code = this.branchThreeAddressAreasCode[i].code
          return;
        }
      }
    },
    setDistrictData: function() {
      var that = this;
      that.branchThreeAddressAreas = ['请选择'];
      that.branchThreeAddressAreasCode = [{
        "area": '请选择',
        "code": 'none'
      }];
      //三级区和县的区域列表（大陆）
      if (allArea.mainland[that.branchAddress.code] && allArea.mainland[that.branchAddress.code][that.branchTwoAddress.code]) {
        var landArea = allArea.mainland[that.branchAddress.code][that.branchTwoAddress.code];
        for (var i = 0; i < landArea.length; i++) {
          var code = landArea[i];
          that.branchThreeAddressAreas.push(allArea.cityArea[code]);
          var area = {
            "area": allArea.cityArea[code],
            "code": code
          };
          that.branchThreeAddressAreasCode.push(area);
        }
      }
      //三级区和县的区域列表（海外）
      if (allArea.outerSea[that.branchAddress.code] && allArea.outerSea[that.branchAddress.code][that.branchTwoAddress.code]) {
        var seaArea = allArea.outerSea[that.branchAddress.code][that.branchTwoAddress.code];
        for (var i = 0; i < seaArea.length; i++) {
          var code = seaArea[i];
          that.branchThreeAddressAreas.push(allArea.cityArea[code]);
          var area = {
            "area": allArea.cityArea[code],
            "code": code
          };
          that.branchThreeAddressAreasCode.push(area);
        }
      }
    },
    Getquestion: function(value) {
      return value.replace(/{.*}/g, '******')
    },
    goBack: function() {
      this.showDialogBack = true;
    },
    //直播间登录
    onliveroom: function() {
      storage.setItem('user-original-fromLogin', 'livebyopen');
      navigator.push({
        url: bundleUrl + 'userLogin.js',
        animated: "true",
        swipePop: "true",
      }, event => {})
    },
    //用户中心登录
    onusercenter: function() {
      storage.setItem('user-original-fromLogin', 'indexbyopen');
      navigator.push({
        url: bundleUrl + 'userLogin.js',
        animated: "true",
        swipePop: "true",
      }, event => {})
    },
    //在线客服超链接
    onclickservice: function() {
      this.loadWebView(this.serviceUrl, '客服');
    },
    loadWebView: function(url, title = '') {
      if (url && url.length > 0) {
        var data = {
          title: title,
          url: url,
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "false"
        }, event => {})
      }
    },
    //弹窗右上角按钮
    dialogCloseBtnClickBack() {
      this.showDialogBack = false;
    },
    //弹窗左下角按钮
    dialogLeftBtnClickBack() {
      this.showDialogBack = false;
    },
    //弹窗右下角按钮
    dialogRightBtnClickBack() {
      this.showDialogBack = false;
      if (this.openAccountFrom === 'live') {
        navigator.pop({
          url: bundleUrl + 'live.js',
          animated: "false"
        }, event => {

        });
      } else {
        navigator.pop({
          url: bundleUrl + 'index.js',
          animated: "false"
        }, event => {

        });
      }
    },
    // 成功提交
    dialogRightBtnClick:function () {
      this.showSuccess = false;
      navigator.pop({
        url: bundleUrl + 'index.js',
        animated: "false"
      }, event => {

      });
    },

    dialogCloseBtnClick:function () {
      this.showSuccess = false;
      navigator.pop({
        url: bundleUrl + 'index.js',
        animated: "false"
      }, event => {

      });
    },

    //输入邮箱地址  /^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/
    inputemail: function(event) {
      // this.logEvent('input_email');
      this.membereMail = event.value;
    },
    onchangememberemail: function(event) {
      this.membereMail = event.value;
      if (!/^[a-zA-Z0-9][a-zA-Z0-9-.]{0,19}@[a-zA-Z0-9][a-zA-Z0-9-.]{0,11}.[a-zA-Z]{2,10}$/.test(this.membereMail)) {
        this.showAlertTips('请填写正确的邮箱');
      }
    },
    //选择密保问题（列表显示隐藏）
    onclickselectquestion: function() {
      if (this.answerDisabled) {
        return;
      }
      picker.pick({
        items: this.selectQuestions,
        index: this.memberQuestionIndex,
      }, event => {
        if (event.result === 'success') {
          this.memberQuestionIndex = event.data;
          this.memberQuestionNumber = appbasedata.secretQuestion[this.memberQuestionIndex].number;
          this.memberQuestion = this.selectQuestions[event.data];
          this.memberQuestionCode = appbasedata.secretQuestion[this.memberQuestionIndex].code;
          this.isOtherQuestion = false;
          if (this.memberQuestion === '其他') {
            this.isOtherQuestion = true;
          }
        }
      })
    },
    onchangememberanswer: function(event) {
      this.memberAnswer = event.value;
      if (this.memberAnswer.length <= 0) {
        this.showAlertTips('请填写密保问题答案');
      }
    },
    //输入密保问题答案
    inputanswer: function(event) {
      // this.logEvent('input_question_answer');
      this.memberAnswer = event.value;
    },
    inputwritequestion: function(event) {
      if (event.value != this.memberOtherQuestion) {
        this.memberOtherQuestion = event.value;
      }
    },
    onchangwritequestion: function(event) {
      if (event.value != this.memberOtherQuestion) {
        this.memberOtherQuestion = event.value;
      }
      if (this.memberOtherQuestion.length <= 0) {
        this.showAlertTips('请填写密保问题');
      }
    },
    //会员密码 @input @onchange
    inputpwd: function(event) {
      // this.logEvent('input_pwd');
      this.memberPassword = event.value;
    },
    onchangememberpwd: function(event) {
      this.memberPassword = event.value;
      if (!this.checkPwd(this.memberPassword)) {
        this.showAlertTips('请填写8-15位英文字母和数字的组合密码');
      }
    },

    //会员确认密码  @input @onchange
    inputsurepwd: function(event) {
      // this.logEvent('input_re_pwd');
      this.memberSurePassword = event.value;
    },
    onchangemembersurepwd: function(event) {
      this.memberSurePassword = event.value;
      if (!this.checkPwd(this.memberSurePassword)) {
        this.showAlertTips('请填写8-15位英文字母和数字的组合密码');
      }
      if (this.memberPassword != this.memberSurePassword) {
        this.showAlertTips('两次密码填写不一致');
      }
    },

    inputAddressDetail: function(event) {
      this.addressDetail = event.value;
    },
    onchangAddressDetail: function(event) {
      this.addressDetail = event.value;
    },

    //检测18位身份证号码的正确性
    Check18CertNO: function(sId) {
      // 中国大陆地区 判断18位身份证号是否正确
      var aCity = {
        11: '北京',
        12: '天津',
        13: '河北',
        14: '山西',
        15: '内蒙古',
        21: '辽宁',
        22: '吉林',
        23: '黑龙江',
        31: '上海',
        32: '江苏',
        33: '浙江',
        34: '安徽',
        35: '福建',
        36: '江西',
        37: '山东',
        41: '河南',
        42: '湖北',
        43: '湖南',
        44: '广东',
        45: '广西',
        46: '海南',
        50: '重庆',
        51: '四川',
        52: '贵州',
        53: '云南',
        54: '西藏',
        61: '陕西',
        62: '甘肃',
        63: '青海',
        64: '宁夏',
        65: '新疆'
      };
      try {
        var iSum = 0;
        if (!/^\d{17}(\d|x)$/i.test(sId)) {
          return false;
        }
        sId = sId.replace(/x$/i, 'a');
        if (aCity[parseInt(sId.substr(0, 2))] == null) {
          return false;
        }
        let sBirthday = sId.substr(6, 4) + '-' + Number(sId.substr(10, 2)) + '-' + Number(sId.substr(12, 2));
        var d = new Date(sBirthday.replace(/-/g, '/'));
        if (sBirthday !== (d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate())) {
          return false;
        }
        for (var i = 17; i >= 0; i--) {
          iSum += (Math.pow(2, i) % 11) * parseInt(sId.charAt(17 - i), 11);
        }
        if (iSum % 11 !== 1) {
          return false;
        }
        return true;
      } catch (e) {
        return false;
      }
    },

    //支行区域（一级  省）
    onclickbranchBank: function() {
      if (this.addressDetailDisabled) {
        return
      }
      var that = this;
      picker.pick({
        items: that.branchAddressAreas,
        index: that.branchAddressIndex,
      }, event => {
        if (event.result === 'success') {
          // that.logEvent('select_bank_province');
          that.branchAddressIndex = event.data;
          that.branchAddress.province = that.branchAddressAreas[event.data]; //一级区域的省
          that.branchTwoAddress.city = '请选择'; //二级区域的市
          that.branchThreeAddress.area = '请选择'; //三级区域的区
          for (var i = 0; i < that.branchAddressAreasCode.length; i++) {
            if (that.branchAddressAreasCode[i].province === that.branchAddress.province) {
              that.branchAddress.code = that.branchAddressAreasCode[i].code; //一级区域的省代码
              that.branchTwoAddress.code = 'none'; //二级区域的市代码
              that.branchThreeAddress.code = 'none'; //三级区域的区代码
            }
          }
          that.branchTwoAddressAreas = ['请选择'];
          that.branchTwoAddressAreasCode = [{
            "city": '请选择',
            "code": 'none'
          }];
          that.branchThreeAddressAreas = ['请选择'];
          that.branchThreeAddressAreasCode = [{
            "area": '请选择',
            "code": 'none'
          }];
          that.setBranchAddressData();
        }
      })
    },

    //支行区域（二级）
    onclickbranchBankTwo: function() {
      if (this.addressDetailDisabled) {
        return
      }
      picker.pick({
        items: this.branchTwoAddressAreas,
        index: this.branchTwoAddressIndex,
      }, event => {
        var that = this;
        if (event.result === 'success') {
          // that.logEvent('select_bank_city');
          that.branchTwoAddressIndex = event.data;
          that.branchTwoAddress.city = that.branchTwoAddressAreas[event.data];
          that.branchThreeAddress.area = '请选择'; //三级区域的区
          for (var i = 0; i < that.branchTwoAddressAreasCode.length; i++) {
            if (that.branchTwoAddressAreasCode[i].city === that.branchTwoAddress.city) {
              that.branchTwoAddress.code = that.branchTwoAddressAreasCode[i].code; //二级区域的市和市代码
              that.branchThreeAddress.code = 'none'; //三级区域的区代码
            }
          }
          that.setDistrictData();
        }
      })
    },
    //支行区域（三级）
    onclickbranchBankThree: function() {
      if (this.addressDetailDisabled) {
        return
      }
      var that = this;
      picker.pick({
        items: that.branchThreeAddressAreas,
        index: that.branchThreeAddressIndex,
      }, event => {
        if (event.result === 'success') {
          // that.logEvent('select_bank_area');
          that.branchThreeAddressIndex = event.data;
          that.branchThreeAddress.area = that.branchThreeAddressAreas[event.data];
          for (var i = 0; i < that.branchThreeAddressAreasCode.length; i++) {
            if (that.branchThreeAddressAreasCode[i].area === that.branchThreeAddress.area) {
              that.branchThreeAddress.code = that.branchThreeAddressAreasCode[i].code; //二级区域的市和市代码
            }
          }
        }
      })
    },
    //input 银行支行名称
    inputbranchbankname: function(event) {
      // this.logEvent('input_bank_addr');
      this.branchBankName = event.value;
    },

    //弹窗事件
    showAlertTips: function(tips, time = 2000) {
      if (false == this.isShowAlert) {
        this.isShowAlert = true;
        this.alertTips = tips;
        setTimeout(() => {
          this.isShowAlert = false;
          // this.tips = '';
        }, time)
      }
    },
    checkPwd: function(pwd) {
      return /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,15}$/.test(pwd);
    },
    //下一步事件
    onclicknext: function() {
      this.logEvent('btn_submit');
      var that = this;
      // var baseurl = that.bibApi + '/EditUserBasic/Bibfx';
      var baseurl = that.bibApi + '/SetTradePassword';
      var body = {}

      if (!this.emailDisabled) {
        if (!/^[a-zA-Z0-9][a-zA-Z0-9-.]{0,19}@[a-zA-Z0-9][a-zA-Z0-9-.]{0,11}.[a-zA-Z]{2,10}$/.test(this.membereMail)) {
          this.showAlertTips('请填写正确的邮箱');
          return;
        }
        body.Email = that.membereMail;
      }

      if (!this.addressDetailDisabled) {
        if (this.branchAddress.code == 'none') {
          this.showAlertTips('请选择省份');
          return;
        }
        if (this.branchAddress.code != 'other') {
          if (this.branchTwoAddress.code == 'none') {
            this.showAlertTips('请选择市');
            return;
          }
          if (this.branchThreeAddress.code == 'none') {
            this.showAlertTips('请选择区');
            return;
          }
        }
        if (!this.addressDetail) {
          this.showAlertTips('请填写详细地址');
          return;
        }
        body.AddressLv1 = that.branchAddress.code;
        if (this.branchAddress.code != 'other') {
          body.AddressLv2 = that.branchTwoAddress.code;
          body.AddressLv3 = that.branchThreeAddress.code;
        }
        body.AddressDetail = that.addressDetail;
      }

      if (!this.answerDisabled) {
        if (this.memberQuestion === '请选择') {
          this.showAlertTips('请选择密保问题');
          return;
        }
        if (this.memberOtherQuestion.length <= 0 && this.isOtherQuestion) {
          this.showAlertTips('请填写密保问题');
          return;
        }

        if (this.memberAnswer.length <= 0) {
          this.showAlertTips('请正确填写密保问题答案');
          return;
        }

        if (this.isOtherQuestion) {
          body.SafeQuestionOther = this.memberOtherQuestion;
        }

        body.SafeQuestion = that.memberQuestionCode;
        body.SafeAnswer = that.memberAnswer;
      }else {
        body.SafeQuestion = that.memberQuestionCode;//密保问题需要再次提交code
      }

      if (!this.passwordDisabled) {
        if (!this.checkPwd(this.memberPassword)) {
          this.showAlertTips('请正确填写密码');
          return;
        }
        if (!this.checkPwd(this.memberSurePassword)) {
          this.showAlertTips('请正确填写确定密码');
          return;
        }
        if (this.memberSurePassword != this.memberPassword) {
          this.showAlertTips('确定密码不一致');
          return;
        }
        // body.MainPassword = that.memberPassword;
        body.TradePassword = that.memberPassword;
        body.ConfirmPassword = body.TradePassword;
      }

      if (that.isSubmitBtnClick) {
        return;
      }
      that.isSubmitBtnClick = true;
      body.Server = that.server;
      body.Trade_ID = that.tradeId;

      if (utils.isBlankString(body.Server) || utils.isBlankString(body.Trade_ID)) {
        this.showAlertTips('交易服务器信息异常，请稍后再试');
        return;
      }
      http.putFormToken(that.userToken, baseurl, body, function(response) {
        that.isSubmitBtnClick = false
        if (response.ok && response.data) {
          var result = response.data
          if (result.IsOK) {
            that.showSuccess = true
          } else {
            if (result.ResponseStatus&&result.ResponseStatus.ErrorCode) {
              var error = that.errorCodes[result.ResponseStatus.ErrorCode];
              if (utils.isBlankString(error)) {
                error = '提交失败，请重试';
              }
              that.showAlertTips(error);
            }
          }
        } else {
          that.showAlertTips('网络异常，请稍后再试')
        }
      })
    }
  }
}
</script>

<style  src="../style/common.css" scoped>
</style>
<style scoped>
.text-item {
  color: white;
}

.item-row {
  position: absolute;
  left: 0px;
  right: 0px;
  top: 0px;
  flex-direction: row;
}

.line {
  flex: 1;
  height: 20px;
  border-bottom-width: 1px;
  border-bottom-color: #2e74e9;
}

.whiteline {
  flex: 1;
  height: 20px;
}

.grayline {
  flex: 1;
  height: 20px;
  border-bottom-width: 1px;
  border-bottom-color: #ABABAB;
  /* border-bottom-style: dashed; */
}

.circle {
  width: 40px;
  height: 40px;
  border-radius: 20px;
  border-color: #2e74e9;
  border-width: 1px;
  align-items: center;
  justify-content: center;
  background-color: white;
  margin-bottom: 15px;
}

.dashed {
  border-style: dashed;
  border-color: #AA9B6A;
}

.innerCircle {
  width: 30px;
  height: 30px;
  background-color: #2e74e9;
  border-radius: 15px;
  align-items: center;
  justify-content: center;
}

.gray {
  background-color: #ABABAB;
}

.align {
  margin-left: 25px;
  margin-right: 25px;
}

.topBorderLine {
  background-color: #f1f1f1;
  height: 1px;
}

.tips {
  font-size: 28px;
  line-height: 46px;
  color: #666666;
}

.text {
  color: white;
}

.text {
  color: #333333;
}

.text-select {
  color: #ffffff;
}

.margin {
  margin-left: 30px;
  margin-right: 30px;
}

.color3 {
  color: #e9302e;
}

.color32 {
  color: #f62b16;
  margin-right: 12px;
}

.infoItem {
  flex: 1;
  height: 70px;
  justify-content: space-between;
  align-items: center;
  margin-top: 50px;
}

.infoItem-branch {
  flex: 1;
  height: 70px;
  justify-content: space-between;
  align-items: center;
  margin-top: 16px;
}

.input-view {
  width: 550px;
  height: 70px;
}
.input-view-w {
  width: 366px;
  height: 70px;
}

.input-auto {
  width: 183px;
  height: 70px;
  border-color: #dddddd;
  border-width: 1px;
  margin: 0;
  /*flex: 1;*/
  align-items: center;
  justify-content: space-between;
}

.input {
  height: 70px;
  width: 550px;
  border-color: #dddddd;
  border-width: 1px;
}

.sex-input {
  justify-content: center;
  align-items: center;
  height: 38px;
  width: 38px;
  margin-right: 20px;
}

.input-size {
  /* width: 500px; */
  flex: 1;
  height: 70px;
  font-size: 24px;
  margin-left: 20px;
  margin-right: 20px;
}

.input-down-select {
  width: 30px;
  height: 70px;
  /* backgroundColor:red; */
  margin-right: 20px;
  align-items: center;
  justify-content: center;
}

.select-id-areacode {
  width: 180px;
  height: 70px;
  justify-content: space-between;
  align-items: center;
  border-right-color: gray;
  border-right-width: 1px;
}

.protocol {
  margin-top: 6px;
  background-color: #f7f7f6;
  height: 35px;
  width: 35px;
  border-color: #dddddd;
  border-width: 1px;
  margin-right: 11px;
  align-items: center;
  justify-content: center;
}

.button {
  width: 750px;
  height: 90px;
  /*margin-top: 68px;*/
  /*margin-bottom: 68px;*/
  /*margin-left: 25px;*/
  /*margin-right: 25px;*/
  justify-content: center;
  align-items: center;
}

.button-normal{
  background-color: #2e74e9;
}

.button-gray {
  background-color: gray;
}

.alert-show {
  position: absolute;
  left: 0px;
  top: 464px;
  right: 0px;
  bottom: 0px;
  align-items: center;
}

.alert-modul {
  height: 74px;
  border-radius: 37px;
  align-items: center;
  justify-content: center;
  padding-left: 60px;
  padding-right: 60px;
  /* background-color: rgba(0, 0, 0, 0.7); */
  background-color: #4c4c4c;
  opacity: 0.68;
}

.gold-text {
  color: #2e74e9
}

.gray-text {
  color: gray;
}
</style>
