<template>
<div class="">
  <status backgroundColor="#FFFFFF"></status>
  <navigation :title="title" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="back()"></navigation>
  <!-- <div class="navibar">
    <text class="navbar-title"> {{title}} </text>
    <div @click="back()" class="navbar-button">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div>
  </div> -->
  <div style="flex:1;justify-content:space-between;align-items:center;">
    <div style="align-items:center;">
      <image style="width:281px;height:252px;margin-top:300px;margin-bottom:40px;" :src="assets+'code.png'"></image>
      <text style="fontSize:32px;color:#666666">{{tips}}</text>
    </div>
    <div class="button" @click="login">
      <text style="fontSize:32px;line-height:48px;color:#2e74e9;text-align:center;">确认登录</text>
    </div>
  </div>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var storage = require('../include/storage.js');
var utils = require('../include/utils.js');
var app = weex.requireModule('app');
var firebase = weex.requireModule('firebase');
var http = require('../include/http.js');
import {ClientID,LiveClientID} from '../include/url.js';

export default {
  components: {
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'dialog': require('../components/wxc-dialog.vue'),
    'message': require('../components/message.vue'),
  },
  data: function() {
    return {
      oauth:'',
      assets:assetsUrl,
      title: "扫描二维码登录",
      jwtToken:'',
      clientId:''
    }
  },
  computed:{
    tips:function(){
      let loginType = ''
      if (ClientID == this.clientId) {
        loginType = '用户中心'
      }else if (LiveClientID == this.clientId){
        loginType = '直播间网页版'
      }
      return "即将在电脑端登录"+loginType;
    }
  },
  created:function(){
    var that = this;
    storage.getItem('memberCenter',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var memberCenter = JSON.parse(value);
      if (memberCenter) {
        that.oauth = memberCenter.oauth;
      }
    });
    storage.getItem('qrcode',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      let qrcode = JSON.parse(value);
      if (qrcode) {
        that.jwtToken = qrcode.jwtToken;
        that.clientId = qrcode.clientId;
      }
    });
  },
  methods:{
    back: function() {
      navigator.pop({
        animated: "true"
      }, res => {});
    },
    login:function(){
      let that = this;
      if (this.oauth && this.jwtToken) {
        let url = this.oauth+'/account/CodeScan?token='+this.jwtToken;
        http.get(url, function(response) {
          that.back();
        });
      }
    }
  }
}
</script>

<style lang="css" scoped>
.navibar {
  height: 88px;
  background-color: #E93030;
  align-items: center;
  justify-content: center;
}

.navbar-title {
  font-size: 36px;
  color: white;
  line-height: 54px;
  text-align: center;
}

.navbar-button {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 120px;
  padding-left: 30px;
  justify-content: center;
}

.goback {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 120px;
  padding-left: 30px;
  justify-content: center;
}

.button{
  width: 600px;
  height: 74px;
  border-color: #2e74e9;
  border-width: 1px;
  justify-content: center;
  align-items: center;
  margin-bottom: 80px;
}
</style>
