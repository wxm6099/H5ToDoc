<template>
<div style="backgroundColor:white">
  <status backgroundColor="#FFFFFF"></status>
  <navigation title="自选行情" textColor="#242424" :leftImg="leftItemSrc" @leftClick="onclickleftitem"></navigation>
  <!-- <div class="navbar">
    <text class="navbar-title"> 自选行情 </text>
    <div class="navbar-button" v-on:click="onclickleftitem">
      <image style="width: 20px; height: 36px" resize="contain" :src="leftItemSrc"></image>
    </div>
  </div> -->
  <div style="flex: 1;" ref="quoteListBG">
    <div class="selected-title">
      <text class="text-selector">我的自选</text>
    </div>
    <div ref="board" class="board" :style="wrapperStyle" @touchstart="touchstart" @touchmove="move" @touchend="touchend">
      <div class="block" :style="blockStyle[index]" v-for="(quote,index) in selectorList" :key="index" v-if="quote && dragingQuoteName != quote.symbolName || (quote && dragingQuoteName == quote.symbolName && false == isShowDraging)">
        <text class="cell-text">{{quote.symbolName}}</text>
      </div>
    </div>
    <div style="width: 750px">
      <text class="add-text"> 点击删除，长按拖动排序 </text>
    </div>
    <div class="selected-title" v-if="unselectorList.length != 0">
      <text class="text-selector">点击添加</text>
    </div>
    <scroller style="width: 750px ;backgroundColor: white;" show-scrollbar="false">
      <div style="flex-direction: row;flex-wrap: wrap;width: 750px;">
        <div class="cell-div" v-for="quote in  unselectorList" v-on:click="unSelecItemclick(quote.symbol)">
          <text class="cell-text-unselector">{{quote.symbolName}}</text>
        </div>
      </div>
    </scroller>
    <!-- <div v-if="showToast" v-on:click="onDialog" style="position:absolute;left:0px;top:0px;right:0px;bottom:0px;align-items:center;justify-content:center;">
      <div class="modul">
        <text style="color:#FFFFFF;font-size:28px;"> 固定产品,请勿删除</text>
      </div>
    </div> -->
  </div>
  <div v-if="isShowDraging" ref="quotedraging" style="position: absolute;width:216px;height: 70px;border-radius: 10px;background-color:#f1f1f1;align-items: center;justify-content: center;border-style: solid;" v-bind:style="{left:dragingLeft,top:dragingTop}">
    <text class="cell-text">{{dragingQuoteName}}</text>
  </div>
  <message></message>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var dom = weex.requireModule('dom');
var navi = weex.requireModule('navigator');
var modal = weex.requireModule('modal')
var firebase = weex.requireModule('firebase');
var storage = require('../include/storage.js');
var animation = weex.requireModule('animation');
var utils = require('../include/utils.js');

const initialBlocks = [{
    left: 0,
    top: 0
  },
  {
    left: 1,
    top: 0
  },
  {
    left: 2,
    top: 0
  },
  {
    left: 0,
    top: 1
  },
  {
    left: 1,
    top: 1
  },
  {
    left: 2,
    top: 1
  },
  {
    left: 0,
    top: 2
  },
  {
    left: 1,
    top: 2
  },
  {
    left: 2,
    top: 2
  },
  {
    left: 0,
    top: 3
  },
  {
    left: 1,
    top: 3
  },
  {
    left: 2,
    top: 3
  },
  {
    left: 0,
    top: 4
  },
  {
    left: 1,
    top: 4
  },
  {
    left: 2,
    top: 4
  },
  {
    left: 0,
    top: 5
  },
  {
    left: 1,
    top: 5
  },
  {
    left: 2,
    top: 5
  },
  {
    left: 0,
    top: 6
  },
  {
    left: 1,
    top: 6
  },
  {
    left: 2,
    top: 6
  },
  {
    left: 0,
    top: 7
  },
  {
    left: 1,
    top: 7
  },
  {
    left: 2,
    top: 7
  },
  {
    left: 0,
    top: 8
  },
  {
    left: 1,
    top: 8
  },
  {
    left: 2,
    top: 8
  }
]

function clone(object) {
  return JSON.parse(JSON.stringify(object))
}

module.exports = {
  components: {
    navigation: require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'message': require('../components/message.vue'),
  },
  data: function() {
    return {
      string: require('../include/string.js'),
      assets: assetsUrl,
      leftItemSrc: assetsUrl + 'back1.png',
      selectorSrc: assetsUrl + 'selector.png',
      unselectorSrc: assetsUrl + 'unselector.png',
      selectorList: [],
      unselectorList: [],
      index: 0,
      tempList: [],
      itemBroad: {},
      showToast: false, // 显示提示框
      touchEnable: false, //判断点击事件是否有效
      isShowDraging: false, //是否拖拽
      dragingQuoteName: '', //拖动的div的name
      dragingLeft: 25, //拖动的div的left
      dragingTop: 25, //拖动的div的top
      boardSize: {
        x: 0,
        y: 205,
        width: 750,
        height: -1
      },
      column: 3, //列表项数
      blocks: clone(initialBlocks),
      blocksIndex: [], //blocks位置索引
    }
  },
  props: {
    borderWidth: {
      type: Number,
      default: 216
    },
    borderHeight: {
      type: Number,
      default: 70
    },
    gap: {
      type: Number,
      default: 25
    }
  },
  created: function() {
    this.itemBroad = new BroadcastChannel('refreshData');
    this.getCacheData();
  },
  mounted: function() {
    setTimeout(this.updateBoardSize, 500);
  },
  computed: {
    wrapperStyle() {
      let count = parseInt((this.selectorList.length + 2) / 3);
      return {
        height: (this.borderHeight + this.gap) * count + 'px'
      }
    },
    blockStyle() {
      var map = this.blocks.map(block => ({
        left: block.left * (this.borderWidth + this.gap) + this.gap + 'px',
        top: block.top * (this.borderHeight + this.gap) + this.gap + 'px'
      }));
      return map;
    },
  },
  methods: {
    onDialog: function() {

    },
    disappear: function() {
      if (true == this.updateList()) {
        this.itemBroad.postMessage("upItem");
      }
      this.saveData();
    },
    onclickleftitem: function() {
      if (true == this.updateList()) {
        this.itemBroad.postMessage("upItem");
      }
      this.saveData();
      this.logEvent('Favorite_back');
      navi.pop({
        animated: "true"
      }, event => {

      });
    },
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    updateBoardSize: function() {
      var that = this;
      dom.getComponentRect(this.$refs.board, function(callback) {
        if (callback.result == true) {
          that.boardSize.x = parseInt(callback.size.left);
          that.boardSize.y = parseInt(callback.size.top);
          that.boardSize.width = callback.size.width;
          that.boardSize.height = callback.size.height;
        }
      });
    },
    setBlockIndex: function(count) {
      for (var i = 0; i < count; i++) {
        this.blocksIndex[i] = i;
      }
    },
    updateBlock: function(update = false) {
      for (var ix = 0; ix < this.blocksIndex.length; ix++) {
        this.blocks[ix].left = this.blocksIndex[ix] % this.column;
        this.blocks[ix].top = parseInt(this.blocksIndex[ix] / this.column);
      }
      if (true == update) {
        this.blocks.splice(0, 0);
      }
    },
    touchstart: function(e) {
      if (e.changedTouches && 1 == e.changedTouches.length) {
        let pointX = parseInt(e.changedTouches[0].screenX - this.boardSize.x);
        let pointY = parseInt(e.changedTouches[0].screenY - this.boardSize.y);

        let x = parseInt(pointX / (this.borderWidth + this.gap));
        let y = parseInt(pointY / (this.borderHeight + this.gap));
        this.changeIndex = (y * this.column + x);

        //点击位置不在选项框内，则不处理事件
        if (this.changeIndex < 0 || this.changeIndex >= this.selectorList.length) {
          this.touchEnable = false;
          return;
        }
        this.touchEnable = true;
        if (1 == this.selectorList.length && this.changeIndex >= 1) {
          this.dragingQuoteName = this.selectorList[0].symbolName;
          this.symbol = this.selectorList[0].symbol;
          return;
        }

        this.dragingLeft = this.boardSize.x + this.gap + x * (this.borderWidth + this.gap); //计算拖动div的left
        this.dragingTop = this.boardSize.y + this.gap + y * (this.borderHeight + this.gap); //计算拖动div的top
        this.left = this.dragingLeft;
        this.top = this.dragingTop;
        this.offsetX = pointX;
        this.offsetY = pointY;
        this.lastdx = 0;
        this.lastdy = 0;

        for (var i = 0; i < this.blocksIndex.length && i < this.selectorList.length; i++) {
          if (this.blocksIndex[i] == this.changeIndex && this.selectorList[i]) {
            this.dragingQuoteName = this.selectorList[i].symbolName;
            this.symbol = this.selectorList[i].symbol;
            break;
          }
        }
      }
    },
    move: function(e) {
      if (this.selectorList.length <= 1 || false == this.touchEnable || e.changedTouches.length > 1) {
        return;
      }
      if (e.changedTouches && e.changedTouches.length > 0) {
        let pointX = parseInt(e.changedTouches[0].screenX - this.boardSize.x);
        let pointY = parseInt(e.changedTouches[0].screenY - this.boardSize.y);

        let dx = pointX - this.offsetX;
        let dy = pointY - this.offsetY;

        if (Math.abs(dx) <= 20 && Math.abs(dy) <= 20 && false == this.isShowDraging) {
          this.lastdx = dx;
          this.lastdy = dy;
          return;
        }

        //防止多点触摸，造成漂移
        if (Math.abs(this.lastdx - dx) > 40 || Math.abs(this.lastdy - dy) > 40) {
          this.isShowDraging = true;
          return;
        }
        this.lastdx = dx;
        this.lastdy = dy;

        this.dragingLeft = this.left + dx;
        this.dragingTop = this.top + dy;

        this.isShowDraging = true;
        let x = parseInt(pointX / (this.borderWidth + this.gap));
        let y = parseInt(pointY / (this.borderHeight + this.gap));

        this.targetIndex = (y * this.column + x);
        this.targetIndex = Math.min(this.targetIndex, this.selectorList.length - 1);

        if (this.targetIndex < 0) {
          return;
        }

        if (this.targetIndex != this.changeIndex && this.targetIndex < this.selectorList.length) {
          if (this.changeIndex < this.targetIndex) {
            //往右或下拖动
            for (var i = 0; i < this.blocksIndex.length; i++) {
              if (this.blocksIndex[i] == this.changeIndex) {
                this.blocksIndex[i] = this.targetIndex;
              } else if (this.blocksIndex[i] > this.changeIndex && this.blocksIndex[i] <= this.targetIndex) {
                this.blocksIndex[i] = this.blocksIndex[i] - 1;
              }
            }
          } else {
            //往左或上拖动
            for (var i = 0; i < this.blocksIndex.length; i++) {
              if (this.blocksIndex[i] == this.changeIndex) {
                this.blocksIndex[i] = this.targetIndex;
              } else if (this.blocksIndex[i] >= this.targetIndex && this.blocksIndex[i] < this.changeIndex) {
                this.blocksIndex[i] = this.blocksIndex[i] + 1;
              }
            }
          }
          this.updateBlock(); //更新界面
          this.changeIndex = this.targetIndex;
          this.symbol = "";
        }
      }
    },
    touchend: function(e) {
      if (this.touchEnable) {
        if (!utils.isBlankString(this.symbol) && false == this.isShowDraging) {
          this.selecItemonclick(this.symbol);
        }
      }
      this.touchEnable = false;
      this.isShowDraging = false;
      this.lastdx = 0;
      this.lastdy = 0;
    },
    saveData: function() {
      storage.setItem('favorite', JSON.stringify(this.selectorList));
    },
    getCacheData: function() {
      var that = this;

      let selectorArr = storage.getItemSync('favorite');
      if (selectorArr && selectorArr.length > 2) {
        that.selectorList = utils.unique(JSON.parse(selectorArr));
      }

      let quoteList = storage.getItemSync('quoteList');
      if (quoteList && quoteList.length > 0) {
        let list = JSON.parse(quoteList);
        let temp = [];
        for (var i = 0; i < list.length; i++) {
          temp = temp.concat(list[i].symbolList);
        }
        this.unselectorList = utils.diffrence(temp, that.selectorList);
      }

      that.setBlockIndex(that.selectorList.length + that.unselectorList.length);
    },
    showTips: function() {
      this.showToast = true;
      setTimeout(() => {
        this.showToast = false;
      }, 2000)
    },
    updateList: function() {
      var needUpate = false;
      var list = clone(this.selectorList);
      for (let i = 0; i < this.blocksIndex.length; i++) {
        let idx = this.blocksIndex[i];
        if (idx < this.selectorList.length) {
          this.selectorList[idx] = list[i];
        }
        if (idx != i) {
          needUpate = true;
        }
        this.blocksIndex[i] = i;
      }
      return needUpate;
    },
    selecItemonclick: function(itemtext) {
      if (this.isShowDraging) {
        return;
      }
      if (!utils.isBlankString(itemtext)) {
        this.logEvent('Favorite_' + itemtext);
      }

      // if (itemtext == "GOLD" || itemtext == "SILVER" || itemtext == "DXY") {
      //   this.showTips();
      //   return;
      // }
      var that = this;
      //更新同步数组后才能进行添加删除操作，否则数据异常
      if (true == that.updateList()) {
        that.updateBlock(true);
      };
      that.removeInList(that.selectorList, itemtext, that.unselectorList);
      that.itemBroad.postMessage("upItem");
    },
    unSelecItemclick: function(itemtext) {
      if (this.isShowDraging) {
        return;
      }
      var that = this;
      this.logEvent('Favorite_' + itemtext);
      that.removeInList(that.unselectorList, itemtext, that.selectorList);
      this.itemBroad.postMessage("upItem");
    },
    removeInList: function(arr, objsymbol, templist) {
      let that = this;
      let quoteItem = {};
      for (var i = 0; i < arr.length; i++) {
        if (arr[i] && arr[i].symbol == objsymbol) {
          templist.push(utils.clone(arr[i]));
          arr.splice(i, 1);
          break;
        }
      }
    }
  },
}
</script>


<style scoped>
.navbar {
  width: 750px;
  height: 88px;
  background-color: #E93030;
  align-items: center;
  justify-content: center;
}

.navbar-button {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 120px;
  padding-left: 30px;
  justify-content: center;
}

.img-selector {
  width: 35px;
  height: 35px;
  margin-top: 14px;
  margin-left: 14px;
  background-color: #f1f1f1;
}

.text-selector {
  margin-top: 34px;
  font-size: 30px;
  margin-left: 24px;
  color: #454950;
  font-family: "Microsoft YaHei";
}

.add-text {
  text-align: right;
  font-size: 26px;
  color: #9ba1ab;
  margin-top: 44px;
  margin-right: 26px;
  font-family: "Microsoft YaHei";
}

.selected-title {
  background-color: #ffffff;
}

.selector-text {
  flex-direction: row;
  align-items: center;
  justify-items: center;
}

.block {
  position: absolute;
  border-style: solid;
  border-radius: 10px;
  width: 216px;
  height: 70px;
  justify-content: center;
  align-items: center;
  background-color: #f1f1f1;
  transition-property: top, left;
  transition-duration: 0s;
  transition-timing-function: linear;
}

.cell-div {
  border-style: solid;
  border-radius: 10px;
  width: 216px;
  height: 70px;
  justify-content: center;
  margin-left: 24px;
  margin-top: 24px;
  align-items: center;
  background-color: #f1f1f1;
}

.navbar-title {
  font-size: 36px;
  color: white;
  line-height: 54px;
  text-align: center;
}

.cell-text {
  color: #454950;
  font-size: 26px;
  line-height: 40px;
  font-family: "Microsoft YaHei";
  text-align: center;
}

.cell-div-unselector {
  border-radius: 10px;
  width: 210px;
  height: 70px;
  justify-content: center;
  align-items: center;
  margin: 20px;
  background-color: #eaedf3;
}

.cell-text-unselector {
  color: #454950;
  font-size: 28px;
  line-height: 42px;
  align-items: center;
  justify-content: center;
}

.modul {
  height: 74px;
  border-radius: 37px;
  align-items: center;
  justify-content: center;
  padding-left: 60px;
  padding-right: 60px;
  background-color: rgba(0, 0, 0, 0.7);
}

.board {
  position: relative;
  width: 750px;
  margin-top: 6px;
  background-color: #FFFFFF;
  flex-direction: row;
  flex-wrap: wrap;
}
</style>
