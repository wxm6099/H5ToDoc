<template>
  <div v-if="show" :class="[service?'unusual-mask-service':'unusual-mask']" @click="maskClick" :style="{top:sizeTop,left:sizeLeft,right:sizeRight,bottom:sizeBottom}">
    <div v-if="!service">
      <div class="image-bg">
        <image class="image-icon" :src="data.img"></image>
      </div>
      <div class="title">
        <text class="title-size">{{dataTitle}}</text>
      </div>
      <div class="margin">
        <richtext class="title-size" @itemclick="pageClick">
          <span style="color:#518deb" pseudo-ref="sub">{{data.sub}}</span>
          <span style="color:#acc5ec">{{data.content}}</span>
        </richtext>
      </div>
    </div>
    <div v-if="service">
      <div class="service-alertView">
        <div style="margin-top:50px;align-items: center;">
          <image style="width: 100px;height: 100px;" :src="data.img"></image>
        </div>
        <div style="margin-top: 50px;align-items: center;">
          <text class="service-title-size">{{dataTitle}}</text>
        </div>
        <div class="footer">
          <div class="footer-btn-l" @click="cancelClick">
            <text class="btn-text-l"> {{cancel}} </text>
          </div>
          <div class="footer-btn-r" @click="confirmClick">
            <text class="btn-text-r"> {{confirm}} </text>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var globalEvent = weex.requireModule('globalEvent');
var app = weex.requireModule('app');
var storage = require('../include/storage.js');
var utils = require('../include/utils.js');
module.exports = {
  props: {
    service: { default: false },
    show: { default: false },
    data:{tag:'',title:'',sub:'',content:'',img:'',cancel:'取消',confirm:'确定'},
    size:{top:0,left:0,right:0,bottom:0},
    confirm: { default: '确定' },
    cancel: { default: '取消' },
  },
  data: function() {
    return {
      iphonex:utils.iphonex(),
      android:utils.isAndroid(),
      assets: assetsUrl,
      indexchannel:{},
    }
  },
  computed: {
    sizeTop () {
      const {data, size } = this;
      // if (!this.android && this.iphonex) {
      //   return size.top ? size.top + 88 : 88;
      // } else if (!this.android && !this.iphonex) {
      //   return size.top ? size.top + 40 : 40;
      // }else {
      //   return size.top ? size.top : 0;
      // }
      return size.top ? size.top : 0;
    },
    sizeLeft () {
      const {data, size } = this;
      return size.left ? size.left : 0;
    },
    sizeRight () {
      const {data, size } = this;
      return size.right ? size.right : 0;
    },
    sizeBottom () {
      const {data, size } = this;
      return size.bottom ? size.bottom : 0;
    },
    dataTitle () {
      const {data, size } = this;
      return data.title ? data.title : '';
    }
  },
  created:function() {
    var that = this;
    globalEvent.addEventListener("netWorkStatus", function(e) {
      if (e.oldStatus != e.netStatus && e.netStatus != 'NONE') {
        that.refreshClick();
      }else if (e.oldStatus != e.netStatus && e.netStatus == 'NONE') {
        that.NoNetClick();
      }
    });

    that.indexchannel = new BroadcastChannel('indexBroadPage');
    that.indexchannel.onmessage = function(event) {
      if (event.data.oldStatus != event.data.netStatus && event.data.netStatus != 'NONE') {
        that.refreshClick();
      }else if (event.data.oldStatus != event.data.netStatus && event.data.netStatus == 'NONE') {
        that.NoNetClick();
      }
    }
  },
  methods: {
    maskClick:function(){

    },
    pageClick:function(foo){
      if (foo.pseudoRef === 'sub') {
        this.$emit('pageClick',this.data.tag);
      }
    },
    NoNetClick: function() {
      this.$emit('pageClick','noNetWork');
    },
    refreshClick: function() {
      this.$emit('pageClick','refresh');
    },
    cancelClick: function() {
      this.show = false;
      this.$emit('cancel');
    },
    confirmClick: function() {
      this.show = false;
      this.$emit('confirm');
    },
  }
}
</script>

<style scoped>
.unusual-mask-service {
  position: absolute;
  background-color: rgba(0, 0, 0, 0.6);
  justify-content: center;
  align-items: center;
}
.unusual-mask {
  position: absolute;
  background-color: white;
  /* background-color: red; */
  /* justify-content: center; */
  align-items: center;
}
.image-bg{
  margin-top:140px;
  justify-content: center;
  align-items: center;
}
.image-icon{
  width:686px;
  height: 424px;
}

.title {
  margin-top: 50px;
  width: 750px;
  justify-content: center;
  align-items: center;
}

.title-size {
  font-size: 30px;
  line-height: 45px;
  color: #acc5ec;
  text-align: center;
}
.margin {
  margin-top: 40px;
  width: 750px;
  justify-content: center;
  align-items: center;
}

.service-title-size{
  font-size: 28px;
  line-height: 42px;
  color: black;
  text-align: center;
}
.service-alertView{
  width: 660px;
  background-color: #FFFFFF;
  border-radius: 10px;
  align-items: center;
}
.footer {
  margin-top: 50px;
  margin-bottom: 30px;
  flex-direction: row;
  align-items: center;
}
.footer-btn-l {
  align-items: center;
  justify-content: center;
  width: 180px;
  height: 80px;
  background-color: #FFFFFF;
  border-color: #2e74e9;
  border-width: 1px;
  border-radius: 10px;
}
.footer-btn-r {
  align-items: center;
  justify-content: center;
  margin-left: 80px;
  width: 180px;
  height: 80px;
  background-color: #2e74e9;
  border-radius: 10px;
}
.btn-text-l {
  font-size: 28px;
  line-height: 42px;
  color: #2e74e9;
  text-align: center;
}
.btn-text-r {
  font-size: 28px;
  line-height: 42px;
  color: white;
  text-align: center;
}
</style>
