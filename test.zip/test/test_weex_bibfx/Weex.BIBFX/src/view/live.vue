<template>
<div @viewdisappear="viewDisappear" @viewappear="viewAppear" @foreground="foreground" @background="background">
  <status backgroundColor="white"></status>
  <div style="flex: 1;width: 750px;margin-bottom: 176px">
    <div class="video">
      <media ref='mymedia' class="media" v-if="src" :src="src" @click="onVideo" :play-status="playStatus" auto-play='false'  :screenKeepOn="screenKeepOn"></media>
      <div v-if="playStatus !='' && playStatus !='play'" @click="onVideo" class="video" style="justify-content: center;align-items: center;background-color: black;">
        <image class="wifiplay" :src="wifistopimg" @click="playStatus ='play'"></image>
      </div>

      <div class="offline" v-if="!online" @click="onVideo">
        <image class="offline-img" resize="contain" :src="offlineimg" @click="onVideo"></image>
        <div class="offline-bottom">
          <text class="font30" style="color: #ffffff;">当前无直播，皇御精英讲师团队约你下期再见~</text>
        </div>
      </div>

      <div v-if="tabbarTime!=0" class="tabbar">
        <div @click="onback" class="goback">
          <image style="width: 20px; height: 36px" resize="contain" :src="backimg"></image>
        </div>
        <div class="gouser">
          <div v-if="!logined" style="flex: 1;flex-direction: row;align-items: center;justify-content: flex-end;">
            <text class="font32" style="color: #ffffff;margin-right: 24px" @click="onLogin">登录</text>
            <text class="font32" style="color: #ffffff;margin-right: 24px">|</text>
            <text class="font32" style="color: #ffffff;" @click="onReg">注册</text>
          </div>
          <div v-if="logined" style="flex: 1;flex-direction: row;align-items: center;justify-content: flex-end;" @click="showLoginMenu">
            <text class="font32" style="color: #ffffff;margin-right: 20px">{{user.name}}</text>
            <image style="width: 20px; height: 36px" resize="contain" :src="downimg"></image>
          </div>
        </div>
      </div>

      <div class="loginmenu-bg" v-if="isShowLoginMenu" @click="hiddenLoginMenu">
        <div class="loginmenu">
          <div class="loginmenu-item" v-if="inputTips == 1" @click="onActivation();hiddenLoginMenu()">
            <image style="width: 30px; height: 35px;margin-right: 12px" resize="contain" :src="activeimg"></image>
            <text class="font28" style="color: #2e74e9">激活账户</text>
          </div>
          <div class="loginmenu-item" v-if="inputTips > 2" @click="speed();hiddenLoginMenu()">
<!--            <gifView style="width: 180px; height: 36px;flex: 1" resize="contain" :src="speedimg"></gifView>-->
            <image style="width: 30px; height: 35px;margin-right: 12px" resize="contain" :src="speedimg" ></image>
            <text class="font28" style="color:#2e74e9">快速注资</text>
          </div>
          <div style="height: 1px;width: 130px;margin-left: 10px;margin-right: 10px;background-color: #dddddd"/>
          <div class="loginmenu-item" style="border-top-width: 1px;border-color: #dddddd;" @click="onLogout();hiddenLoginMenu()">
            <image style="width: 30px; height: 35px;margin-right: 12px" resize="contain" :src="exitimg" ></image>
            <text class="font28" style="color:#abafbc">退出登录</text>
          </div>
        </div>
      </div>

      <div v-if="tabbarTime!=0 && online" class="controlbar">
        <image class="play" :src="playStatus=='play'?playimg:stopimg" @click="onPlay"></image>
        <image class="refresh" :src="refreshimg" @click="onRefresh"></image>
        <image class="sound" :src="isSilent==true?muteimg:soundimg" @click="onSound"></image>
<!--        <text v-if="!logined" class="time">{{liveTime}}</text>-->
        <div style="margin-left: 100px;flex-direction: row;justify-content: flex-start;align-items: center;">
          <image style="width: 40px;height: 40px;" :src="onlineimg"></image>
          <text class="font30" style="margin-left: 10px;color: #e2e2e2;">在线：{{onlineNumber}} 人</text>
        </div>
        <image class="full" :src="fullimg" @click="onFull"></image>
      </div>
      <!--移动流量-->
      <div class="netwifi" v-if="netStatus=='MOBILE' && (true == showTips)">
        <div class="">
          <text class="wifi-text">当前无WIFI,是否允许用流量播放</text>
        </div>
        <div class="mobile">
          <div class="wifi-btn-play" style="background-color: #e9302e;" @click="onMBplay">
            <text class="wifi-btn" style="color: #fff;">继续播放</text>
          </div>
          <div class="wifi-btn-delete" style="background-color: #d8d8d8;" @click="onMBCancel">
            <text class="wifi-btn" style="color: #61656b;">取消</text>
          </div>
        </div>
        <div @click="onback" class="viewgoback">
          <image style="width: 20px; height: 36px" resize="contain" :src="backimg"></image>
        </div>
      </div>
      <div class="netwifi" v-if="netStatus=='ERROR'">
        <div @click="onback" class="viewgoback">
          <image style="width: 20px; height: 36px" resize="contain" :src="backimg"></image>
        </div>
        <div>
          <text style="color: #e9e9e9;font-size: 32px">网络未连接，请检查网络设置</text>
        </div>
        <div class="nonetwork" @click="onNetError">
          <text class="refreshText">刷新重试</text>
        </div>
      </div>
      <div class="netwifi" v-if="showNoLogin && !noLoginClicked && netStatus !='ERROR' ">
        <div style="width:750px;justify-content: center;align-items:center;margin-top:30px">
          <text style="text-align:center;color: #e9e9e9;font-size: 32px">每日直播课程，跟着名师做投资</text>
          <text style="margin-top:24px;text-align:center;color: #e9e9e9;font-size: 32px">登录后可与老师及其他投资者分享经验 </text>
        </div>
        <div class="mobile">
          <div class="wifi-btn-play" style="background-color: #d8d8d8;" @click="setAnchor('LIVE_prompt');logEvent('LIVE_prompt_login');menuClick(2);">
            <text class="wifi-btn" style="color: #61656b;">马上登录</text>
          </div>
          <div class="wifi-btn-delete" style="background-color: #e9302e;" @click="setAnchor('LIVE_prompt_register');logEvent('LIVE_prompt_register_sign');menuClick(1);">
            <text class="wifi-btn" style="color: #fff;">立即注册</text>
          </div>
        </div>
        <div class="nottLoginText" @click="onNoLoginPlay();logEvent('LIVE_prompt_visitors');">
          <text style="text-align:center;color: #9ba1ab;font-size: 28px;">游客限时观看</text>
          <div style="height: 1px;width: 180px ;background-color: #9ba1ab;"></div>
        </div>
        <div @click="onback" class="viewgoback">
          <image style="width: 20px; height: 36px" resize="contain" :src="backimg"></image>
        </div>
      </div>
      <!--登录 账号未激活-->
      <div class="netwifi" v-if="logined && isNoActivation && netStatus !='ERROR' ">
        <div style="width:750px;justify-content: center;align-items:center;margin-top:30px">
          <text style="text-align:center;color: #e9e9e9;font-size: 32px">看直播，侃行情，现在登录用户中心，</text>
          <text style="margin-top:24px;text-align:center;color: #e9e9e9;font-size: 32px">激活后可与老师及其他投资者分享经验~ </text>
        </div>
        <div class="mobile">
          <div class="wifi-btn-play" style="background-color: #d8d8d8;" @click="setAnchor('LIVE_activate');logEvent('LIVE_activate_sign');onActivation();">
            <text class="wifi-btn" style="color: #61656b;">马上激活</text>
          </div>
          <div class="activation-delay" @click="setAnchor('LIVE_activate');logEvent('LIVE_activate_later');delayActivation();">
            <text class="wifi-btn" style="color: #fff;">以后再说</text>
          </div>
        </div>
        <div @click="onback" class="viewgoback">
          <image style="width: 20px; height: 36px" resize="contain" :src="backimg"></image>
        </div>
      </div>

      <!--&lt;!&ndash;直播暂停&ndash;&gt;-->
      <div class="netwifi" v-if="showNotLoginView">
        <div @click="onback" class="viewgoback">
          <image style="width: 20px; height: 36px" resize="contain" :src="backimg"></image>
        </div>
        <div>
          <image class="wifiplay" :src="wifistopimg" @click="onCancelplay"></image>
        </div>
      </div>
    </div>
    <liveChatView :loginUser="user" :onData="messageData" @touchSlider="touchSlider" :login="loginChatJson" :button="chatButtonDic" @alertView="touchChat"></liveChatView>
  </div>

  <chatBar :isShowEmoji=isShowEmoji
           :isShowAt=isShowAt
           :inputTips="inputTips"
           :inputState="inputState"
           :keyboardShow="keyboardShow"
           :value="messageStr"
           @keyboard="keyboard"
           @oninput="oninput"
           @inputHeight="oninputheight"
           @login="onLogin"
           @register="onReg"
           @active="onActivation"
           @sendTextMessage="sendTextMessage"
           @selectAt="selectAt"
           @selectAtItem="selectAtItem"
           @selectPhoto="selectPhoto"
           @selectEmoji="selectEmoji"
           @selectLock="selectLock"
           @selectUnlock="selectUnlock"
           @emptyClick="touchSlider"
           @ref="setChatbarRef">
  </chatBar>

  <chatemoji :isShowEmoji=isShowEmoji
             @deleteEmoji="deleteEmoji"
             @selectEmojiItem="selectEmojiItem">
  </chatemoji>

  <markAlertView :isShowScore="isShowScoreAlert" @leftBtn="scoreLeftBtn" @bottomBtn="scoreBottomBtn" @rightBtn="scoreRightBtn"></markAlertView>
  <alertBoard :show="isShowBoard" :data="dataBoard" @close="isShowBoard = false"></alertBoard>
  <alertLogin :show="isShowLogin" :type="isShowLoginType" @login="onLogin" @register="onReg" @close="alertLoginWithClose"></alertLogin>
  <alertDuty :show="isShowDuty"></alertDuty>
  <alertScore :show="isShowScore" @close="isShowScore = false"></alertScore>

  <updateName :isShow="logined && (undefined == user.name || user.name == '')" :isSelectSex="undefined == user.sexy" :keyname="user.name"
  :sexy="userNick.sexy" :nickNameTips="userNick.tips" @updateNickName="updateNickName" @onInputName="onInputName" @onClose="onback"></updateName>

  <browser :show="showBrowser" noButton="true" :path="album" @close="showBrowser=false"></browser>
  <browserEdit :show="photoEdit.isShow" :path="photoEdit.photo" @close="photoEdit.isShow=false" @confirm="upload"></browserEdit>
  <selectBtns :show="isShowPhoto" :datas="photoBtns" @cancel="photoCancel" @btnClick="photoBtnsClick"></selectBtns>
</div>
</template>

<script>
import messageProtocal from '../include/Message_pb'
var http = require('../include/http.js');
var storage = require('../include/storage.js');
var assetsUrl = require('../include/base-url.js').assetsUrl();
var bundleUrl = require('../include/base-url.js').bundleUrl();
var animation = weex.requireModule('animation');
var modal = weex.requireModule('modal');
var navigator = weex.requireModule('navigator');
var dom = weex.requireModule('dom');
var utils = require('../include/utils.js');
var app = weex.requireModule('app');
var firebase = weex.requireModule('firebase');
const media = weex.requireModule('mediaplayer');
const netEvent = weex.requireModule('globalEvent');
const cookieStorage = weex.requireModule('cookieStorage');
const tripleDes = weex.requireModule('tripleDes');
import {LiveClientID} from '../include/url.js';
const imagePicker = weex.requireModule('imagePicker')
const websocket = weex.requireModule('webSocket')
const transfer = weex.requireModule('transfer')
const chatbarRef = undefined;

const tabTimeLimit = 5 * 1000;
const freeTimeLimit = 3600 * 1000;

module.exports = {
  components: {
    'status': require('../components/statusbar.vue'),
    'dialog': require('../components/wxc-dialog.vue'),
    markAlertView: require('./markAlertView.vue'),
    chatBar: require('../components/chatBar.vue'),
    chatemoji: require('../components/chatemoji.vue'),
    alertBoard: require('../components/alertBoard.vue'),
    alertLogin: require('../components/alertLogin.vue'),
    liveChatView: require('../components/liveChatView.vue'),
    alertDuty: require('../components/alertDuty.vue'),
    alertScore: require('../components/alertScore.vue'),
    selectBtns: require('../components/selectBtns.vue'),
    browser: require('./photoBrowser.vue'),
    browserEdit: require('./photoEdit.vue'),//编辑图片描述
    updateName: require('../components/updateNickName.vue'), // 补填昵称
  },
  computed: {
    inputState: function () {
      // return !this.logined || this.user.isShield || !this.socketOpened || this.offlineMode || this.forbidAll || (this.user.level < 10 && this.user.type < 30)
      return !this.logined || this.user.isShield || !this.socketOpened || this.forbidAll || (this.user.level < 10 && this.user.type < 30)
    },
    inputTips: function () {
      if (!this.logined) {
        return 0;
      } else if (this.user.level < 10 && this.user.type < 30) {
        return 1;
      } else if (!this.socketOpened) {
        return 4;
      } else if (this.forbidAll) {
        return 3;
      } else if (this.inputState == true) {
        return 2;
      }
      return 5
    },
  },
  data: function() {
    return {
      tabbarTime: 0,
      playStatus: "",
      netStatus: "",
      src: '',
      utm:'',
      channelName:'',
      cmsApiHost:'',
      deposit:'',//注资的url
      memberCenterUrl: "",
      liveTime: "00:00:00",
      user: {
        'name': '',
        'uName':'',
        'uPwd':'',
        'avator': '',
        'uid': '',
        'level': 0,
        'type': 0,
        'setting': {
          'c': '333',
          's': 14,
          'b': 0,
          'i': 0,
          'u': 0
        },
        'sexy': 0,
        'isShield': true,
        'userToken':''
      },
      wifistopimg: assetsUrl + 'live_wifi_stop.png',
      stopimg: assetsUrl + 'live_stop.png',
      playimg: assetsUrl + 'live_playing.png',
      refreshimg: assetsUrl + 'live_refresh.png',
      soundimg: assetsUrl + 'live_sound.png',
      fullimg: assetsUrl + 'live_full.png',
      registimg: assetsUrl + 'register.png',
      loginout: assetsUrl + 'loginout.png',
      backimg: assetsUrl + 'back1.png',
      muteimg: assetsUrl + 'live_mute.png',
      landingimg: assetsUrl + 'login.png',

      videoTime: freeTimeLimit,
      logined: false, //登录标记
      isNoActivation: false, //登录并且未激活的标记
      isShowMenu: false, // 登录注册菜单
      isSilent: false, //静音标记
      showNoLogin: false, //未登录，进入直播室标记
      noLoginClicked: false, //记录点击
      showNotLoginView: false, //移动流量不观看
      webSocket: new BroadcastChannel('liveTime'),
      // title: '观看结束',
      // content: '游客观看时间已结束，请登录会员账号，即可继续观看直播。',
      // confirmText: '登录',
      // cancelText: '注册',
      showDialog: false, //倒计时弹窗
      isBeginTimer: false, //是否开始倒计时
      isinitPlayStatus: false,
      isFull: false,
      showTips: true,
      insideview: false, //标记当前界面，避免重复调用
      playStatusCopy: '',
      isRunBg: false,
      anchor: '', //锚点记录
      enterBackGround: false, //兼容android后台模式
      miniPlay:true,
      sizeIndex:1,
      screenKeepOn:true,
      isShowScoreAlert:false,//是否显示评分弹窗
      scoreBroadcastChannel:false,//评分广播信息
      oauth:'',//单点
      clientId:LiveClientID,//clientID

      ///////////
      isShowEmoji: false,
      keyboardHeight:0,
      keyboardShow: false,
      messageStr: '',
      // isLogin: true,   // test 登录标记
      downimg: assetsUrl + 'down.png',
      activeimg: assetsUrl + 'active.png',
      exitimg: assetsUrl + 'exit.png',
      onlineimg: assetsUrl + 'live_online.png',
      offlineimg: assetsUrl + 'offlinebg.png',
      atalertimg: assetsUrl + 'live_img_at.png',
      speedimg: assetsUrl + 'speed.png',
      isShowLoginMenu: false,
      online: true,   //   无课程模式：false  有课程模式：true
      isShowPhoto: false,
      isShowAt: false,
      photoBtns:[
        {title:'拍照',img:assetsUrl + 'live_camera.png'},
        {title:'照片图库',img:assetsUrl+ 'live_photo.png'}],
      rtmp: '',
      chatSocket: '',
      outofview: false,//退出view（app是否切到后台运行）
      socketId: 0,
      socketOpened: false,
      forbidAll: false, // 全体禁言
      update: 1,
      loginChatJson:{isLogin:false,downTime:'00:00:00'},
      album: '',
      showBrowser: false,
      photoEdit:{isShow:false,photo:''},
      uploadUrl: '',
      chatButtonDic:{clear:false,lock:false,at:'hide'},
       isAndroid:utils.isAndroid(),
      isShowBoard: false,
      dataBoard:{},
      isShowDuty: true,
      isShowLogin: false,
      isShowLoginType: 0,  // 0：倒计时结束  1：点击讲师说  2：最新广播
      isShowScore: false,
      onlineNumber: 0,
      connecting: false, // 断线重连标记
      ///////////
      messageData:[],
      userNick: {name:'',tips:'',sexy:1}, // 更新昵称

      intoScanOrPhoto: false,  // 进入相机或者相册
      curCourse: { time: '', date: '', teacher: '' }, // 当前课程信息
    }
  },
  destroyed: function() {
    if (!utils.isAndroid()) {
      // this.viewDisappear();
    }
  },
  beforeCreate:function(){
    var that = this;
    storage.getItem('liveShowTips', function(value) {
      if (!utils.isBlankString(value)) {
        that.showTips = JSON.parse(value).showTips;
        that.isSilent = JSON.parse(value).mute;
      }
    });
    // that.isSilent = app.isSilentMode();
  },
  created: function() {
    var that = this;
    if (cookieStorage) {
      cookieStorage.deleteCookie('');
    }
    if (undefined != media) {
      media.stop();//关闭小视屏窗口
    }

    if (utils.iOS()) {
      const scoreStar = new BroadcastChannel('scoreStarChannel');
      var data = {
        isLivePage:true,
        isShowScore:false,
      };
      scoreStar.postMessage(JSON.stringify(data));
      scoreStar.onmessage = function(event) {
        if (!utils.isBlankString(event.data)) {
          var score = JSON.parse(event.data);
          if (score.isLivePage) {
            if (that.playStatus == 'stop') {
              that.isShowScoreAlert = score.isShowScore;
            }else {
              that.scoreBroadcastChannel = score.isShowScore;
            }
          }
        }
      };
    }
    this.setNetWorkEvent();

    if (app) {
      app.setStatusBarStyle(0);
      if (utils.isAndroid()) {
        app.setNetwork();
      }
    }

    let mcData = storage.getItemSync('memberCenter');
    if (!utils.isBlankString(mcData)) {
      let memberCenter = JSON.parse(mcData);
      if (memberCenter) {
        that.memberCenterUrl = memberCenter.memberCenterUrl;
        that.oauth = memberCenter.oauth;
      }
    }

    var _chatroom = storage.getItemSync('chatRoom')
    if (_chatroom && _chatroom.length >= 2) {
      var chatroom = JSON.parse(_chatroom)
      that.rtmp = chatroom.rtmp
      that.chatSocket = chatroom.socket
      that.chatSocketGuest = chatroom.socketguest

      that.src = chatroom.rtmpUrl;

      if (chatroom.interval != undefined) {
        that.interval = chatroom.interval
      }
    }

    this.updateUserInfo()

    if (!this.logined || (this.user.name != undefined && this.user.name != '')) {
      this.chatRoom()
    }

    this.onTabbarTime();
    if (this.videoTime > 0) {
      this.playStatus = 'play';
    }
    this.liveChannel = new BroadcastChannel('liveScanner-photo');
    this.liveChannel.onmessage = function (event) {
      that.photoEdit.isShow = true;
      that.photoEdit.photo = event.data.url; //event.data.file
    };
    let value  = storage.getItemSync('commonUrl');
    if (utils.isBlankString(value)) {
        return
    }
    var commonUrl = JSON.parse(value);
    if (commonUrl) {
        that.cmsApiHost = commonUrl.cmsApi; //接口基址
        that.uploadUrl = commonUrl.upload;
        that.deposit = commonUrl.deposit;
    }
     storage.getItem('nodeIdList',function (channel) {
          if (channel && channel.length >= 2) {
            var channelIds = JSON.parse(channel)
            let nolive = channelIds.nolive
            that.getBanner(nolive)// 获取无直播banner
          }
     })
    this.channelName = app.channelName();
    if (this.channelName) {
      this.utm = "?ComeFrom=GlobalApps&utm_source=APP&utm_campaign=&utm_content=&utm_term=&utm_medium=" + this.channelName;
    }
    // that.silent = weex.requireModule('app').isSilentMode();
    storage.getItem('playsetting', function(value) {
      if (value && value.length>2) {
        var seting = JSON.parse(value);
        that.miniPlay = seting.enable;
        that.sizeIndex = seting.sizeIndex;
      }else {
        that.miniPlay = true;
        that.sizeIndex = 1;
      }
    });
  },
  methods: {
    onInputName: function (event) {
      if (event.value != this.userNick.name) {
        this.userNick.name = event.value
      }
      if (!utils.checkNickName(this.userNick.name)) {
        this.userNick.tips = '请输入1-16位中英文'
      } else {
        this.userNick.tips = ''
      }
    },
    updateNickName: function (sex) {
      var that = this
      this.userNick.sexy = sex;
      if (!utils.checkNickName(this.userNick.name)) {
        this.userNick.tips = '请输入1-16位中英文'
        return
      } else {
        this.userNick.tips = ''
      }
      if (this.cmsApiHost) {
        let body = {
          IsUpdate: true,
          userDetail: {
            'Id': this.user.uid,
            'NickName': this.userNick.name,
            'Sexy': this.userNick.sexy
          },
          Channel: 'bibfx'
        }
        if (undefined == this.cmsApiHost || this.cmsApiHost.length <= 5) {
          return
        }
        var updateUserUrl = this.cmsApiHost + '/UserCenter/UpdateUserDetail?format=json'
        http.putFormToken(that.user.userToken,updateUserUrl, JSON.stringify(body), function (resp) {
          if (resp.ok && resp.data) {
            if (resp.data.IsOK == true) {
              var value = storage.getItemSync('userInfo')
              if (value && value.length > 4) {
                that.userNick.name = ''//昵称设置成功后清除昵称选项
                that.userNick.sexy = 1//昵称设置成功后清除性别选项
                var userJson = JSON.parse(value)
                // userJson.UserProductResult.NickName = body.userDetail.NickName;
                // userJson.UserProductResult.Sexy = body.userDetail.Sexy;
                // userJson.nickName = body.userDetail.NickName;
                userJson.nickName = body.userDetail.NickName
                userJson.sex = body.userDetail.Sexy
                storage.setItem('userInfo', JSON.stringify(userJson))
              }
              that.user.name = body.userDetail.NickName
              that.user.sexy = body.userDetail.Sexy
              if (!that.socketOpened) {
                that.socketId++
                that.chatRoom(that.socketId)
              }
            } else {
              that.userNick.tips = resp.data.Message
            }
          }
        })
      }
    },

    ////////////////////////////////////////////////////////////////////////////////
    sendTextMessage:function(){
      this.isShowAt = false
      var msg = {
        'type': 'message',
        'text': this.updateMessage(this.messageStr),
        'font': {
          's': 14,
          'c': '333',
          'b': 0,
          'i': 0,
          'u': 0
        },
        'channel': 'bibfx',
        'isShield': false,
        'setting': this.user.setting,
        'classTime': this.curCourse.time,
        'classDate': this.curCourse.date,
        'classTeacher': this.curCourse.teacher,
      }

      if (this.logined && this.socketOpened && this.messageStr.length) {
        websocket.send(JSON.stringify(msg))
      }
      this.messageStr = ''
      this.chatBoxHeight = 70
    },
    selectAt:function(){
      if (this.inputState) {
        return
      }
      this.isShowAt = !this.isShowAt;
      var dic = {
        lock:false,
        clear:false,
        at:this.isShowAt == true ? 'show' : 'hide'
      }
      this.chatButtonDic = dic;
    },
    selectPhoto:function(){
      var that = this
      if (!that.isShowPhoto && !that.inputState) {
        that.isShowPhoto = true;
        that.isShowAt = false;
        that.touchSlider();
      }
    },

    selectEmoji: function () {
      let that = this
      this.isShowAt = false
      if (this.inputState) {
        return
      }

      setTimeout(function () {
        if (that.keyboardShow) {
          that.keyboardShow = false
          that.keyboardHeight = 0
        }
        setTimeout(function () {
            that.isShowEmoji = !that.isShowEmoji
        },230)
        // if (that.isAndroid){
        //     that.animations();
        // }
      }, 50)
      if (that.isAndroid) {
        this.$refs.list1.itemIsBottom(function(e){
          if (e && e.value){
            setTimeout(function(){
              that.scrollToBottom();
            },500)
          }
        });
      }
    },
    selectLock:function(){
      var dic = {
        lock:true,
        clear:false,
        at:this.chatButtonDic.at
      }
      this.chatButtonDic = dic;
    },
    selectUnlock:function(){
      var dic = {
        lock:false,
        clear:true,
        at:this.chatButtonDic.at
      }
      this.chatButtonDic = dic;
    },

    selectEmojiItem: function (item) {
      var that = this;
      if (item.face_text == 'empty') {
        return
      }
      let dic = item
      dic.code = new Date().getTime()
      // TO DO 获取点击的表情，转化为字符串
      if (utils.isAndroid()&&this.chatbarRef) {
        this.chatbarRef.addEmojiValue(dic,function (value) {})
      } else {
        this.messageStr = JSON.stringify(dic)
      }
    },

    deleteEmoji: function () {
      var that = this;
      let dic = {
        'face_text': 'delete',
        'face_name': 'delete',
        'face_id': '',
        'code': new Date().getTime()
      }
      if (utils.isAndroid()&&this.chatbarRef) {
        this.chatbarRef.setDeleteValue(dic,function (value) {
          that.messageStr =  value;
        })
      } else {
        this.messageStr = JSON.stringify(dic)
      }
    },

    keyboard:function(event){
      let that = this
      // setTimeout(function () {
      let height = event.height
      that.keyboardHeight = parseInt(height)
      if (that.isShowEmoji && height != 0) {
        that.isShowEmoji = false
      }
      that.keyboardShow = height != 0
      that.isShowAt = false
      // }, 50)
      if (that.isAndroid) {
        this.$refs.list1.itemIsBottom(function(e){
          if (e && e.value){
            setTimeout(function(){
              that.scrollToBottom();
            },500)
          }
        });
      }
    },

    oninputheight: function (event) {
      let height = event.height
      this.chatBoxHeight = height
    },

    oninput: function (event) {
      let message = event.value
      this.messageStr = message
    },

    touchSlider: function () {
      if (this.keyboardShow) {
        this.keyboardShow = false;
        this.keyboardHeight = 0;
      }
      if (this.isShowEmoji) {
        this.isShowEmoji = false
      }
      if (this.isShowAt){
        this.isShowAt = false;
      }
    },
    setChatbarRef:function(e){
        this.chatbarRef = e;
    },
    touchChat:function(e){
      let type = e.type;
      let data = e.data;
      if (type == 'headerImg') {
        if (this.inputState) {
          return// 禁止输入时不可点击头像
        }
        let item = data;
        if ((item.from && this.user.uid == JSON.parse(item.from).uid) || (item.m_from && this.user.uid == JSON.parse(item.m_from).uid)) {
          return// 自己的头像不可点击
        }
        let atName = ''
        if (item.from && JSON.parse(item.from).name) {
          atName = '{@' + JSON.parse(item.from).name + '}'
        }
        if (item.m_from && JSON.parse(item.m_from).name) {
          atName = '{@' + JSON.parse(item.m_from).name + '}'
        }
        let str = this.updateMessage(this.messageStr)
        if (str.indexOf(atName) < 0) {
          this.messageStr = atName
        }
      }

      if (type == 'newBroad'){
        if (data.done == 'login'){
          // 需要登录
          this.isShowLogin = true;
          this.isShowLoginType = 2;
        }
      }
      if (type == 'teacherSay') {
        if (data.done == 'login'){
          // 需要登录
          this.isShowLogin = true;
          this.isShowLoginType = 1;
        }
      }
      if (type == 'broadCell'){
        // 弹起广播弹窗
        this.isShowBoard = true;
        this.dataBoard = data;

      }
      if (type == 'bigImg'){
        // 弹出大图预览
        if (!this.showBrowser) {
          this.album = data.imgUrl
          this.showBrowser = true
          this.touchSlider()
        }

      }

      if (type == 'course'){ //课程信息
        this.curCourse = { time: '', date: '', teacher: '' }
        if (data.lessons.length <= 0) {
          return
        }
        const ms = (new Date()).getTime() // 当前时间
        for (var i = 0; i < data.lessons.length; i++) { // 获取当前课程
          const lesson = data.lessons[i]
          const duration = lesson.TimeSpan
          const startTime = lesson.StartTime ? parseInt(lesson.StartTime.slice(6, -7)) : ''
          const endTime = startTime + duration

          if (ms < startTime || ms > endTime) { // 非当前时间的课程
            continue
          }

          // 00:00-00:00
          this.curCourse.time = startTime > 0 && endTime > 0
            ? utils.dateFormat(startTime, 'hh:mm') + '-' + utils.dateFormat(endTime, 'hh:mm')
            : this.curCourse.time
          this.curCourse.date = utils.dateFormat(ms, 'yyyy-MM-dd') // 2019-11-22
          this.curCourse.teacher = lesson.Name || ''
          break
        }
      }
    },
    showLoginMenu:function(){
      this.isShowLoginMenu = true;
      this.tabbarTime = tabTimeLimit;
    },
    hiddenLoginMenu:function(){
      this.isShowLoginMenu = false;
    },

    photoBtnsClick:function(title){
      var that = this;
      that.intoScanOrPhoto = true;
      that.isShowPhoto = false;
      if (title == '拍照') {
        if (that.isAndroid && app) {
          app.isCheckCameraPermission(function (value) {
            if (value) {
              that.startScanner()
            }
          })
        }
        if (!that.isAndroid) {
          that.startScanner()
        }
      }else if (title == '照片图库') {
        if (imagePicker) {
          if (that.isAndroid) {
            app.isCheckPhotoPermission(function (value) {
              if (value) {
                imagePicker.takePhoto(function (cb) {
                  if (cb.path && cb.path.length > 5) {
                    that.photoEdit.isShow = true
                    that.photoEdit.photo = cb.path
                  }
                })
              }
            })
          }
          if (!that.isAndroid) {
            imagePicker.takePhoto(function (cb) {
              if (cb.path && cb.path.length > 5) {
                that.photoEdit.isShow = true
                that.photoEdit.photo = cb.path
              }
            })
          }
        }
      }
    },

    photoCancel:function(){
      this.isShowPhoto = false;
    },

    startScanner: function () {
      navigator.push({
        url: bundleUrl + 'liveScanner.js',
        animated: 'true',
        swipePop: 'true'
      }, event => {})
    },

    selectAtItem: function (item) {
      this.isShowAt = !this.isShowAt
      let atName = ''
      if (item == 'teacher') {
        atName = '{@讲师}'
      } else if (item == 'helper') {
        atName = '{@助理}'
      }
      let str = this.updateMessage(this.messageStr)
      if (str.indexOf(atName) < 0) {
        this.messageStr = atName
      }
    },

    updateMessage: function (detail) {
      let arr = []
      let arr_text = []
      let regex = /\s@(.*?)\s/g
      let match_array
      while (match_array = regex.exec(detail)) {
        if (match_array[1] != '' && undefined != match_array[1]) {
          arr.push(match_array[0])
          arr_text.push(match_array[1])
        }
      }
      for (let i = 0; i < arr.length; i++) {
        let reg = `${arr[i]}`
        let replacement = `{@${arr_text[i]}}`
        detail = detail.replace(reg, replacement)
      }
      return detail
    },

    alertLoginWithClose:function(type){
      this.isShowLogin = false;
      if (type == 0){
        navigator.pop({
          url: bundleUrl + 'index.js',
          animated: "false"
        }, event => {

        })
      }
    },

    speed:function(){
      this.touchSlider();
      if (this.deposit && this.deposit.length > 0) {
        var data = {
          title: '账户注资',
          url: this.deposit + this.utm,
          source: 'fastdeposit',
          from: 'fastdeposit'
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'memberCenter.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },

    getBanner: function (nolive) {
      if (utils.isBlankString(this.cmsApiHost) || utils.isBlankString(nolive)) {
        return
      }
      let that = this
      var url = this.cmsApiHost + '/Content/Site?format=json&channelId=' + nolive + '&OrderByDesc=AddDate&Take=1'
      // var url = 'http://demo.fantasysz.com:16629' + '/Content/Site?format=json&channelId=' + '231' + '&OrderByDesc=AddDate&Take=1'
      http.get(url, function (response) {
        if (response.data && response.data.Results && response.data.Results.length > 0) {
          let item = response.data.Results[0]
          // that.bannerTitle = item.Title
          // that.bannerImg = item.ImageUrl || item.imageUrl
          // that.bannerContent = item.ContentNoHtmlTag
          // that.bannerSummary = item.Summary.replace(/\r\n/g, '\n')
          that.offlineimg = item.ImageUrl || item.imageUrl;
        }
      })
    },


    ////////////////////////////////////////////////////////////////////////////////////////////////

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // websocket
    onSocketOpen: function (e) {

      var data = {
        'channel': 'bibfx',
        'user': this.user,
        'token': this.user.userToken
      }
      // data = '{"channel":"acetop","user":{"name":"哈哈哈家哈哈哈","avator":"http://demo.fantasysz.com:17001/20190725/d50e8308cf9748378e599582782150e3.jpg","uid":"d3f0f634-f008-4d8f-825f-52bf0359392d","level":0,"type":20,"setting":{"c":"333","s":14,"b":0,"i":0,"u":0},"sexy":1,"isShield":false,"userToken":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJkM2YwZjYzNC1mMDA4LTRkOGYtODI1Zi01MmJmMDM1OTM5MmQiLCJuYW1lIjoiTzZZWkRZSzg1ODI0TlZURSJ9.RNqx1RhGbfFe1Xz8x0hlKSZ7z7bkPq6wuiWWsZq1ym4"},"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJkM2YwZjYzNC1mMDA4LTRkOGYtODI1Zi01MmJmMDM1OTM5MmQiLCJuYW1lIjoiTzZZWkRZSzg1ODI0TlZURSJ9.RNqx1RhGbfFe1Xz8x0hlKSZ7z7bkPq6wuiWWsZq1ym4"}'
      if (this.socketOpened == false) {
        this.socketOpened = true
        websocket.send(JSON.stringify(data))
        this.heartbeat()
      }
    },
    heartbeat: function () {
      if (this.socketOpened == true) {
        websocket.send('{"type":"ping"}')
      }
      setTimeout(this.heartbeat, 15000)
    },
    onmessage: function (e) {
      var that = this
      let response = messageProtocal.Response.deserializeBinary(e.data.base64 == undefined ? e.data : e.data.base64)
      let events = response.toObject()
      if (events.eventsList) {
        that.messageData = events.eventsList;
      }
      if (events.eventsList) {
        let needScroll = false
        for (var i = 0; i < events.eventsList.length; i++) {

          if (events.eventsList[i].type == 'forbidAll') {
            if (events.eventsList[i].text == 'true') {
              this.touchSlider();
              this.forbidAll = true
            } else {
              this.forbidAll = false
            }
          }
          else if (events.eventsList[i].type == 'duringClass') {
            if (events.eventsList[i].text == 'true' || events.eventsList[i].text == 'True') {
              this.online = true
            } else {
              this.online = false
              this.playStatus = 'stop';
            }
          }
          else if (events.eventsList[i].type == 'online' || events.eventsList[i].type == 'offline' ) {
            // console.log('events.eventsList[i]:' + JSON.stringify(events.eventsList[i]));
            if (events.eventsList[i].text) {
              this.onlineNumber = events.eventsList[i].text;
            }
            /// TO DO  赋值 在线人数
            var msg = {
              'type': 'userlist',
              'text': '',
              'font': {
                's': 14,
                'c': '333',
                'b': 0,
                'i': 0,
                'u': 0
              },
              'channel': 'bibfx',
              'isShield': false,
              'setting': this.user.setting,
              'classTime': this.curCourse.time,
              'classDate': this.curCourse.date,
              'classTeacher': this.curCourse.teacher,
            }

            if (this.socketOpened) {
              websocket.send(JSON.stringify(msg))
            }
          }
          else if (events.eventsList[i].type == 'update') {
            // 用户更改信息，会推送这一条过来
            var info = JSON.parse(events.eventsList[i].text)
            if (info.uid == this.user.uid) {
              this.user.isShield = info.isShield
              var value = storage.getItemSync('userInfo')
              if (value && value.length > 4) {
                var userJson = JSON.parse(value)
                // userJson.UserAccount.IsShield = info.isShield;
                userJson.liveIsShield = info.isShield
                if (userJson.liveIsShield){
                    this.touchSlider();
                }
                if (!utils.isBlankString(info.avator)) {
                  userJson.headUrl = info.avator
                  this.user.avator = info.avator
                }
                storage.setItem('userInfo', JSON.stringify(userJson))
              }
            }
          }
        }
        if (needScroll) {
          setTimeout(this.scrollToBottom, 500)
        }
      }

    },
    onerror: function (e) {
      var that = this;
      this.socketOpened = false
      if (this.outofview == true || e.data == 'closed') {
        return
      }
      let id = this.socketId
      if (this.connecting == false) {
        that.connecting = true
        setTimeout(() => {
          that.chatRoom(id)
          that.connecting = false
        }, 10000)
      }
    },
    onclose: function (e) {
      this.socketOpened = false
    },
    chatRoom: function (id = 0) {
      if (this.outofview == true || id != this.socketId || this.chatSocket == '') {
        return
      }
      let requestHeader = {
        'weexVersion':WXEnvironment.weexVersion,
        'appName':WXEnvironment.appName,
        'appVersion':WXEnvironment.appVersion,
        'Name':WXEnvironment.deviceName,
        'OS':WXEnvironment.osName,
        'OSVersion':WXEnvironment.osVersion,
        'Device':WXEnvironment.deviceModel,
        'IsApp':'1'
      }

      this.socketOpened = false
      if (!utils.iOS()) {
        if (this.logined) {
          websocket.WebSocket(this.chatSocket, '',requestHeader)
        } else {
          websocket.WebSocket(this.chatSocketGuest, '',requestHeader)
        }
      }
      websocket.onopen(this.onSocketOpen)
      websocket.onmessage(this.onmessage)
      websocket.onerror(this.onerror)
      websocket.onclose(this.onclose)

      if (utils.iOS()) {
        if (this.logined) {
          websocket.WebSocket(this.chatSocket, '',requestHeader)
        } else {
          websocket.WebSocket(this.chatSocketGuest, '',requestHeader)
        }
      }
    },
    updateUserInfo: function () {
      var that = this
      var value = storage.getItemSync('userInfo')
      if (value && value.length >= 4 ) {
        var userJson = JSON.parse(value)
        if (userJson.userId&&userJson.userName&&userJson.userPassWord&&userJson.token) {//判断注册回到直播间后自动登录
          if (userJson.UserProductResult) {
            that.user.name = userJson.UserProductResult.NickName
            that.user.uid = userJson.UserProductResult.UserId
            that.user.uName = userJson.UserProductResult.userName
            that.user.uPwd = userJson.UserProductResult.userPassWord
            that.user.avator = userJson.UserProductResult.HeadUrl
            that.user.level = userJson.UserAccount.Level
            that.user.type = userJson.UserAccount.Type
            that.user.sexy = userJson.UserProductResult.Sexy
            that.user.isShield = userJson.UserAccount.IsShield
            that.user.userToken = storage.getItemSync('tonken')
          } else {
            that.user.name = userJson.nickName
            if (userJson.liveNickName) {
              that.user.name = userJson.liveNickName
            }
            that.user.uid = userJson.userId
            that.user.uName = userJson.userName
            that.user.uPwd = userJson.userPassWord
            that.user.avator = userJson.headUrl
            that.user.level = userJson.liveLevel
            that.user.type = userJson.liveType
            that.user.userToken = userJson.token
            that.user.sexy = userJson.liveSex
            that.user.isShield = userJson.liveIsShield
          }
          that.user.setting = {
            'c': '333',
            's': 14,
            'b': 0,
            'i': 0,
            'u': 0
          }
          if (undefined != that.user.sexy) {
            that.userNick.sexy = that.user.sexy
          } else {
            that.userNick.sexy = 1
          }
          that.logined = true;
          that.isShowLogin = false;
          this.loginChatJson.isLogin = this.logined;

          // if (undefined == that.user.avator || that.user.avator == '' || that.user.avator.length <= 0) {
          //   if (that.user.sexy == 1) {
          //     that.user.avator = that.defaultPic.maleAvatar
          //   } else {
          //     that.user.avator = that.defaultPic.femaleAvatar
          //   }
          // }
          // 登陆成功后直播间获取到的用户信息
          var liveurl = that.cmsApiHost + '/UserAccounts/UserInfo'
          http.getByHeader(that.user.userToken,encodeURI(liveurl), function (responseLive) {
            // console.log('输出直播用户的信息：'+JSON.stringify(responseLive));
            if (responseLive.data && responseLive.data.Results && responseLive.data.Results.length > 0) {
              var liveDic = responseLive.data.Results[0]// 直播间获取到的用户信息
              if (liveDic.UserProductResult.NickName) {
                that.user.name = liveDic.UserProductResult.NickName
                userJson.nickName = liveDic.UserProductResult.NickName
                userJson.liveNickName = liveDic.UserProductResult.NickName
              }
              if (liveDic.UserAccount.UserId) {
                that.user.uid = liveDic.UserAccount.UserId
                userJson.userId = liveDic.UserAccount.UserId
              }
              if (liveDic.UserProductResult.HeadUrl) {
                that.user.avator = liveDic.UserProductResult.HeadUrl
                userJson.headUrl = liveDic.UserProductResult.HeadUrl
              }
              if (liveDic.UserAccount.Level != undefined) {
                that.user.level = liveDic.UserAccount.Level
                userJson.liveLevel = liveDic.UserAccount.Level
              }
              if (liveDic.UserAccount.Type != undefined) {
                that.user.type = liveDic.UserAccount.Type
                userJson.liveType = liveDic.UserAccount.Type
              }
              if (liveDic.UserProductResult.Sexy != undefined) {
                that.user.sexy = liveDic.UserProductResult.Sexy
                userJson.liveSex = liveDic.UserProductResult.Sexy
              }
              if (liveDic.UserProductResult.UserName != undefined) {
                that.user.uName = liveDic.UserProductResult.UserName
                userJson.userName = liveDic.UserProductResult.UserName
              }
              if (liveDic.UserProductResult.Password != undefined) {
                that.user.uPwd = liveDic.UserProductResult.Password
                userJson.userPassWord = liveDic.UserProductResult.Password
              }
              if (undefined != that.user.sexy) {
                that.userNick.sexy = that.user.sexy
              } else {
                that.userNick.sexy = 1
              }
              if (liveDic.UserAccount.IsShield) {
                that.user.isShield = liveDic.UserAccount.IsShield
                userJson.liveIsShield = liveDic.UserAccount.IsShield
              }
              userJson.liveUserType = liveDic.UserProductResult.UserType
              storage.setItem('userInfo', JSON.stringify(userJson))
            }
          })
        }else{
          that.user.name = '游客'
          that.user.uid = ''
          that.user.uName = ''
          that.user.uPwd = ''
          that.user.avator = ''
          that.user.level = 0
          that.user.type = 0
          that.user.setting = {
            'c': '333',
            's': 14,
            'b': 0,
            'i': 0,
            'u': 0
          }
          that.user.sexy = 0
          that.user.isShield = true
          that.logined = false
          that.user.userToken = 'tonken_visitor_' + Date.now()
        }
      } else {
        that.user.name = '游客'
        that.user.uid = ''
        that.user.uName = ''
        that.user.uPwd = ''
        that.user.avator = ''
        that.user.level = 0
        that.user.type = 0
        that.user.setting = {
          'c': '333',
          's': 14,
          'b': 0,
          'i': 0,
          'u': 0
        }
        that.user.sexy = 0
        that.user.isShield = true
        that.logined = false
        that.user.userToken = 'tonken_visitor_' + Date.now()
      }
      if (utils.isAndroid()){
        setTimeout(that.scrollToBottom, 500)
      }
    },
    upload: function (content) {
      if (this.forbidAll || this.user.isShield || this.logined == false) {
        return
      }
      if (this.photoEdit.photo && this.photoEdit.photo.startsWith("file:///")) {//拍照的图片会带有此前缀，图库不会带
        this.photoEdit.photo = this.photoEdit.photo.replace('file:///','/');
      }
      var param = {
        url: this.uploadUrl,
        filePath: this.photoEdit.photo
      }
      var that = this

      transfer.uploadImage(param, function (params) {
        if (params && params.url) {
          if (utils.isBlankString(content)) {
            that.sendFileMessage(params.url)
          }else {
            that.sendFileMessage(params.url+' '+content)
          }
        }
      })
    },
    sendFileMessage: function (url) {
      var msg = {
        'type': 'file',
        'text': url,
        'font': {
          's': 14,
          'c': '333',
          'b': 0,
          'i': 0,
          'u': 0
        },
        'channel': 'bibfx',
        'isShield': false,
        'setting': this.user.setting,
        'classTime': this.curCourse.time,
        'classDate': this.curCourse.date,
        'classTeacher': this.curCourse.teacher,
      }

      if (this.socketOpened) {
        websocket.send(JSON.stringify(msg))
      }
      this.messageStr = ''
    },

    ////////////////////////////////////////////////////////////////////////////////////////////////


    menuClick: function(index) {
      switch (index) {
        case 0:
          this.isShowMenu = !this.isShowMenu;
          break;
        case 1:
          this.needRefresh = false;
          this.onReg();
          break;
        case 2:
          this.needRefresh = true;
          this.onLogin();
          break;
        case 3:
          this.onLogout();
          break;
        default:
      }
    },
    setAnchor: function(anchor) {
      this.anchor = anchor;
    },
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    background: function() {
      if (false ==  this.enterBackGround) {
        if (this.$refs.mymedia) {
          this.$refs.mymedia.setVideoEnable(false);
        }
        this.enterBackGround = true;
        this.touchSlider()
      }
      this.outofview = true
      this.socketId++
      websocket.close()
      // this.playStatusCopy = this.playStatus;
      // this.playStatus = 'stop';
      // storage.setItem('liveTime', this.getLocLiveTime() + ":" + this.videoTime);
    },
    foreground: function() {
      if (true == this.enterBackGround) {
        if (this.$refs.mymedia) {
          this.$refs.mymedia.setVideoEnable(true);
        }
        this.enterBackGround = false;
      }
      this.outofview = false
      this.socketId++
      this.chatRoom(this.socketId)
      // if (this.isFull) {
      //   return;
      // }
      // if (this.netStatus != 'MOBILE') {
      //   this.playStatus = this.playStatusCopy;
      // }
    },
    openDialog() {
      const self = this;
      self.showDialog = true;
    },
    closeDialog() {
      const self = this;
      self.showDialog = false;
    },
    setNetWorkEvent: function() {
      var that = this;
      netEvent.addEventListener("netStatus", function(e) {
        that.netStatus = e.net;
        if ('ERROR' == that.netStatus) {
          that.logEvent('LIVE_error');
        }
        if (!that.isFull) {
          if (e.net == 'WIFI' && !that.showNoLogin && !that.isNoActivation) {
            that.playStatus = 'play';
            that.showNotLoginView = false;
          }
          if (e.net == 'MOBILE') {
            if (false == that.showTips && !that.showNoLogin && !that.isNoActivation) {
              that.playStatus = 'play';
            }else {
              that.playStatus = 'stop';
            }
            // that.showTips = true;
          }
          that.playStatusCopy = that.playStatus;
        }
      });
    },
    dialogCancelBtnClick() {
      this.showDialog = false;
      this.menuClick(1);
    },
    dialogConfirmBtnClick() {
      this.showDialog = false;
      this.menuClick(2);
    },
    onMBplay: function() {
      // this.netStatus = 'WIFI';
      this.playStatus = 'play';
      this.showTips = false;
      this.logEvent('LIVE_data_hints_Y');
    },
    onMBCancel: function() {
      this.showNotLoginView = true;
      this.logEvent('LIVE_data_hints_N');
    },

    dialogNoPromptClick(e) {
      this.isChecked = e.isChecked;
    },
    viewAppear: function() {
      this.intoScanOrPhoto = false;
      media.stop();//关闭小视屏窗口
      // if (true == this.background) {
      //   return;
      // }
      var that = this;
      if (app) {
        app.setStatusBarStyle(0);
      }
      if (this.insideview == true) {
        return
      }
      this.insideview = true;

      if (cookieStorage) {
        cookieStorage.deleteCookie('');
      }
      // that.isSilent = app.isSilentMode();
      storage.getItem('userInfo', function(data) {
        if (data && data.length > 5) {
          var info = JSON.parse(data);
          if (!utils.isBlankString(info.userId)&&!utils.isBlankString(info.token)&&!utils.isBlankString(info.userName)&&!utils.isBlankString(info.userPassWord)) {
            that.logined = true;
            if (info.accountStatus == 0) {
              that.isNoActivation = true; //未激活
            } else {
              that.isNoActivation = false;
            }
          }
          that.showNoLogin = false;
          that.initNetView();
        } else {
          that.logined = false;
          if (that.isFull == false) {
            // that.startTimer();
          }
          if (that.showNoLogin) {
            that.initNetView();
            that.showNoLogin = true;
          } else {
            that.getLiveStatus();
          }
        }

        if (that.$refs.mymedia) {
          that.$refs.mymedia.disableSound(that.isSilent);
        }

        that.isFull = false;
      });

      this.updateUserInfo();

      if (!that.logined){
        if (that.isBeginTimer == false){
          that.isBeginTimer = true;
          that.startTimer();
        }
      }else {
        if (that.playStatus = 'stop') {
          that.playStatus = 'play'
        }
      }
      if (!this.logined || (this.user.name != undefined && this.user.name != '')) {
        if (!that.socketOpened) {
          that.socketId++
          that.chatRoom(that.socketId)
          this.update++
        }
      }
    },

    endTimer:function(){
      if (!this.isFull){
        this.isBeginTimer = false;
      }
      storage.setItem('liveTime', this.getLocLiveTime() + ":" + this.videoTime);
    },

    chatLoginParams: function() {
      if (utils.isBlankString(this.user.uid) || utils.isBlankString(this.user.userToken) || utils.isBlankString(this.user.uName) || utils.isBlankString(this.user.uPwd)) {
        return '';
      }
      var parm = {
        Username: this.user.uName,
        Password: this.user.uPwd,
        ClientID: this.clientId,
        TimeStamp: parseInt(Date.now() / 1000)
      }

      let content = tripleDes.encrypt(JSON.stringify(parm));
      return "content="+encodeURIComponent(content);
    },
    getLiveStatus: function() {
      var that = this;

      storage.getItem('livestatus', function(data) {
        if (utils.isBlankString(data)) {
          return;
        }
        var meg = JSON.parse(data);
        if (meg) {
          if (true == that.showTips) {
            that.showTips = meg.showTips;
          }

          if (that.isSilent != meg.mute) {
            that.isSilent = meg.mute
            if (that.$refs.mymedia) {
              that.$refs.mymedia.disableSound(that.isSilent);
            }
          }

          if (that.showTips && that.netStatus == 'MOBILE') {
            that.playStatus = 'stop';
          } else {
            that.playStatus = meg.playStatus;
          }
          that.isNoActivation = meg.isNoActivation;
        }
      });
    },
    startTimer: function() {
      var that = this;
      if (that.playStatus = 'stop') {
        that.playStatus = 'play'
      }
      storage.getItem('liveTime', function(value) {
        if (value == '') {
          that.videoTime = freeTimeLimit;
        } else {
          if (value.split(":")[0] == that.getLocLiveTime()) {
            that.videoTime = value.split(":")[1];
          } else {
            that.videoTime = freeTimeLimit;
          }
        }
        that.onCountdown();
      });
    },
    //评分弹窗的底部“下次再说”按钮
    scoreLeftBtn:function(){
      this.isShowScoreAlert = false;
    },
    //评分弹窗的底部“有话要说”按钮
    scoreRightBtn:function(){
      this.isShowScoreAlert = false;
    },
    //评分弹窗的底部“赞”按钮
    scoreBottomBtn:function(){
      this.isShowScoreAlert = false;
    },
    stopScoreAlertDownTimer:function(){
      const scoreStar = new BroadcastChannel('scoreStarChannel');
      var data = {
        isLivePage:false,
        isShowScore:this.scoreBroadcastChannel,
      };
      scoreStar.postMessage(JSON.stringify(data));
    },
    viewDisappear: function() {
      // if (true == this.background) {
      //   return;
      // }
      storage.setItem('liveShowTips', JSON.stringify({"showTips":this.showTips,"mute":this.isSilent}));

      this.insideview = false;
      this.endTimer();
      if (this.isFull == false) {
        netEvent.removeEventListener("netStatus");
        if (utils.iOS()) {
          this.stopScoreAlertDownTimer();//页面销毁或者退出直播间时 停止评分倒计时
        }
        this.showMiniView();
        this.playStatus = 'stop';
      } else {
        this.playStatus = 'stop';
        if (this.isinitPlayStatus == true) {
          storage.setItem('livestatus', '');
        }
      }

      this.playStatus = 'stop';

      websocket.close();
    },
    onVideo: function(event) {
      this.tabbarTime = this.tabbarTime == 0 ? tabTimeLimit : 0;
      if (this.tabbarTime != 0) {
        this.onTabbarTime();
      }
    },
    onNetError: function() {
      this.logEvent('LIVE_error_retry');
      this.initNetView();
    },
    onPlay: function(event) {
      if (this.playStatus == 'stop') {
        this.playStatus = 'play';
        this.logEvent('LIVE_play');
      } else {
        this.playStatus = 'stop';
        this.logEvent('LIVE_pause');
      }
      if (this.playStatus == 'stop') {
        this.isShowScoreAlert = this.scoreBroadcastChannel;
      }
    },
    //type=1 表示只更新用户信息不跳转到激活页面
    onActivation: function(type) {
      var that = this;
      that.touchSlider();
      this.playStatus = 'play';
      this.isNoActivation = false;
      that.endTimer();
      that.isShowMenu = false;
      if (that.logined) {
        storage.getItem('user-logintoken-id', function(value) {
          if (value) {
            var dataToken = JSON.parse(value);
            //登陆成功后获取用户状态
            let liveUrl = that.cmsApiHost + '/UserAccounts/UserInfo?format=json&channel=bibfx'
            http.getByHeader(dataToken.token,encodeURI(liveUrl),function (responseLive) {
              var liveDic = {}// 直播间获取到的用户信息
              if (responseLive.data && responseLive.data.IsOK && responseLive.data.Results.length > 0) {
                liveDic = responseLive.data.Results[0]// 直播间获取到的用户信息
              }
              //登陆成功后获取用户交易密码信息
              var tradeApi = that.cmsApiHost+'/MT4Account?format=json&UserId='+that.user.userId;
              http.getByHeader(dataToken.token,encodeURI(tradeApi),function (responseTrade) {
                var tradeDic = {BC_ACCOUNT_STATUS:''}// 直播间获取到的用户信息
                if (responseTrade.data && responseTrade.data.IsOK && responseTrade.data.Results.length > 0) {
                  for (var i = 0; i < responseTrade.data.Results.length; i++) {
                    if (responseTrade.data.Results[i].Platform == 'MT5') {
                      tradeDic = responseTrade.data.Results[i]// 直播间获取到的用户信息
                    }
                  }
                }
                let MainPassword = tradeDic.TRADE_PASSWORD;//MT5交易密码
                var StatusApi = that.cmsApiHost + '/IFXAccountDetails/IFXMC?format=json&NeedAttachmentIamges=false';
                http.getByHeader(dataToken.token, encodeURI(StatusApi), function(responseStatus) {
                  if (responseStatus.ok && responseStatus.data) {
                    if (responseStatus.data.Results.length > 0) {
                      var dataResult = responseStatus.data.Results[0];
    									let ReceiptStatus = dataResult.ReceiptStatus;
                      var BindBankNo = dataResult.Member.BindBankNo; //银行卡号
                      var CertNo = dataResult.Member.CertNo; //身份证号
    									let IsEmailValid = dataResult.Member.IsEmailValid;//
    									// let MainPassword = dataResult.Member.MainPassword;//
    									let AddressDetail = dataResult.Member.AddressDetail;//
                      // var memberAccount = dataResult.Member.MemberAccount; //交易账号（判断账号是否激活）
                      var memberAccount = tradeDic.BC_ACCOUNT_STATUS=='Normal'?'Normal':'';//交易账号（判断账号是否激活）
                      let SafeQuestion = dataResult.Member.SafeQuestion;
                      let SafeQuestionAnswer = dataResult.Member.SafeQuestionAnswer;
                      //0:默认(Default) 1:无(None)  2:已上传未处理(Unprocessing)  3:审核中(Approving)  4:审核通过(ApprovedPass)
                      //5:审核退回(ApprovedFail) 6等待账户审核通过:(WaitingAccountApproved)
                      var AttachmentStatus = dataResult.Member.AttachmentStatus;
                      //0:Default(默认) 1:NULL(无 None)   2:(Unprocessing)未处理  3:(Approving)审核中  4:(ApprovedPass)审核完成
                      //  4:(ApprovedFail)审核退回
                      var KycStatus = dataResult.Member.KycStatus;
                      var userDemo = {
                        userId:dataToken.userId,
                        userName: dataToken.userName,
                        userPassWord: dataToken.userPwd,
                        token: dataToken.token,
                        nickName: dataResult.Member.NickName,
                        realName: dataResult.Member.Name,
                        phone: dataResult.Member.Phone,
                        phoneArea: dataResult.Member.PhoneArea,
                        sex: dataResult.Member.Sex,
                        birthday: dataResult.Member.Birthday,
                        chatLoginParams: dataResult.ChatLoginParams,
                        accountStatus: dataResult.Member.AccountStatus,
                        server:tradeDic.SERVER,//交易服务器
                        tradeId:tradeDic.TRADE_ID,
    	                  mainPassword:MainPassword,//mt4交易密码
    					 					addressDetail:AddressDetail,//详细地址
    										email:dataResult.Member.Email,//邮箱
    										safeQuestion:dataResult.Member.SafeQuestion,//密保问题
    										safeQuestionAnswer:dataResult.Member.SafeQuestionAnswer,//密保答案
                        SafeQuestionOther:dataResult.Member.SafeQuestionOther,//其他密保问题
    										iB_NO : dataResult.Member.IB_NO,
    										certType : dataResult.Member.NationalArea,
    										certNo : dataResult.Member.CertNo,
    										bindBankNo : dataResult.Member.BindBankNo, // 银行卡号
    										bindSubBankName : dataResult.Member.BindSubBankName, // 支行名称
    										bindBank : dataResult.Member.BindBank,	//银行简称
    										bindSubBankOther : dataResult.Member.BindSubBankOther,	//支行其他
                        addressLv1:dataResult.Member.AddressLv1,
    										addressLv2:dataResult.Member.AddressLv2,
    										addressLv3:dataResult.Member.AddressLv3,
    										bindSubBankArea : dataResult.Member.BindSubBankArea,	// 省
    										bindSubBankAreaCounty : dataResult.Member.BindSubBankAreaCounty,	// 区
    										bindSubBankAreaCity : dataResult.Member.BindSubBankAreaCity,	//  市
                      };
                      //登录得到的用户信息可以保存下来
                      if (liveDic && liveDic.UserProductResult && liveDic.UserAccount) {
                        userDemo.headUrl = liveDic.UserProductResult.HeadUrl
                        userDemo.liveType = liveDic.UserAccount.Type
                        userDemo.liveLevel = liveDic.UserAccount.Level
                        userDemo.liveIsShield = liveDic.UserAccount.IsShield
                        userDemo.liveNickName = liveDic.UserProductResult.NickName
                        userDemo.liveSex = liveDic.UserProductResult.Sexy
                        userDemo.liveUserType = liveDic.UserProductResult.UserType
                      }
    									let url = that.cmsApiHost + '/ReceiptList/Bibfx'
    									http.getByHeader(dataToken.token, encodeURI(url),function(res){
    										if (res.ok) {
    											if (res.data && res.data.IsOK && res.data.Results) {
    												// ReceiptStatus = res.data.Results.ReceiptStatus;
                            if (ReceiptStatus == null && res.data.Results.ReceiptStatus) {
                              ReceiptStatus = res.data.Results.ReceiptStatus=='ApprovedPass'?'PassAndNo':res.data.Results.ReceiptStatus;//审核通过且未到账
                            }
                            if (!utils.isBlankString(res.data.Results.TradeAmount)){
                              userDemo.TradeAmount = res.data.Results.TradeAmount;
                              userDemo.TradeCurrency = res.data.Results.TradeCurrency;
                            }
    											}
    											ReceiptStatus = ReceiptStatus == null ? '' : ReceiptStatus;
    											storage.setItem('userInfo', JSON.stringify(userDemo));//更新并存储用户信息

    											if(type == -1){  return   }//参数 -1表示只做更新数据，不做跳转

    											storage.setItem('user_openaccount_from', 'live');//记录激活流程返回页面
    											// TO DO 填写资料
    											if (!BindBankNo || !CertNo) {
    												navigator.push({ //跳转填写资料
    												  url: bundleUrl + 'openAccount2.js',
    												  animated: "true",
    												  swipePop: "true",
    													disableBackPan: 'true',
    												}, event => {})
    											}
    											// TO DO 上传附件
    											else if (BindBankNo && CertNo && AttachmentStatus != 4) {
    												navigator.push({ //跳转上传附件
    												  url: bundleUrl + 'authentication.js',
    												  animated: "true",
    												  swipePop: "true",
    													disableBackPan: 'true',
    												}, event => {})
    											}else if (memberAccount) {
    												if (MainPassword && IsEmailValid && SafeQuestion && SafeQuestionAnswer){
    													//  TO DO 个人中心
                                var data = {
                                  title: '用户中心',
                                  url: that.memberCenterUrl + that.utm,
                                  source: 'mc',
                                  from: 'User_center',
                                  anchor: 'User_center',
                                }
                                storage.setItem('app-url', JSON.stringify(data));
                                navigator.push({
                                  url: bundleUrl + 'memberCenter.js',
                                  animated: "true",
                                  swipePop: "true",
                                  edgePop: "true",
                                  disableBackPan: 'true',
                                }, event => {})
    												}else{
    													// TO DO  交易密码
    													navigator.push({
    													  url: bundleUrl + 'tradePassword.js',
    													  animated: "true",
    													  swipePop: "true",
    														disableBackPan: 'true',
    													}, event => {})
    												}
    											} else {
    												if (BindBankNo && CertNo && AttachmentStatus == 4 && KycStatus != 'ApprovedPass') {
    													navigator.push({
    													  url: bundleUrl + 'survey.js',
    													  animated: "true",
    													  swipePop: "true",
    														disableBackPan: 'true',
    													}, event => {})
    												}
    												if (BindBankNo && CertNo && AttachmentStatus == 4 && KycStatus == 'ApprovedPass') {
    													// TO DO 非审核中 非审核通过
    													if (ReceiptStatus == 'Default' || ReceiptStatus == 'ApprovedFail' || ReceiptStatus == ''){
    														// tianxie 金额
    														navigator.push({
    														  url: bundleUrl + 'activateAccount.js?active=0',
    														  animated: "true",
    														  swipePop: "true",
    															disableBackPan: 'true',
    														}, event => {})
    													}else if (ReceiptStatus == 'Unprocessing' || ReceiptStatus == 'Approving' || ReceiptStatus == 'PassAndNo'){
    														navigator.push({
    														  url: bundleUrl + 'activateAccount.js?active=1',
    														  animated: "true",
    														  swipePop: "true",
    															disableBackPan: 'true',
    														}, event => {})
    													}
    												}
    											}
    										}
    									})
                    } else {
                      that.showAlertTips('网络异常，请稍后再试');
                    }
                  } else {
                    that.showAlertTips('网络异常，请稍后再试');
                  }
                });
              });
            })
          }
        });
      }
    },
    delayActivation: function() {
      this.playStatus = 'play';
      this.isNoActivation = false;
    },
    onLogin: function(event) {
      this.logEvent('live_login');

      this.isShowMenu = false;
      this.anchor = '';
      storage.setItem('user-original-fromLogin', 'live');
      navigator.push({
        url: bundleUrl + 'userLogin.js',
        animated: "true",
        swipePop: "true",
      }, event => {})
    },
    onReg: function(event) {
      this.logEvent('Live_sign');
      this.isShowMenu = false;

      var data = {
        from: 'live',
        openName: 'Live_sign',
      }
      storage.setItem('user-original-openAccount', JSON.stringify(data));
      storage.setItem('user_openaccount_from', 'live');
      navigator.push({
        url: bundleUrl + 'openAccount.js',//survey  openAccount userLogin  authentication
        animated: "true",
        swipePop: "true",
      }, event => {})
    },
    onLogout: function(event) {
      var that = this;
      that.touchSlider();
      this.isBeginTimer = true;
      that.startTimer();
      if (that.logoutUrl) {
        that.logined = false;
        that.chatRoomUrl = that.logoutUrl + "?roomName=" + that.roomName;
      }
			storage.setItem('user-logintoken-id', "{}");
      this.logined = false;
      this.loginChatJson.isLogin = this.logined;
      storage.setItem('userInfo', '{}', function (callback) {
        that.updateUserInfo()
      })

      // that.liveTime = that.videoTime;
      if (cookieStorage) {
        cookieStorage.deleteCookie('');
      }
    },
    onCountdown: function() {
      if (this.isBeginTimer == false){
        return;
      }
      if (this.videoTime <= 0) {
        this.playStatus = 'stop';
        this.showDialog = true;
        storage.setItem('liveTime', this.getLocLiveTime() + ":" + this.videoTime);
        if (!this.logined){
          this.isShowLogin = true;
        }
      } else {
        this.videoTime -= 1000;
       this.liveTime = "今日剩余观看时间：" + this.formatTime(this.videoTime / 1000);
        this.webSocket.postMessage(this.liveTime);

        this.loginChatJson.downTime = this.formatTime(this.videoTime / 1000);

        setTimeout(this.onCountdown.bind(this), 1000);
      }
    },
    getLocLiveTime: function() {
      var mData = new Date();
      var yy = mData.getFullYear();
      var mm = mData.getMonth() + 1;
      var dd = mData.getDate();
      return yy + "-" + mm + "-" + dd;
    },
    onRefresh: function(event) {
      this.logEvent('LIVE_refresh');
      if (this.videoTime > 0 && this.playStatus == 'play') {
        if (this.$refs.mymedia) {
          this.$refs.mymedia.refresh();
        }
      }
    },
    loadWebView: function(url, title = '', cookie = '') {
      if (url && url.length > 0) {
        var data = {
          title: title,
          url: url,
          cookie: cookie,
        }
        if (this.anchor && this.anchor.length > 0) {
          data.anchor = this.anchor;
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "false"
        }, event => {})
      }
    },
    onSound: function(event) {
      this.logEvent('LIVE_voice');
      this.isSilent = !this.isSilent;
      if (this.$refs.mymedia) {
        this.$refs.mymedia.disableSound(this.isSilent);
      }
    },
    onNoLoginPlay: function() {
      this.showNoLogin = false;
      this.noLoginClicked = true;

      if (this.netStatus == 'WIFI' && this.showNoLogin == false) {
        this.playStatus = 'play';
      }
      if (this.netStatus == 'MOBILE') {
        this.playStatus = 'stop';
        this.netStatus = 'MOBILE';
      }
      if (this.netStatus == 'ERROR') {
        this.showNoLogin = false;
        this.netStatus = 'ERROR';
      }
    },
    initNetView: function() {
      if (this.isFull) {
        this.getLiveStatus();
      } else {
        if (this.netStatus == 'WIFI') {
          if (this.logined == true) {
            if (this.isNoActivation == false) {
              this.playStatus = 'play';
            } else {
              this.playStatus = 'stop';
            }
          } else {
            this.showNoLogin = true;
          }
        }
        if (this.netStatus == 'MOBILE') {
          this.netStatus = 'MOBILE';
          if (this.logined == true) {
            if (false == this.showTips) {
              this.playStatus = 'play';
            }else {
              this.playStatus = 'stop';
            }
          } else {
            this.playStatus = 'stop';
            this.showNoLogin = true;
          }
        }
        if (this.netStatus == 'ERROR') {
          this.netStatus = 'ERROR';
          this.showNoLogin = false;
        }
      }
    },
    showMiniView: function(){
      var ispower = true;
      if (utils.isAndroid()) {
        ispower = app.isCheckWindowPermission();
      }
      if (this.playStatus != 'stop' && true == this.miniPlay && true == this.logined && false == this.intoScanOrPhoto && ispower) {
        media.setUrl(this.src);
        media.setViewSize(this.sizeIndex);
        media.play();
        media.setAudioEnable(!this.isSilent);
        this.screenKeepOn = true;
      }else {
        this.screenKeepOn = false;
      }

    },
    onCancelplay: function() {
      this.initNetView();
      this.showNotLoginView = false;
      this.logEvent('LIVE_data_hints_play');
    },
    onback: function(event) {
      if (utils.isAndroid()) {
        this.$refs.mymedia.release();
        this.showMiniView();
        this.playStatus = 'stop';
      }
      this.logEvent('LIVE_back');
      this.isinitPlayStatus = true;

      if(!this.logined){
        storage.setItem('liveTime', this.getLocLiveTime() + ":" + this.videoTime);
      }
      navigator.pop({
        // url: bundleUrl + 'index.js',
        animated: "false"
      }, event => {

      })
    },
    setLiveStatus: function() {
      storage.setItem('livestatus', JSON.stringify({
        "playStatus": this.playStatus,
        netStatus: this.netStatus,
        showTips: this.showTips,
        isNoActivation: this.isNoActivation,
        mute:this.isSilent
      }));
    },
    onFull: function(event) {
      if (this.online == false) {
        // 无课程直播时，禁示全屏操作
        return
      }
      this.setLiveStatus();
      this.playStatus = 'stop';
      this.isFull = true;
      this.logEvent('LIVE_screen');
      navigator.push({
        disableBackPan: 'true',
        orientation: 'horizontal',
        url: bundleUrl + 'liveFullScreen.js',
        animated: "false"
      }, event => {

      })
    },
    onTabbarTime: function() {
      this.tabbarTime = this.tabbarTime - 1000;
      if (this.tabbarTime > 0) {
        setTimeout(this.onTabbarTime.bind(this), 1000);
      } else {
        this.tabbarTime = 0;
        this.isShowMenu = false;
        this.isShowLoginMenu = false;
      }
    },
    formatTime: function(second, type = 0) {
      if (0 == type) {
        return [parseInt(second / 3600), parseInt(second / 60 % 60), parseInt(second % 60)].join(":").replace(/\b(\d)\b/g, "0$1");
      } else {
        return [parseInt(second / 3600), parseInt(second / 60 % 60)].join(":").replace(/\b(\d)\b/g, "0$1");
      }
    },
  }
}
</script>
<style src="../style/common.css"></style>
<style scoped>
.video {
  left: 0px;
  right: 0px;
  top: 0px;
  height: 421px;
}

.tabbar {
  position: absolute;
  left: 0px;
  top: 0px;
  right: 0px;
  height: 88px;
  background-color: black;
  filter: alpha(opacity=26);
  /* CSS3 standard */
  opacity: 0.6;
}

.media {
  position: absolute;
  left: 0px;
  top: 0px;
  right: 0px;
  bottom: 0px;
  background-color: black;
}

.goback {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 200px;
  padding-left: 30px;
  flex-direction: row;
  align-items: center;
}
/* ************************* */
.gouser{
  position: absolute;
  top: 0px;
  right: 0px;
  bottom: 0px;
  /*width: 200px;*/
  padding-right: 36px;
  /*flex-direction: row;*/
  /*align-items: center;*/
  /*justify-content: space-between;*/
}
.loginmenu-bg{
  position: absolute;
  top: 0px;
  bottom: 0px;
  left: 0px;
  right: 0px;
  justify-content: center;
  align-items: center;
}
.loginmenu{
  position: absolute;
  background-color: #ffffff;
  top: 74px;
  right: 36px;
  /*width: 150px;*/
  /*height: 150px;*/
  /*border-width: 1px;*/
  border-radius: 5px;
  flex-direction: column;
  align-items: center;
  box-shadow:1px  1px 6px rgba(1, 1, 0, 0.57);
}
.loginmenu-item{
  justify-content: center;
  align-items: center;
  flex-direction: row;
  flex: 1;
  padding: 20px;
}
.offline{
  position: absolute;
  top: 0px;
  bottom: 0px;
  left: 0px;
  right: 0px;
}
.offline-img{
  position: absolute;
  top: 0px;
  bottom: 0px;
  left: 0px;
  right: 0px;
}
.offline-bottom{
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  width: 750px;
  height: 80px;
  background-color: rgba(0,0,0,0.6);
  align-items: center;
  justify-content: center;
}

/* ************************* */
.viewgoback {
  position: absolute;
  left: 0px;
  width: 44px;
  height: 44px;
  top: 25px;
  margin-left: 30px;
}

.controlbar {
  position: absolute;
  bottom: 0px;
  height: 68px;
  width: 750px;
  flex-direction: row;
  align-items: center;
  background-color: black;
  filter: alpha(opacity=26);
  /* CSS3 standard */
  opacity: 0.6;
}

.play {
  height: 44px;
  width: 44px;
  margin-left: 24px;
}

.wifiplay {
  height: 114px;
  width: 114px;
}

.refresh {
  height: 44px;
  width: 44px;
  margin-left: 50px;
}

.sound {
  height: 44px;
  width: 44px;
  margin-left: 50px;
}

.time {
  font-size: 32px;
  margin-left: 80px;
  color: #e2e2e2;
}

.full {
  position: absolute;
  height: 44px;
  width: 44px;
  align-items: center;
  right: 24px;
  top: 12px;
}

.webview {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  /* background-color: #f1f1f1; */
}

.webview-menu {
  position: absolute;
  right: 0;
  top: 0;
  align-items: flex-end;
}

.menu-window {
  position: absolute;
  right: 0px;
  top: 90px;
  width: 200px;
  background-color: white;
  z-index: 15;
}

.menu-item {
  flex-direction: row;
  width: 200px;
  height: 75px;
  align-items: center;
}

.live-menu {
  background-color: #ffffff;
  flex-direction: row;
  align-items: center;
  width: 280px;
  height: 82px;
}

.live-menu:active {
  background-color: #EEEEEE;
}

.logo:active {
  width: 180px;
  height: 82px;
  background-color: green;
}

.menu-img {
  width: 38px;
  height: 46px;
}

.menu-loginout {
  width: 63px;
  height: 54px;
}

.menu-text {
  margin-left: 0px;
  font-size: 28px;
}

.login {
  color: #FE8115;
}

.normal {
  color: #828282;
}

.netwifi {
  position: absolute;
  top: 0px;
  bottom: 0px;
  left: 0px;
  right: 0px;
  justify-content: center;
  align-items: center;
  background-color: black;
}

.wifi-text {
  text-align: center;
  font-size: 32px;
  color: #e9e9e9;
}

.wifi-btn-play {
  width: 178px;
  height: 60px;
  border-radius: 5px;
  justify-content: center;
  align-items: center;
}

.wifi-btn-delete {
  margin-left: 40px;
  width: 178px;
  height: 60px;

  border-radius: 5px;
  justify-content: center;
  align-items: center;
}

.activation-delay {
  margin-left: 40px;
  width: 178px;
  height: 60px;

  border-radius: 5px;
  justify-content: center;
  align-items: center;
  background-color: #2e74e9;
}

.wifi-btn {
  font-size: 28px;
  line-height: 56px;
  text-align: center;
}

.mobile {
  margin-top: 48px;
  flex-direction: row;
}

.nottLoginText {
  align-items: center;
  flex-direction: column;
  margin-top: 48px
}

.nonetwork {
  margin-top: 48px;
  width: 180px;
  height: 60px;
  border-radius: 30px;
  border-width: 1px;
  border-color: #2e74e9;
  justify-content: center;
  align-items: center;
}

.refreshText {
  text-align: center;
  color: #2e74e9;
  font-size: 28px;
}
</style>
