<template>
<div class="black" @viewappear="viewappear">
  <status color="#FFFFFF"></status>
  <navigation title="拍照" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="goBack"></navigation>
  <!-- <div class="navbar">
    <text class="navbar-title">拍照</text>
    <div class="goback" @click="goBack" >
       <image class="image-size40" :src="backimg"></image>
    </div>
    <div class="nav-right" @click="onServerClick" >
       <image class="image-size50" :src="serverimg"></image>
    </div>
  </div> -->
  <div style="flex:1;align-items:center;justify-content:center;">
    <camera ref="camera" :rectMake="rectMake" class="camera-horizontal-live"></camera>
    <image v-if="border&&isIOS" class="camera-horizontal-live" resize="cover" :src="border"></image>
  </div>
  <div class="button-top-submit" @click="upclick(photo.up)">
    <text class="text">{{photo.up}}</text>
  </div>
  <div class="button-bottom-cancel" @click="downclick(photo.down)">
    <text class="text2">{{photo.down}}</text>
  </div>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl()
var assetsUrl = require('../include/base-url.js').assetsUrl()
var navigator = weex.requireModule('navigator')
var storage = require('../include/storage.js')
const app = weex.requireModule('app')
var utils = require('../include/utils.js')
module.exports = {
  components: {
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue')
  },
  data: function () {
    return {
      isShooted: false, // 是否已拍摄过
      serverurl: '',
      assets: assetsUrl,
      serverimg: assetsUrl + 'my_cs.png',
      backimg: assetsUrl + 'my_icon_closed.png',
      border: '',
      pictureFile: '',
      isTransform: false,
      photo: {up: '拍摄', down: '取消'},
      isIOS: utils.iOS(),
      rectMake:{top:0,left:0,width:0,height:0},
    }
  },
  created: function () {
    var that = this
    storage.getItem('commonUrl', function (value) {
      var commonUrl = JSON.parse(value)
      if (commonUrl) {
        that.serverurl = commonUrl.feedback
      }
    })
  },
  methods: {
    viewappear:function(){
      if (app) {
        app.setStatusBarStyle(0)
      }
    },
    onServerClick: function () {
      var json = {
        'title': '在线客服',
        'url': this.serverurl
      }
      storage.setItem('web', JSON.stringify(json))
      this.onStartView('webview.js')
    },
    onStartView: function (url) {
      navigator.push({
        url: bundleUrl + url,
        animated: 'true'
      }, event => {
      })
    },
    goBack: function () {
      navigator.pop({
        animated: 'true'
      }, event => {

      })
    },
    upclick: function (title) {
      if (title == '拍摄') {
        var that = this
        this.$refs.camera.shutterCamera(function (data) {
          that.border = data.path
          // that.border = 'data:image/png;base64,'+ data.file;
          that.pictureFile = data.file
          that.photo.up = '完成'
          that.photo.down = '重拍'
          that.isTransform = true
        })
      } else if (title == '完成') {
        let data = {
          url: this.border,
          file: this.pictureFile
        }
        const liveBroadcast = new BroadcastChannel('liveScanner-photo')
        liveBroadcast.postMessage(data)
        this.cancel()
      }
    },
    // 取消
    cancel: function () {
      this.isTransform = false
      navigator.pop({
        animated: 'true'
      }, event => { })
    },
    downclick: function (title) {
      if (title == '取消') {
        this.cancel()
      } else if (title == '重拍') {
        this.isTransform = false
        this.photo.up = '拍摄'
        this.photo.down = '取消'
        this.border = ''
        this.pictureFile = ''
        if (!this.isIOS) { this.$refs.camera.rePreview() }
      }
    }
  }
}
</script>

<style  src="../style/common.css" scoped>
</style>
<style scoped>
.black{
  /* background-color: black; */
  /* opacity:0.4; */
}
.navbar {
    width: 750px;
    height: 88px;
    background-color: #FFFFFF;
    align-items: center;
    justify-content: center;
}
.navbar-title {
    font-size: 36px;
    line-height: 54px;
    lines: 1;
    text-align: center;
    text-overflow: ellipsis;
    color: #333333;
    font-weight: bold;
    margin-left: 80px;
    margin-right: 80px;
}
.goback {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 80px;
  justify-content: center;
  align-items: center;
 }
 .nav-right {
    position: absolute;
    top: 0px;
    right: 0px;
    bottom: 0px;
    width: 120px;
    justify-content: center;
    align-items: center;
 }
 .image-size40{
   width: 40px;
   height: 40px;
 }
 .image-size50{
   width: 50px;
   height: 50px;
 }
/* 相机拍摄框横向iOS需要逆向旋转90度  竖向则不需要 */
.picture-transform-s{
  transform:  'rotate(90deg)';
  transform-origin: center center;
  overflow: hidden;
  width:775px;
  height:489px;
}
.picture-transform{
  transform:  'rotate(0deg)';
  transform-origin: center center;
  width:489px;
  height:775px;
  overflow: hidden;
}
.button-top-submit{
  margin-top: 20px;
  margin-bottom: 5px;
  margin-left: 30px;
  width:690px;
  height:90px;
  justify-content: center;
  align-items: center;
  border-radius: 10px;
  background-color: #518deb;
}
.button-bottom-cancel{
  margin-bottom: 30px;
  margin-left: 30px;
  width:690px;
  height:90px;
  justify-content: center;
  align-items: center;
  border-radius: 10px;
  background-color: #ffffff;
  border-color: #518deb;
  border-width: 1px;
}
.text{
  font-size: 32px;
  line-height: 48px;
  color: #ffffff;
}
.text2{
  font-size: 32px;
  line-height: 48px;
  color: #518deb;
}
.camera-horizontal-live{
  position:absolute;
  top:0px;
  left:0px;
  right: 0px;
  bottom: 0px;
}
</style>
