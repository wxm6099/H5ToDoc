<template scoped>
<scroller>
  <div class="flex left right" style="height:98px; justify-content:space-between;align-items:center">
    <text class="size text-normal">只看重要</text>
    <div style="height:98px;flex-direction:row;justify-content:flex-end;align-items:center" @click="onlyClick">
      <image v-if="only" style="width:80px;height:40px" :src="assets+'on.png'"></image>
      <image v-else style="width:80px;height:40px" :src="assets+'off.png'"></image>
    </div>
  </div>
  <div class="margin border"></div>
  <div class="flex left right" style="height:70px;align-items:center">
    <text class="size text-normal">状态</text>
  </div>
  <div class="flex">
    <div v-for="(item,index) in state" class="item" :key="index" :class="[index ==stateIndex?'item-focus':'item-normal']" @click="stateItemClick(index)">
      <text class="size" :class="[index ==stateIndex?'text-focus':'text-normal']">{{item}}</text>
    </div>
  </div>
  <div class="margin border"></div>
  <div class="flex left" style="height:70px;align-items:center">
    <text class="size text-normal">地区</text>
  </div>
  <div class="flex">
    <div v-for="(item,index) in areas" class="item" :key="index" :class="[(true == areasFocus[index])?'item-focus':'item-normal']" @click="areaItemClick(index)">
      <text class="size" :class="[(true == areasFocus[index])?'text-focus':'text-normal']">{{item}}</text>
    </div>
  </div>
  <div class="margin border"></div>
  <div class="flex left" style="height:70px;align-items:center" v-if="!only">
    <text class="size text-normal">重要程度</text>
  </div>
  <div class="flex" v-if="!only">
    <div class="item" :class="[star ==0?'item-focus':'item-normal']" @click="starClick(0);logEvent('News_calendar_Imp_all')">
      <text class="size" :class="[star ==0?'text-focus':'text-normal']">全部</text>
    </div>
    <div class="starItem starLeftMargin starRightMargin" :class="[star ==1?'item-focus':'item-normal']" @click="starClick(1);logEvent('News_calendar_Imp_Star1')">
      <image class="star" :src="assets+(star ==1?'white_star01.png':'calendar_star_solid.png')"></image>
      <image class="star" :src="assets+(star ==1?'white_star02.png':'calendar_star_white.png')"></image>
      <image class="star" :src="assets+(star ==1?'white_star02.png':'calendar_star_white.png')"></image>
      <image class="star" :src="assets+(star ==1?'white_star02.png':'calendar_star_white.png')"></image>
      <image class="star" :src="assets+(star ==1?'white_star02.png':'calendar_star_white.png')"></image>
    </div>
    <div class="starItem starRightMargin" :class="[star ==2?'item-focus':'item-normal']" @click="starClick(2);logEvent('News_calendar_Imp_Star2')">
      <image class="star" :src="assets+(star ==2?'white_star01.png':'calendar_star_solid.png')"></image>
      <image class="star" :src="assets+(star ==2?'white_star01.png':'calendar_star_solid.png')"></image>
      <image class="star" :src="assets+(star ==2?'white_star02.png':'calendar_star_white.png')"></image>
      <image class="star" :src="assets+(star ==2?'white_star02.png':'calendar_star_white.png')"></image>
      <image class="star" :src="assets+(star ==2?'white_star02.png':'calendar_star_white.png')"></image>
    </div>
    <div class="starItem" :class="[star ==3?'item-focus':'item-normal']" @click="starClick(3);logEvent('News_calendar_Imp_grande');logEvent('News_calendar_Imp_Star3')">
      <image class="star" :src="assets+(star ==3?'white_star01.png':'calendar_star_solid.png')"></image>
      <image class="star" :src="assets+(star ==3?'white_star01.png':'calendar_star_solid.png')"></image>
      <image class="star" :src="assets+(star ==3?'white_star01.png':'calendar_star_solid.png')"></image>
      <image class="star" :src="assets+(star ==3?'white_star02.png':'calendar_star_white.png')"></image>
      <image class="star" :src="assets+(star ==3?'white_star02.png':'calendar_star_white.png')"></image>
    </div>
    <div class="item"></div>
    <div class="starItem starLeftMargin starRightMargin" :class="[star ==4?'item-focus':'item-normal']" @click="starClick(4);logEvent('News_calendar_Imp_Star4')">
      <image class="star" :src="assets+(star ==4?'white_star01.png':'calendar_star_solid.png')"></image>
      <image class="star" :src="assets+(star ==4?'white_star01.png':'calendar_star_solid.png')"></image>
      <image class="star" :src="assets+(star ==4?'white_star01.png':'calendar_star_solid.png')"></image>
      <image class="star" :src="assets+(star ==4?'white_star01.png':'calendar_star_solid.png')"></image>
      <image class="star" :src="assets+(star ==4?'white_star02.png':'calendar_star_white.png')"></image>
    </div>
    <div class="starItem starRightMargin" :class="[star ==5?'item-focus':'item-normal']" @click="starClick(5);logEvent('News_calendar_Imp_Star5')">
      <image class="star" :src="assets+(star ==5?'white_star01.png':'calendar_star_solid.png')"></image>
      <image class="star" :src="assets+(star ==5?'white_star01.png':'calendar_star_solid.png')"></image>
      <image class="star" :src="assets+(star ==5?'white_star01.png':'calendar_star_solid.png')"></image>
      <image class="star" :src="assets+(star ==5?'white_star01.png':'calendar_star_solid.png')"></image>
      <image class="star" :src="assets+(star ==5?'white_star01.png':'calendar_star_solid.png')"></image>
    </div>
  </div>
  <div class="margin border"></div>
  <div class="flex left right" style="margin-top:34px; margin-bottom:20px;justify-content:space-between;align-items:center">
    <div class="button reset" @click="reset">
      <text class="reset-font">重置</text>
    </div>
    <div class="button item-focus" @click="done">
      <text class="size text-focus ">完成</text>
    </div>
  </div>
</scroller>
</template>

<script scoped>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var app = weex.requireModule('app');
var storage = require('../include/storage.js');
var firebase = weex.requireModule('firebase');
const focus = [true,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false];
module.exports = {
  data: function() {
    return {
      assets: assetsUrl,
      only: false,
      stateIndex: -1,
      state: ["全部", "已公布", "未公布"],
      stateEvent: ["all", "published", "unpublished"],
      areaIndex: -1,
      areas: ["全部", "美国", "加拿大", "欧元区", "德国", "英国", "法国", "瑞士", "意大利", "西班牙", "中国", "澳大利亚", "日本", "韩国", "新西兰", "印度", "香港", "台湾地区"],
      areasEvent: ["all", "US", "CA", "EMU", "GER", "UK", "FRA", "CH", "ITA", "ES", "CHN", "AU", "JPN", "KR", "NZL", "IND", "HK", "TWN"],
      areasFocus:JSON.parse(JSON.stringify(focus)),
      star :-1
    }
  },
  created: function() {
    var that = this;
    storage.getItem('filter', function(value) {
      if (value && value.length > 0) {
        var filter = JSON.parse(value);
        if (filter) {
          that.only = filter.only;
          that.stateIndex = filter.stateIndex;
          that.areaIndex = filter.areaIndex;
          if (filter.areasFocus) {
            that.areasFocus = filter.areasFocus;
          }else {
            that.areasFocus = JSON.parse(JSON.stringify(focus));
          }
          that.star = filter.star;
        }
      }else {
        that.only = false;
        that.stateIndex = 0;
        that.areaIndex = 0;
        that.star = 0;
      }
    });
  },
  methods: {
    logEvent:function(name){
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    stateItemClick: function(index) {
      this.stateIndex = index;
      if (this.stateIndex>=0 && this.stateIndex<this.stateEvent.length) {
        this.logEvent('News_calendar_State_'+this.stateEvent[this.stateIndex])
      }
    },
    areaItemClick: function(index) {
      if (index>0 && index<this.areasFocus.length) {
        this.areasFocus[index] = !this.areasFocus[index];
        this.areasFocus[0] = false;
      }else {
        this.areasFocus[0] = !this.areasFocus[0];
        if (true == this.areasFocus[0]) {
          for (let i = 1; i < this.areasFocus.length; i++) {
            this.areasFocus[i] = false;
          }
        }
      }
      this.areaIndex = index;
      if (this.areaIndex>=0 && this.areaIndex<this.areasEvent.length) {
        this.logEvent('News_calendar_Area_'+this.areasEvent[this.areaIndex])
      }
      this.areasFocus.splice(0,0);
    },
    starClick: function(index) {
      this.star = index;
    },
    reset: function() {
      this.stateIndex = 0;
      this.areaIndex = 0;
      this.star = 0;
      this.only = false;
      this.areasFocus = JSON.parse(JSON.stringify(focus));
      this.areasFocus.splice(0,0);
      this.logEvent('News_calendar_reset');
    },
    done: function() {
      var params = {
        type: '',
        level: '',
        country:'',
      };
      this.logEvent('News_calendar_setting');

      var countries = '';
      for (let i = 1; i < this.areasFocus.length && i < this.areas.length; i++) {
        if( true == this.areasFocus[i] ){
            countries = countries+this.areas[i]+',';
        }
      }
      params.country = countries;

      if (this.stateIndex == 1) {
        params.type = 'true';
      } else if (this.stateIndex == 2){
        params.type = 'false';
      }else {
        params.type = '';
      }
      if (this.only) {
        params.star = 5;
      }else {
        params.star = this.star;
      }

      var filter = {
        only:this.only,
        stateIndex : this.stateIndex,
        areaIndex : this.areaIndex,
        star : this.star,
        areasFocus : this.areasFocus
      }
      storage.setItem('filter', JSON.stringify(filter));
      this.$emit('confirmClick', params);
    },
    onlyClick: function() {
      this.logEvent('News_calendar_important');
      this.only = !this.only;
      if (this.only == true) {
        this.star = 5;
        this.stateIndex = 0;
        this.areaIndex = 0;
      } else {
        this.star = 0;
      }
    }
  }
}
</script>

<style scoped>
.margin {
  margin-left: 20px;
  margin-right: 20px;
}

.left {
  padding-left: 20px;
}

.right {
  padding-right: 20px;
}

.border {
  border-bottom-width: 1px;
  border-bottom-color: #e1e1e1;
}

.flex {
  width: 750px;
  flex-direction: row;
  flex-wrap: wrap;
}

.size {
  align-items: center;
  font-size: 28px;
  line-height: 32px;
}

.text-normal {
  color: #454950;
}

.text-focus {
  color: #ffffff;
}

.item {
  width: 126px;
  height: 70px;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  border-radius: 10px;
  margin-bottom: 24px;
  margin-left: 20px;
}

.item-normal {
  height: 70px;
  border-color: #c6c6c6;
  border-width: 1px;
  background-color: #ffffff;
}

.item-focus {
  height: 70px;
  /*background-color: #e9302e;*/
  background-color: #2e74e9;
}

.starItem {
  width: 180px;
  height: 70px;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  border-radius: 10px;
  margin-bottom: 24px;
}
.starLeftMargin {
  margin-left: 20px;
}
.starRightMargin {
  margin-right: 12px;
}

.star {
  width: 24px;
  height: 24px;
  margin-left: 4px;
  margin-right: 4px;
}

.button {
  width: 146px;
  height: 70px;
  justify-content: center;
  align-items: center;
  border-radius: 10px;
}

.reset {
  /*border-color: #e9302e;*/
  border-color: #2e74e9;
  border-width: 1px;
}

.reset-font {
  font-size: 26px;
  line-height: 30px;
  /*color: #e9302e;*/
  color: #2e74e9;
}
</style>
