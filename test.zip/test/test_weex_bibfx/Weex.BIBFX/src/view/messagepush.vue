<template>
<div @viewappear="viewappear" @foreground="viewappear">
  <status backgroundColor="#FFFFFF"></status>
  <navigation :title="title" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="onBack()"></navigation>
  <!-- <div class="navbar">
    <text class="navbar-title"> {{title}} </text>
    <div v-on:click="onBack()" class="goback">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div>
  </div> -->
  <div style="margin-left: 20px; margin-right: 20px;height: 70px; align-items: center; flex-direction: row;justify-content: space-between;" v-on:click="setNotification();logEvent('Setting_page_push_system')">
    <text class="item-text">接收新消息通知 </text>
    <text style=" font-size: 26px; color: darkgray; align-items: center; margin-right: 20px">{{(pushEnable>0)?'已开启':'已关闭'}}</text>
  </div>
  <div class="setting-view" v-on:click="setNotification();logEvent('Setting_page_push_system')">
    <text class="setting-text">关闭或开启新消息通知，请在您设备的"设置-消息推送-铸博环球金融"进行更改</text>
  </div>
  <div class="item" @click="strategy();logEvent('Setting_page_push_strategy')">
    <text class="item-text"> 直播间交易策略</text>
    <image style="width:80px;height:40px" :src="(pushEnable && strategyNotice)?switchOn:switchOff"></image>
  </div>
  <div class="item" @click="live();logEvent('Setting_page_push_LIVE')">
    <text class="item-text"> 直播间课程通知</text>
    <image style="width:80px;height:40px" :src="(pushEnable && liveNotice)?switchOn:switchOff"></image>
  </div>
  <message></message>
  <dialog :show="showLoginTips" title="" content="您好，登录账号即可使用消息推送订阅" confirm="登录" cancel="注册" @confirm="login" @cancel="openAccount" @close="showLoginTips=false"></dialog>
  <wxc-loading :show="setting" needMask="true"></wxc-loading>
</div>
</template>

<script>
var storage = require('../include/storage.js');
var assetsUrl = require('../include/base-url.js').assetsUrl();
var bundleUrl = require('../include/base-url.js').bundleUrl();
var animation = weex.requireModule('animation');
var modal = weex.requireModule('modal');
var navi = weex.requireModule('navigator');
var dom = weex.requireModule('dom');
const app = weex.requireModule('app');
var utils = require('../include/utils.js');
var navigator = weex.requireModule('navigator');
const jpush = weex.requireModule('jpush');
var firebase = weex.requireModule('firebase');

module.exports = {
  components: {
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'message': require('../components/message.vue'),
    'dialog': require('../components/dialog.vue'),
    "wxc-loading": require('../components/wxc-loading.vue'),
  },
  data: function() {
    return {
      title: '消息推送',
      assets: assetsUrl,
      switchOn: assetsUrl + 'on.png',
      switchOff: assetsUrl + 'off.png',
      pushEnable: false,
      strategyNotice: false,
      liveNotice: false,
      isIOS: utils.iOS(),
      showLoginTips: false,
      user: {}, //用户信息
      trueAccountUrl: '', //开户链接
      setting: false,
    }
  },
  beforeCreate: function() {
    var self = this;
    storage.getItem('jpush', function(value) {
      if (value && value.length >= 2) {
        var tags = JSON.parse(value);
        for (var i = 0; i < tags.length; i++) {
          if ('strategy' == tags[i]) {
            self.strategyNotice = true;
          } else if ('live' == tags[i]) {
            self.liveNotice = true;
          }
        }
      }
    })

    this.channelName = app.channelName();
    if (this.channelName) {
      this.utm = "?ComeFrom=GlobalApps&utm_source=APP&utm_campaign=&utm_content=&utm_term=&utm_medium=" + this.channelName;
    }

    storage.getItem('memberCenter', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var memberCenter = JSON.parse(value);
      if (memberCenter) {
        self.memberCenterUrl = memberCenter.memberCenterUrl;
      }
    });
  },
  created: function() {
    this.viewappear();
  },
  methods: {
    onBack: function() {
      navi.pop({
        animated: "true"
      }, res => {});
    },
    viewappear: function() {
      var that = this;
      storage.getItem('userInfo', function(data) {
        if (data) {
          that.user = JSON.parse(data);
        }
      });

      if (weex.supports('@module/app.notificationSettingTypes')) {
        this.pushEnable = app.notificationSettingTypes();
        // if (type > 0) {
        //   this.text = '已开启';
        // } else {
        //   this.text = '已关闭';
        // }
      }
    },
    setNotification: function() {
      app.openAppSetting();
    },
    login: function() {
      this.showLoginTips = false;
      storage.setItem('user-original-fromLogin', 'messagepush');
      navigator.push({
        url: bundleUrl + 'userLogin.js',
        animated: "true",
        swipePop: "true",
      }, event => {})
      // if (undefined == this.memberCenterUrl || this.memberCenterUrl.length <= 0) {
      //   return;
      // }
      // var data = {
      //   title: '登录',
      //   url: this.memberCenterUrl,
      //   anchor: 'message_push'
      // }
      // storage.setItem('app-url', JSON.stringify(data));
      // navigator.push({
      //   url: bundleUrl + 'memberCenter.js',
      //   animated: "false",
      //   swipePop: "true",
      // }, event => {})
    },
    setTags: function() {
      var that = this;
      var tags = [];
      if (this.strategyNotice) {
        tags.push("strategy");
      }
      if (this.liveNotice) {
        tags.push("live");
      }
      that.setting = true;
      jpush.setTags(tags, function(callback) {
        that.setting = false;
        if (callback && 0 == callback.code) {
          storage.setItem('jpush', JSON.stringify(callback.tags));
        }
      });
    },
    strategy: function() {
      if (this.user && (this.user.nickName || this.user.userName)) {
        if (this.pushEnable) {
          this.strategyNotice = !this.strategyNotice;
          this.setTags();
        }
      } else {
        this.logEvent('setting_msgpush_sign');
        this.showLoginTips = true;
      }
    },
    live: function() {
      if (this.user && (this.user.nickName || this.user.userName)) {
        if (this.pushEnable) {
          this.liveNotice = !this.liveNotice;
          this.setTags();
        }
      } else {
        this.showLoginTips = true;
      }
    },
    openAccount: function() {
      this.logEvent('setting_msgpush_sign');
      var data = {
        from: 'setting_msgpush',
        openName: 'setting_msgpush_sign',
      }
      storage.setItem('user-original-openAccount', JSON.stringify(data));
      storage.setItem('user_openaccount_from', 'index');
      navigator.push({
        url: bundleUrl + 'openAccount.js',
        animated: "true",
        swipePop: "true",
      }, event => {})
      // if (this.trueAccountUrl && this.trueAccountUrl.length > 0) {
      //   this.loadWebView(this.trueAccountUrl + this.utm, '');
      // }
    },
    loadWebView: function(url, title = '') {
      if (url && url.length > 0) {
        var data = {
          title: title,
          url: url,
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "false",
          swipePop: "true",
        }, event => {})
      }
    },
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
  }
}
</script>

<style scoped>
.goback {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 120px;
  padding-left: 30px;
  justify-content: center;
}

.navbar-title {
  font-size: 36px;
  color: white;
  line-height: 54px;
  text-align: center;
}

.navbar {
  width: 750px;
  height: 88px;
  background-color: #2e74e9;
  align-items: center;
  justify-content: center;
}

.item {
  border-bottom-width: 1px;
  border-bottom-color: #c0c0c0;
  height: 100px;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin-left: 20px;
  margin-right: 20px;
}

.setting-view {
  margin-left: 20px;
  margin-right: 20px;
  border-bottom-width: 1px;
  border-bottom-color: #c0c0c0;
  padding-bottom: 40px;
}

.setting-text {
  font-size: 26px;
  color: darkgray;
}

.item-text {
  font-size: 32px;
  line-height: 48px;
}
</style>
