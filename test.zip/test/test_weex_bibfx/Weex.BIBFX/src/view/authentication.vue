<template >
<div @viewappear="viewappear" @viewdisappear="viewdisappear">
  <status backgroundColor="#FFFFFF"></status>
  <navigation :title="title" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="goBack"></navigation>
  <!-- <div class="navbar">
    <text class="navbar-title"> {{title}} </text>
    <div @click="goBack" class="goback">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div>
  </div> -->
  <div style="flex-direction:row;marginTop:30px;marginBottom:30px;">
      <div style="align-items:center;flex:1">
        <div class="item-row">
          <div class="whiteline"></div>
          <div class="line"></div>
        </div>
        <div class="circle">
          <div class="innerCircle">
            <text class="font20 text" style="text-align: center;">01</text>
          </div>
        </div>
        <text class="font30 gold" style="text-align: center;color:#2e74e9">填写资料</text>
      </div>
      <div style="align-items:center;flex:1">
        <div class="item-row">
          <div class="line"></div>
          <div class="grayline"></div>
        </div>
        <div class="circle">
          <div class="innerCircle">
            <text class="font20 text" style="  text-align: center;">02</text>
          </div>
        </div>
        <text class="font30 gold" style="text-align: center;color:#2e74e9">身份验证</text>
      </div>
      <div style="align-items:center;flex:1">
        <div class="item-row">
          <div class="grayline"></div>
          <div class="grayline"></div>
        </div>
        <div class="circle dashed">
          <div class="innerCircle gray">
            <text class="font20 text" style="  text-align: center;">03</text>
          </div>
        </div>
        <text class="font30" style="text-align: center;color:gray">调查问卷</text>
      </div>
      <div style="align-items:center;flex:1">
        <div class="item-row">
          <div class="grayline"></div>
          <div class="grayline"></div>
        </div>
        <div class="circle dashed">
          <div class="innerCircle gray">
            <text class="font20 text" style="  text-align: center;">04</text>
          </div>
        </div>
        <text class="font30" style="text-align: center;color:gray">存款激活</text>
      </div>
      <div style="align-items:center;flex:1">
        <div class="item-row">
          <div class="grayline"></div>
          <div class="whiteline"></div>
        </div>
        <div class="circle dashed">
          <div class="innerCircle gray">
            <text class="font20 text" style="text-align: center;">05</text>
          </div>
        </div>
        <text class="font30" style="text-align: center;color:gray">交易密码</text>
      </div>
    </div>
    <div style="margin: 0px;height: 20px;background-color: #F1F1F1;"></div>
  <scroller alwaysScrollableVertical="false" show-scrollbar="false">
    <div class="align" style="paddingTop:30px;marginBottom:50px">
      <div v-if="verifyStatus!=0 && verifyStatus!=1 && verifyStatus!=2">
        <text class="tips tips-color2">{{'抱歉，您的审核未通过！请重新上传文件，如有疑问，请咨\n询'}}</text>
        <div style="position:absolute;left:72px;top:0px;backgroundColor:white">
          <text class="tips" style="color:#f62b16;">您的审核未通过！</text>
        </div>
        <div style="position:absolute;left:25px;top:39px;backgroundColor:white;">
          <text class="tips" style="color:#2e74e9;text-decoration: underline;" @click="onlineCS">在线客服.</text>
        </div>
      </div>
      <div v-if="verifyStatus!=0 && verifyStatus!=1 && verifyStatus!=2" style="flex:1;height:2px;background-color: #F1F1F1;margin-top:36px;margin-bottom:32px;"></div>
      <div v-if="verifyStatus!=0 && verifyStatus!=1 && verifyStatus!=2">
        <text class="tips tips-color2">以下资料未通过审核：</text>
        <text class="tips tips-color2" v-if="idCardFace.failReason">{{idCardFace.failReason}}</text>
        <text class="tips tips-color2" v-if="idCardFaceBack.failReason">{{idCardFaceBack.failReason}}</text>
        <text class="tips tips-color2" v-if="bankCardCode.failReason">{{bankCardCode.failReason}}</text>
      </div>
      <text class="tips tips-color1" v-if="verifyStatus===1">阁下资料已提交，请耐心等候，审核通过后将由专人通知，并指导您完成开户手续。</text>
      <text class="tips tips-color2" v-if="verifyStatus===0">为保证阁下能顺利进行金/银投资，请于以下正确位置上传您的身份证明文件及银行卡资料，审核无误后，方可继续进行开户操作。</text>
    </div>
    <div style="align-items:center;">
      <div class="certificate">
        <div class="pic" @click="clickShowTips(1)">
          <image class="image-pic-size" :src="picture[0] || assets+'auth/demo1.png'"></image>
          <div class="pic-bg" v-if="idCardFace.check && idCardFace.bg">
            <image class="image-camera-size" :src="idCardFace.cameraimg" v-if="idCardFace.camera"></image>
          </div>
          <div class="pic-check" v-if="idCardFace.check">
            <image class="image-check-size" :src="idCardFace.img"></image>
            <text class="pic-check-text">{{idCardFace.check}}</text>
          </div>
          <!-- <div class="upload-progress" v-if="idCardFace.upload">
                <div class="upload-progress-red" :style="{width:idCardFace.uploadWidth}">
                  <text class="upload-percentage">{{idCardFace.percentage}}%</text>
                </div>
              </div> -->
        </div>
        <div style="flex:1;align-items:center;justify-content:center">
          <text class="picture-tips-text">{{tips}}</text>
        </div>
      </div>
      <div class="certificate">
        <div class="pic" @click="clickShowTips(2)">
          <image class="image-pic-size" :src="picture[1] || assets+'auth/demo2.png'"></image>
          <div class="pic-bg" v-if="idCardFaceBack.check && idCardFaceBack.bg">
            <image class="image-camera-size" :src="idCardFaceBack.cameraimg" v-if="idCardFaceBack.camera"></image>
          </div>
          <div class="pic-check" v-if="idCardFaceBack.check">
            <image class="image-check-size" :src="idCardFaceBack.img"></image>
            <text class="pic-check-text">{{idCardFaceBack.check}}</text>
          </div>
          <!-- <div class="upload-progress" v-if="idCardFaceBack.upload">
                <div class="upload-progress-red" :style="{width:idCardFaceBack.uploadWidth}">
                  <text class="upload-percentage">{{idCardFaceBack.percentage}}%</text>
                </div>
              </div> -->
        </div>
        <div style="flex:1;align-items:center;justify-content:center">
          <text class="picture-tips-text">身份证(反面)</text>
        </div>
      </div>
      <div class="certificate">
        <div class="pic" @click="clickShowTips(3)">
          <image class="image-pic-size" :src="picture[2] || assets+'auth/demo3.png'"></image>
          <div class="pic-bg" v-if="bankCardCode.check && bankCardCode.bg">
            <image class="image-camera-size" :src="bankCardCode.cameraimg" v-if="bankCardCode.camera"></image>
          </div>
          <div class="pic-check" v-if="bankCardCode.check">
            <image class="image-check-size" :src="bankCardCode.img"></image>
            <text class="pic-check-text">{{bankCardCode.check}}</text>
          </div>
        </div>
        <div style="flex:1;align-items:center;justify-content:center">
          <text class="picture-tips-text">银行卡(有号码的照片)</text>
        </div>
      </div>
    </div>
    <div class="align" style="margin-bottom:50px;margin-top:8px">
      <text style="font-size:28px;line-height:42px;color:#454950;">上传说明：</text>
      <text class="bottom-tips-text">1.图片格式限【.jpg】,【.png】。</text>
      <text class="bottom-tips-text">2.图片大小限5M以下。</text>
      <text class="bottom-tips-text">3.请客户上传身份证件及银行卡图片以供审核确认（为能加快审核处理，请确保您提交的身份证件/银行卡图片四角完整无缺，请上传时把图片旋转至正向）。</text>
      <text class="bottom-tips-text">(1）  身份证件： 国籍为中国(大陆)之客户,请上传身份证正反两面的图片；其他非中国(大陆)地区客户，请上传身份证正面图片；以护照号码登记开户者，请上传具护照号码的图片。</text>
      <text class="bottom-tips-text">(2）  银行卡： 请上传卡号清晰可见的图片。</text>
    </div>
  </scroller>
  <div style="flex-direction: row ;height: 90px;width:750px;justify-content: space-between;align-items: center;">
    <div class="button-front" @click="frontClick" v-if="verifyStatus == 0 || verifyStatus == 3">
      <text class="font32" style="color: #2e74e9">上一步</text>
    </div>
    <!--class="button-next"-->
    <div :class="[isSubmitBtnClick?'button-next-gray':'button-next']" @click="next">
      <text class="font32 text">下一步</text>
    </div>
  </div>




  <div v-if="showTips!=0" class="overlay" @click="clickShowTips(0)">
    <div>
      <image style="width:600px;height:612px;" :src="assets+'auth/tips'+showTips+'.png'"></image>
      <div @click="takePicture(showTips)" style="position:absolute;bottom:0px;left:0px;right:0px;height:76px;"></div>
    </div>
  </div>
  <div v-if="isShowAlert" class="alert-show">
    <div class="alert-modul">
      <text style="color:#FFFFFF;font-size:28px;"> {{alertTips}} </text>
    </div>
  </div>
  <!--<dialog :show="showDialogBack" title="提示" content="返回后，可登陆用户中心查看个人信息和审核状态！" confirm="确认返回" cancel="取消" @confirm="dialogRightBtnClickBack" @cancel="dialogLeftBtnClickBack" @close="dialogCloseBtnClickBack">-->
  <!--</dialog>-->
  <dialog :show="showDialogBack" title="温馨提示" content="您尚未提交资料，返回后将清空内容，请确认是否继续退出？" confirm="继续填写" cancel="退出"
          @confirm="dialogLeftBtnClickBack" @cancel="dialogRightBtnClickBack" @close="dialogCloseBtnClickBack">
  </dialog>

  <wxc-loading :show="isLoading" loading-text="加载中" needMask="true"></wxc-loading>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var storage = require('../include/storage.js');
const app = weex.requireModule('app');
var utils = require('../include/utils.js');
var firebase = weex.requireModule('firebase');
var http = require('../include/http.js');
var filequestion = require('../survey.json');
module.exports = {
  components: {
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'dialog': require('../components/dialog.vue'),
    "wxc-loading": require('../components/wxc-loading.vue'),
  },
  data: function() {
    return {
      title: "身份验证",
      userId: '', //
      userToken: '',
      assets: assetsUrl,
      serviceUrl: '', //客服地址
      bibApi: '', //网络请求基址
      tips: "身份证(正面)\n或含护照号码的照片",
      picture: ["", "", ""],
      isFaceTransform: false,
      pictureFiles: ["", "", ""],
      showTips: 0,
      idCardFace: {
        bg: false,
        camera: false,
        check: '',
        img: '',
        cameraimg: assetsUrl + 'auth/checkfailcamera.png',
        failReason: '',
        isSubmit: true,
        upload: false,
        uploadWidth: 0,
        percentage: 0
      },
      idCardFaceBack: {
        bg: false,
        camera: false,
        check: '',
        img: '',
        cameraimg: assetsUrl + 'auth/checkfailcamera.png',
        failReason: '',
        isSubmit: true,
        upload: false,
        uploadWidth: 0,
        percentage: 0
      },
      bankCardCode: {
        bg: false,
        camera: false,
        check: '',
        img: '',
        cameraimg: assetsUrl + 'auth/checkfailcamera.png',
        failReason: '',
        isSubmit: true,
        upload: false,
        uploadWidth: 0,
        percentage: 0
      },
      verifyStatus: 0, //审核结果 0未提交审核 1审核中 2审核通过 3审核失败
      isAndorid: utils.isAndroid(),
      progressBarWidth: 0,
      percentage: 0,
      // timecountdownq:100,
      isShowAlert: false,
      alertTips: '', //弹窗提示语
      isSubmitBtnClick: false, //是否可点击提交(下一步)按钮

      showDialogBack: false, //返回按钮的提示弹窗
      openAccountFrom: '', //从哪里进入开户步骤
      isDataEnd: true,

      isLoading: false,
      kycStatus: 'None',
      errorCodes:filequestion.fileErrorCodes,//错误码
    }
  },
  created: function() {
    var that = this;
    // that.verifyStatus = Math.floor(Math.random() * 10);
    // that.timecountdown();
    storage.getItem('user_openaccount_from', function(value) {
      if (value) {
        that.openAccountFrom = value;
      }
    });
    storage.getItem('commonUrl',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.serviceUrl = commonUrl.feedback;
        that.bibApi = commonUrl.cmsApi;

        storage.getItem('user-logintoken-id', function(value) {
          if (value) {
            var data = JSON.parse(value);
            that.userId = data.userId;
            that.userToken = data.token;
            var fileStatus = that.bibApi + '/IFXAccountDetails/IFXMC?format=json&NeedAttachmentIamges=true';
            that.isDataEnd = false;

            that.isLoading = true;

            http.getByHeader(that.userToken, encodeURI(fileStatus), function(responseStatus) {

              that.isLoading = false;

              if (responseStatus.ok && responseStatus.data) {
                if (responseStatus.data.Results.length > 0) {
                  that.isDataEnd = true;
                  var dataResult = responseStatus.data.Results[0];


									storage.getItem('userInfo', function(data) {
									  if (data) {
									    let value = JSON.parse(data);
											value.iB_NO = dataResult.Member.IB_NO;
											value.realName = dataResult.Member.Name;
											value.sex = dataResult.Member.Sex;
											value.certType = dataResult.Member.NationalArea;
											value.certNo = dataResult.Member.CertNo;
											value.bindBankNo = dataResult.Member.BindBankNo; // 银行卡号
											value.bindSubBankName = dataResult.Member.BindSubBankName; // 支行名称
											value.bindBank = dataResult.Member.BindBank;	//银行简称
											value.bindSubBankOther = dataResult.Member.BindSubBankOther;	//支行其他

											value.bindSubBankArea = dataResult.Member.BindSubBankArea;	// 省
											value.bindSubBankAreaCounty = dataResult.Member.BindSubBankAreaCounty;	// 区
											value.bindSubBankAreaCity = dataResult.Member.BindSubBankAreaCity;	//  市

											value.attachmentStatus = dataResult.Member.AttachmentStatus;	//

											var statusLists = dataResult.Member.AttachmentList;
											if (statusLists.length > 0) {
											  for (var i = 0; i < statusLists.length; i++) {
											    var pictureStatus = statusLists[i];
													// type = 1 身份证正面
													// type = 2 身份证反面
													// type = 3 银行卡正面
											    if (pictureStatus.Type === 1) { //正面
														value.IDfrontStatus = pictureStatus.ApprovalStatus == 5 ? false : true;
											    } else if (pictureStatus.Type === 2) { //反面
														value.IDbackStatus = pictureStatus.ApprovalStatus == 5 ? false : true;
											    } else if (pictureStatus.Type === 3) { //银行卡
														value.bankStatus = pictureStatus.ApprovalStatus == 5 ? false : true;
											    }
											  }
											}
											storage.setItem('userInfo', JSON.stringify(value));
									  }

									});
                  that.kycStatus = dataResult.Member.KycStatus;
                  //0:默认(Default) 1:无(None)  2:已上传未处理(Unprocessing)  3:审核中(Approving)  4:审核通过(ApprovedPass)
                  //5:审核退回(ApprovedFail) 6等待账户审核通过:(WaitingAccountApproved)
                  var AttachmentStatus = dataResult.Member.AttachmentStatus;
                  if (AttachmentStatus == 0 || AttachmentStatus == 1) {
                    that.initDataByList(dataResult.Member.AttachmentList); //初始化已提交附件的图片信息
                    that.verifyStatus = 0;
                    that.idCardFace.bg = false;
                    that.idCardFace.camera = false;
                    that.idCardFace.check = '';
                    that.idCardFace.img = '';
                    that.idCardFace.failReason = '';
                    that.idCardFace.isSubmit = true;
                    that.idCardFaceBack.bg = false;
                    that.idCardFaceBack.camera = false;
                    that.idCardFaceBack.check = '';
                    that.idCardFaceBack.img = '';
                    that.idCardFaceBack.failReason = '';
                    that.idCardFaceBack.isSubmit = true;
                    that.bankCardCode.bg = false;
                    that.bankCardCode.camera = false;
                    that.bankCardCode.check = '';
                    that.bankCardCode.img = '';
                    that.bankCardCode.failReason = '';
                    that.bankCardCode.isSubmit = true;
                  } else if (AttachmentStatus == 2 || AttachmentStatus == 3 || AttachmentStatus == 6) {
                    that.initDataByList(dataResult.Member.AttachmentList); //初始化已提交附件的图片信息
                    that.verifyStatus = 1;
                    that.idCardFace.bg = true;
                    that.idCardFace.camera = false;
                    that.idCardFace.check = '审核中';
                    that.idCardFace.img = assetsUrl + 'auth/checking.png';
                    that.idCardFace.failReason = '';
                    that.idCardFace.isSubmit = false;
                    that.idCardFaceBack.bg = true;
                    that.idCardFaceBack.camera = false;
                    that.idCardFaceBack.check = '审核中';
                    that.idCardFaceBack.img = assetsUrl + 'auth/checking.png';
                    that.idCardFaceBack.failReason = '';
                    that.idCardFaceBack.isSubmit = false;
                    that.bankCardCode.bg = true;
                    that.bankCardCode.camera = false;
                    that.bankCardCode.check = '审核中';
                    that.bankCardCode.img = assetsUrl + 'auth/checking.png';
                    that.bankCardCode.failReason = '';
                    that.bankCardCode.isSubmit = false;
                  } else if (AttachmentStatus == 4) {
                    that.initDataByList(dataResult.Member.AttachmentList); //初始化已提交附件的图片信息
                    that.verifyStatus = 2;
                    that.idCardFace.bg = true;
                    that.idCardFace.camera = false;
                    that.idCardFace.check = '审核通过';
                    that.idCardFace.img = assetsUrl + 'auth/checked.png';
                    that.idCardFace.failReason = '';
                    that.idCardFace.isSubmit = false;
                    that.idCardFaceBack.bg = true;
                    that.idCardFaceBack.camera = false;
                    that.idCardFaceBack.check = '审核通过';
                    that.idCardFaceBack.img = assetsUrl + 'auth/checked.png';
                    that.idCardFaceBack.failReason = '';
                    that.idCardFaceBack.isSubmit = false;
                    that.bankCardCode.bg = true;
                    that.bankCardCode.camera = false;
                    that.bankCardCode.check = '审核通过';
                    that.bankCardCode.img = assetsUrl + 'auth/checked.png';
                    that.bankCardCode.failReason = '';
                    that.bankCardCode.isSubmit = false;
                  } else if (AttachmentStatus == 5) {
                    that.initDataByList(dataResult.Member.AttachmentList); //初始化已提交附件的图片信息
                    that.verifyStatus = 3;
                    //审核失败需要具体判断
                    var statusLists = dataResult.Member.AttachmentList;
                    if (statusLists.length > 0) {
                      for (var i = 0; i < statusLists.length; i++) {
                        var pictureStatus = statusLists[i];
                        if (pictureStatus.Type === 1) { //正面
                          if (pictureStatus.ApprovalStatus == 5) {
                            that.idCardFace.bg = true;
                            that.idCardFace.camera = true;
                            that.idCardFace.check = '审核失败';
                            that.idCardFace.img = assetsUrl + 'auth/checkfail.png';
                            that.idCardFace.failReason = that.failureReason(pictureStatus.ApprovalRemark, pictureStatus.Type);
                            that.idCardFace.isSubmit = true;
                          } else {
                            that.idCardFace.bg = true;
                            that.idCardFace.camera = false;
                            that.idCardFace.check = '审核通过';
                            that.idCardFace.img = assetsUrl + 'auth/checked.png';
                            that.idCardFace.failReason = '';
                            that.idCardFace.isSubmit = false;
                          }

                        } else if (pictureStatus.Type === 2) { //反面
                          if (pictureStatus.ApprovalStatus == 5) {
                            that.idCardFaceBack.bg = true;
                            that.idCardFaceBack.camera = true;
                            that.idCardFaceBack.check = '审核失败';
                            that.idCardFaceBack.img = assetsUrl + 'auth/checkfail.png';
                            that.idCardFaceBack.failReason = that.failureReason(pictureStatus.ApprovalRemark, pictureStatus.Type);
                            that.idCardFaceBack.isSubmit = true;
                          } else {
                            that.idCardFaceBack.bg = true;
                            that.idCardFaceBack.camera = false;
                            that.idCardFaceBack.check = '审核通过';
                            that.idCardFaceBack.img = assetsUrl + 'auth/checked.png';
                            that.idCardFaceBack.failReason = '';
                            that.idCardFaceBack.isSubmit = false;
                          }

                        } else if (pictureStatus.Type === 3) { //银行卡
                          if (pictureStatus.ApprovalStatus == 5) {
                            that.bankCardCode.bg = true;
                            that.bankCardCode.camera = true;
                            that.bankCardCode.check = '审核失败';
                            that.bankCardCode.img = assetsUrl + 'auth/checkfail.png';
                            that.bankCardCode.failReason = that.failureReason(pictureStatus.ApprovalRemark, pictureStatus.Type);
                            that.bankCardCode.isSubmit = true;
                          } else {
                            that.bankCardCode.bg = true;
                            that.bankCardCode.camera = false;
                            that.bankCardCode.check = '审核通过';
                            that.bankCardCode.img = assetsUrl + 'auth/checked.png';
                            that.bankCardCode.failReason = '';
                            that.bankCardCode.isSubmit = false;
                          }
                        }
                      }
                    }
                  }

                } else {
                  that.isDataEnd = true;
                }
              } else {
                that.isDataEnd = true;
              }

            })
          }
        });
      }
    });
  },
  methods: {
    //埋点追踪方法(在input事件里面执行)
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    onlineCS: function() {
      this.loadWebView(this.serviceUrl, '客服');
    },
    loadWebView: function(url, title = '') {
      if (url && url.length > 0) {
        var data = {
          title: title,
          url: url,
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "false"
        }, event => {})
      }
    },

    initDataByList: function(lists) {
      var that = this;
      if (lists.length > 0) {
        for (var i = 0; i < lists.length; i++) {
          var imageurl = 'data:image/png;base64,' + lists[i].ImageStream;
          if (lists[i].Type === 1) { //正面
            that.picture.splice(0, 1, imageurl);
            that.pictureFiles.splice(0, 1, lists[i].ImageStream);
          } else if (lists[i].Type === 2) { //反面
            that.picture.splice(1, 1, imageurl);
            that.pictureFiles.splice(1, 1, lists[i].ImageStream);
          } else if (lists[i].Type === 3) { //银行卡
            that.picture.splice(2, 1, imageurl);
            that.pictureFiles.splice(2, 1, lists[i].ImageStream);
          }
        }
      }
    },
    failureReason: function(reason, type) {
      if (!utils.isBlankString(reason)) {
        return utils.isBlankString(this.errorCodes[reason])?reason:this.errorCodes[reason];
      }
      // if (reason === 'BankCardNoIsWrong') {
      //   if (type == 1) {
      //     return '身份证正面:账号不符';
      //   } else if (type == 2) {
      //     return '身份证反面:账号不符';
      //   } else if (type == 3) {
      //     return '银行卡:账号不符';
      //   }
      // } else if (reason === 'BankCardNoIsVague') {
      //   if (type == 1) {
      //     return '身份证正面:账号不清晰';
      //   } else if (type == 2) {
      //     return '身份证反面:账号不清晰';
      //   } else if (type == 3) {
      //     return '银行卡:账号不清晰';
      //   }
      // } else if (reason === 'BankCardNameIsWrong') {
      //   if (type == 1) {
      //     return '身份证正面:名称不符';
      //   } else if (type == 2) {
      //     return '身份证反面:名称不符';
      //   } else if (type == 3) {
      //     return '银行卡:名称不符';
      //   }
      // } else if (reason === 'ImageIsVague') {
      //   if (type == 1) {
      //     return '身份证正面:不清晰';
      //   } else if (type == 2) {
      //     return '身份证反面:不清晰';
      //   } else if (type == 3) {
      //     return '银行卡:不清晰';
      //   }
      // } else if (reason === 'NumberIsBlocked') {
      //   if (type == 1) {
      //     return '身份证正面:号码被遮挡';
      //   } else if (type == 2) {
      //     return '身份证反面:号码被遮挡';
      //   } else if (type == 3) {
      //     return '银行卡:号码被遮挡';
      //   }
      // } else if (reason === 'AppearanceIsBlocked') {
      //   if (type == 1) {
      //     return '身份证正面:模样被遮挡';
      //   } else if (type == 2) {
      //     return '身份证反面:模样被遮挡';
      //   } else if (type == 3) {
      //     return '银行卡:模样被遮挡';
      //   }
      // } else if (reason === 'PhotoIsNotComplete') {
      //   if (type == 1) {
      //     return '身份证正面:图片不完整(四边需要在照片内)';
      //   } else if (type == 2) {
      //     return '身份证反面:图片不完整(四边需要在照片内)';
      //   } else if (type == 3) {
      //     return '银行卡:图片不完整(四边需要在照片内)';
      //   }
      // } else if (reason === 'PositionOfPhotoIsWrong') {
      //   if (type == 1) {
      //     return '身份证正面:图片位置不符';
      //   } else if (type == 2) {
      //     return '身份证反面:图片位置不符';
      //   } else if (type == 3) {
      //     return '银行卡:图片位置不符';
      //   }
      // } else if (reason === 'OrientationOfPhotoIsWrong') {
      //   if (type == 1) {
      //     return '身份证正面:图片颠倒';
      //   } else if (type == 2) {
      //     return '身份证反面:图片颠倒';
      //   } else if (type == 3) {
      //     return '银行卡:图片颠倒';
      //   }
      // } else if (reason === 'FalseOfPhotoIsWrong') {
      //   if (type == 1) {
      //     return '身份证正面:虚假图片';
      //   } else if (type == 2) {
      //     return '身份证反面:虚假图片';
      //   } else if (type == 3) {
      //     return '银行卡:虚假图片';
      //   }
      // } else if (reason === 'IDCardNoIsWrong') {
      //   return '身份证号码不符';
      // } else if (reason === 'IDCardNameIsWrong') {
      //   return '身份证姓名不符';
      // } else if (reason === 'IDCardIsVague') {
      //   return '身份证不清晰';
      // } else if (reason === 'IDCardIsOverdue') {
      //   if (type == 1) {
      //     return '身份证正面:过期';
      //   } else if (type == 2) {
      //     return '身份证反面:过期';
      //   } else if (type == 3) {
      //     return '银行卡:过期';
      //   }
      // } else if (reason === 'InfoIsLack') {
      //   if (type == 1) {
      //     return '身份证正面:资料不齐';
      //   } else if (type == 2) {
      //     return '身份证反面:资料不齐';
      //   } else if (type == 3) {
      //     return '银行卡:资料不齐';
      //   }
      // } else if (reason === 'BankCardIsLack') {
      //   return '缺少银行卡';
      // } else if (reason === 'AddressProofIsLack') {
      //   return '缺少地址证明';
      // } else if (reason === 'CustomerServiceRequestToBack') {
      //   return '客服要求退回';
      // }
    },
    showAlertTips: function(tips, time = 2000) {
      if (false == this.isShowAlert) {
        this.isShowAlert = true;
        this.alertTips = tips;
        setTimeout(() => {
          this.isShowAlert = false;
          // this.tips = '';
        }, time)
      }
    },
    // //获取验证码倒计时
    // timecountdown: function() {
    //   if (this.timecountdownq <= 0) {
    //     this.timecountdownq = 0
    //   } else if (this.timecountdownq > 0) {
    //     setTimeout(this.timecountdown.bind(this), 100);
    //     this.timecountdownq--;
    //     // this.progressBarWidth += 300*0.1;
    //     this.idCardFace.uploadWidth += 300*0.01;
    //     this.idCardFace.percentage = parseInt((this.idCardFace.uploadWidth/300)*100);
    //     if (this.idCardFace.percentage === 100) {
    //       this.idCardFace.upload = false;
    //     }
    //   }
    // },
    goBack: function() {
      this.showDialogBack = true;
    },
    //弹窗右上角按钮
    dialogCloseBtnClickBack() {
      this.showDialogBack = false;
    },
    //弹窗左下角按钮
    dialogLeftBtnClickBack() {
      this.showDialogBack = false;
    },
    //弹窗右下角按钮
    dialogRightBtnClickBack() {
      this.showDialogBack = false;
      if (this.openAccountFrom === 'live') {
        navigator.pop({
          url: bundleUrl + 'live.js',
          animated: "false"
        }, event => {

        });
      } else {
        navigator.pop({
          url: bundleUrl + 'index.js',
          animated: "false"
        }, event => {

        });
      }
    },
    clickShowTips: function(value) {
      if (!this.isDataEnd) {
        return;
      }
      if (value === 1) {
        if (this.idCardFace.check === '审核通过' || this.idCardFace.check === '审核中') {
          return; //身份证正面 审核通过和审核中  不可点击
        }
      } else if (value === 2) {
        if (this.idCardFaceBack.check === '审核通过' || this.idCardFaceBack.check === '审核中') {
          return; //身份证反面 审核通过和审核中  不可点击
        }
      } else if (value === 3) {
        if (this.bankCardCode.check === '审核通过' || this.bankCardCode.check === '审核中') {
          return; //银行卡 审核通过和审核中  不可点击
        }
      }
      this.showTips = value;
    },
    //点击弹窗底部   知道了
    takePicture: function(value) {
      var that = this;
      var type = '';
      var tips = '';
      var border = '';
      if (value == 1) {
        // this.logEvent('btn_upload_id_positive');
        type = '扫描证件';
        tips = '请将身份证正面放到框内，并调整好光线';
        border = that.assets + 'scanner/scanner_face.png';
        // border = this.assets +'scanner/border-face.png';
      } else if (value == 2) {
        // this.logEvent('btn_upload_id_negative');
        type = '扫描证件';
        tips = '请将国徽面放到框内，并调整好光线';
        border = that.assets + 'scanner/scanner_back.png';
        // border = this.assets +'scanner/border-back.png';
      } else if (value == 3) {
        // this.logEvent('btn_upload_bank');
        type = '扫描证件';
        tips = '请将银行卡正面放到框内，并调整好光线';
        // border = this.assets +'scanner/border.png';
        border = that.assets + 'scanner/scanner.png';
      }
      that.showTips = false;
      let data = {
        title: type,
        tips: tips,
        index: value,
        border: border,
      }
      storage.setItem('app-scanner', JSON.stringify(data));
      if (utils.isAndroid() && app) {
        app.isCheckCameraPermission(function(value) {
          if (value) {
            that.startScanner();
          }
        });
      }
      if (!utils.isAndroid()) {
        that.startScanner();
      }
    },
    startScanner: function() {
      navigator.push({
        url: bundleUrl + 'scanner.js',
        animated: "true",
        swipePop: "true",
        edgePop: "true",
      }, event => {})
    },
    viewdisappear: function() {
      let data = {
        url: '',
        file: '',
        index: -1,
      }
      storage.setItem('user-scanner-picture', JSON.stringify(data));
    },
    viewappear: function() {
      var that = this;
      storage.getItem('user-scanner-picture', function(value) {

        if (value && value.length > 0) {
          let data = JSON.parse(value);
          if (data.index == 1) { //身份证正面
            that.isFaceTransform = true;
            that.picture.splice(0, 1, data.url);
            that.pictureFiles.splice(0, 1, data.file);
            that.idCardFace.bg = false;
            that.idCardFace.camera = false;
            that.idCardFace.check = '';
            that.idCardFace.img = '';
            that.idCardFace.failReason = '';
            that.idCardFace.isSubmit = true;
          } else if (data.index == 2) { //身份证反面
            that.picture.splice(1, 1, data.url);
            that.pictureFiles.splice(1, 1, data.file);
            that.idCardFaceBack.bg = false;
            that.idCardFaceBack.camera = false;
            that.idCardFaceBack.check = '';
            that.idCardFaceBack.img = '';
            that.idCardFaceBack.failReason = '';
            that.idCardFaceBack.isSubmit = true;
          } else if (data.index == 3) { //银行卡正面
            that.picture.splice(2, 1, data.url);
            that.pictureFiles.splice(2, 1, data.file);
            that.bankCardCode.bg = false;
            that.bankCardCode.camera = false;
            that.bankCardCode.check = '';
            that.bankCardCode.img = '';
            that.bankCardCode.failReason = '';
            that.bankCardCode.isSubmit = true;
          }
        }
      });
    },

		frontClick:function(){
			navigator.push({
			  url: bundleUrl + 'openAccount2.js',
			  animated: "true",
			  swipePop: "true",
			  disableBackPan: 'true',
			  currentPop:'true'
			}, event => {})
// 			navigator.pop({
// 			  animated: "true"
// 			}, event => {
//
// 			});
		},

    next: function() {
      this.logEvent('btn_id_submit');
      var that = this;
      if (that.isSubmitBtnClick) {
        return;
      }
      if (that.verifyStatus == 1 || that.verifyStatus == 2){
        storage.setItem('user_openaccount_from', that.openAccountFrom);
        if (that.kycStatus == 'ApprovedPass'){
          navigator.push({
            url: bundleUrl + 'survey.js?isverify=1',
            animated: "true",
            swipePop: "true",
            disableBackPan: 'true',
            currentPop: 'true'
          }, event => {})
        }else {
          navigator.push({
            url: bundleUrl + 'survey.js',
            animated: "true",
            swipePop: "true",
            disableBackPan: 'true',
            currentPop: 'true'
          }, event => {})
        }
        return

      }

      if (that.idCardFace.check == '审核失败' || !that.pictureFiles[0]) {

        that.showAlertTips('请上传身份证正面照片');
        return;
      }
      if (that.idCardFaceBack.check == '审核失败' || !that.pictureFiles[1]) {
        that.showAlertTips('请上传身份证反面照片');
        return;
      }
      if (that.bankCardCode.check == '审核失败' || !that.pictureFiles[2]) {
        that.showAlertTips('请上传银行卡正面照片');
        return;
      }
      var baseurl = that.bibApi + '/UploadAttachments?format=json';
      var body0 = [];
      var body1 = {
        AttType: "CardFront",
        OperationType: "Modify",
        ImageStream: that.pictureFiles[0],
        Suffix: ".jpg"
      };
      var body2 = {
        AttType: "CardBack",
        OperationType: "Modify",
        ImageStream: that.pictureFiles[1],
        Suffix: ".jpg"
      };
      var body3 = {
        AttType: "BankCard",
        OperationType: "Modify",
        ImageStream: that.pictureFiles[2],
        Suffix: ".jpg"
      };
      if (that.idCardFace.isSubmit) {
        body0.push(body1);
      }
      if (that.idCardFaceBack.isSubmit) {
        body0.push(body2);
      }
      if (that.bankCardCode.isSubmit) {
        body0.push(body3);
      }
      let body = {
        "AttachmentComeFrom":"GlobalApps",
        "AttApprovalCon": body0
      };
      // console.log("bj 附件上传参数:"+JSON.stringify(body));
      // if (that.isSubmitBtnClick) {
      //   return;
      // }
      that.isSubmitBtnClick = true;
      that.isLoading = true;
      http.putFormToken(that.userToken, baseurl, body, function(response) {
        that.isSubmitBtnClick = false;
        that.isLoading = false;
        if (response.ok && response.data) {
          var result = response.data;
          if (result.IsOK) {
            storage.setItem('user_openaccount_from', that.openAccountFrom);
            if (that.kycStatus == 'ApprovedPass'){
              navigator.push({
                url: bundleUrl + 'survey.js?isverify=1',
                animated: "true",
                swipePop: "true",
                disableBackPan: 'true',
                currentPop: 'true'
              }, event => {})
            }else {
              navigator.push({
                url: bundleUrl + 'survey.js',
                animated: "true",
                swipePop: "true",
                disableBackPan: 'true',
                currentPop: 'true'
              }, event => {})
            }
          } else {
            if (result.ResponseStatus&&result.ResponseStatus.ErrorCode) {
              var error = that.errorCodes[result.ResponseStatus.ErrorCode];
              if (utils.isBlankString(error)) {
                error = '资料提交失败，请重试';
              }
              that.showAlertTips(error);
            }
          }
        } else {
          that.showAlertTips('网络异常，请稍后再试');
        }
      })
    },
  }
}
</script>

<style  src="../style/common.css" scoped>
</style>
<style scoped>
.overlay {
  width: 750px;
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
  z-index: 99999;
  background-color: rgba(0, 0, 0, 0.6);
  align-items: center;
  justify-content: center;
}

.align {
  margin-left: 30px;
  margin-right: 25px;
}

.item-row {
  position: absolute;
  left: 0px;
  right: 0px;
  top: 0px;
  flex-direction: row;
}

.line {
  flex: 1;
  height: 20px;
  border-bottom-width: 1px;
  border-bottom-color: #2e74e9;
}

.whiteline {
  flex: 1;
  height: 20px;
}

.grayline {
  flex: 1;
  height: 20px;
  border-bottom-width: 1px;
  border-bottom-color: #ABABAB;
}

.circle {
  width: 40px;
  height: 40px;
  border-radius: 20px;
  border-color: #2e74e9;
  border-width: 1px;
  align-items: center;
  justify-content: center;
  background-color: white;
  margin-bottom: 15px;
}


.dashed {
  border-style: dashed;
  border-color: #AA9B6A;
}

.innerCircle {
  width: 30px;
  height: 30px;
  background-color: #2e74e9;
  border-radius: 15px;
  align-items: center;
  justify-content: center;
}

.gray {
  background-color: #ABABAB;
}

.topBorder {
  border-top-color: #f1f1f1;
  border-top-width: 1px;
  border-top-style: solid;
}

.button {
  height: 90px;
  margin-bottom: 70px;
  background-color: #e9302e;
  border-radius: 8px;
  justify-content: center;
  align-items: center;
  margin-left: 30px;
  margin-right: 30px;
}

.button-gray {
  height: 90px;
  margin-bottom: 70px;
  background-color: gray;
  border-radius: 8px;
  justify-content: center;
  align-items: center;
  margin-left: 30px;
  margin-right: 30px;
}

.text {
  color: white;
}

.tips {
  font-size: 26px;
  line-height: 39px;
}
.tips-color1{
  color: #9ba1ab;
}
.tips-color2{
  color: #454950;
}
.certificate {
  width: 689px;
  height: 262px;
  margin-bottom: 50px;
  background-color: #F1F1F1;
  border-color: #e7e7e7;
  border-width: 1px;
  flex-direction: row;
  overflow: hidden;
  align-items: center;
}

.pic {
  background-color: #ffffff;
  border-width: 1px;
  border-style: solid;
  border-color: #D2D2D2;
  margin-left: 60px;
  border-radius: 5px;
}

.pic-bg {
  position: absolute;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
  top: 0px;
  width: 320px;
  height: 149px;
  align-items: center;
  justify-content: center;
  background-color: gray;
  opacity: 0.7;
}

.pic-check {
  position: absolute;
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
  bottom: 0px;
  width: 320px;
  height: 52px;
  align-items: center;
  justify-content: center;
  background-color: #000000;
  flex-direction: row;
  opacity: 0.7;
}
.picture-tips-text{
  font-size:26px;
  line-height: 39px;
  text-align:center;
  color:#454950;
}
.upload-progress {
  position: absolute;
  bottom: 0px;
  width: 320px;
  height: 40px;
  background-color: gray;
}

.upload-progress-red {
  flex: 1;
  background-color: red;
}

.upload-percentage {
  width: 320px;
  height: 40px;
  text-align: center;
  color: blue;
}

.pic-check-text {
  font-size: 26px;
  text-align: center;
  color: #ffffff;
  padding-top: 5px;
  margin-left: 12px;
}
.image-camera-size{
  width:70px;
  height:70px;
}
.image-pic-size{
  border-radius: 5px;
  width:320px;
  height:200px;
}
.image-check-size{
  width:30px;
  height:30px;
}
.alert-show {
  position: absolute;
  left: 0px;
  top: 464px;
  right: 0px;
  bottom: 0px;
  align-items: center;
}
.bottom-tips-text{
  font-size:24px;
  line-height:38px;
  color:#9ba1ab;
}
.alert-modul {
  height: 74px;
  border-radius: 37px;
  align-items: center;
  justify-content: center;
  padding-left: 60px;
  padding-right: 60px;
  background-color: #4c4c4c;
  opacity: 0.68;
}

.button-front {
  height: 90px;
  background-color: #ffffff;
  justify-content: center;
  align-items: center;
  flex: 1;
  border-width: 1px;
  border-color: #2e74e9;
}
.button-next {
  height: 90px;
  background-color: #2e74e9;
  justify-content: center;
  align-items: center;
  flex: 1;
}
.button-next-gray {
  height: 90px;
  background-color: gray;
  justify-content: center;
  align-items: center;
  flex: 1;
}

</style>
