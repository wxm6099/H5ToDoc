<template>
<div style="backgroundColor:#f1f1f1" @viewappear="viewAppear">
  <status backgroundColor="#FFFFFF"></status>
  <navigation title="设置" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="logEvent('Setting_page_back');goBack();"></navigation>
  <div class="my-scroller">
    <div class="group">
      <div class="container border" v-on:click="onPushSetting();logEvent('Setting_page_push')">
        <div class="content">
          <text class="title">消息推送 </text>
        </div>
        <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
      </div>
      <div class="container border" v-on:click="onArticleSetting();logEvent('Setting_page_article')">
        <div class="content">
          <text class="title">文章页字体 </text>
        </div>
        <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
      </div>
      <div class="container border" v-on:click="onPlaySetting();logEvent('Setting_page_play')">
        <div class="content">
          <text class="title">播放设置 </text>
        </div>
        <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
      </div>
      <div class="container border" v-on:click="onClearCache();logEvent('Setting_page_Cache')">
        <div class="content">
          <text class="title">清除缓存 </text>
          <text class="detail"> {{cacheSize}}</text>
        </div>
        <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
      </div>
      <div class="container " v-on:click="checkUpdate();logEvent('Setting_page_Version')">
        <div class="content">
          <text class="title">版本检查 </text>
          <text class="detail"> {{localVersion}}</text>
        </div>
        <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
      </div>
    </div>
    <div class="group">
      <div class="container border" v-if="true == isIos" v-on:click="onEvaluation();logEvent('Setting_page_review')">
        <div class="content">
          <text class="title">给个好评 </text>
        </div>
        <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
      </div>
      <div class="container border" v-on:click="onFeedback();logEvent('Setting_page_feeback')">
        <div class="content">
          <text class="title">意见反馈 </text>
        </div>
        <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
      </div>
      <div class="container" v-on:click="onDisclaimer();logEvent('Setting_page_disclaimer')">
        <div class="content">
          <text class="title">免责声明 </text>
        </div>
        <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
      </div>
    </div>
    <div v-if="logined" class="group">
      <div class="container" style="justify-content:center" v-on:click="logout();logEvent('Setting_page_Logout')">
        <text class="logout-text"> 退出 </text>
      </div>
    </div>
  </div>
  <text v-if="bundleVersion" class="resversion">Res:{{bundleVersion}}</text>
  <dialog :show="showDialog" :title="cacheTag?cacheTitle:alter" :content="cacheTag?cacheContent:content" :confirm="cacheTag?cacheText:confirmText" :cancel="cacheTag?cancelText:cachecancelText" @confirm="dialogConfirmBtnClick" @cancel="dialogCancelBtnClick"
    @close="dialogCancelBtnClick">
  </dialog>
  <dialog :show="showWarm" title="" :content="loginTips" confirm="登录" cancel="注册" @confirm="memberCenter(0)" @cancel="openAccount()" @close="showWarm=false"></dialog>
  <div v-if="showToast" style="position:absolute;left:0px;top:0px;right:0px;bottom:0px;align-items:center;justify-content:center;">
    <div class="modul">
      <text style="color:#FFFFFF;font-size:28px;"> {{toastText}} </text>
    </div>
  </div>
  <message></message>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var bundleVersion = require('../include/base-url.js').bundleVersion;
var dom = weex.requireModule('dom')
var navigator = weex.requireModule('navigator')
const app = weex.requireModule('app')
var storage = require('../include/storage.js');
var modal = weex.requireModule('modal');
var utils = require('../include/utils.js');
const cookieStorage = weex.requireModule('cookieStorage');
var firebase = weex.requireModule('firebase');
var http = require('../include/http.js');

module.exports = {
  components: {
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'dialog': require('../components/dialog.vue'),
    'message': require('../components/message.vue'),
  },
  computed: {
    platform: function() {
      const {
        platform
      } = weex.config.env;
      return platform.toLowerCase() || 'common';
    },
  },
  data: function() {
    return {
      alter: '检测更新',
      content: '发现新版本，请立即更新',
      confirmText: '前往更新',
      cancelText: '取消',
      cacheTitle: '缓存提示',
      cacheContent: '',
      cacheText: '立即清除',
      cachecancelText: '以后再说',
      cacheTag: false,
      showDialog: false,
      showWarm: false,
      assets: assetsUrl,
      rightItemSrc: assetsUrl + 'arrow.png',
      cmsApiHost: '', //接口地址
      memberCenterUrl: '', //用户中心地址
      user: {}, //用户信息
      logined: false, //登录标记
      token: '', //
      feedback: "", //意见反馈
      serverVersion: 0,//服务器最新版本
      localVersion: 0,//本地版本
      bundleVersion: bundleVersion,
      disclaimer: "",
      isIos: utils.iOS(),
      cacheSize: '',
      showToast: false,
      toastText: '',
      loginTips: '',
      trueAccountUrl: '', //开户链接
      versionId : 0 ,
      download : "",
      anchor : '',
      isClickPlaySet:false,
    }
  },
  beforeCreate: function() {
  },
  created: function() {
    var that = this;

    if (weex.supports('@module/app.bundleVersion')) {
      that.localVersion = app.bundleVersion();
    }
    this.channelName = app.channelName();
    if (this.channelName) {
      this.utm = "?ComeFrom=GlobalApps&utm_source=APP&utm_campaign=&utm_content=&utm_term=&utm_medium=" + this.channelName;
    }
    let kb = 0
    if (weex.supports('@module/storage.totalSize')) {
      that.cacheSize = storage.totalSize() / 1024;
    } else {
      that.cacheSize = app.getCacheSize() / 1024;
    }
    if (that.cacheSize >= 1048576) {
      that.cacheSize = (that.cacheSize / 1048576).toFixed(2) + " GB";
    } else if (that.cacheSize >= 1024) {
      that.cacheSize = (that.cacheSize / 1024).toFixed(2) + " MB";
    } else {
      that.cacheSize = that.cacheSize.toFixed(2) + " KB";
    }
    that.cacheContent = " 缓存" + that.cacheSize + ",是否清除";
    storage.getItem('commonUrl',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.cmsApiHost = commonUrl.cmsApi; //接口基址
        that.imageBaseUrl = commonUrl.imageBaseUrl; //图片基址
        that.disclaimer = commonUrl.disclaimer;
        that.feedback = commonUrl.feedback;
      }
    });
    storage.getItem('memberCenter', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var memberCenter = JSON.parse(value);
      if (memberCenter) {
        that.memberCenterUrl = memberCenter.memberCenterUrl;
      }
    });
    storage.getItem('contentIdList', function(value) {
      var contentIdList = JSON.parse(value);
      if ('ios' == that.platform) {
        that.versionId = contentIdList.iosUpdate;
      }else {
        that.versionId = contentIdList.androidUpdate;
      }
    });
    this.viewAppear();
  },
  methods: {
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    showTips: function() {
      var that = this;
      that.showToast = true;
      setTimeout(() => {
        that.showToast = false;
      }, 2000)
    },
    viewAppear: function(event) {
      var that = this;
      //设置状态栏字体颜色为黑色
      weex.requireModule('app').setStatusBarStyle(0);
      storage.getItem('userInfo', function(data) {
        if (data) {
          that.user = JSON.parse(data);
        }
        if (that.user && (that.user.nickName || that.user.userName)) {
          that.logined = true;
        }else {
          that.logined = false;
        }
      });
    },
    goBack: function() {
      navigator.pop({
        animated: "true"
      }, res => {});
    },
    openDialog() {
      const self = this;
      self.showDialog = true;
    },
    dialogCancelBtnClick() {
      this.showDialog = false;
    },
    dialogConfirmBtnClick() {
      this.showDialog = false;
      if (this.cacheTag == true) {
        this.clearCache();
      } else {
        this.updateVersion();
      }
    },
    onPushSetting: function() {
        navigator.push({
          url: bundleUrl + 'messagepush.js',
          animated: "false",
          swipePop: "true",
        }, event => {})
    },
    onArticleSetting:function(){
      navigator.push({
        url: bundleUrl + 'articleSetting.js',
        disableBackPan: 'true',
        animated: 'true',
      }, event => {})
    },
    onPlaySetting: function() {
      if (this.user && (this.user.nickName || this.user.userName)) {
        navigator.push({
          url: bundleUrl + 'playsetting.js',
          disableBackPan: 'true',
          animated: 'true',
          // swipePop: 'true',
        }, event => {})
      } else {
        this.isClickPlaySet = true;
          this.loginTips = '您好，登录账号即可使用播放设置';
          this.anchor = 'Setting_page_play';
          this.showWarm = true;
      }
    },
    clearCache: function() {
      var that = this;
      storage.getAllKeys(function(e) {
        var arr = e.splice(',');
        for (var i = 0; i < arr.length; i++) {
          if (/^app-/.test(arr[i])) {
            storage.removeItem(arr[i]);
          }
        }
        that.toastText = '已清除缓存';
        that.showTips();
      })
      that.cacheSize = "0 KB";
      that.cacheContent = " 缓存0KB,是否清除";
    },
    updateVersion: function() {
      let that = this;
      this.showDialog = false;
      if (utils.isAndroid()) {
        var apkName = 'Android_APP.apk';
        if ('' != that.channelName && 'Android' != that.channelName && 'android' != that.channelName) {
          apkName = "Android_APP_"+that.channelName+".apk";
        }
       var  downloadUrl = that.download+'/'+apkName;
        app.isCheckStorgePermission(function (value) {
            if (value){
                app.downloadApp(downloadUrl);
                that.download = '';
            }
        })
      } else {
        app.openURL(this.download);
      }
    },
    memberCenter: function() {
      if (this.logined) {
        if (undefined == this.memberCenterUrl || this.memberCenterUrl.length <= 0) {
          return;
        }
        var data = {
          title: '用户中心',
          url: this.memberCenterUrl,
          anchor: this.anchor,
          from: this.anchor,
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'memberCenter.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }else {
        storage.setItem('user-original-fromLogin', 'setting');
        navigator.push({
          url: bundleUrl + 'userLogin.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    account: function() {
      if (this.user && (this.user.nickName || this.user.userName)) {
        navigator.push({
          url: bundleUrl + 'account.js',
          animated: "false",
          swipePop: "true",
        }, event => {})
      } else {
        this.isClickPlaySet = false;
          this.loginTips = '您好，登录账号即可使用账户与安全';
          this.anchor = 'Setting_page_secure';
          this.showWarm = true;
      }
    },
    onEvaluation: function() {
      if (weex.supports('@module/app.openRatingReview')) {
        //"itms-apps://itunes.apple.com/app/id892731216?action=write-review"
        app.openRatingReview();
      }
    },
    onFeedback: function() {
      this.loadWebView(this.feedback, '意见反馈');
    },
    onClearCache: function() {
      this.cacheTag = true;
      this.openDialog();
    },
    onUpVersion: function() {
      if (this.localVersion >= this.serverVersion) {
        this.toastText = '已经是最新版本了',
        this.showTips();
      } else {
        this.cacheTag = false;
        this.openDialog();
      }
    },
    onDisclaimer: function() {
      this.loadWebView(this.disclaimer, '免责声明');
    },
    openAccount: function() {
      if (this.isClickPlaySet) {
        this.logEvent('Setting_playset_sign');
        var data = {
          from: 'Setting_playset',
          openName: 'Setting_playset_sign',
        }
        storage.setItem('user-original-openAccount', JSON.stringify(data));
      }else {
        this.logEvent('setting_sign');
        var data = {
          from: 'setting_account',
          openName: 'setting_sign',
        }
        storage.setItem('user-original-openAccount', JSON.stringify(data));
      }
      storage.setItem('user_openaccount_from', 'index');
      navigator.push({
        url: bundleUrl + 'openAccount.js',
        animated: "true",
        swipePop: "true",
      }, event => {})
      // if (this.trueAccountUrl && this.trueAccountUrl.length > 0) {
      //   this.loadWebView(this.trueAccountUrl + this.utm, '');
      // }
    },
    loadWebView: function(url, title = '') {
      if (url && url.length > 0) {
        var data = {
          title: title,
          url: url,
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "false",
          swipePop: "true",
        }, event => {})
      }
    },
    checkUpdate: function() {
      var that = this;
      if (true == utils.iOS()) {
        this.serverVersion = app.appStoreVersion();
        if (utils.compareVersion(this.serverVersion,this.localVersion)) {
          app.openURL("https://itunes.apple.com/cn/app/id1482728265");
        }else {
          this.toastText = '已经是最新版本了',
          this.showTips();
        }
      } else if (this.cmsApiHost && this.cmsApiHost.length > 0) {
        var url = that.cmsApiHost + '/ContentUnion/Site?format=json&id=' + that.versionId;
        http.get(url, function(resp) {
          if (resp.ok && resp.data && resp.data.Results && resp.data.Results.length > 0) {
            var result = resp.data.Results[0];
              that.serverVersion = result.Description;
              that.download = result.LinkUrl;
              that.onUpVersion();
          }
        });
      }
    },
    logout: function() {
      var that = this;
      modal.confirm({
        message: '是否需要退出登录?',
        okTitle: '确定',
        cancelTitle: '取消',
        duration: 0.3
      }, function(value) {
        if ('确定' == value) {
          this.doLogout();
        }
      }.bind(this))
    },
    doLogout: function() {
      storage.setItem('userInfo', '{}', function(callback) {});
      storage.setItem('user-logintoken-id', '{}', function(callback) {});
      storage.setItem('token', '', function(callback) {});
      if (cookieStorage) {
        cookieStorage.deleteCookie('');
      }
      this.goBack();
    },
  },
}
</script>


<style scoped>
.navibar {
  height: 88px;
  background-color: #2e74e9;
  align-items: center;
  justify-content: center;
}

.navbar-title {
  font-size: 36px;
  color: white;
  line-height: 54px;
  text-align: center;
}

.navbar-button {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 120px;
  padding-left: 30px;
  justify-content: center;
}

.my-scroller {
  margin-top: 0px;
  background-color: white;
  width: 750px;
}

.group {
  /* margin-top: 20px; */
  width: 750px;
  border-top-width: 20px;
  border-top-style: solid;
  border-top-color: #F1F1F1;
  background-color: white;
}

.border {
  border-bottom-width: 1px;
  border-bottom-style: solid;
  border-bottom-color: #E1E1E1;
}

.container {
  flex-direction: row;
  height: 98px;
  margin-left: 24px;
  margin-right: 24px;
  align-items: center;
}

.content {
  flex: 1;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  overflow: hidden;
}

.title {
  flex: 1;
  text-align: left;
  text-overflow: ellipsis;
  font-size: 32px;
  line-height: 48px;
  color: #454950;
  lines: 1;
}

.detail {
  flex: 1;
  text-align: right;
  text-overflow: ellipsis;
  font-size: 28px;
  line-height: 34px;
  color: #9ba1ab;
  lines: 1;
}

.right-image {
  width: 18px;
  height: 30px;
  margin-left: 24px;
}

.logout-text {
  color: #e9302e;
  font-size: 32px;
  line-height: 38px;
  text-align: center;
  letter-spacing: 24px;
}

.container-alert {
  position: fixed;
  left: 0px;
  top: 0px;
  right: 0px;
  bottom: 0px;
  /*兼容H5异常*/
  z-index: 99999;
  justify-content: center;
  align-items: center;
  background-color: rgba(0, 0, 0, 0.6);
}

.content-alert {
  width: 500px;
  background-color: #FFFFFF;
  padding-top: 20px;
  border-radius: 10px;
}

.title-alert {
  flex: 1;
  height: 72px;
  justify-content: center;
  align-items: center;
}

.margin-alert {
  margin-left: 36px;
  margin-right: 36px;
  /*justify-content: center;*/
  /*align-items: center;*/
}

.version {
  flex: 1;
  height: 68px;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
}

.color-alert {
  color: #454950;
}

.title-size-alert {
  font-size: 32px;
  lines: 0;
  text-align: center;
}

.text-size {
  font-size: 28px;
  line-height: 42px;
  text-align: left;
}

.lines-alert {
  lines: 0;
}

.footer-alert {
  flex-direction: row;
  align-items: center;
  border-top-color: #F3F3F3;
  border-top-width: 1px;
  margin-top: 20px;
}

.footer-btn-alert {
  flex-direction: row;
  align-items: center;
  justify-content: center;
  flex: 1;
  height: 88px;
}

.border-alert {
  border-right-color: #F3F3F3;
  border-right-width: 1px;
}

.cancel-alert {
  color: #9ba1ab;
}

.confirm-alert {
  color: #e9302e;
}

.btn-text-alert {
  font-size: 28px;
  text-align: center;
}

.close-alert {
  position: absolute;
  top: 0px;
  right: 0px;
  width: 100px;
  height: 80px;
  flex-direction: row;
  justify-content: flex-end;
}

.close-icon-alert {
  width: 38px;
  height: 38px;
  margin-top: 14px;
  margin-right: 14px;
}

.modul {
  height: 74px;
  border-radius: 37px;
  align-items: center;
  justify-content: center;
  padding-left: 60px;
  padding-right: 60px;
  background-color: rgba(0, 0, 0, 0.7);
}
.resversion{
  position: absolute;
  left: 10px;
  right: 10px;
  bottom: 0px;
 font-size: 22px;
 color: #e6e6e6;
 text-align: center;
}
</style>
