<template>
 <div class="wrapper" @viewappear="viewappear" @viewdisappear="disappear" @foreground="viewresume" @background="viewpause">
  <div class="video">
    <media ref='livefull' class="media" v-if="src" :src="src" @click="onVideo" :play-status="playStatus" auto-play='false'></media>
    <div v-if="playStatus !='' && playStatus !='play'"  @click="onVideo" class="video" style="justify-content: center;align-items: center;background-color: black;">
      <image class="wifi-play-ios"  :src="wifiStopimg" @click="playStatus ='play'"></image>
    </div>
    <div v-if="tabbarTime!=0" class="tabbar-ios">
      <div style="width:144px;height:116px;" @click="onFull(false)">
        <image class="back-ios" :src="backimg"></image>
      </div>
    </div>
    <div v-if="tabbarTime!=0" class="controlbar-ios">
      <div class="button-bg-ios" @click="onPlay">
        <image class="play-ios" :src="playStatus=='play'?playimg:stopimg"></image>
      </div>
      <div class="button-bg-ios" @click="onRefresh">
        <image class="refresh-ios" :src="refreshimg"></image>
      </div>
      <div class="button-bg-ios" @click="onSound">
        <image class="sound-ios" :src="isMute==false?soundimg:muteimg"></image>
      </div>
      <text :class="[isIOS?'time-ios':'time']">{{liveTime}}</text>
      <div class="full-bg-ios" @click="onFull(true)">
        <image class="full-ios" :src="outFullimg"></image>
      </div>
    </div>
    <!--没有wifi播放直播-->
    <div class="netwifi" v-if="netText=='MOBILE' && showTips">
      <text :class="[isIOS?'wifi-text-ios':'wifi-text']">当前无WIFI,是否允许用流量播放</text>
      <div class="row">
        <div class="wifi-btn-play-ios " style="background-color: #e9302e;" @click="onMBplay">
          <text :class="[isIOS?'wifi-btn-ios':'wifi-btn']" style="color: #fff;">继续播放</text>
        </div>
        <div class="wifi-btn-delete-ios" style="background-color: #d8d8d8;" @click="onMBCancel">
          <text :class="[isIOS?'wifi-btn-ios':'wifi-btn']" style="color: #61656b;">取消</text>
        </div>
      </div>
      <div @click="onFull(false)" class="viewgoback-ios">
        <image class="back-ios" resize="contain" :src="backimg"></image>
      </div>
    </div>
    <!--&lt;!&ndash;无网络&ndash;&gt;-->
    <div class="netwifi" v-if="netText=='ERROR'">
      <div @click="onFull(false)" class="viewgoback-ios">
        <image class="back-ios" resize="contain" :src="backimg"></image>
      </div>
      <div>
        <text :class="[isIOS?'nonetwork-text-ios':'nonetwork-text']">网络未连接，请检查网络设置</text>
      </div>
      <div class="nonetwork-ios" @click="onNetError">
        <text :class="[isIOS?'refreshText-ios':'refreshText']">刷新重试</text>
      </div>
    </div>
    <!--暂停直播-->
    <div class="netwifi" v-if="isMBStop">
      <div @click="onFull(false)" class="viewgoback-ios">
        <image class="back-ios" resize="contain" :src="backimg"></image>
      </div>
      <image class="wifi-play-ios" :src="wifiStopimg" @click="onMbRefresh"></image>
    </div>
  </div>
  <!-- <div v-if="isAndroid" class="video" ref="videoview">
    <media ref='livefull' class="media" v-if="src" :src="src" @click="onVideo" :play-status="playStatus" auto-play='false'></media>
    <div v-if="playStatus !='' && playStatus !='play'"  @click="onVideo" class="video" style="justify-content: center;align-items: center;background-color: black;">
      <image class="wifi-play"  :src="wifiStopimg" @click="playStatus ='play'"></image>
    </div>
    <div v-if="tabbarTime!=0" class="tabbar">
      <div style="width:72px;height:58px;" @click="onFull">
        <image class="back" :src="backimg"></image>
      </div>
    </div>
    <div v-if="tabbarTime!=0" class="controlbar">
      <div class="button-bg" @click="onPlay">
        <image class="play" :src="playStatus=='play'?playimg:stopimg"></image>
      </div>
      <div class="button-bg" @click="onRefresh">
        <image class="refresh" :src="refreshimg"></image>
      </div>
      <div class="button-bg" @click="onSound">
        <image class="sound" :src="isMute==false?soundimg:muteimg"></image>
      </div>
      <text class="time">{{liveTime}}</text>
      <div class="full-bg" @click="onFull">
        <image class="full" :src="outFullimg"></image>
      </div>
    </div>
    <div class="netwifi" v-if="netText=='ERROR'">
      <div @click="onFull" class="viewgoback">
        <image class="back" resize="contain" :src="backimg"></image>
      </div>
      <div>
        <text style="color: #e9e9e9;font-size: 21px">网络未连接，请检查网络设置</text>
      </div>
      <div class="nonetwork" @click="onNetError">
        <text class="refreshText"> 刷新重试</text>
      </div>
    </div>
    <div class="netwifi" v-if="netText=='MOBILE' && showTips">
      <div class="">
        <text class="wifi-text"> 当前无WIFI,是否允许用流量播放</text>
      </div>
      <div class="mobile">
        <div class="wifi-btn-play" style="background-color: #e9302e;" @click="onMBplay">
          <text class="wifi-btn" style="color: #fff;"> 继续播放</text>
        </div>
        <div class="wifi-btn-delete" style="background-color: #d8d8d8;" @click="onMBCancel">
          <text class="wifi-btn" style="color: #61656b;"> 取消</text>
        </div>
      </div>
      <div @click="onFull" class="viewgoback">
        <image class="back" resize="contain" :src="backimg"></image>
      </div>
    </div>
    <div class="netwifi" v-if="isMBStop">
      <div @click="onFull" class="viewgoback">
        <image class="back" resize="contain" :src="backimg"></image>
      </div>
      <image class="wifi-play" :src="wifiStopimg" @click="onMbRefresh"></image>
    </div>
  </div> -->
</div>
</template>

<script>
var storage = require('../include/storage.js');
var utils = require('../include/utils.js');
var assetsUrl = require('../include/base-url.js').assetsUrl();
var bundleUrl = require('../include/base-url.js').bundleUrl();
var modal = weex.requireModule('modal');
var navi = weex.requireModule('navigator')
var app = weex.requireModule('app');
var firebase = weex.requireModule('firebase');

module.exports = {
  components: {
    'status': require('../components/statusbar.vue'),
    'dialog': require('../components/wxc-dialog.vue'),
  },
  data: function() {
    return {
      title: '观看结束',
      content: '游客观看时间已结束，请登录会员账号，即可继续观看直播。',
      confirmText: '登录',
      cancelText: '注册',
      showDialog: false,
      cmsApiHost: '',
      imageBaseUrl: '',
      playStatus: "stop",
      state: "----",
      // src:"http://flv2.bn.netease.com/videolib3/1611/01/XGqSL5981/SD/XGqSL5981-mobile.mp4",
      src: "",
      backimg: assetsUrl + 'live_back.png',
      menuimg: assetsUrl + 'live_menu.png',
      stopimg: assetsUrl + 'live_stop.png',
      wifiStopimg: assetsUrl + 'live_wifi_stop.png',
      playimg: assetsUrl + 'live_playing.png',
      refreshimg: assetsUrl + 'live_refresh.png',
      soundimg: assetsUrl + 'live_sound.png',
      fullimg: assetsUrl + 'live_full.png',
      outFullimg: assetsUrl + 'live_out_full.png',
      menuimgbg: assetsUrl + 'live_menu_bg.png',
      registimg: assetsUrl + 'live_register.png',
      landingimg: assetsUrl + 'live_landing.png',
      teacherimg: assetsUrl + 'live_teachers.png',
      courseimg: assetsUrl + 'live_course.png',
      muteimg: assetsUrl + 'live_mute.png',
      menubgimg: {},
      liveTime: "",
      isShowMenu: false,
      isMute: false,
      isFull: false,
      tabbarTime: 0,
      isIOS: true,
      isAndroid: false,
      isIphoneX: true,
      netText: "",
      showTips: true,
      isMBStop: false,
      playStatusCopy: '',
      background: false, //进入后台模式
    }
  },

  created: function() {
    var that = this;
    if (utils.isAndroid()) {
      app.setNetwork();
    }
    storage.getItem('chatRoom', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var data = JSON.parse(value);
      if (data) {
        that.src = data.rtmpUrl;
      }
    });
    //倒计时
    const wsData = new BroadcastChannel('liveTime');
    wsData.onmessage = function(event) {
      if (event.data == "今日剩余观看时间：00:00:00") {
        that.onFull(true);
      } else {
        that.liveTime = '' + event.data;
      }
    }
    that.isIOS = utils.iOS();
    that.isAndroid = utils.isAndroid();
    that.isIphoneX = utils.iphonex();
    storage.getItem('livestatus', function(data) {
      var meg = JSON.parse(data);
      if (meg) {
        that.playStatus = meg.playStatus;
        that.netText = meg.netStatus;
        that.playStatusCopy = that.playStatus;
        that.showTips = meg.showTips;
        that.isMute = meg.mute;
      }
    });
    that.setNetWorkEvent();
    // if (!utils.isAndroid()) {
    //   var globalEvent = weex.requireModule('globalEvent');
    //   globalEvent.addEventListener("WXApplicationWillResignActiveEvent", function(e) {
    //     that.playStatusCopy = that.playStatus;
    //     that.playStatus = 'stop';
    //   });
    //   globalEvent.addEventListener("WXApplicationDidBecomeActiveEvent", function(e) {
    //     if (that.netText != 'MOBILE') {
    //       that.playStatus = that.playStatusCopy;
    //     }
    //   });
    // }
    // that.isMute = weex.requireModule('app').isSilentMode();
  },
  methods: {
    viewpause: function() {
      if (false == this.background) {
        this.background = true;
        this.$refs.livefull.setVideoEnable(false);
        // this.playStatusCopy = this.playStatus;
        // this.playStatus = 'stop';
      }
    },
    viewresume: function() {
      if (true == this.background) {
        this.$refs.livefull.setVideoEnable(true);
        this.background = false;
        // if (this.netText != 'MOBILE') {
        //   this.playStatus = this.playStatusCopy;
        // }
      }
    },
    logEvent:function(name){
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    openDialog() {
      const self = this;
      self.showDialog = true;
    },
    closeDialog() {
      const self = this;
      self.showDialog = false;
    },
    dialogCancelBtnClick() {
      this.showDialog = false;
    },
    dialogConfirmBtnClick() {
      this.showDialog = false;
    },
    dialogNoPromptClick(e) {
      this.isChecked = e.isChecked;
    },
    onMBplay: function() {
      this.netText = 'WIFI';
      this.playStatus = 'play';
      this.showTips = false;
    },
    onMBCancel: function() {
      this.netText = 'WIFI';
      this.isMBStop = true;
    },
    setNetWorkEvent: function() {
      var that = this;
      const netEvent = weex.requireModule('globalEvent');
      netEvent.addEventListener("netStatus", function(e) {
        that.isMBStop = false;
        if (e.net == 'WIFI') {
          that.playStatus = "play";
        }
        if (e.net == 'MOBILE' && that.netText != e.net && true == that.showTips) {
          that.playStatus = 'stop';
          // that.showTips = true;
        }
        that.netText = e.net;
      });
    },
    initNetView: function() {
      if (this.netText == 'WIFI') {
        this.playStatus = "play";
        this.isMBStop = false;
      }
      if (this.netText == 'MOBILE') {
        this.netText = 'MOBILE'
      }
      if (this.netText == 'ERROR') {
        this.netText = 'ERROR';
      }
    },
    disappear: function(e) {
      if (true != this.background) {
        this.playStatusCopy = this.playStatus;
        if (this.$refs.livefull && !this.iOS && false == this.background) {
          // this.$refs.livefull.stopLive();
          this.playStatus = 'stop';
        }
      }
    },
    viewappear: function(e) {
      if (true != this.background) {
        if (utils.isAndroid()) {
          if (this.netText != 'MOBILE') {
            this.playStatus = this.playStatusCopy;
          }
        }
      }
      setTimeout(() => {
        this.$refs.livefull.disableSound(this.isMute);
      }, 500)
    },
    onVideo: function(event) {
      this.tabbarTime = this.tabbarTime == 0 ? 5000 : 0;
      if (this.tabbarTime != 0) {
        this.onTabbarTime();
      }
    },
    onTabbarTime: function() {
      this.tabbarTime = this.tabbarTime - 1000;
      if (this.tabbarTime > 0) {
        setTimeout(this.onTabbarTime.bind(this), 1000);
      } else {
        this.tabbarTime = 0;
        this.isShowMenu = false;
      }
    },
    onNetError: function() {
      this.initNetView();
    },
    onPlay: function(event) {
      if (this.playStatus == 'stop') {
        this.playStatus = 'play';
      } else {
        this.playStatus = 'stop';
      }
    },
    onRefresh: function(event) {
      if (this.playStatus == 'play' && this.videoTime > 0) {
        this.$refs.livefull.refresh();
      }
    },
    onSound: function(event) {
      this.isMute = !this.isMute;
      this.$refs.livefull.disableSound(this.isMute);
    },
    onMbRefresh: function() {
      this.netText = 'MOBILE';
      this.initNetView();
      this.isMBStop = false;
    },
    onback:function(){
      this.logEvent('LIVE_screen_back');
    },
    onFull: function(isOnFull) {
      if (isOnFull) {
        this.logEvent('LIVE_screen_exit');
      }else {
        this.logEvent('LIVE_screen_back');
      }
      storage.setItem('livestatus', JSON.stringify({
        "playStatus": this.playStatus,
        "showTips": this.showTips,
        "mute" : this.isMute
      }));
      this.playStatus = 'stop';
      navi.pop({
        // url: bundleUrl + 'live.js',
        animated: "false"
      }, event => {})
    },
    formatTime: function(second, type = 0) {
      if (0 == type) {
        return [parseInt(second / 3600), parseInt(second / 60 % 60), parseInt(second % 60)].join(":").replace(/\b(\d)\b/g, "0$1");
      } else {
        return [parseInt(second / 3600), parseInt(second / 60 % 60)].join(":").replace(/\b(\d)\b/g, "0$1");
      }
    },
  }
}
</script>

<style scoped>
.wrapper {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  /* background-color: blue; */
}

.video {
  position: absolute;
  left: 0px;
  right: 0px;
  top: 0px;
  bottom: 0px;
  /* background-color: black; */
  /*width: 200px;*/
  /*height: 50px;*/
}

.media {
  /*width: 200px;*/
  /*height: 100px;*/
  position: absolute;
  left: 0px;
  top: 0px;
  right: 0px;
  bottom: 0px;
  background-color: black;
}

.tabbar-ios {
  position: absolute;
  left: 0px;
  top: 0px;
  right: 0px;
  height: 116px;
  align-items: center;
  flex-direction: row;
  background-color: black;
  filter: alpha(opacity=26);
  /* CSS3 standard */
  opacity: 0.6;
}

.tabbar {
  position: absolute;
  left: 0px;
  top: 0px;
  right: 0px;
  height: 58px;
  align-items: center;
  flex-direction: row;
  background-color: black;
  filter: alpha(opacity=26);
  /* CSS3 standard */
  opacity: 0.6;
}

.back-ios {
  position: absolute;
  left: 50px;
  top: 50px;
  width: 44px;
  height: 44px;
}

.back {
  position: absolute;
  left: 25px;
  top: 25px;
  width: 22px;
  height: 22px;
}

.menu {
  position: absolute;
  right: 30px;
  top: 25px;
  width: 25px;
  height: 25px;
}

.controlbar-ios {
  position: absolute;
  left: 0px;
  right: 0px;
  bottom: 0px;
  height: 88px;
  flex-direction: row;
  align-items: center;
  background-color: black;
  filter: alpha(opacity=26);
  /* CSS3 standard */
  opacity: 0.6;
}

.controlbar {
  position: absolute;
  left: 0px;
  right: 0px;
  bottom: 0px;
  height: 44px;
  flex-direction: row;
  align-items: center;
  background-color: black;
  filter: alpha(opacity=26);
  /* CSS3 standard */
  opacity: 0.6;
}

.button-bg-ios {
  margin-left: 40px;
  width: 64px;
  height: 64px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
}

.button-bg {
  margin-left: 20px;
  width: 32px;
  height: 32px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
}

.play-ios {
  height: 44px;
  width: 44px;
  /*margin-left: 60px;*/
}

.play {
  height: 22px;
  width: 22px;
  /*margin-left: 30px;*/
}

.refresh-ios {
  height: 44px;
  width: 44px;
  /*margin-left: 112px;*/
}

.refresh {
  height: 22px;
  width: 22px;
  /*margin-left: 56px;*/
}

.sound-ios {
  height: 44px;
  width: 44px;
  /*margin-left: 128px;*/
}

.sound {
  height: 22px;
  width: 22px;
  /*margin-left: 64px;*/
}

.time-ios {
  /*color: white;*/
  color: #e2e2e2;
  font-size: 28px;
  margin-left: 80px;
}

.time {
  /*color: white;*/
  color: #e2e2e2;
  font-size: 14px;
  margin-left: 40px;
}

.full-bg-ios {
  position: absolute;
  top: 12px;
  right: 40px;
  width: 64px;
  height: 64px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
}

.full-bg {
  position: absolute;
  top: 6px;
  right: 20px;
  width: 32px;
  height: 32px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
}

.full-ios {
  /*position: absolute;*/
  height: 44px;
  width: 44px;
  /*align-items: center;*/
  /*right: 40px;*/
  /*top: 16px;*/
}

.full {
  /*position: absolute;*/
  height: 22px;
  width: 22px;
  align-items: center;
  /*right: 20px;*/
  /*top: 8px;*/
}

.menu-window {
  position: absolute;
  right: 0px;
  top: 60px;
  width: 180px;
  height: 160px;
  background-color: white;
  z-index: 15;
}

.menu-item {
  flex-direction: row;
  width: 200px;
  height: 40px;
  align-items: center;
}

.menu-img {
  width: 26px;
  height: 26px;
  margin-left: 26px;
}

.menu-text {
  margin-left: 16px;
  font-size: 16px;
}

.wifi-play-ios {
  height: 114px;
  width: 114px;
}

.wifi-play {
  height: 57px;
  width: 57px;
}

.netwifi {
  position: absolute;
  left: 0px;
  top: 0px;
  right: 0px;
  bottom: 0px;
  justify-content: center;
  align-items: center;
  background-color: black;
}

.wifi-text-ios {
  text-align: center;
  font-size: 32px;
  color: #e9e9e9;
}

.mobile {
  margin-top: 24px;
  flex-direction: row;
}

.wifi-text {
  text-align: center;
  font-size: 21px;
  color: #e9e9e9;
}

.wifi-btn-play-ios {
  width: 178px;
  height: 60px;
  border-radius: 5px;
  justify-content: center;
  align-items: center;
}

.wifi-btn-play {
  width: 89px;
  height: 30px;
  background-color: #e9302e;
  border-radius: 3px;
  justify-content: center;
  align-items: center;
}

.wifi-btn-delete-ios {
  margin-left: 40px;
  width: 178px;
  height: 60px;

  border-radius: 5px;
  justify-content: center;
  align-items: center;
}

.wifi-btn-delete {
  margin-left: 20px;
  width: 89px;
  height: 30px;

  border-radius: 3px;
  justify-content: center;
  align-items: center;
}

.wifi-btn-ios {
  font-size: 28px;
  line-height: 42px;
  text-align: center;
}

.wifi-btn {
  font-size: 18px;
  line-height: 27px;
  text-align: center;
}

.nonetwork {
  margin-top: 24px;
  width: 110px;
  height: 40px;
  border-radius: 20px;
  border-width: 1px;
  border-color: #e9e9e9;
  justify-content: center;
  align-items: center;
}
.nonetwork-text-ios{
  color: #e9e9e9;
  font-size: 42px
}
.nonetwork-text{
  color: #e9e9e9;
  font-size: 21px
}

.nonetwork-ios {
  margin-top: 48px;
  width: 220px;
  height: 80px;
  border-radius: 40px;
  border-width: 2px;
  border-color: #2e74e9;
  justify-content: center;
  align-items: center;
}

.refreshText-ios {
  text-align: center;
  color: #2e74e9;
  font-size: 36px;
  line-height: 54px;
}

.refreshText {
  text-align: center;
  color: #2e74e9;
  font-size: 18px;
  line-height: 27px;
}
.viewgoback-ios {
  position: absolute;
  top: 0px;
  left: 0px;
  width: 144px;
  height: 112px;
  /* margin-left: 30px; */
}
.viewgoback {
  position: absolute;
  left: 0px;
  width: 72px;
  height: 56px;
  top: 0px;
  /* margin-left: 30px; */
}

.row {
  flex-direction: row;
  margin-top: 48px;
}
</style>
