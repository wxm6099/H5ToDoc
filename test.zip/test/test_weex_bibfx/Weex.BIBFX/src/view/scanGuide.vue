<template>
  <div v-if="show && canShow" class="opacity" @click="maskClick">
    <status backgroundColor="transparent"></status>
    <div style="width:270px;height:200px;align-items: flex-end;">
      <div class="center" style="width:70px;height:70px;top:10px;right:10px;backgroundColor:#e9302e; border-radius: 35px;">
        <image style="width:30px;height:30px;" v-bind:src="scan"></image>
      </div>
      <image style="width:186px;height:134px;top:-10;right:80px;" v-bind:src="arrow"></image>
    </div>
    <div style="align-items: center;marginRight:80px;">
      <div style="flex-direction:row">
      <text class="text">点击 "</text>
      <text class="textH">扫一扫</text>
      <text class="text">"</text>
      </div>
      <text class="text">轻松登录直播间与用户中心</text>
      <div class="center" @click="close" style="width:200px;height:60px;margin:10px;backgroundColor:#FFFFFF;border-radius:5px;">
        <text class="textB">知道了</text>
      </div>
    </div>
  </div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator')
var app = weex.requireModule('app')
var storage = require('../include/storage.js');
module.exports = {
  components: {
    'status': require('../components/statusbar.vue')
  },
  props: {
    show: {
      type: Boolean,
      default: false
    }
  },
  data:function(){
    return {
      scan:assetsUrl+'scan.png',
      arrow:assetsUrl+'scanArrow.png',
      canShow:false
    }
  },
  created: function() {
    var that = this;
    storage.getItem('scanShowTips', function(value) {
      if ('false' == value) {
        that.canShow = false;
      }else {
        that.canShow = true;
      }
    });
  },
  methods:{
    close:function(){
      this.canShow = false;
      storage.setItem('scanShowTips',"false");
    },
    maskClick:function(){
      //此函数只为兼容android
    }
  }
}
</script>

<style lang="css" scoped>
.opacity{
  background-color: rgba(0, 0, 0, 0.7);
  position: fixed;
  top: 0px;
  left: 0px;
  right: 0px;
  bottom: 0px;
  align-items: flex-end;
}

.center{
  justify-content: center;
  align-items: center;
}

.text{
  font-size: 30px;
  line-height: 45px;
  color: #FFFFFF;
}

.textB{
  font-size: 30px;
  line-height: 45px;
  color: #666666;
}

.textH{
  font-size: 30px;
  line-height: 45px;
  color: #e83737;
}
</style>
