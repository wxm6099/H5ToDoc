<template>
<div style="backgroundColor:white;" :style="{'padding-bottom': iphonex?'34px':'0px'}" @viewdisappear="viewDisappear">
  <status backgroundColor="#FFFFFF"></status>
  <div style="flex:1">
    <navigation :title="title" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="goBack"></navigation>
    <!-- <div class="navbar">
      <text class="navbar-title"> {{title}} </text>
      <div @click="goBack" class="goback">
        <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
      </div>
    </div> -->
    <div style="flex:1;width:750px;overflow: hidden;">
      <div style="flex:1;width:750px;overflow: hidden;">
        <web v-if="url" ref="webview" :src="url" class="webview" @message="onmessage" @error="error" @pagestart="start" @pagefinish="finish"></web>
  			<web v-if="context" style="flex: 1;width: 750px;" @pagefinish="finish" :source="context"></web>
        <div v-if="isService" class="service" @click="closeService()"></div>
        <wxc-loading :show="loading" loading-text="加载中" needMask="true"></wxc-loading>
      </div>
      <div v-if="isLoadError" style="position:absolute;left:0px; top:0px;right:0px; bottom:0px;background-color: white;justify-content: center;align-items: center">
        <loadError @refreshNetWorkError="refreshNetWorkError"></loadError>
      </div>
    </div>
    <message></message>
    <unusual :show="isShowUnusual" :service="unusual.isService" :data="unusual.data" :size="unusual.size" @cancel="cancelClick" @confirm="confirmClick"></unusual>
  </div>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigators = weex.requireModule('navigator')
var storage = require('../include/storage.js');
var utils = require('../include/utils.js');
var webview = weex.requireModule('webview');
const cookieStorage = weex.requireModule('cookieStorage');
var app = weex.requireModule('app');
var firebase = weex.requireModule('firebase');

module.exports = {
  components: {
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'message': require('../components/message.vue'),
    "wxc-loading": require('../components/wxc-loading.vue'),
    'loadError': require('../components/loadError.vue'),
    'unusual': require('./unusual.vue')
  },
  computed: {
    iphonex: function() {
      return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' || weex.config.env.deviceModel === 'iPhone11,2' || weex.config.env.deviceModel === 'iPhone11,4' || weex.config.env.deviceModel === 'iPhone11,6' || weex.config.env.deviceModel === 'iPhone11,8');
    }
  },
  data: function() {
    return {
      assets: assetsUrl,
      height: 0, //屏幕的高度
      url: '',
      title: '',
      loading: true,
      canGoBack: false,
      canGoForward: false,
      cookieName: '',
      isLoadError: false, //网络加载出错
      enable:true,
      fontSize:38,
      utm: '',
			context: '',
      isService:false,//是否是在线客服
      isShowUnusual:false,//是否显示在线客服关闭弹窗
      unusual:{isService:true,data:{title:'您确定要结束对话并关闭当前窗口吗？',img:assetsUrl + 'my_icon_tips.png'},size:{top:88+1}},
    }
  },
  beforeCreate: function() {
    var that = this;
    storage.getItem('fontSetting', function(value) {
      if (value && value.length>0) {
        var seting = JSON.parse(value);
        that.fontSize = seting.fontSize;
      }
    });
  },
  created: function() {
    app.setStatusBarStyle(0);
    this.channelName = app.channelName();
    if (this.channelName) {
      this.utm = "ComeFrom=GlobalApps&utm_source=APP&utm_campaign=&utm_content=&utm_term=&utm_medium=" + this.channelName;
    }

    if (weex.supports('@module/app.disableStatusBar')) {
      app.disableStatusBar(true);
    }
    storage.getItem('nodeIdList', function(value) {
      var nodeIdList = JSON.parse(value);
      if (nodeIdList) {
        that.nodeId = nodeIdList.homeTeacherInfo;
      }
    });

    this.height = (weex.config.env.deviceHeight * 750) / weex.config.env.deviceWidth - 128;
    var that = this;
    storage.getItem('app-url', function(value) {
      if (value) {
        var data = JSON.parse(value);
        if (data.title === '客服'|| data.title === '意见反馈') {
          that.isService = true;
        }
		if(data.context){
		  that.context = data.context;
          that.url = '';
		  return;
		}

        that.context = '';
        that.url = utils.appendProtocol(data.url);
        if (0 != data.fontSize) {
          that.url = utils.appendURLParams(that.url,'fontSize='+that.fontSize);
        }

        if (that.utm) {
          that.url = utils.appendURLParams(that.url,that.utm);
        }
        that.title = data.title;
        that.type = data.type;
        if (that.type && 'article' == that.type) {
          that.logEvent('Article');
        }
        if (data.source) {
          that.source = data.source;
        }
        if (data.anchor) {
          that.anchor = data.anchor;
        }
      }
    });

      // // 接收网络错误的广播
      // var that = this;
      // const Network = new BroadcastChannel('GloballyRefreshNetwork');
      // Network.onmessage = function(event) {
      //     // var reload_url = that.url;
      //     // that.url = "";
      //     // that.url = reload_url;
      //     that.reload();
      // };

  },
  methods: {
      // 接收网络错误的点击事件的回调
      refreshNetWorkError:function(){
          this.reload();
      },
    showTeacher: function(name) {
      this.logEvent('Article_author')
      storage.setItem('lecturer', JSON.stringify({
        name: name,
        channelId: this.nodeId
      }));
      navigators.push({
        url: bundleUrl + 'lecturer.js',
        animated: "true",
      }, event => {})
    },
    logEvent:function(name){
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    onmessage: function(message) {
      var that = this;
      // console.log("onmessage:"+JSON.stringify(message));
      if ('message' == message.type && message.data) {
        var data = JSON.parse(message.data);
        if (data && data.type && data.type == 'teacher') {
          if (data.title) {
            that.showTeacher(data.title)
          }
        } else if (data.type == 'anchor' ){
          var _data = data.data;
          if (_data && _data.length>0) {
            if (that.anchor && that.anchor.length>0) {
              that.logEvent(that.anchor+'_'+_data);
            }else {
              that.logEvent(_data);
            }
          }
        }
      }
    },
    viewDisappear:function(){
      if (weex.supports('@module/app.disableStatusBar')) {
        app.disableStatusBar(false);
      }
      if (this.source) {
        app.setStatusBarStyle(0);
      }
    },
    pop: function() {
      // this.saveCookie();
      if (weex.supports('@module/app.disableStatusBar')) {
        app.disableStatusBar(false);
      }
      navigators.pop({
        animated: "true"
      }, res => {});
    },
    goBack: function() {
      if (this.canGoBack &&  !utils.isBlankString(this.url)) {
        webview.goBack(this.$refs.webview);
      } else {
        if (this.type && 'article' == this.type) {
          this.logEvent('Article_back');
        }
        this.pop();
      }
    },
    goForward: function() {
      if (this.canGoForward) {
        webview.goForward(this.$refs.webview);
      }
    },
    reload: function() {
      webview.reload(this.$refs.webview);
    },
    start: function(e) {
        this.isLoadError =false;
        // this.loading = true;
      // console.log("start:" + JSON.stringify(e));
    },
    finish: function(e) {
       // this.isLoadError =false;
      this.loading = false;
      this.canGoBack = e.canGoBack;
      this.canGoForward = e.canGoForward;
      if (e.title && (undefined == this.type || 'article' == this.type)) {
        this.title = e.title;
      }
    },
    error: function(e) {
      if (e.errorCode == -1009||e.errorMsg.errorCode == -2) {
        this.isLoadError =true;
      }
      this.loading = false;
    },
    closeService:function(){
      this.isShowUnusual = true;
    },
    cancelClick:function(){
      this.isShowUnusual = false;
    },
    confirmClick:function(){
      this.isShowUnusual = false;
      this.goBack();
    },
  }
}
</script>

<style scoped>
.navbar {
  width: 750px;
  height: 88px;
  background-color: #2e74e9;
  align-items: center;
  justify-content: center;
}

.navbar-title {
  font-size: 36px;
  line-height: 54px;
  lines:1;
  text-align: center;
  text-overflow:ellipsis;
  color: white;
  margin-left: 80px;
  margin-right: 80px;
}

.goback {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 120px;
  padding-left: 30px;
  justify-content: center;
}

.refresh {
  position: absolute;
  top: 0px;
  right: 0px;
  bottom: 0px;
  width: 120px;
  justify-content: center;
}

.webview {
  flex: 1;
  width: 750px;
}
.service{
  position: absolute;
  top: 0px;
  right: 0px;
  width:100px;
  height:100px;
  align-items: center;
  justify-content: center;
  background-color: rgba(0, 0, 0, 0);
}
</style>
