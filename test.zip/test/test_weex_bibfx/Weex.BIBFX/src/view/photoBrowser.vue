<template>
<div v-if="show" class="container" @click="maskClick">
  <proviewImg class="fullScreen" :src="path" @click="maskClick"></proviewImg>
  <div class="footer" v-if="false == noButton">
    <div v-if="!single" class="button border marginRight" @click="cancelClick">
      <text class="font32 cancel"> {{cancel}} </text>
    </div>
    <div class="button border bg" @click="confirmClick">
      <text class="font32 confirm"> {{confirm}} </text>
    </div>
  </div>
</div>
</template>

<script>
export default {
  props: {
    show: { default: false },
    close: { default: true },
    path:{type: String,default: ''},
    noButton:{ type: Boolean,default: false},
    viewType:{type: Number,default: 0},
    confirm: {
      default: '确定'
    },
    cancel: {
      default: '取消'
    },
  },
  methods: {
  closeClick: function() {
    this.show = false;
    this.$emit('close');
  },
  cancelClick: function() {
    this.show = false;
    this.$emit('cancel');
    this.$emit('close');
  },
  confirmClick: function() {
    this.show = false;
    this.$emit('confirm');
    this.$emit('close');
  },
  maskClick:function(){
    this.$emit('close');
  }
}
}
</script>

<style scoped>
.container {
  position: fixed;
  left: 0px;
  top: 0px;
  right: 0px;
  bottom: 0px;
  /*兼容H5异常*/
  z-index: 99999;
  justify-content: flex-end;
  align-items: center;
  background-color: rgba(0,0,0,0.8);
}

.fullScreen{
  position: absolute;
  left: 0px;
  top:0px;
  right: 0px;
  bottom: 0px;
}

.footer {
  width: 750px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  margin-bottom: 60px;
}

.button {
  width: 316px;
  height: 80px;
  align-items: center;
  justify-content: center;
  border-radius: 10px
}
.marginRight {
  margin-right: 46px;
}
.border {
  border-color: #518deb;
  border-width: 2px;
}

.bg {
  background-color: #518deb;
}

.font32{
  font-size: 32px;
}

.cancel {
  color: #518deb;
}

.confirm {
  color: #ffffff;
}
</style>
