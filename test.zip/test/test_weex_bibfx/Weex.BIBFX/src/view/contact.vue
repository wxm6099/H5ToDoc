<template>
<div style="backgroundColor:#f1f1f1">
  <status backgroundColor="#FFFFFF"></status>
  <navigation title="联系我们" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="back();logEvent('Contactus_page_back')"></navigation>
  <!-- <div class="navibar">
    <text class="navbar-title"> 联系我们 </text>
    <div @click="back();logEvent('Contactus_page_back')" class="navbar-button">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div>
  </div> -->

  <div class="my-scroller">
    <div class="container border" v-on:click="onLiaoMe();logEvent('Contactus_page_service')">
      <div class="content">
        <text class="title">专业在线客服  </text>
        <text class="detail"> 与我交谈</text>
      </div>
      <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
    </div>
    <!--v-on:click="onCall()-->
    <div class="container border" v-on:click="onCall('+(852)3579-2688');logEvent('Contactus_page_tel')" v-on:longpress="copy('+(852)3579-2688')">
      <div class="content">
        <text class="title">公司电话 </text>
        <text class="detail">4001209311</text>
      </div>
      <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
    </div>

    <!-- <div class="container border" v-on:click="onCall('+(852)3579-2888');logEvent('Contactus_page_fax')" v-on:longpress="copy('+(852)3579-2888')">
      <div class="content">
        <text class="title">公司传真 </text>
        <text class="detail">（+852）3579-2888</text>
      </div>
      <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
    </div> -->
    <div class="line"></div>
    <div class="container border" v-on:click="onQQ();logEvent('Contactus_page_QQ')" v-on:longpress="copy('800821879')">
      <div class="content">
        <text class="title">企业QQ </text>
        <text class="detail"> 800822551</text>
      </div>
      <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
    </div>
    <!-- <div class="container border" @click="onWechatSer();logEvent('Contactus_page_bibgoldnews')" @longpress="copy('bibgold')">
      <div class="content">
        <text class="title">微信服务号 </text>
        <text class="detail"> bibfx</text>
      </div>
      <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
    </div> -->
    <!-- <div class="container border" v-on:click="onWechatNew();logEvent('Contactus_page_bibgold')" v-on:longpress="copy('bibgoldnews')">
      <div class="content">
        <text class="title">微信订阅号 </text>
        <text class="detail"> bibfxnews</text>
      </div>
      <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
    </div> -->
    <div class="line"></div>
    <div class="container border" v-on:click="onEmil();logEvent('Contactus_page_email')" v-on:longpress="copy('cs@bibfx.com')">
      <div class="content">
        <text class="title">客服邮箱 </text>
        <text class="detail"> cs@bibfx.com</text>
      </div>
      <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
    </div>
    <!-- <div class="container border" v-on:click="onMap();logEvent('Contactus_page_add')">
      <div class="content">
        <text class="title">公司地址 </text>
        <text class="detail"> 打开地图</text>
      </div>
      <image :src="rightItemSrc" resize="contain" class="right-image"></image>
    </div> -->
  </div>
  <wechat-code :url="src" :show="isShowCode" loading-text="长按保存，微信识别二维码" needMask="true" @wxcLoadingMaskClicked="isShowCode=false"></wechat-code>
  <message></message>
  <div v-if="showToast" style="position:absolute;left:0px;top:0px;right:0px;bottom:0px;align-items:center;justify-content:center;">
    <div class="modul">
      <text style="color:#FFFFFF;font-size:28px;line-height:42px;"> 已复制 </text>
    </div>
  </div>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var dom = weex.requireModule('dom')
var navigator = weex.requireModule('navigator')
var storage = require('../include/storage.js');
const app = weex.requireModule('app');
var firebase = weex.requireModule('firebase');
const clipboard = weex.requireModule('clipboard');

module.exports = {
  components: {
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'dialog': require('../components/wxc-dialog.vue'),
    'wechat-code': require('../components/wechat-code.vue'),
    'message': require('../components/message.vue'),
  },
  data: function() {
    return {
      assets: assetsUrl,
      rightItemSrc: assetsUrl + 'arrow.png',
      wechatSerSrc: assetsUrl + 'bibgoldserver.jpg',
      wechatNewSrc: assetsUrl + 'bibgoldnews.jpg',
      feedback: "",
      isShowCode: false,
      src: '',
      showToast: false,
    }
  },
  created: function() {
    var that = this;
    storage.getItem('commonUrl',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.feedback = commonUrl.feedback;
      }
    });
  },
  methods: {
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    onLiaoMe: function() {
      this.loadWebView(this.feedback, '客服');
    },
    onCall: function(num) {
      if (app) {
        app.makeCall(num);
      }
    },
    onQQ: function() {
      weex.requireModule('app').openQQ("800821879");
    },
    onWechatSer: function() {
      this.src = this.wechatSerSrc;
      this.isShowCode = !this.isShowCode;
    },
    onWechatNew: function() {
      this.src = this.wechatNewSrc;
      this.isShowCode = !this.isShowCode;
    },
    onEmil: function() {
      weex.requireModule('app').openEmail("cs@bibgold.com");
    },
    onMap: function() {
      // weex.requireModule('app').openMap("22.300773,114.176239");//gcj02
      weex.requireModule('app').openMap("22.303616,114.171258"); //wgs84
    },

    loadWebView: function(url, title = '') {
      if (url && url.length > 0) {
        var data = {
          title: title,
          url: url,
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "false"
        }, event => {})
      }
    },
    back: function() {
      navigator.pop({
        animated: "true"
      }, res => {});
    },
    copy: function(string) {
      clipboard.setString(string);
      this.showTips();
    },
    showTips: function() {
      if (false == this.showToast) {
        this.showToast = true;
        setTimeout(() => {
          this.showToast = false;
        }, 1500)
      }
    },
  },
}
</script>

<style scoped>
.navibar {
  height: 88px;
  background-color: #2e74e9;
  align-items: center;
  justify-content: center;
}

.navbar-title {
  font-size: 36px;
  color: white;
  line-height: 54px;
  text-align: center;
}

.navbar-button {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 120px;
  padding-left: 30px;
  justify-content: center;
}

.my-scroller {
  margin-top: 0px;
  background-color: white;
  width: 750px;
}

.border {
  border-bottom-width: 1px;
  border-bottom-style: solid;
  border-bottom-color: #E1E1E1;
}

.container {
  flex-direction: row;
  height: 98px;
  margin-left: 30px;
  margin-right: 24px;
  align-items: center;
}

.content {
  flex: 1;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  overflow: hidden;
}

.title {
  flex: 1;
  text-align: left;
  text-overflow: ellipsis;
  font-size: 32px;
  line-height: 48px;
  color: #454950;
  lines: 1;
}

.detail {
  flex: 1;
  text-align: right;
  text-overflow: ellipsis;
  font-size: 32px;
  line-height: 48px;
  color: #9ba1ab;
  lines: 1;
}

.right-image {
  width: 18px;
  height: 30px;
  margin-left: 24px;
}

.line {
  width: 750px;
  height: 20px;
  background-color: #F1F1F1;
}

.modul {
  height: 74px;
  border-radius: 37px;
  align-items: center;
  justify-content: center;
  padding-left: 60px;
  padding-right: 60px;
  background-color: rgba(0, 0, 0, 0.7);
}
</style>
