<template>
<div v-if="isShowScore" class="container-bg" @click="maskClick">
  <div class="container">
    <div class="title">
      <text class="title-size"> {{title}} </text>
    </div>
    <div class="image">
      <image class="image-size" :src="assets+'score_star.png'"></image>
      <image class="image-size" :src="assets+'score_star.png'"></image>
      <image class="image-size" :src="assets+'score_star.png'"></image>
      <image class="image-size" :src="assets+'score_star.png'"></image>
      <image class="image-size" :src="assets+'score_star.png'"></image>
    </div>
    <div class="content">
      <text class="content-size">{{content}}</text>
    </div>
    <div class="subContent">
      <text class="subContent-size">{{subContent}}</text>
    </div>
    <div class="footer">
      <div class="footer-btn border" @click="leftBtnClick">
        <text class="btn-text"> {{leftBtnTitle}} </text>
      </div>
      <div class="footer-btn" @click="rightBtnClick">
        <text class="btn-text"> {{rightBtnTitle}} </text>
      </div>
    </div>
    <div class="bottom-btn" @click="bottomBtnClick">
      <text class="bottom-btn-text"> {{bottomBtnTitle}} </text>
    </div>
  </div>
</div>
</template>

<script >
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var storage = require('../include/storage.js');
var navigator = weex.requireModule('navigator');
var http = require('../include/http.js');
var app = weex.requireModule('app');
var utils = require('../include/utils.js');
var firebase = weex.requireModule('firebase');

module.exports = {
  components: {
    wxcOverlay: require('../components/wxc-overlay.vue'),
  },
  computed: {
    platform: function() {
      const {
        platform
      } = weex.config.env;
      return platform.toLowerCase() || 'common';
    },
  },
  props: {
    isShowScore: { default: false },//是否显示评分弹窗
  },
  data: function() {
    return {
      assets: assetsUrl,
      serviceUrl:'',//客服url
      title:'评分鼓励',
      content:'直播黄金 最懂你心',
      subContent:'用1分钟鼓励每天700分钟的精心直播，好吗？',
      leftBtnTitle:'忙，下次再说',
      rightBtnTitle:'不，有话要说',
      bottomBtnTitle:'赞，给个好评',
    }
  },
  created: function() {
    let that = this;
    storage.getItem('commonUrl',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.serviceUrl = commonUrl.feedback;
      }
    });
  },
  methods: {
    logEvent:function(name){
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    loadWebView: function(url, title = '') {
      if (url && url.length > 0) {
        var data = {
          title: title,
          url: url,
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "false"
        }, event => {})
      }
    },
    leftBtnClick: function() {
      // this.logEvent('Version_hints_close');
      this.isShowScore = false;
      this.$emit('leftBtn');
      storage.getItem('userScoreStar',function(value) {
        if ('' == value || value == undefined || value.length <= 0) {
          return
        }
        var userScoreStar = JSON.parse(value);
        if (userScoreStar) {
          userScoreStar.isNeedShowScore = false;
        }
        storage.setItem('userScoreStar', JSON.stringify(userScoreStar));
        console.log('输出left的userScoreStar的信息：'+JSON.stringify(userScoreStar));
      });
    },
    rightBtnClick: function() {
      // this.logEvent('Version_hints_postponed');
      this.isShowScore = false;
      this.$emit('rightBtn');
      storage.getItem('userScoreStar',function(value) {
        if ('' == value || value == undefined || value.length <= 0) {
          return
        }
        var userScoreStar = JSON.parse(value);
        if (userScoreStar) {
          userScoreStar.isScoreStar = true;
          userScoreStar.isNeedShowScore = false;
        }
        storage.setItem('userScoreStar', JSON.stringify(userScoreStar));
        console.log('输出right的userScoreStar的信息：'+JSON.stringify(userScoreStar));
      });
      this.loadWebView(this.serviceUrl, '客服');
    },
    bottomBtnClick: function() {
      // this.logEvent('Version_hints_update');
      this.isShowScore = false;
      this.$emit('bottomBtn');
      storage.getItem('userScoreStar',function(value) {
        if ('' == value || value == undefined || value.length <= 0) {
          return
        }
        var userScoreStar = JSON.parse(value);
        if (userScoreStar) {
          userScoreStar.isScoreStar = true;
          userScoreStar.isNeedShowScore = false;
        }
        storage.setItem('userScoreStar', JSON.stringify(userScoreStar));
        console.log('输出bottom的userScoreStar的信息：'+JSON.stringify(userScoreStar));
      });
      if (weex.supports('@module/app.openRatingReview')) {
        app.openRatingReview();
      }
    },
    maskClick:function(){

    }
  }
}
</script>

<style scoped>
.container-bg {
  position: fixed;
  left: 0px;
  top: 0px;
  right: 0px;
  bottom: 0px;
  /*兼容H5异常*/
  z-index: 99999;
  justify-content: center;
  align-items: center;
  background-color: rgba(0, 0, 0, 0.6);
}

.container {
  width: 572px;
  height: 676px;
  background-color: #FFFFFF;
  border-radius: 20px;
}

.title {
    margin-top: 60px;
    margin-bottom: 16px;
    justify-content: center;
    align-items: center;
}

.title-size {
    font-size: 40px;
    line-height: 66px;
    color: #333333;
}

.image{
  flex-direction: row;
  margin-left: 124px;
  height: 48px;
  align-items: center;
}
.image-size{
  margin-right: 20px;
  width: 48px;
  height: 48px;
  align-items: center;
  overflow: hidden;
}
.content{
  margin-top: 82px;
  height: 60px;
  justify-content: center;
  align-items: center;
}
.content-size {
    font-size: 40px;
    line-height: 60px;
    font-weight: bold;
    color: #333333;
}

.subContent{
  margin-top: 36px;
  height: 44px;
  justify-content: center;
  align-items: center;
}
.subContent-size {
    font-size: 24px;
    line-height: 44px;
    color: #999999;
}
.footer {
  margin-top: 76px;
  height: 88px;
  flex-direction: row;
  align-items: center;
  border-top-color: #e3e1e2;
  border-top-width: 1px;
  border-bottom-color: #e3e1e2;
  border-bottom-width: 1px;

}

.footer-btn {
  flex-direction: row;
  align-items: center;
  justify-content: center;
  flex: 1;
  height: 88px;
}

.border {
  border-right-color: #e3e1e2;
  border-right-width: 1px;
}
.btn-text {
  font-size: 32px;
  text-align: center;
  color: #666666;
}
.bottom-btn{
  width: 572;
  flex: 1;
  justify-content: center;
  align-items: center;
}

.bottom-btn-text{
  font-size: 32px;
  text-align: center;
  color: #0068e8;
  font-weight: bold;
}

.close {
  position: absolute;
  top: 0px;
  right: 0px;
  width: 100px;
  height: 80px;
  flex-direction: row;
  justify-content: flex-end;
}

.close-icon {
  width: 38px;
  height: 38px;
  margin-top: 14px;
  margin-right: 14px;
}
</style>
