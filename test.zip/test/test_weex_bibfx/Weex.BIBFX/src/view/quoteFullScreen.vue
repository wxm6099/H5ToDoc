<template>
<div ref="quoteFull" :class="[isIphoneX == true ? 'quotefull-all-iphoneX' : 'quotefull-all']" @viewappear="viewappear">

  <div class="quotefull-top-ios" v-if="isIOS">
    <div class="quotefull-top-left-text-bg-ios">
      <text class="quotefull-top-left-text-name-ios">{{nameChannel}}</text>
    </div>
    <div class="quotefull-top-left-text-number-bg-ios">
      <text :class="[nowsell-open>=0 ? 'quotefull-top-left-text-number-in-ios' : 'quotefull-top-left-text-number-out-ios'] ">{{nowsell}}</text>
    </div>
    <div class="quotefull-top-change-text-bg-ios">
      <div class="quotefull-top_change-div-bg-ios">
        <text :class="[nowsell-open>=0 ? 'quotefull-top-change-text-in-ios' : 'quotefull-top-change-text-out-ios'] ">{{change}}</text>
      </div>
      <div class="quotefull-top_change-div-bg-ios">
        <text :class="[nowsell-open>=0 ? 'quotefull-top-change-text-in-ios' : 'quotefull-top-change-text-out-ios'] ">{{Prochange}}%</text>
      </div>
    </div>
    <div class="quotefull-top_quote-ios">
      <div class="quotefull-top_quote-text-up-bg-ios">
        <div class="quotefull-top_quote-text-up-div-bg-ios">
          <text class="quotefull-top_quote-text-up-ios">最高</text>
        </div>
        <div class="quotefull-top_quote-text-number-div-ios">
          <text class="quotefull-top_quote-text-number-ios">{{high}}</text>
        </div>
      </div>
      <div class="quotefull-top_quote-text-up-bg-ios">
        <div class="quotefull-top_quote-text-up-div-bg-ios">
          <text class="quotefull-top_quote-text-up-ios">今开</text>
        </div>
        <div class="quotefull-top_quote-text-number-div-ios">
          <text class="quotefull-top_quote-text-number-ios">{{open}}</text>
        </div>
      </div>
      <div class="quotefull-top_quote-text-up-bg-ios">
        <div class="quotefull-top_quote-text-up-div-bg-ios">
          <text class="quotefull-top_quote-text-up-ios">最低</text>
        </div>
        <div class="quotefull-top_quote-text-number-div-ios">
          <text class="quotefull-top_quote-text-number-ios">{{low}}</text>
        </div>
      </div>
      <div class="quotefull-top_quote-text-up-bg-ios">
        <div class="quotefull-top_quote-text-up-div-bg-ios">
          <text class="quotefull-top_quote-text-up-ios">昨收</text>
        </div>
        <div class="quotefull-top_quote-text-number-div-ios">
          <text class="quotefull-top_quote-text-number-ios">{{Yclose}}</text>
        </div>
      </div>
    </div>
  </div>

  <div class="quotefull-top" v-else>
    <div class="quotefull-top-left-text-bg">
      <text class="quotefull-top-left-text-name">{{nameChannel}}</text>
    </div>
    <div class="quotefull-top-left-text-number-bg">
      <text :class="[nowsell-open>=0 ? 'quotefull-top-left-text-number-in' : 'quotefull-top-left-text-number-out'] ">{{nowsell}}</text>
    </div>
    <div class="quotefull-top-change-text-bg">
      <div class="quotefull-top_change-div-bg">
        <text :class="[nowsell-open>=0 ? 'quotefull-top-change-text-in' : 'quotefull-top-change-text-out'] ">{{change}}</text>
      </div>
      <div class="quotefull-top_change-div-bg">
        <text :class="[nowsell-open>=0 ? 'quotefull-top-change-text-in' : 'quotefull-top-change-text-out'] ">{{Prochange}}%</text>
      </div>
    </div>
    <div class="quotefull-top_quote">
      <div class="quotefull-top_quote-text-up-bg">
        <div class="quotefull-top_quote-text-up-div-bg">
          <text class="quotefull-top_quote-text-up">最高</text>
        </div>
        <div class="quotefull-top_quote-text-number-div">
          <text class="quotefull-top_quote-text-number">{{high}}</text>
        </div>
      </div>
      <div class="quotefull-top_quote-text-up-bg">
        <div class="quotefull-top_quote-text-up-div-bg">
          <text class="quotefull-top_quote-text-up">今开</text>
        </div>
        <div class="quotefull-top_quote-text-number-div">
          <text class="quotefull-top_quote-text-number">{{open}}</text>
        </div>
      </div>
      <div class="quotefull-top_quote-text-up-bg">
        <div class="quotefull-top_quote-text-up-div-bg">
          <text class="quotefull-top_quote-text-up">最低</text>
        </div>
        <div class="quotefull-top_quote-text-number-div">
          <text class="quotefull-top_quote-text-number">{{low}}</text>
        </div>
      </div>
      <div class="quotefull-top_quote-text-up-bg">
        <div class="quotefull-top_quote-text-up-div-bg">
          <text class="quotefull-top_quote-text-up">昨收</text>
        </div>
        <div class="quotefull-top_quote-text-number-div">
          <text class="quotefull-top_quote-text-number">{{Yclose}}</text>
        </div>
      </div>
    </div>
    <!--<div class="quotefull-top-right" v-on:click="onclickrightrefresh">-->
    <!--<image class="quotefull-top-right-image" :src="rightItemSrc"></image>-->
    <!--</div>-->
  </div>

  <!--分隔线-->
  <div style="height: 1px;left: 0px;right: 0px;background-color: #d4d4d4"></div>

  <!--<fullChart ref="fullChart" style="flex:1; background-color: white" :quoteData="arrData" :typeChannelIndex="typeChannelIndex" @ScrollKlineChart="ScrollKlineChart"></fullChart>-->
  <fullChart ref="fullChart" style="flex:1; background-color: white" CandleNumber="80" :quoteData="arrData" :typeChannelIndex="typeChannelIndex" :socketLine="nowsell" ></fullChart>

  <div v-if="isIOS" :class="[isIphoneX == true ? 'quotefull-bottom-ios-x' : 'quotefull-bottom-ios']">
    <scroller ref="typeScroller" class="quotefull-type-scroller-ios" show-scrollbar="false" scrollDirection="horizontal">
      <div ref="typeChannel" class="quotefull-type-item-ios" v-for="item in string.quotetypechannel" @click="typechannelClick(item.id)">
        <text :class="[item.id == typeChannelIndex?'quotefull-type-selected-ios':'quotefull-type-normal-ios']">{{item.name}}</text>
        <div v-if="item.id == typeChannelIndex" style="position: absolute;  bottom: 0px;left:36px;right: 36px;height: 4px; background-color:#2e74e9;"></div>
      </div>
    </scroller>
    <div v-if="true == showMt4" class="quotefull-bottom-text-icon-left-ios" v-on:click="onclickbottomMT4">
      <image class="quotefull-bottom-image-ios" :src="bottomLeftSrc"></image>
    </div>
    <div v-if="true == showMt4" class="quotefull-bottom-text-icon-center-ios" v-on:click="onclickbottomMT4">
      <text class="quotefull-bottom-text-ios">MT5交易</text>
    </div>
    <div class="quotefull-bottom-text-icon-right-ios" v-on:click="onclickrightbottomback">
      <image class="quotefull-bottom-image-full-ios" :src="bottomRightSrc"></image>
    </div>
  </div>
  <div class="quotefull-bottom" v-else>
    <scroller ref="typeScroller" class="quotefull-type-scroller" show-scrollbar="false" scrollDirection="horizontal">
      <div ref="typeChannel" class="quotefull-type-item" v-for="item in string.quotetypechannel" @click="typechannelClick(item.id)">
        <text :class="[item.id == typeChannelIndex?'quotefull-type-selected':'quotefull-type-normal']">{{item.name}}</text>
        <div v-if="item.id == typeChannelIndex" style="position: absolute;  bottom: 0px;left:18px;right: 18px;height: 4px; background-color: #2e74e9;"></div>
      </div>
    </scroller>
    <div class="quotefull-bottom-text-icon-left" v-on:click="onclickbottomMT4">
      <image class="quotefull-bottom-image" :src="bottomLeftSrc"></image>
      <!--<text class="quotefull-bottom-text">MT4交易</text>-->
    </div>
    <div class="quotefull-bottom-text-icon-center" v-on:click="onclickbottomMT4">
      <!--<image class="quotefull-bottom-image" :src="bottomLeftSrc"></image>-->
      <text class="quotefull-bottom-text">MT5交易</text>
    </div>
    <div class="quotefull-bottom-text-icon-right" v-on:click="onclickrightbottomback">
      <image class="quotefull-bottom-image-full" :src="bottomRightSrc"></image>
    </div>
  </div>
</div>
</template>

<script>
const animation = weex.requireModule('animation')
const modal = weex.requireModule('modal')

export default {
  name: "quoteFullScreen"
}

var storage = require('../include/storage.js');
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navi = weex.requireModule('navigator');
var http = require('../include/http.js');
var utils = require('../include/utils.js');
var url = require('../include/url.js');
var app = weex.requireModule('app');
var dom = weex.requireModule('dom');
var firebase = weex.requireModule('firebase');
const localBundleVersion = require('../include/base-url.js').bundleVersion;

module.exports = {
  components: {
    // 'statusBar': require('../components/statusbar.vue'),
  },
  data: function() {
    return {
      string: require('../include/string.js'),
      assets: assetsUrl,
      kline: assetsUrl + 'kline.html',
      rightItemSrc: assetsUrl + 'quote_full_refresh.png',
      bottomLeftSrc: assetsUrl + 'quote_MT4.png',
      bottomRightSrc: assetsUrl + 'quote_close_full_screen.png',

      arrData: [], //k线图的数据源
      timeNumber: 1, //数据请求的时间间隔的次数

      nowbuy: 0.0000, //当时买入价
      nowsell: 0.0000, //最新报价(当时卖价)
      change: '+' + 0.00, //涨跌
      Prochange: '+' + 0.00, //涨跌幅
      high: 0.0000, //最高报价
      low: 0.0000, //最低报价
      open: 0.0000, //开盘价
      Yclose: 0.0000, //昨天收盘价
      typeChannelIndex: -1, //默认选中k线类型编号
      codeChannel: 'XAUUSD',
      typeChannel: 'H1P', //默认选中的k线类型名称代码
      nameChannel: '伦敦金', //代号名称
      indexName: 'MACD', //默认选中指标
      utc: 0, //本地时区
      startTime: new Date().getTime(), //k线数据开始时间点
      endtTime: new Date().getTime(), //k线数据结束时间点
      stringStartTime: '', //k线数据开始时间点
      stringEndtTime: '', //k线数据结束时间点
      isIOS: true,
      isIphoneX: false,
      fixed:2,
      loadingData: false, //加载中
      loadingDataError: false, //加载更多数据失败
      videoTime: 500, //广播k线类型的延时时间
      showMt4:false
    }
  },

  mounted: function() {
    // setTimeout(this.typechannelClick.bind(this), 300);
  },

  created: function() {
    var selfThis = this;
    let bundleVersion = storage.getItemSync('bundleVersion');
    if (bundleVersion >= localBundleVersion) {
      this.showMt4 = true;
    }else {
      this.showMt4 = false;
    }
    //行情页传递的数据
    storage.getItem('topproductdata',function(value) {
      // console.log("+——+大家撒还记得发货+——+—— data:" + value);
      var dataP = JSON.parse(value);
      selfThis.fixed = dataP.fixed== 0 ? 2 : dataP.fixed;
      selfThis.nowbuy = parseFloat(dataP.Ask.length == 0 ? selfThis.nowbuy : dataP.Ask).toFixed(selfThis.fixed);
      selfThis.nowsell = parseFloat(dataP.Bid.length == 0 ? selfThis.nowsell : dataP.Bid).toFixed(selfThis.fixed);
      selfThis.open = parseFloat(dataP.Open.length == 0 ? selfThis.open : dataP.Open).toFixed(selfThis.fixed);
      selfThis.Yclose = parseFloat(dataP.YClose.length == 0 ? selfThis.Yclose : dataP.YClose).toFixed(selfThis.fixed);
      selfThis.high = parseFloat(dataP.High.length == 0 ? selfThis.high : dataP.High).toFixed(selfThis.fixed);
      selfThis.low = parseFloat(dataP.Low.length == 0 ? selfThis.low : dataP.Low).toFixed(selfThis.fixed);
      if (!utils.isBlankString(dataP.symbol)) {
        selfThis.codeChannel = dataP.symbol;
      }else if (!utils.isBlankString(dataP.Symbol)) {
        selfThis.codeChannel = dataP.Symbol;
      }else {
        selfThis.codeChannel = '';
      }
      selfThis.nameChannel = dataP.symbolName.length == 0 ? selfThis.nameChannel : dataP.symbolName;
      selfThis.change = selfThis.nowsell - selfThis.open;
      var pro = (selfThis.change / selfThis.nowsell) * 100;
      selfThis.change = selfThis.change >= 0 ? '+' + selfThis.change.toFixed(selfThis.fixed) : selfThis.change.toFixed(selfThis.fixed);

      pro = pro.toFixed(selfThis.fixed);
      // selfThis.Prochange = pro >= 0 ? '+' + pro : pro;
      selfThis.Prochange = selfThis.nowsell - selfThis.open >= 0 ? '+' + pro : pro;
      // selfThis.Prochange = pro;

      //获取网络请求的基址
      storage.getItem('commonUrl',function(value) {
        if ('' == value || value == undefined || value.length <= 0) {
          return
        }
        var commonUrl = JSON.parse(value);
        if (commonUrl) {
          selfThis.cmsApiHost = commonUrl.cmsApi;
          //k线类型的参数(获取storage存储的竖屏传给横屏的k线类型参数)
          storage.getItem("quoteKlineType", function(value) {
            selfThis.typechannelClick(parseInt(value));
          });
        }
      });
    });


    //websocket推送广播数据
    const wsData = new BroadcastChannel('bibfx');
    wsData.onmessage = function(event) {
      var dataPP = JSON.parse(event.data);
      // console.log("+——+大家撒还+——+—— data:" + event.data);
      if (selfThis.codeChannel.toString() == dataPP.Symbol.toString()) {
        selfThis.nowbuy = parseFloat(dataPP.Ask.length == 0 ? selfThis.nowbuy : dataPP.Ask).toFixed(selfThis.fixed);
        selfThis.nowsell = parseFloat(dataPP.Bid.length == 0 ? selfThis.nowsell : dataPP.Bid).toFixed(selfThis.fixed);
        selfThis.open = parseFloat(dataPP.Open.length == 0 ? selfThis.open : dataPP.Open).toFixed(selfThis.fixed);
        selfThis.high = parseFloat(dataPP.High.length == 0 ? selfThis.high : dataPP.High).toFixed(selfThis.fixed);
        selfThis.low = parseFloat(dataPP.Low.length == 0 ? selfThis.low : dataPP.Low).toFixed(selfThis.fixed);
        selfThis.Yclose = parseFloat(dataPP.YClose.length == 0 ? selfThis.Yclose : dataPP.YClose).toFixed(selfThis.fixed);
        selfThis.change = selfThis.nowsell - selfThis.open;
        var pro = 100 * (selfThis.change / selfThis.nowsell);
        pro = pro.toFixed(selfThis.fixed);
        selfThis.change = selfThis.change >= 0 ? '+' + selfThis.change.toFixed(selfThis.fixed) : selfThis.change.toFixed(selfThis.fixed);
        selfThis.Prochange = selfThis.nowsell - selfThis.open >= 0 ? '+' + pro : pro;
      }
    }
    selfThis.nowsell = selfThis.nowsell.toFixed(4);
    selfThis.high = selfThis.high.toFixed(4);
    selfThis.low = selfThis.low.toFixed(4);
    selfThis.open = selfThis.open.toFixed(4);
    selfThis.Yclose = selfThis.Yclose.toFixed(4);

    weex.requireModule('app').showStatusBar(false);
    // weex.requireModule('quoteEvent').showMessage('这次我是第二个我是新手');
    selfThis.isIOS = utils.iOS();
    selfThis.isIphoneX = utils.iphonex();
    // console.log('输出是否是x'+selfThis.isIphoneX);

    var globalEvent = weex.requireModule('globalEvent');
    globalEvent.addEventListener("ScrollKlineChart", function(e) {
      selfThis.ScrollKlineChart(e);
    });
  },

  methods: {
    viewappear: function() {
      var selfThis = this;
      // selfThis.$refs.fullChart.setFullScreen('k线全屏的viewappear方法');
      if (utils.isAndroid()) {
        selfThis.$refs.fullChart.rotationLive();
      }
      weex.requireModule('app').showStatusBar(false);
    },
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    getTheKLineData: function(value, timeNumber, startTimeStamp) {
      var selfThis = this;
      if (value) { //首次进入  开始时间即时当前时间
        selfThis.starttime = startTimeStamp;
        selfThis.endtime = selfThis.starttime;
        switch (selfThis.typeChannelIndex) {
          case 0:
            //小时 (距离starttime推前6天  24*6=144  个点)
            selfThis.endtime = selfThis.starttime - 6 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          case 1:
            //日k(距离starttime推前150天  150  个点)
            selfThis.endtime = selfThis.starttime - 150 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          case 2:
            //周k(距离starttime推前3年  52*3=156  个点)
            selfThis.endtime = selfThis.starttime - 3 * 365 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          case 3:
            //月k(距离starttime推前10年  12*10=120  个点)
            selfThis.endtime = selfThis.starttime - 10 * 365 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          case 4:
            //1分(距离starttime推前2小时  2*60=120  个点)
            selfThis.endtime = selfThis.starttime - 1 * 2 * 60 * 60 * 1000 * timeNumber;
            break;
          case 5:
            //5分(距离starttime推前0.5天  0.5*24*60/5=144  个点)
            selfThis.endtime = selfThis.starttime - 0.5 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          case 6:
            //15分(距离starttime推前1.5天  1.5*24*60/15=144  个点)
            selfThis.endtime = selfThis.starttime - 1.5 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          case 7:
            //30分(距离starttime推前3天  3*24*60/30=144  个点)
            selfThis.endtime = selfThis.starttime - 3 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          case 8:
            //4小时(距离starttime推前25天  25*24/4=150  个点)
            selfThis.endtime = selfThis.starttime - 25 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          default:
            //case以外的情况
        }

      } else { //非首次进入  开始时间为时当前时间减去时间间隔（小时的k线 要多减去一小时）
        if (!selfThis.loadingDataError) {
          switch (selfThis.typeChannelIndex) {
            case 0:
              //小时 (距离starttime推前6天  24*6=144  个点)
              // selfThis.starttime = selfThis.endtime - 60 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 60 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 6 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            case 1:
              //日k(距离starttime推前150天  150*1=150  个点)
              // selfThis.starttime = selfThis.endtime - 24 * 60 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 24 * 60 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 150 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            case 2:
              //周k(距离starttime推前3年  52*3=156  个点)
              // selfThis.starttime = selfThis.endtime - 7 * 24 * 60 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 7 * 24 * 60 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 3 * 365 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            case 3:
              //月k(距离starttime推前10年  12*10  个点)
              // selfThis.starttime = selfThis.endtime - 30 * 24 * 60 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 30 * 24 * 60 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 10 * 365 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            case 4:
              //1分(距离starttime推前2小时  2*60   120个点)
              // selfThis.starttime = selfThis.endtime - 5 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 1 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 1 * 2 * 60 * 60 * 1000 * timeNumber;
              break;
            case 5:
              //5分(距离starttime推前0.5天  0.5*24*60/5  个点)
              // selfThis.starttime = selfThis.endtime - 5 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 5 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 0.5 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            case 6:
              //15分(距离starttime推前1.5天  1.5*24*60/15=144  个点)
              // selfThis.starttime = selfThis.endtime - 15 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 15 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 1.5 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            case 7:
              //30分(距离starttime推前3天  3*24*60/30=144  个点)
              // selfThis.starttime = selfThis.endtime - 30 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 30 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 3 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            case 8:
              //4小时(距离starttime推前25天  25*24/4=150  个点)
              // selfThis.starttime = selfThis.endtime - 4 * 60 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 4 * 60 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 25 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            default:
              //case以外的情况
              break;
          }
        }
      }

      selfThis.stringStartTime = utils.dateFormat(selfThis.starttime, 'yyyy-MM-dd hh:mm:ss');
      selfThis.stringEndTime = utils.dateFormat(selfThis.endtime, 'yyyy-MM-dd hh:mm:ss');
      selfThis.utc = -(new Date().getTimezoneOffset() / 60);
      selfThis.loadingData = true;

      var kurl = selfThis.cmsApiHost + '/Quotes/Line?DateTimeBetween=' + selfThis.stringEndTime + ',' + selfThis.stringStartTime + '&Symbol=' + selfThis.codeChannel + '&UTC=' + selfThis.utc + '&type=' + selfThis.typeChannel + '&isapp=1';
      http.get(encodeURI(kurl), function(response) {
        selfThis.loadingData = false;
        if (response.ok && response.data) {
          selfThis.loadingDataError = false;
          var results = response.data.Results;
          if (results && results.length >= 0) {
            //当数据不足一屏所画蜡烛图个数时 向前延长数据请求时间间隔  但是最多6次(当selfThis.timeNumber=6时，还可以执行一次)
            if (selfThis.timeNumber <= 6) {
              if (results.length > 80) { //其中 80 为横屏下 一屏可以画的蜡烛图的个数
                selfThis.arrData = selfThis.uniteQuoteTimeStamp(results);
              } else {
                //当数据少于80条时  并且是月k（数据只有51条） 不用延长时间间隔
                if (selfThis.typeChannel == 'MNP' && results.length > 0) {
                  selfThis.arrData = selfThis.uniteQuoteTimeStamp(results);
                } else {
                  //当数据少于80条时  延长数据请求的时间间隔+1
                  selfThis.timeNumber = selfThis.timeNumber + 1;
                  if (value) {
                    var stamp = new Date().getTime(); //当前时间转换的时间戳
                    selfThis.getTheKLineData(true, selfThis.timeNumber, stamp);
                  } else {
                    //左滑加载更多历史数据不足时 延长请求时间间隔 传入上一次请求数据的开始时间戳
                    selfThis.getTheKLineData(false, selfThis.timeNumber, selfThis.starttime);
                  }
                }
              }
            } else {
              //如果大于或者等于7次   不管多少条数据都执行返回数据
              if (results.length >= 0) {
                selfThis.arrData = selfThis.uniteQuoteTimeStamp(results);
              }
            }
          }
          if (selfThis.typeChannelIndex!=4){
             clearTimeout(selfThis.timer);
             selfThis.startTimer();
          }
        } else {
          selfThis.loadingDataError = true;
          // console.log('++++++++++++输出response.ok的值' + response.ok + '    输出response.status的值' + response.status);
        }
      })
    },
    startTimer :function(){
      if (this.typeChannelIndex==4){
         return;
      }
      this.loadMoreData();
      this.timer = setTimeout(this.startTimer.bind(this), 300000);
    },
    loadMoreData(){
       var selfThis =this;
       var kurl = selfThis.cmsApiHost + '/Quotes/Line?DateTimeBetween=' + startTime + ',' + endTime + '&Symbol=' + selfThis.codeChannel + '&UTC=' + selfThis.utc + '&type=' + selfThis.typeChannel + '&isapp=1';
       http.get(encodeURI(kurl), function(response) {
          if (response.ok && response.data) {
              var data =  selfThis.uniteQuoteTimeStamp(response.data.Results);
             if (undefined !=  selfThis.$refs.fullChart)
                 selfThis.$refs.fullChart.setloadMoreData(data);
          }
       })
    },
    uniteQuoteTimeStamp: function(quotes) {
      var selfThis = this;
      var arrQuotes = [];
      for (var i = 0; i < quotes.length; i++) {
        var dic_quote = quotes[i];
        dic_quote.UTC = selfThis.utc;
        var time_quote = dic_quote.DateTime; //  /Date(1531760400000-0000)/
        var tamp_quote = time_quote.replace('/Date(', '').replace(')/', '').substring(0, 13);
        dic_quote.timestamp = tamp_quote;
        arrQuotes.push(dic_quote);
      }
      return arrQuotes;
    },

    //全屏下点击MT4按钮
    onclickbottomMT4: function() {
      if (utils.isAndroid()) {
        weex.requireModule('app').openMt4();
      } else {
        if (app.canOpenURL("metatrader5://")) {
          app.openURL("metatrader5://com.app.test");
        } else {
          app.openURL(url.MT4);
        }
      }
    },

    //全屏下底部返回竖屏按钮
    onclickrightbottomback: function() {
      this.logEvent(this.codeChannel + '_page_screen_Exit');
      //storage存储横屏传值给竖屏的k线类型值
      storage.setItem("quoteKlineType", ''+this.typeChannelIndex);
      navi.pop({
        animated: "true"
      }, event => {});
    },

    //切换K线图的类型的方法
    typechannelClick: function(index = 0) {
      var selfThis = this;
      if (selfThis.loadingData) {
        return;
      }
      if (index >= selfThis.string.quotetypechannel.length || index == selfThis.typeChannelIndex) {
        return;
      }
      this.typeChannelIndex = index;
      this.selectedTypeHighlight(); //高亮选中的栏目
      this.typeChannel = this.string.quotetypechannel[index].type;
      this.timeNumber = 1;
      var stamp = new Date().getTime(); //当前时间转换的时间戳
      this.getTheKLineData(true, this.timeNumber, stamp); //请求网络数据
    },
    //高亮选中的栏目
    selectedTypeHighlight: function() {
      var that = this;
      if (undefined == this.$refs.typeChannel) {
        return;
      }
      var el = this.$refs.typeChannel[this.typeChannelIndex];
      if (el == undefined) {
        return;
      }
    },

    //k线左右滑动的代理方法
    ScrollKlineChart: function(e) {
      var selfThis = this;
      if (selfThis.loadingData) {
        return; //正在加载数据时  滑动更新加载数据直接返回
      }
      //k线左右滑动的代理方法
      if (e.isRight) { //右滑加载更多历史k线数据
        selfThis.timeNumber = 1;
        //正常左滑加载更多历史数据时 传入上一次请求数据的结束时间戳
        selfThis.getTheKLineData(false, selfThis.timeNumber, selfThis.endtime);
      } else {
        //左滑刷新最新k线数据
        selfThis.timeNumber = 1;
        var stamp = new Date().getTime(); //当前时间转换的时间戳
        selfThis.getTheKLineData(true, selfThis.timeNumber, stamp);
      }
    },
  },
}
</script>

<style lang="css">
    .wrap {
      overflow: hidden;
    }

    .quotefull-all-iphoneX {
        /*flex: 1;*/
        padding-left: 60px;
        padding-right: 60px;
        background-color: #ffffff;
    }
    .quotefull-all {
        /*flex: 1;*/
        background-color: #ffffff;
    }

    .quotefull-top-ios {
        /*position: absolute;*/
        margin-top: 0px;
        margin-left: 0px;
        margin-right: 0px;
        height: 104px;
        flex-direction: row;
        background-color: #ffffff;
    }

    .quotefull-top {
        /*position: absolute;*/
        margin-top: 20px;
        margin-left: 0px;
        margin-right: 0px;
        height: 90px;
        flex-direction: row;
        background-color: #ffffff;
    }

    .quotefull-top-left-text-bg-ios {
        margin-left: 30px;
        align-items: flex-start;
        justify-content: center;
    }

    .quotefull-top-left-text-bg {
        margin-left: 15px;
        align-items: flex-start;
        justify-content: center;
    }

    .quotefull-top-left-text-name-ios {
        font-size: 40px;
        color: #454950;
    }

    .quotefull-top-left-text-name {
        font-size: 20px;
        color: #454950;
    }

    .quotefull-top-left-text-number-bg-ios {
        margin-left: 12px;
        align-items: flex-start;
        justify-content: center;
    }

    .quotefull-top-left-text-number-bg {
        margin-left: 6px;
        align-items: flex-start;
        justify-content: center;
    }

    .quotefull-top-left-text-number-in-ios {
        font-size: 70px;
        color: #32a80a;
    }

    .quotefull-top-left-text-number-out-ios {
        font-size: 70px;
        color: #eb290f;
    }

    .quotefull-top-left-text-number-in {
        font-size: 28px;
        color: #32a80a;
    }

    .quotefull-top-left-text-number-out {
        font-size: 35px;
        color: #eb290f;
    }

    .quotefull-top-change-text-bg-ios {
        margin-left: 28px;
        align-items: flex-start;
        justify-content: center;
    }

    .quotefull-top-change-text-bg {
        margin-left: 14px;
        align-items: flex-start;
        justify-content: center;
    }
    .quotefull-top_change-div-bg-ios {
        height: 36px;
        justify-content: center;
        align-items: flex-start;
    }
    .quotefull-top_change-div-bg {
        height: 30px;
        justify-content: center;
        align-items: flex-start;
    }
    .quotefull-top-change-text-in-ios {
        font-size: 30px;
        color: #32a80a;
        /*font-weight: bold;*/
    }

    .quotefull-top-change-text-out-ios {
        font-size: 30px;
        color: #eb290f;
        /*font-weight: bold;*/
    }

    .quotefull-top-change-text-in {
        font-size: 15px;
        color: #32a80a;
        /*font-weight: bold;*/
    }

    .quotefull-top-change-text-out {
        font-size: 15px;
        color: #eb290f;
        /*font-weight: bold;*/
    }

    .quotefull-top_quote-ios {
        position: absolute;
        right: 30px;
        height: 104px;
        flex-direction: row;
        align-items: center;
        justify-content: center;

    }

    .quotefull-top_quote {
        position: absolute;
        right: 15px;
        height: 90px;
        flex-direction: row;
        align-items: center;
        justify-content: center;
    }

    .quotefull-top_quote-text-up-bg-ios {
        width: 160px;
        align-items: flex-start;
        justify-content: center;
    }
    .quotefull-top_quote-text-up-bg {
        width: 150px;
        align-items: flex-start;
        justify-content: center;
    }

    .quotefull-top_quote-text-up-div-bg-ios {
        width: 50px;
        height: 26px;
        background-color: #f4f4f4;
        border-radius: 5px;
        justify-content: center;
        align-items: center;
    }
    .quotefull-top_quote-text-up-div-bg {
        width: 60px;
        height: 28px;
        background-color: #f4f4f4;
        border-radius: 2.5px;
        justify-content: center;
        align-items: center;
    }

    .quotefull-top_quote-text-up-ios {
        font-size: 20px;
        line-height: 24px;
        color: #8b9099;
        text-align: center;
    }

    .quotefull-top_quote-text-up {
        font-size: 10px;
        line-height: 12px;
        color: #8b9099;
        text-align: center;
    }

    .quotefull-top_quote-text-number-div-ios {
        width: 160px;
        height: 34px;
        justify-content: center;
        align-items: flex-start;
    }
    .quotefull-top_quote-text-number-div {
        width: 120px;
        height: 28px;
        justify-content: center;
        align-items: flex-start;
    }

    .quotefull-top_quote-text-number-ios {
        font-size: 27px;
        color: #454950;
        text-align: left;
    }

    .quotefull-top_quote-text-number {
        font-size: 13px;
        color: #454950;
        text-align: left;
    }

    .quotefull-bottom-ios-x {
        position: relative;
        left: 0px;
        right: 0px;
        bottom: 0px;
        height: 104px;
        padding-bottom: 34px;

        flex-direction: row;
        justify-content: flex-end;
        background-color: #f5f5f5;
    }

    .quotefull-bottom-ios {
        position: relative;
        left: 0px;
        right: 0px;
        bottom: 0px;
        height: 70px;
        flex-direction: row;
        justify-content: flex-end;
        background-color: #f5f5f5;
    }
    .quotefull-bottom {
        position: relative;
        left: 0px;
        right: 0px;
        bottom: 0px;
        height: 60px;
        flex-direction: row;
        justify-content: flex-end;
        background-color: #f5f5f5;
    }

    .quotefull-type-scroller-ios {
        flex: 1;
        height: 70px;
        margin-right: 30px;
        flex-direction: row;
        overflow: hidden;
    }
    .quotefull-type-scroller {
        flex: 1;
        height: 60px;
        margin-right: 15px;
        flex-direction: row;
        overflow: hidden;
    }
    .quotefull-type-item-ios {
        width: 114px;
        justify-content: center;
        align-items: center;
        overflow: hidden;
    }
    .quotefull-type-item {
        width: 100px;
        justify-content: center;
        align-items: center;
        overflow: hidden;
    }
    .quotefull-type-normal-ios {
        font-size: 28px;
        color: #454950;
    }

    .quotefull-type-selected-ios {
        font-size: 28px;
        /*color: #e9302e;*/
        color: #2e74e9;
    }
    .quotefull-type-normal {
        font-size: 14px;
        color: #454950;
    }

    .quotefull-type-selected {
        font-size: 14px;
        /*color: #e9302e;*/
        color: #2e74e9;
    }
    .quotefull-bottom-text-icon-left-ios {
        padding-right: 4px;
        height: 70px;
        align-items: center;
        justify-content: center;
        overflow: hidden;
    }
    .quotefull-bottom-text-icon-left {
        padding-right: 2px;
        height: 60px;
        align-items: center;
        justify-content: center;
        overflow: hidden;
    }
    .quotefull-bottom-image-ios {
        width: 26px;
        height: 30px;
    }
    .quotefull-bottom-image {
        width: 26px;
        height: 28px;
    }

    .quotefull-bottom-text-icon-center-ios {
        margin-right: 48px;
        height: 70px;
        justify-content: center;
        align-items: center;
        overflow: hidden;
    }
    .quotefull-bottom-text-icon-center {
        margin-right: 24px;
        height: 60px;
        justify-content: center;
        align-items: center;
        overflow: hidden;
    }
    .quotefull-bottom-text-ios {
        font-size: 28px;
        color: #454950;
    }
    .quotefull-bottom-text {
        font-size: 14px;
        color: #454950;
    }
    .quotefull-bottom-text-icon-right-ios {
        margin-right: 16px;
        width: 66px;
        height: 70px;
        justify-content: center;
        align-items: center;
        overflow: hidden;
    }
    .quotefull-bottom-text-icon-right {
        margin-right: 28px;
        width: 33px;
        height: 60px;
        justify-content: center;
        align-items: center;
        overflow: hidden;
    }
    .quotefull-bottom-image-full-ios {
        width: 38px;
        height: 38px;
    }
    .quotefull-bottom-image-full {
        width: 38px;
        height: 38px;
    }
</style>
