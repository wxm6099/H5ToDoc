<template>
<div class="black">
  <status backgroundColor="black"></status>
  <div class="navbar-scan">
    <text class="navbar-title"> {{title}} </text>
    <div @click="goBack" class="goback">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div>
	<div @click="setFlashMode" class="goflash">
		<image style="width: 20px; height: 36px" resize="contain" :src="assets+(flashMode == 0?'flash_close.png':'flash.png')"></image>
	</div>
  </div>

	<div style="flex:1;align-items:center;justify-content:center;">
		<div style="justify-content:center;align-items:center;width:750px;" :style="{height: ipad?'500px':'648px'}">
			<camera ref="camera" orientation="horizontal" :class="[ipad?'camera-horizontal-ipad':'camera-horizontal']"></camera>
			<image v-if="isIOS" :class="[transforms]" resize="cover" :src="border"></image>
			<image v-if="!isIOS&& !isShooted" class="transform" resize="cover" :src="borderdefault"></image>
		</div>
		<text class="tips-text">{{tips}}</text>
	</div>
	<div v-if="!isShooted">
		<div class="button" @click="shooting">
			<text class="font28 text">拍摄</text>
		</div>
		<div class="button2" @click="cancel()">
			<text class="font28 text">取消</text>
		</div>
	</div>
	<div v-else>
		<div class="button" @click="confirm()">
			<text class="font28 text2">确定</text>
		</div>
		<div class="button2" @click="retakePicture()">
			<text class="font28 text2">重拍</text>
		</div>
	</div>

	<div v-if="alertShow" class="alert-container">
		<div class="alert-view">
			<div class="alert-title">
				<text v-if="scanResult == 1" class="font32" style="color: #454950;">识别结果</text>
				<text v-if="scanResult == 0" class="font32" style="color: #454950;">识别失败</text>
			</div>
			<div class="alert-content">
				<text class="font28" v-for="item in contentArr" style="color: #454950;;margin-bottom: 5px;" :style="{'text-align': ( scanResult == 0?'center':'')}">{{item}}</text>
			</div>
			<div class="alert-action">
				<template v-if="scanResult == 1">
					<div style="border-right-color: #e1e1e1;border-right-width: 1px; border-right-style: solid;" class="alert-button" @click="scan()">
						<text class="font28" style="color: #9ba1ab;">重新扫描</text>
					</div>
					<div class="alert-button" @click="sure()">
						<text class="font28" style="color: #e9302e;">确定</text>
					</div>
				</template>
				<template v-if="scanResult == 0">
					<div class="alert-button" @click="scan()">
					<text class="font28" style="color: #e9302e;">重新扫描</text>
					</div>
				</template>

			</div>
		</div>

	</div>

	<wxc-loading :show="loading" loading-text="识别中" needMask="false"></wxc-loading>

</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var storage = require('../include/storage.js');
const app = weex.requireModule('app');
var utils = require('../include/utils.js');
const OCR = weex.requireModule('OCRModule');
var http = require('../include/http.js');

const FlashMode = {OFF:0,ON:1,AUTO:2};

module.exports = {
  components: {
    'status': require('../components/statusbar.vue'),
		"wxc-loading": require('../components/wxc-loading.vue'),
  },
	computed:{
		transforms:function(){
			if (this.ipad) {
				return this.isTransform == true ? 'transform-s-ipad':'transform-ipad'
			}else {
				return this.isTransform == true ? 'transform-s':'transform'
			}
		}
	},
  data: function() {
    return {
			cmsApi:'',
      isShooted:false,//是否已拍摄过
      title: "扫描银行",
      tips:"请将银行卡放到框内，并调整好光线",
      index:0,
      assets: assetsUrl,
      borderdefault:assetsUrl +'scanner/scanner.png',//扫描框默认图
      border:assetsUrl +'scanner/scanner.png',
      pictureFile:'',
			isTransform:false,
			isIOS:utils.iOS(),
			ipad:utils.ipad(),

			alertShow: false,
			contentArr:['请重新调整摄像头,\n并将银行卡设置在光线充足的地方重新扫描'],
			scanType : 0,   //0 身份证  //1 银行卡
			scanResult: 0,  // 1 扫描成功  // 0 扫描失败

			scanResultData:{
				name:'',
				sex:'',
				IDNumber:'',

				bankNumber:'',
				bankName: ''
			},

			userToken: '',
			loading: false,

			flashMode: 0,//闪光灯模式 0：关闭 1：打半： 2：自动
    }
  },
  created: function() {
    let that = this;
		storage.getItem('commonUrl', function (value) {
			if ('' == value || value == undefined || value.length <= 0) {
				return;
			}
			var commonUrl = JSON.parse(value);
			if (commonUrl) {
				that.cmsApi = commonUrl.cmsApi;
			}
		});

    storage.getItem('recognize', function(value) {
      if (value && value.length>0) {
        let data = JSON.parse(value);
        that.title = data.title;
        that.tips = data.tips;
        that.index = data.index;
				that.scanType = data.scanType;
      }
    });

		storage.getItem('user-logintoken-id', function (value) {
			if (value) {
				var data = JSON.parse(value);
				that.userId = data.userId;
				that.userToken = data.token;
			}
		});
  },
  methods: {
    goBack: function() {
      navigator.pop({
        animated: "true"
      }, event => {

      });
    },
    setFlashMode:function(){
      if (this.$refs.camera) {
        if (this.flashMode != 0) {
          this.flashMode = 0;
          this.$refs.camera.setFlashMode(this.flashMode);
        }else {
          this.flashMode = 1;
          this.$refs.camera.setFlashMode(this.flashMode);
        }
      }
    },

    //拍摄
    shooting:function(){
      var that = this;
      this.$refs.camera.shutterCamera(function(data){
				that.border = data.path;
				that.pictureFile = data.file;

				that.isShooted = true;
				that.isTransform = true;
      });
    },
		//重拍
		retakePicture:function(){
			this.isTransform = false;
			this.isShooted = false;
			this.border = this.borderdefault;
			this.pictureFile = '';

			this.alertShow = false;

			if (!this.isIOS)
				this.$refs.camera.rePreview();
		},
		//确定
		confirm: function() {
    	let that = this;
    	that.loading = true;
			let scanType = that.scanType;
			if (scanType == 0){
				that.OCRForIDCard(that.pictureFile);
			} else {
				that.OCRForBankCard(that.pictureFile)
			}
		},
		//取消
		cancel: function() {
			this.isTransform = false;
			navigator.pop({
				animated: "true"
			}, event => {

			});
		},

		scan:function(){
			this.alertShow = false;
			this.retakePicture();
		},

		sure:function(){
			this.alertShow = false;
			this.isTransform = false;
			this.isShooted = false;
			this.pictureFile = '';

			let dic = this.scanResultData;
			let str = JSON.stringify(dic);
			storage.setItem('recognizeResult', str);

			navigator.pop({
				animated: "true"
			}, event => {

			});
		},


		OCRForBankCard:function(file){
    	let that = this;
			// let url = 'http://192.168.0.184:10610/OCR/BankCard?format=json';
			let url = that.cmsApi + '/OCR/BankCard?format=json';
			let body = {'FileBody': file};
			// let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI1MzY2MWMzMi03MTI0LTRkZGUtYmIwOS00ODY0NWIzNjcyNzAiLCJuYW1lIjoiMjk4MldERU9ZWTQzWkFBSyJ9.F_ArfJuR6tkquQvozmABhm_iOtHg8oJrqh2y1fw15xU';
			let token = that.userToken;
			http.postFormToken2(token ,url, body, function (response) {

				that.loading = false;
				that.alertShow = true;
				if (response && response.data && response.data.Results) {
					let Results = response.data.Results[0];
					let CardNo = Results.CardNo;
					let BankCardName = Results.BankCardName;
					let BankName = Results.BankName;
					let BankNo = Results.BankNo;
					let Type = Results.Type;

					that.scanResultData.bankNumber = CardNo;
					that.scanResultData.bankName = BankName;

					// TO DO 银行卡
					if (BankName && CardNo){
						let number_str = `银行卡卡号: ${CardNo}`;
						let bank_str = `银行名称: ${BankName}`;
						that.scanResult = 1;
						that.contentArr = [bank_str,number_str];
					}else {
						that.scanResult = 0;
						that.contentArr = ['请重新调整摄像头,\n并将银行卡设置在光线充足的地方重新扫描'];
					}
				}else {
					that.scanResult = 0;
					that.contentArr = ['请重新调整摄像头,\n并将银行卡设置在光线充足的地方重新扫描'];
				}

			})
		},


		OCRForIDCard:function(file){
			let that = this;
			// let url = 'http://192.168.0.184:10620/OCR/IDCard?format=json';
			let url = that.cmsApi + '/OCR/IDCard?format=json';
			let body = {'FileBody': file};
			// let token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI1MzY2MWMzMi03MTI0LTRkZGUtYmIwOS00ODY0NWIzNjcyNzAiLCJuYW1lIjoiMjk4MldERU9ZWTQzWkFBSyJ9.F_ArfJuR6tkquQvozmABhm_iOtHg8oJrqh2y1fw15xU';
			let token = this.userToken;
			http.postFormToken2(token ,url, body, function (response) {

				that.loading = false;
				that.alertShow = true;
				if (response && response.data && response.data.Results) {
					let Results = response.data.Results[0];
					let Name = Results.Name;
					let Sex = Results.Sex;
					let Nation = Results.Nation;
					let Address = Results.Address;
					let IdNum = Results.IdNum;
					let Birth = Results.Birth;

					that.scanResultData.name = Name;
					that.scanResultData.sex = Sex;
					that.scanResultData.IDNumber = IdNum;

					if (IdNum){
						that.scanResult = 1;
						let name_str = `姓名: ${Name}`;
						let sex_str = `性别: ${Sex}`;
						let number_str = `身份证号码: ${IdNum}`;
						that.contentArr = [name_str, sex_str, number_str];
					} else {
						that.scanResult = 0;
						that.contentArr = ['请重新调整摄像头,\n并将身份证设置在光线充足的地方重新扫描'];
					}
				}else {
					that.scanResult = 0;
					that.contentArr = ['请重新调整摄像头,\n并将身份证设置在光线充足的地方重新扫描'];
				}

			})

		},

		judge(text, reg){
			// reg = 0 验证数字
				// reg = 1 验证名字
				// reg = 2 验证身份证
				let pattern;
				switch(reg){
					case 0:pattern = /[0-9]+/;
					break;
					case 1:pattern = /^[\u2E80-\u9FFF]+$/;   //以汉字开始,以汉字结束,不能有一个其他字符
					// case 1:pattern = /[\u4e00-\u9fa5]/;
					break;
					case 2:pattern = /(^\d{15}$)|(^\d{18}$)|/;
					// case 2:pattern = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;  // 较准确
					// case 2:pattern = /^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X)$/;  // 最准确
					break;
					default:
					break;
				}
				return pattern.test(text);
		},

		getSexWithIDNumber:function(num){
			let arr = num.split('');
			// let code = parseInt(arr[16]);
			let code = parseInt(arr[arr.length - 2]);
			let sex = code % 2 == 0 ? '女':'男';
			return sex;
		}

  }
}
</script>

<style  src="../style/common.css" scoped>
</style>
<style scoped>
.black{
  background-color: black;
}
.camera-horizontal{
  position:absolute;
  top:0px;
  left:174px;
  width:402px;
  height:648px;
}
/* 相机拍摄框横向iOS需要逆向旋转90度  竖向则不需要 */
.transform-s{
  transform:  'rotate(90deg)';
  transform-origin: center center;
  overflow: hidden;
  width:648px;
  height:404px;
}
.transform{
  transform:  'rotate(0deg)';
  transform-origin: center center;
  width:402px;
  height:648px;
  overflow: hidden;
}

.align {
  margin-left: 25px;
  margin-right: 25px;
}

.bottom{
  position: absolute;
  bottom: 0px;
  left: 0px;
  right: 0px;
}

.button {
  height: 90px;
  justify-content: center;
  align-items: center;
  margin-left: 30px;
  margin-right: 30px;
  margin-bottom: 2px;
  border-radius: 5px;
  background-color: #ffffff;
}
.button2 {
  height: 90px;
  justify-content: center;
  align-items: center;
  margin-left: 30px;
  margin-right: 30px;
  margin-bottom: 30px;
  border-radius: 5px;
  background-color: #ffffff;
}
.tips-text{
  color:white;
  margin-top:50px;
  text-align: center;
  width:622px;
}
.text{
  color: #333333;
}
.text2{
  color: red;
}

.alert-container{
	position:absolute;
	left: 73px;
	top: 471px;
	z-index: 1000;

	align-items:center;
	background-color: #30B700;
}
.alert-view{
	width: 604px;
	height: 392px;

	flex-flow: column nowrap;
	justify-content: space-around;
	background-color: white;
	border-radius: 10px;
}
.alert-title{
	align-items: center;
	justify-content: center;
	flex-direction: column;
	height: 80px;
}
.alert-content{

	/*padding: 36px;*/
	padding-right: 36px;
	padding-left: 36px;
	padding-top: 46px;
	padding-bottom: 44px;


	border-bottom-color: #e1e1e1;
	border-bottom-width: 1px;
	border-bottom-style: solid;
}
.alert-action{
	height: 88px;

	flex-direction: row;
	justify-content: space-around;
	align-content: center;
	align-items: center;

}
.alert-button{
	flex: 2;

	align-items: center;


	border-right-color: #e1e1e1;
	border-right-width: 1px;
	border-right-style: solid;

}

.navbar-scan {
  width: 750px;
  height: 88px;
  background-color: black;
  align-items: center;
  justify-content: center;
}
.goflash {
  position: absolute;
  top: 0px;
  right: 0px;
  bottom: 0px;
  width: 120px;
  justify-content: center;
	align-items: center;
}

</style>
