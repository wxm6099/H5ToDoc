<template>
<div >
  <status backgroundColor="#FFFFFF"></status>
  <navigation :title="title" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="goBack"></navigation>
  <!-- <div class="navbar"> -->
    <!-- <text class="navbar-title">{{title}}</text>
    <div @click="goBack" class="goback">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div> -->
    <!-- <div @click="reload" class="refresh">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div> -->
  <!-- </div> -->
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var dom = weex.requireModule('dom')
var navigator = weex.requireModule('navigator')
var app = weex.requireModule('app')
var storage = require('../include/storage.js');
var url = require('../include/url.js');
var modal = weex.requireModule('modal');

module.exports = {
  components:{
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
  },
  computed:{

  },
  data: function(){
    return {

    }
  },
  created: function() {

  },
  methods:{
    goBack:function(){
      navigator.pop({
        animated: "true",
      });
    },
  },
}
</script>

<style scoped>
.navbar {
  width: 750px;
  height: 88px;
  background-color: #E93030;
  align-items: center;
  justify-content: center;
}

.navbar-title {
  font-size: 38px;
  color: white;
}
.goback {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 120px;
  padding-left: 30px;
  justify-content: center;
}
</style>
