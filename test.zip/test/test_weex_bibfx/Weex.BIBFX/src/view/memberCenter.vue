<template>
<div style="backgroundColor:white;" :style="{'padding-bottom': iphonex?'34px':'0px'}" @viewdisappear="viewDisappear">
  <status backgroundColor="#FFFFFF"></status>
  <navigation :title="title" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="goBack"></navigation>
  <!-- <div class="navbar"> -->
    <!-- <text class="navbar-title"> {{title}} </text>
    <div @click="goBack" class="goback">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div> -->
    <!--<div @click="reload" class="refresh">-->
    <!--<image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>-->
    <!--</div>-->
  <!-- </div> -->
  <div style="flex:1;width:750px;overflow: hidden;">
    <div style="flex:1;width:750px;overflow: hidden;">
      <web v-if="url" ref="webview" :src="url" class="webview" :cookie="cookie" @message="onmessage" @error="error" @pagestart="start" @pagefinish="finish"></web>
      <wxc-loading :show="loading" loading-text="加载中" needMask="true"></wxc-loading>
    </div>
    <div v-if="isLoadError" style="position:absolute;left:0px; top:0px;right:0px; bottom:0px;background-color: white;justify-content: center;align-items: center">
      <loadError @refreshNetWorkError="refreshNetWorkError"></loadError>
    </div>
  </div>
  <message></message>
</div>
</template>

<script>
import {
  ClientID
} from '../include/url.js';
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigators = weex.requireModule('navigator')
var storage = require('../include/storage.js');
var utils = require('../include/utils.js');
var webview = weex.requireModule('webview');
var tripleDes = weex.requireModule('tripleDes');
var http = require('../include/http.js');
const cookieStorage = weex.requireModule('cookieStorage');
var firebase = weex.requireModule('firebase');

module.exports = {
  components: {
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    "wxc-loading": require('../components/wxc-loading.vue'),
    'loadError': require('../components/loadError.vue'),
    'message': require('../components/message.vue'),
  },
  computed: {
    iphonex: function() {
      return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' || weex.config.env.deviceModel === 'iPhone11,2' || weex.config.env.deviceModel === 'iPhone11,4' || weex.config.env.deviceModel === 'iPhone11,6' || weex.config.env.deviceModel === 'iPhone11,8');
    }
  },
  data: function() {
    return {
      assets: assetsUrl,
      height: 0, //屏幕的高度
      url: '',
      title: '',
      loading: true,
      canGoBack: false,
      canGoForward: false,
      cookieName: '',
      logined: false,
      user: {},
      cookie: false,
      autoComplete: true,
      anchor:'',//登录成功锚点
      whereFrom:'',//从哪个页面进入个人中心
      oauth: '',
      isLoadError: false, //网络加载出错
    }
  },
  created: function() {
    var that = this;
    if (weex.supports('@module/app')) {
      weex.requireModule('app').setStatusBarStyle(0);
    }
    storage.getItem('commonUrl', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.cmsApiHost = commonUrl.cmsApi; //接口基址
        that.imageBaseUrl = commonUrl.imageBaseUrl; //图片基址
      }
    });
    storage.getItem('memberCenter', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var memberCenter = JSON.parse(value);
      if (memberCenter) {
        that.oauth = memberCenter.oauth;
      }
      storage.getItem('app-url', function(value) {
        if (value) {
          var data = JSON.parse(value);
          let srcUrl = utils.appendProtocol(data.url);
          that.title = data.title;
          that.anchor = data.anchor;//锚点信息
          if (data && data.from && data.from.length > 0) {
            that.whereFrom = data.from;
          }
          if (data && data.source && data.source.length > 0) {
            that.autoComplete = false;
            that.source = data.source;
            if (data.source != 'mc') {
              that.redirectUrl = srcUrl;
            }
          } else {
            that.autoComplete = true;
          }
          storage.getItem('userInfo', function(info) {
            if (info) {
              that.user = JSON.parse(info);
            }
            if (that.user && that.user.userName && that.user.userPassWord) {
              that.logined = true;
              if (data.source == 'forgot') {
                that.url = srcUrl;
              }else {
                that.autoLogin();
              }
            } else {
              that.logined = false;
              that.url = srcUrl;
            }
          });
        }
      });
    });
    // // 接收网络错误的广播
    // var that = this;
    // const Network = new BroadcastChannel('GloballyRefreshNetwork');
    // Network.onmessage = function(event) {
    //   // var reload_url = that.url;
    //   // that.url = "";
    //   // that.url = reload_url;
    //   that.reload();
    // };
    this.height = (weex.config.env.deviceHeight * 750) / weex.config.env.deviceWidth - 128;
  },
  methods: {
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
      // 接收网络错误的点击事件的回调
    refreshNetWorkError:function(){
          this.reload();
    },
    deleteCookie: function() {
      if (cookieStorage) {
        cookieStorage.deleteCookie('');
      }
    },
    saveCookie: function() {
      // if (cookieStorage && this.cookieName.length > 0) {
      //   cookieStorage.saveCookie(this.cookieName, this.url);
      // }
    },
    viewDisappear: function() {
      // console.log("viewDisappear    ");
      // this.saveCookie();
    },
    onmessage: function(message) {
      var that = this;
      if ('message' == message.type && message.data) {
        var data = JSON.parse(message.data);
        if (data && data.type) {
          if (data.type == 'login' && that.type != data.type) {
            if (undefined != that.redirectUrl) {//用户登录后需要重定向跳转
              setTimeout(() => {
                that.url = that.redirectUrl;
              }, 500);
            }
          } else if (data.type == 'logout') {
            storage.setItem('userInfo', "{}");
            that.logined = false;
            that.pop();
          } else if (data.type == 'anchor' ){
            // var data = data.data;
            // if (data && data.length>0) {
            //   if (that.anchor && that.anchor.length>0) {
            //     that.logEvent(that.anchor+'_'+data);
            //   }else {
            //     that.logEvent(data);
            //   }
            // }
          }
          that.type = data.type
        }
      }
    },
    autoLogin: function() {
      var parm = {
        Username: this.user.userName,
        Password: this.user.userPassWord,
        ClientID: ClientID,
        TimeStamp: parseInt(Date.now() / 1000)
      }
      let content = tripleDes.encrypt(JSON.stringify(parm));
      this.url = this.oauth + '/account/autoLogin?content=' + encodeURIComponent(content);
    },
    pop: function() {
      if (this.logined) {
        storage.setItem('userInfo', JSON.stringify(this.user));
      } else {
        storage.setItem('userInfo', "{}");
        this.deleteCookie();
      }
      this.saveCookie();
      if (this.whereFrom && (this.whereFrom == 'index' || this.whereFrom == 'indexbyopen')) {
        navigators.pop({
          url: bundleUrl + 'index.js',
          animated: "true"
        }, event => {});
      }else if (this.whereFrom && this.whereFrom == 'live') {
        navigators.pop({
          url: bundleUrl + 'live.js',
          animated: "true"
        }, event => {});
      }else if (this.whereFrom && this.whereFrom == 'setting') {
        navigators.pop({
          url: bundleUrl + 'setting.js',
          animated: "true"
        }, event => {});
      }else {
        navigators.pop({
          animated: "true"
        }, res => {});
      }
    },
    goBack: function() {
      if ('fastdeposit' == this.source || 'modifyPwd' == this.source || 'security' == this.source || 'mc' == this.source) {
        this.pop();
      } else if (this.canGoBack) {
        webview.goBack(this.$refs.webview);
      } else {
        this.pop();
      }
    },
    goForward: function() {
      if (this.canGoForward) {
        webview.goForward(this.$refs.webview);
      }
    },
    reload: function() {
      webview.reload(this.$refs.webview);
    },
    start: function(e) {
      this.isLoadError = false;
      this.loading = true;
      // console.log("rc start:"+JSON.stringify(e));
    },
    finish: function(e) {
      this.loading = false;

      this.canGoBack = e.canGoBack;
      this.canGoForward = e.canGoForward;
      if (e.title) {
        // this.title = e.title;
      }
    },
    error: function(e) {
       if (e.errorCode == -1009||e.errorMsg.errorCode == -2) {
        this.isLoadError =true;
      }
      this.loading = false;
    },
  }
}
</script>

<style scoped>
.navbar {
  width: 750px;
  height: 88px;
  background-color: #2e74e9;
  align-items: center;
  justify-content: center;
}

.navbar-title {
  font-size: 36px;
  color: white;
  line-height: 54px;
  text-align: center;
}

.goback {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 120px;
  padding-left: 30px;
  justify-content: center;
}

.refresh {
  position: absolute;
  top: 0px;
  right: 0px;
  bottom: 0px;
  width: 120px;
  justify-content: center;
}

.webview {
  flex: 1;
  width: 750px;
}
</style>
