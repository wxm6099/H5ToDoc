<template>
<div :style="{'padding-bottom': iphonex?'34px':'0px'}">
  <image v-if="iOS" class="banner" ref="banner" style="position: absolute;top: 0px;" resize="cover" :src="banner"></image>
  <list show-scrollbar="false" offset-accuracy=1 scrollDirection="vertical" alwaysScrollableVertical="true" @scroll="scroll">
    <cell>
      <image class="banner" resize="cover" :src="iOS?opacitybg:banner"></image>
    </cell>
    <cell v-for="(item,index) in lists" :class="['rank-item','rank-item-bg-'+index]" @click="onLecturer(item);itemClick(index+1)">
      <div class="" style="width:200px;padding-left:24px;">
        <image class="rank-item-icon" resize="contain" :src="item.icon"></image>
      </div>
      <!--:class="[(index>0)?'rank-item-border':'']"-->
      <div style="flex:1;flex-direction:row;margin-right:24px;">
        <div style="flex:1;height:190px;">
          <text class="rank-item-name"> {{item.name}}</text>
          <text class="rank-item-title"> {{item.subTitle}}</text>
          <!-- <div class="" style="flex-direction:row;align-items:center;position:absolute;bottom:34px;">
            <text class="rank-item-font"> 周盈利:</text>
            <text class="rank-item-number"> {{item.profit}}</text>
            <text class="rank-item-font">美金/手</text>
          </div> -->
        </div>
        <div class="" style="width:160px;height:190px;align-items:center;">
          <image v-if="assets && index<=2" class="crown" :src="assets+'crown'+(index+1)+'.png'"></image>
          <!-- <div class="" style="flex-direction:row;align-items:center;height:34px;position:absolute;bottom:34px;">
            <text class="rank-item-font"> 周胜率:</text>
            <text class="rank-item-number"> {{item.weekRate}}</text>
          </div> -->
        </div>
      </div>
    </cell>
  </list>

  <div v-if="isLoadError" style="position:absolute;left:0px; top:0px;right:0px; bottom:0px;background-color: white;justify-content: center;align-items: center">
    <loadError @refreshNetWorkError="refreshNetWorkError"></loadError>
  </div>

  <div class="head-title">
    <status backgroundColor="#FFFFFF" v-bind:style="{opacity: opacity}"></status>
    <div class="navbar">
      <div  v-bind:style="{opacity: opacity}" style="position: absolute;left: 0px;top: 0px;right: 0px;bottom: 0px;background-color: #FFFFFF;"></div>
      <text v-bind:style="{opacity: opacity}" class="navbar-title"> {{title}}</text>
      <div @click="goBack" class="goback">
        <image style="width: 20px; height: 36px" resize="contain" :src="arrow"></image>
      </div>
    </div>
  </div>
  <message></message>
</div>
</template>
<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var dom = weex.requireModule('dom')
var navi = weex.requireModule('navigator')
var app = weex.requireModule('app')
var storage = require('../include/storage.js');
var http = require('../include/http.js');
var navigator = weex.requireModule('navigator');
var animations = weex.requireModule('animation');
const utils = require('../include/utils.js');
const statusBar = weex.requireModule('app');
const firebase = weex.requireModule('firebase');
module.exports = {
  components: {
    'status': require('../components/statusbar.vue'),
    'loadError': require('../components/loadError.vue'),
    'message': require('../components/message.vue'),
  },
  computed: {
    iOS: function() {
      const {
        platform
      } = weex.config.env;
      return platform.toLowerCase() === 'ios';
    },
    iphonex: function() {
      return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' || weex.config.env.deviceModel === 'iPhone11,2' || weex.config.env.deviceModel === 'iPhone11,4' || weex.config.env.deviceModel === 'iPhone11,6' || weex.config.env.deviceModel === 'iPhone11,8' );
    }
  },
  data: function() {
    return {
      cmsApiHost: '', //接口地址
      imageBaseUrl: '', //图片基地址
      assets: assetsUrl,
      opacitybg: assetsUrl + 'trans.png',
      title: '金牌讲师',
      nodeIdTecher: '',
      banner: '',
      arrow: assetsUrl + 'back2.png',
      lists: [],
      top: 0,
      height: 478,
      opacity: 0,
      barColor: 0, //状态颜色 0：黑色 1：白色
      isLoadError: false, //网络加载出错
    }
  },
  created: function() {
    var that = this;
    var domModule = weex.requireModule('dom');
    domModule.addRule('fontFace', {
      'fontFamily': "GEO415M",
      'src': "url('" + assetsUrl + "geo415m_0.ttf')",
    });
    //设置状态栏字体颜色为黑色
    if (app) {
      app.setStatusBarStyle(0);
    }
    this.logEvent('Ranking_page');
    storage.getItem('commonUrl',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.cmsApiHost = commonUrl.cmsApi; //接口基址
        that.imageBaseUrl = commonUrl.imageBaseUrl; //图片基址

        storage.getItem('nodeIdList', function(value) {
          var nodeIdList = JSON.parse(value);
          that.nodeIdTecher = nodeIdList.homeTeacherInfo;
          that.bannerId = nodeIdList.rankBanner;
          console.log('3--------loadConfigs ----');
          that.getBanner();
          that.getList();
        });
      }
    });
    // // 接收网络错误的广播
    // const Network = new BroadcastChannel('GloballyRefreshNetwork');
    // Network.onmessage = function(event) {
    //     that.getBanner();
    //     that.getList();
    // };
  },
  methods: {
      // 接收网络错误的点击事件的回调
      refreshNetWorkError:function(){
          this.getBanner();
          this.getList();
      },
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    itemClick: function(index) {
      if (index >= 0 && index <= 9) {
        this.logEvent('Ranking_page_0' + index);
      } else {
        this.logEvent('Ranking_page_' + index);
      }
    },
    onLecturer: function(item) {
      storage.setItem('lecturer', JSON.stringify({
        name: item.name,
        channelId: this.nodeIdTecher
      }));
      navigator.push({
        url: bundleUrl + 'lecturer.js',
        animated: "true",
        swipePop: "true",
      }, event => {})
    },
    refresh: function(e) {

    },
    scroll: function(e) {
      if (e.contentOffset.y < 0) {
        this.top = parseInt(e.contentOffset.y);
        if (utils.isAndroid()) {
          this.opacity = 1;
        } else {
          this.opacity = -e.contentOffset.y / 200;

        }
        this.height = 478;
        if (false == weex.supports('@module/app')) {
          return;
        }
        if (statusBar) {
          statusBar.setStatusBarStyle(0);
        }
        this.arrow = assetsUrl + 'back1.png';
      } else {
        this.top = 0;
        this.opacity = 0;
        this.height = parseInt(478 + e.contentOffset.y);
        this.barColor = 1;
        if (statusBar) {
          statusBar.setStatusBarStyle(0);
        }
        this.arrow = assetsUrl + 'back2.png';
      }
      var bannerEl = this.$refs.banner;
      if (bannerEl) {
        animations.transition(bannerEl, {
          styles: {
            height: this.height,
            transform: 'translateY(' + this.top + 'px) ',
          },
          duration: 0, //ms
          timingFunction: 'linear',
          delay: 0, //ms
        }, function() {})
      }
    },
    goBack: function() {
      this.logEvent('Ranking_page_back');
      navigator.pop({
        animated: "true"
      }, res => {});
    },
    getBanner: function() {
      var that = this;
      if ('' === this.cmsApiHost || this.cmsApiHost.length <= 5) {
        return
      }
      var url = this.cmsApiHost + '/ContentUnion/Site?format=json&ChannelIds=' + that.bannerId ;

      http.get(url, function(response) {
        that.isLoadError = false;
        if (response.status < 200) {
          that.isLoadError = true;
        }
        if (response.ok && response.data && response.data.Results && response.data.Results.length > 0) {
          if (response.data.Results[0].appImageUrl.indexOf('@') >= 0) {
            that.banner = response.data.Results[0].appImageUrl.replace('@', that.imageBaseUrl);
          }else {
            that.banner = response.data.Results[0].appImageUrl;
          }
        } else {
          that.banner = that.assets + 'rank-banner.png';
        }

      })
    },
    getList: function() {
      var that = this;
      if (that.cmsApiHost && this.nodeIdTecher.length > 0) {
        var url = that.cmsApiHost + '/ContentUnion/Site?format=json&OrderByDesc=analystDataWeekProfit&ChannelIds=' + this.nodeIdTecher;
        http.get(url, function(response) {
          that.isLoadError = false;
          if (response.status < 200) {
            that.isLoadError = true;
          }
          if (response.ok && response.data) {
            var results = response.data.Results;
            if (results && results.length > 0) {
              that.lists.splice(0, that.lists.length);
              for (var i = 0; i < results.length; i++) {
                var temp = results[i];
                if (temp) {
                  var item = {};
                  if (temp.Id) {
                    item.id = temp.Id;
                  } else {
                    item.id = 0;
                  }

                  if (temp.Title) {
                    item.name = temp.Title;
                  } else {
                    item.name = '';
                  }
                  if (temp.SubTitle) {
                    item.subTitle = temp.SubTitle;
                  } else {
                    item.subTitle = '';
                  }

                  if (undefined != temp.analystDataWeekProfit) {
                    item.profit = temp.analystDataWeekProfit;
                  } else {
                    item.profit = '';
                  }

                  if (temp.analystDataWeekRate) {
                    item.weekRate = temp.analystDataWeekRate;
                  } else {
                    item.weekRate = '';
                  }

                  if (temp.appteacherranking && temp.appteacherranking.length > 0) {
                      item.icon = temp.appteacherranking.replace('@', that.imageBaseUrl);
                  } else if (temp.appTeacherRanking && temp.appTeacherRanking.length > 0) {
                      item.icon = temp.appTeacherRanking.replace('@', that.imageBaseUrl);
                  } else {
                    item.icon = '';
                  }

                  if ('1' != temp.activityType && 1 !== temp.activityType) {
                    that.lists.push(item);
                  }
                }
              }
            }
          }
        });
      }
    }
  }
}
</script>

<style scoped>
.screenwidth {
  width: 750px;
}

.banner {
  width: 750px;
  height: 478px;
  background-color: transparent;
}

.rank-item {
  width: 750px;
  height: 190px;
  align-items: center;
  flex-direction: row;
  background-color: #FFFFFF;
  border-bottom-width: 1px;
  border-bottom-color: #f1f1f1;
  border-top-style: solid;
}

.rank-item-border {
  border-top-color: #f1f1f1;
  border-top-width: 1px;
  border-top-style: solid;
}

.rank-item-bg-0 {
  background-color: #faf1e0;
}

.rank-item-bg-1 {
  background-color: #fcf8ef;
}

.rank-item-bg-2 {
  background-color: #fefdf9;
}

.rank-item-icon {
  width: 136px;
  height: 136px;
  resize:
}

.crown {
  width: 68px;
  height: 48px;
  margin-top: 58px;
}

.rank-item-name {
  font-size: 28px;
  color: #1b222c;
  margin-top: 34px;
  margin-bottom: 8px;
  lines: 1;
  text-overflow: ellipsis;
}

.rank-item-title {
  font-size: 24px;
  color: #454950;
  lines: 1;
  text-overflow: ellipsis;
}

.rank-item-font {
  font-size: 24px;
  line-height: 42px;
  text-align: center;
  color: #9ba1ab;
  text-overflow: clip;
}

.rank-item-number {
  font-size: 28px;
  line-height: 42px;
  text-align: center;
  color: #e9302e;
  width: auto;
  /* height: 34px; */
  font-family: GEO415M;
}

.head-title {
  position: absolute;
  top: 0px;
  left: 0px;
  right: 0px;
}

.navbar {
  width: 750px;
  height: 88px;
  align-items: center;
  justify-content: center;
}

.navbar-title {
  font-size: 38px;
  color: #242424;
}

.goback {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 200px;
  padding-left: 30px;
  flex-direction: row;
  align-items: center;
}

.refresh {
  width: 750px;
  height: 80px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
}

.indicator-text {
  color: #888888;
  font-size: 30px;
  margin-left: 8px;
  text-align: center;
}

.indicator {
  height: 50px;
  width: 50px;
  color: gray;
}
</style>
