<template>
<div style="backgroundColor:#f1f1f1" @viewappear="viewAppear">
  <status backgroundColor="#FFFFFF"></status>
  <navigation title="我的账户" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="back();logEvent('Setting_page_back')"></navigation>
  <!-- <div class="navibar">
    <text class="navbar-title"> 我的账户 </text>
    <div @click="back();logEvent('Setting_page_back')" class="navbar-button">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div>
  </div> -->
  <div class="my-scroller">
    <div class="container border" @click="changeAvatar()">
      <div class="content" >
        <text class="title">更改头像 </text>
        <!-- <text class="detail"> {{account}}</text> -->
        <image v-if="headUrl" :src="headUrl" style="width: 54px;height: 54px;border-radius: 27px;"></image>
      </div>
      <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
    </div>
    <!-- <div class="container border" @click="logEvent('Center_page_account')">
      <div class="content" >
        <text class="title">会员账号 </text>
        <text class="detail"> {{account}}</text>
      </div>
      <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
    </div> -->
    <div class="container border" @click="logEvent('Center_page_tel')">
      <div class="content">
        <text class="title">手机号码 </text>
        <text class="detail"> {{phone}}</text>
      </div>
      <!-- <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image> -->
    </div>
    <div v-if="0 != user.accountStatus" class="container border" v-on:click="modify();logEvent('Center_page_password')">
      <div class="content">
        <text class="title">修改密码 </text>
      </div>
      <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
    </div>
    <div class="container border" v-on:click="forgot();logEvent('Center_page_retrieve')">
      <div class="content">
        <text class="title">忘记密码 </text>
      </div>
      <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
    </div>
    <div v-if="0 != user.accountStatus" class="container" v-on:click="security();logEvent('Center_page_security')">
      <div class="content">
        <text class="title">密保设置 </text>
      </div>
      <image v-if="rightItemSrc" :src="rightItemSrc" resize="contain" class="right-image"></image>
    </div>
    <div class="group">
      <div class="container" style="justify-content:center" v-on:click="logout();logEvent('Center_page_Logout')">
        <text class="logout-text"> 退出 </text>
      </div>
    </div>
  </div>
  <div v-if="showDialog" class="dialog">
      <div class="dialog-content">
          <div class="dialog-margin">
              <text class="dialog-color text-size lines"> 是否需要退出登录? </text>
          </div>
          <div class="footer">
              <div class="footer-btn footer-border" @click="cancel">
                  <text class="btn-text cancel"> 取消</text>
              </div>
              <div class="footer-btn" @click="confirm">
                  <text class="btn-text confirm"> 确定</text>
              </div>
          </div>
      </div>
  </div>
  <message></message>
  <choose-avatar :show=showChooseAvatar @cancel="close"></choose-avatar>
  <div v-if="isShowAlert" class="alert-show">
    <div class="alert-modul">
      <text style="color:#FFFFFF;font-size:28px;"> {{alertTips}} </text>
    </div>
  </div>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var dom = weex.requireModule('dom')
var navigator = weex.requireModule('navigator')
var app = weex.requireModule('app')
var storage = require('../include/storage.js');
var http = require('../include/http.js');
const utils = require('../include/utils.js')
var modal = weex.requireModule('modal');
const cookieStorage = weex.requireModule('cookieStorage');
var firebase = weex.requireModule('firebase');

module.exports = {
  components: {
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'dialog': require('../components/wxc-dialog.vue'),
    'message': require('../components/message.vue'),
    chooseAvatar: require('../components/chooseAvatar.vue'),
  },
  computed: {
    account: function() {
      if (this.user.userName) {
        return this.user.userName;
      }
      return '';
    },
    phone: function() {
      if (this.user.phone) {
        return this.user.phone.replace(/\{{\w+\}}/, '*****');
      }
      return '';
    },
  },
  data: function() {
    return {
      string: require('../include/string.js'),
      assets: assetsUrl,
      rightItemSrc: assetsUrl + 'arrow.png',
      showDialog: false,
      cmsApiHost: '', //接口地址
      imageBaseUrl: '', //图片基地址
      memberCenterUrl: '', //用户中心地址
      logined: false, //登录标记
      user: {},

      showChooseAvatar: false,
      headUrl: '',
      isShowAlert: false,
      alertTips: '',//弹窗提示语
    }
  },
  beforeCreate: function(){
    var that = this;
    storage.getItem('userInfo', function(data) {
      if (data) {
        that.user = JSON.parse(data);
        that.headUrl = that.user.headUrl;
      }
    });
  },
  created: function() {
    var that = this;
    storage.getItem('commonUrl',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.cmsApiHost = commonUrl.cmsApi; //接口基址
        that.imageBaseUrl = commonUrl.imageBaseUrl; //图片基址
      }
    });
    storage.getItem('memberCenter',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var memberCenter = JSON.parse(value);
      if (memberCenter) {
        that.memberCenterUrl = memberCenter.memberCenterUrl;
        that.modifyPwd = memberCenter.modifyPwd;
        that.forgetPwd = memberCenter.forgetPwd;
        that.securityUrl = memberCenter.security;
      }
    });
  },
  methods: {
    viewAppear: function(event) {
      //设置状态栏字体颜色为白色
      weex.requireModule('app').setStatusBarStyle(0);
      this.checkEffectPwd();//检测密码是否已失效
    },
    logEvent:function(name){
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    back: function() {
      navigator.pop({
        animated: "true"
      }, res => {});
    },
    loadWebView: function(url, title = '',src='') {
      if (url && url.length > 0) {
        var data = {
          title: title,
          url: url,
        }
        if (src && src.length>0) {
          data.source = src;
          data.from = src;
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'memberCenter.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    modify: function(title) {
      this.loadWebView(this.modifyPwd, '修改密码','modifyPwd');
    },
    forgot: function(title) {
      this.loadWebView(this.forgetPwd, '忘记密码','forgot');
    },
    security: function(title) {
      this.loadWebView(this.securityUrl, '密保设置','security');
    },
    logout: function() {
      this.showDialog = true;
      return;
      var that = this;
      modal.confirm({
        message: '是否需要退出登录?',
        okTitle: '确定',
        cancelTitle: '取消',
        duration: 0.3
      }, function(value) {
        if ('确定' == value) {
          this.doLogout();
        }
        // console.log('confirm callback', value)
      }.bind(this))
    },
    cancel:function(){
      this.showDialog = false;
    },
    confirm:function(){
      this.showDialog = false;
      this.doLogout();
    },
    doLogout: function() {
      storage.setItem('userInfo', '{}', function(callback) {});
			storage.setItem('user-logintoken-id', '{}', function(callback) {});
      storage.setItem('token', '', function(callback) {});
      if (cookieStorage) {
        cookieStorage.deleteCookie('');
      }
      this.back();
    },
    changeAvatar:function(){
      this.showChooseAvatar = true;
    },
    close:function () {
      let that = this;
      this.showChooseAvatar = false;
      storage.getItem('userInfo', function(data) {
        if (data) {
          that.user = JSON.parse(data);
          that.headUrl = that.user.headUrl;
        }
      });
    },
    //检测密码是否已失效
    checkEffectPwd:function(){
      let that = this;
      let json = storage.getItemSync('userInfo');
      if (json && json.length > 2) {
         var info = JSON.parse(json);
        if (utils.isBlankString(that.cmsApiHost)) {
          return;
        }
        let url = that.cmsApiHost + '/UserAccounts/UserInfo';
        http.getByHeader(info.token,encodeURI(url), function (response) {
          if (response.data && response.data.IsOK && response.data.Results.length > 0) {
            let liveDic = response.data.Results[0];
            if (liveDic.UserProductResult && liveDic.UserProductResult.Password && info.userPassWord != liveDic.UserProductResult.Password) {
              that.showAlertTips('密码已更改，请重新登录');
            }
          }
        });
      }
    },
    showAlertTips: function(tips, time = 2000) {
      if (false == this.isShowAlert) {
        this.isShowAlert = true;
        this.alertTips = tips;
        setTimeout(() => {
          this.isShowAlert = false;
          this.doLogout();
          // this.tips = '';
        }, time)
      }
    },
  },
}
</script>


<style scoped>
.navibar {
  height: 88px;
  background-color: #2e74e9;
  align-items: center;
  justify-content: center;
}

.navbar-title {
  font-size: 36px;
  line-height: 54px;
  text-align: center;
  color: white;
}

.navbar-button {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 120px;
  padding-left: 30px;
  justify-content: center;
}

.my-scroller {
  margin-top: 0px;
  background-color: white;
  width: 750px;
}

.group {
  /* margin-top: 20px; */
  width: 750px;
  border-top-width: 20px;
  border-top-style: solid;
  border-top-color: #F1F1F1;
  background-color: white;
}

.border {
  border-bottom-width: 1px;
  border-bottom-style: solid;
  border-bottom-color: #E1E1E1;
}

.container {
  flex-direction: row;
  height: 98px;
  margin-left: 24px;
  margin-right: 24px;
  align-items: center;
}

.content {
  flex: 1;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  overflow: hidden;
}

.title {
  flex: 1;
  text-align: left;
  text-overflow: ellipsis;
  font-size: 32px;
  line-height: 48px;
  color: #454950;
  lines: 1;
}

.detail {
  flex: 1;
  text-align: right;
  text-overflow: ellipsis;
  font-size: 28px;
  line-height: 34px;
  color: #9ba1ab;
  lines: 1;
}

.right-image {
  width: 18;
  height: 30;
  margin-left: 24px;
}

.logout-text {
  color: #2e74e9;
  font-size: 32px;
  line-height: 38px;
  text-align: center;
  letter-spacing: 24px;
}

.dialog {
    position: fixed;
    left: 0px;
    top: 0px;
    right: 0px;
    bottom: 0px;
    /*兼容H5异常*/
    z-index: 99999;
    justify-content: center;
    align-items: center;
    background-color: rgba(0, 0, 0, 0.6);
}

.dialog-content {
    width: 500px;
    background-color: #FFFFFF;
    padding-top: 20px;
    border-radius: 10px;
    overflow:hidden;
}

.dialog-title {
    flex: 1;
    height: 72px;
    justify-content: center;
    align-items: center;
}

.dialog-margin {
    margin-left: 36px;
    margin-right: 36px;
    justify-content: center;
    align-items: center;
}

.dialog-color {
    color: #454950;
}

.title-size {
    font-size: 32px;
    lines: 0;
}

.text-size {
    font-size: 28px;
    line-height: 42px;
    text-align: left;
}

.lines {
    lines: 0;
}

.footer {
    flex-direction: row;
    align-items: center;
    border-top-color: #F3F3F3;
    border-top-width: 1px;
    margin-top: 20px;
}

.footer-btn {
    flex-direction: row;
    align-items: center;
    justify-content: center;
    flex: 1;
    height: 88px;
}

.footer-border {
    border-right-color: #F3F3F3;
    border-right-width: 1px;
}

.cancel {
    color: #9ba1ab;
}

.confirm {
    color: #2e74e9;
}

.btn-text {
    font-size: 28px;
    text-align: center;
}
.alert-show{
  position:absolute;
  left:0px;
  top:464px;
  right:0px;
  bottom:0px;
  align-items:center;
}
.alert-modul {
  height: 74px;
  border-radius: 37px;
  align-items: center;
  justify-content: center;
  padding-left: 60px;
  padding-right: 60px;
  /* background-color: rgba(0, 0, 0, 0.7); */
  background-color: #4c4c4c;
  opacity:0.68;
}
</style>
