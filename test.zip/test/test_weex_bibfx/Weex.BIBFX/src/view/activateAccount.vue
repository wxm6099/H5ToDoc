<template >
<div>
  <status backgroundColor="#FFFFFF"></status>
  <navigation :title="title" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="goBack"></navigation>
  <!-- <div class="navbar">
    <text class="navbar-title"> {{title}} </text>
    <div @click="goBack" class="goback">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div>
  </div> -->
  <div style="flex-direction:row;marginTop:30px;marginBottom:30px;">
    <div style="align-items:center;flex:1">
      <div  class="item-row">
        <div class="whiteline"></div>
        <div class="line"></div>
      </div>
      <div class="circle">
        <div class="innerCircle">
          <text class="font20 text" style="  text-align: center;">01</text>
        </div>
      </div>
      <text class="font30 gold" style="text-align: center;color:#2e74e9">填写资料</text>
    </div>
    <div style="align-items:center;flex:1">
      <div  class="item-row">
        <div class="line"></div>
        <div class="line"></div>
      </div>
      <div class="circle">
        <div class="innerCircle">
          <text class="font20 text" style="  text-align: center;">02</text>
        </div>
      </div>
      <text class="font30 gold" style="text-align: center;color:#2e74e9">身份验证</text>
    </div>
    <div style="align-items:center;flex:1">
      <div  class="item-row">
        <div class="line"></div>
        <div class="line"></div>
      </div>
      <div class="circle">
        <div class="innerCircle">
          <text class="font20 text" style="  text-align: center;">03</text>
        </div>
      </div>
      <text class="font30 gold " style="text-align: center;color:#2e74e9">调查问卷</text>
    </div>
    <div style="align-items:center;flex:1">
      <div  class="item-row">
        <div class="line"></div>
        <div class="grayline"></div>
      </div>
      <div class="circle">
        <div class="innerCircle">
          <text class="font20 text" style=" text-align: center;">04</text>
        </div>
      </div>
      <text class="font30 gold" style="text-align: center;color:#2e74e9">存款激活</text>
    </div>
    <div style="align-items:center;flex:1">
      <div  class="item-row">
        <div class="grayline"></div>
        <div class="whiteline"></div>
      </div>
      <div class="circle dashed">
        <div class="innerCircle gray">
          <text class="font20 text" style="text-align: center;">05</text>
        </div>
      </div>
      <text class="font30" style="text-align: center;color:gray">交易密码</text>
    </div>
  </div>
  <div style="margin: 0px;height: 20px;background-color: #F1F1F1;"></div>
	<scroller alwaysScrollableVertical="false" show-scrollbar="false">
    <div class="info-controller">
    	<div class="info-title" v-if="active == 0">
    		<text class="font26" style="color: #e82c20;">资料验证成功,请根据提示激活MT5交易账户!</text>
    	</div>

    	<div class="info-title" v-if="active == 1">
        <richtext class="font26" style="color: #454950;" @itemclick="onlineCS()">
          <span>注资申请审批中，请关注短信提醒，并根据指示完成操作。如有任何疑问，欢迎咨询</span>
          <span style="text-decoration: underline;color:#2e74e9" pseudo-ref="service">在线客服!</span>
        </richtext>
    	</div>
    	<div class="info-item flexH">
    		<text class="font24" style="color: #e82c20;">*</text>
    		<text class="font24" style="color: #454950;">贵宾姓名: {{userName}}</text>
    	</div>
    	<div class="info-item flexH" v-if="active == 0">
    		<text class="font24" style="color: #e82c20;">*</text>
    		<text class="font24" style="color: #454950;">存款金额: </text>
    		<input class="input" type="text" maxlength=18 placeholder="50美元以上" @change="onchangeAmount" @input="inputAmount"></input>
    	</div>
    	<div class="info-item flexH" v-if="active == 1">
    		<text class="font24" style="color: #e82c20;">*</text>
    		<text class="font24" style="color: #454950;">存款金额: {{amount}}</text>
    	</div>
    	<div class="info-item flexH" v-if="active == 0">
    		<image style="width:30px;height:30px" :src="assets+'warning_gray.png'"></image>
    		<text class="font24" style="color: #454950;margin-left: 8px;">款项到账时间以银行显示为准，到账后将进行注资审批.</text>
    	</div>
    </div>

    <div style="margin: 0px;height: 1px;background-color: #F1F1F1;"></div>

    <div class="notice-controller">
    	<div class="notice-header">
    		<div class="notice-title">
    			<text class="font24" style="color: #454950;">注意事项</text>
    		</div>
    		<div class="notice-count flexH" @click="showCountBox">
    			<image style="width:24px;height:24px" :src="assets+'count_box.png'"></image>
    			<text class="font24" style="color: #2e74e9;margin-left: 20px;">汇率计算</text>
    		</div>
    	</div>
    	<div class="notice-body">
    		<div class="notice-item flexH" v-for="item in noticeData">
    			<image style="width:8px;height:8px;margin-top: 10px;" :src="assets+'icon1.png'"></image>
    			<div class="margin flexV">
    				<text class="font24" style="color: #9BA1AB;margin-left: 15px; width: 660px;">{{item.text}}</text>
    			</div>
    		</div>
    	</div>
    </div>
  </scroller>
	<div :class="[isSubmitBtnClick?'button-next-gray':'button-next']" @click="onsubmitClick" v-if="active == 0">
		<text class="font32 text">下一步</text>
	</div>
  <!--<dialog :show="showDialog" title="提示" content="返回后，可登陆用户中心查看个人信息和审核状态！" confirm="确认返回" cancel="取消"-->
  <!--@confirm="dialogRightBtnClick" @cancel="dialogLeftBtnClick" @close="dialogCloseBtnClick">-->
  <!--</dialog>-->
	<dialog :show="showDialog" title="温馨提示" content="您尚未提交资料，返回后将清空内容，请确认是否继续退出？" confirm="继续填写" cancel="退出"
			@confirm="dialogLeftBtnClick" @cancel="dialogRightBtnClick" @close="dialogCloseBtnClick">
	</dialog>


	<div v-if="alertShow" class="alert-container">
		<div class="alert-view">
			<div class="alert-title">
				<text class="font32" style="color: #454950;">汇率计算器</text>
			</div>
			<div class="alert-row">
				<input class="input"  maxlength=18 placeholder="输入金额" @change="onchangeMoney" @input="inputMoney" :value="currentMoney"></input>
				<div class="pick-view flexH" @click="tapMoneyLeft">
					<text class="font28">{{pickLeftTitle}}</text>
					<div class="input-down-select">
					  <image style="width:15px;height:12px" :src="assets+'auth/selectdown.png'"></image>
					</div>
				</div>
				<div class="gap">
					<image style="width:30px;height:30px" resize="contain" :src="assets+'count.png'"></image>
				</div>
				<div class="pick-view flexH" @click="tapMoneyRight">
					<text class="font28">{{pickRightTitle}}</text>
					<div class="input-down-select">
					  <image style="width:15px;height:12px" :src="assets+'auth/selectdown.png'"></image>
					</div>
				</div>
			</div>
			<div class="alert-row">
				<input class="input" disabled="true" type="number" maxlength=18 placeholder="换算结果" @change="onchangeResult" @input="inputResult" :value="currentResult"></input>
				<div class="button-view" @click="count">
					<text class="font28 text">换算</text>
				</div>
			</div>
			<div class="alert-row-text">
				<text class="font24" style="color:#9BA1AB;margin-right: 5px;">*</text>
				<text class="font24" style="color:#9BA1AB">因汇率浮动,实际交易金额以平台显示结果为准</text>
			</div>

			<!-- <div style="background-color: blue;width: 178px;height: 70px;"></div> -->

			<div class="alert-close" @click="closeAlert">
				<image style="width:20px;height:20px" resize="contain" :src="assets+'close_red.png'"></image>
			</div>
		</div>

	</div>

	<div v-if="isShowAlert" class="alert-show">
	  <div class="alert-modul">
	    <text style="color:#FFFFFF;font-size:28px;"> {{alertTips}} </text>
	  </div>
	</div>

</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var storage = require('../include/storage.js');
const app = weex.requireModule('app');
var utils = require('../include/utils.js');
const picker = weex.requireModule('picker');
var http = require('../include/http.js');

// const MONEY_TYPE = {
// 	"CNY":'人民币',
// 	'HKD':'港币',
// 	'USD':'美元',
// }
const MONEY_TYPE = require('../include/constant.js').MONEY_TYPE;


module.exports = {
  components: {
    navigation: require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'dialog': require('../components/dialog.vue'),
  },
  data:function(){
    return{
      title:"存款激活",
      assets:assetsUrl,
      serviceUrl:'',//客服url
      showDialog: false,//返回时的确认弹窗
      isAndroid:utils.isAndroid(),
      openAccountFrom:'',//从哪里进入开户步骤
      pcUrl :  assetsUrl+'pc.png',

			MoneyNum: 0, // 存款金额
      isSubmitBtnClick: false,
			isShowAlert: false,
      alertTips: '', // 弹窗提示语

      isAndorid: utils.isAndroid(),
			alertShow: false,
			pickLeftData:[],
			pickLeftTitle: '',
			pickLeftCode:'',

			pickRightData:[],
			pickRightTitle: '',
			pickRightCode:'',

			currentMoney: '',
			currentResult: '',

			noticeData:[
				{ text: '本平台的交易币种为美元，如通过网银进行人民币注资，您的存款金额将依实时汇率计算。' },
				{ text: '本注资系统仅支持中国内地签发银行卡。' },
				{ text: '本注资系统暂不支持信用卡结算，若因使用信用卡注资而导致的一切后果及损失，本公司概不负责' }
			],

			exchangeData:[
				{"OriginalCurrency":"CNY","TargetCurrency":"HKD","ExchangeRate":7.506666,"ExchangeRateType":"Receipt","UpdateDateTime":"/Date(1537922132273+0800)/"},
				{"OriginalCurrency":"USD","TargetCurrency":"CNY","ExchangeRate":6.616001,"ExchangeRateType":"Receipt","UpdateDateTime":"/Date(1537912315273+0800)/"},
				{"OriginalCurrency":"USD","TargetCurrency":"HKD","ExchangeRate":1.500017,"ExchangeRateType":"Receipt","UpdateDateTime":"/Date(1537917587273+0800)/"},
				{"OriginalCurrency":"HKD","TargetCurrency":"CNY","ExchangeRate":0.8,"ExchangeRateType":"Receipt","UpdateDateTime":"/Date(1537916697273+0800)/"},
				{"OriginalCurrency":"HKD","TargetCurrency":"USD","ExchangeRate":0.501012,"ExchangeRateType":"Receipt","UpdateDateTime":"/Date(1537924873273+0800)/"},
			],

			active: 0,
			userName: '',
			userToken: '',
			amount: '',

    }
  },
  created: function() {
    var that = this;

		that.active = utils.getQueryString(weex.config.bundleUrl,'active');/////////////


    storage.getItem('user_openaccount_from', function(value) {
      if (value ) {
        that.openAccountFrom = value;
      }
    });
    storage.getItem('commonUrl',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.serviceUrl = commonUrl.feedback;
				that.cmsApi = commonUrl.cmsApi;

				that.getExchangeRate(that);
      }
    });
		storage.getItem('userInfo', function(value) {
		  if (value && value.length>=2) {
		    var data = JSON.parse(value);
		    that.userToken = data.token;
        if (data.TradeAmount) {
          let type = MONEY_TYPE[data.TradeCurrency];
          if (!type) {
            type = '美元';
          }
          that.amount = `${data.TradeAmount}${type}`;
        }

				that.getReceiptList(that);

				if (data.realName){
					that.userName = data.realName;
				} else if (data.nickName) {
					that.userName = data.nickName;
				}else{
					that.userName = data.userName;
				}

		  }
		});

  },
  methods:{
		//弹窗事件
		showAlertTips: function(tips, time = 2000) {
		  if (false == this.isShowAlert) {
		    this.isShowAlert = true;
		    this.alertTips = tips;
		    setTimeout(() => {
		      this.isShowAlert = false;
		      // this.tips = '';
		    }, time)
		  }
		},

    goBack:function(){
      this.showDialog = true;
    },
    //弹窗右上角按钮（关闭）
    dialogCloseBtnClick() {
      this.showDialog = false;
    },
    //弹窗左下角按钮（确认）
    dialogLeftBtnClick() {
      this.showDialog = false;
    },
    //弹窗右下角按钮（取消）
    dialogRightBtnClick() {
      this.showDialog = false;
      if (this.openAccountFrom === 'live') {
        navigator.pop({
          url: bundleUrl + 'live.js',
          animated: "false"
        }, event => {

        });
      }else {
        navigator.pop({
          url: bundleUrl + 'index.js',
          animated: "false"
        }, event => {

        });
      }
    },
    onlineCS:function(){
      this.loadWebView(this.serviceUrl, '客服');
    },
    loadWebView: function(url, title = '') {
      if (url && url.length > 0) {
        var data = {
          title: title,
          url: url,
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "false"
        }, event => {})
      }
    },

		getReceiptList:function(that){
			// let that = this;
			var saveurl = that.cmsApi + '/ReceiptList/Bibfx'
			http.getByHeader(that.userToken,encodeURI(saveurl), function (response) {
				// console.log('输出已存款的金额：' + JSON.stringify(response));
			  if (response.ok) {
					if (response.data && response.data.IsOK && response.data.Results){
						let Results = response.data.Results;
						let amount = Results.TradeAmount;
						let type = MONEY_TYPE[Results.TradeCurrency];
						if (!type) {
							type = '美元';
						}
						that.amount = `${amount}${type}`;
					}
			  }
			})
		},

		getExchangeRate:function(that){
			// let that = this;
			let body = `?ExchangeRateType=Receipt`
			var saveurl = that.cmsApi + '/ExchangeRate' + body;
			http.get(encodeURI(saveurl), function (response) {
			  if (response.ok && response.data) {
					that.exchangeData = response.data;
			    that.createPickDataAll();
			  } else {
			    // that.showAlertTips('提交失败，请重试')
					that.createPickDataAll();
			  }
			})
		},


		createPickDataAll:function(){
			let data = this.exchangeData;

			let pickLeftData = [];
			let pickRightData = [];

			for (let i = 0; i < data.length; i++){
				let rate = data[i].ExchangeRate;
				let Original = data[i].OriginalCurrency;
				let Target = data[i].TargetCurrency;
				let rateType = data[i].ExchangeRateType;

				let leftDic = {
					'name': MONEY_TYPE[Original],
					'code': Original,
				}
				if (!this.find(pickLeftData, leftDic)){
					pickLeftData.push(leftDic);
				}

				let rightDic = {
					'name': MONEY_TYPE[Target],
					'code': Target,
				}
				if (!this.find(pickRightData, rightDic)){
					pickRightData.push(rightDic);
				}
			}
			this.pickLeftData = pickLeftData;
			// this.pickLeftTitle = pickLeftData[0].name
			this.pickRightData = pickRightData;


			// set Default
			// 美元USD
			// 人民币 CRY
			this.pickLeftTitle = '美元';
			this.pickLeftCode = 'USD';
			this.pickRightTitle = '人民币';
			this.pickRightCode = 'CNY';

		},

		find:function(arr,obj){
			let judge = false;
			for (let i = 0; i < arr.length; i++){
				if (this.compareObject(arr[i], obj)){
					judge = true;
				}
			}
			return judge;
		},

		compareObject:function(x, y) {
			if (x === y) {
				return true;
			}

			if (!(x instanceof Object) || !(y instanceof Object)) {
				return false;
			}

			if (x.constructor !== y.constructor) {
				return false;
			}

			for (var p in x) {
				if (x.hasOwnProperty(p)) {
					if (!y.hasOwnProperty(p)) {
						return false;
					}
					if (x[p] === y[p]) {
						continue;
					}
					if (typeof (x[p]) !== "object") {
						return false;
					}
					if (!Object.equals(x[p], y[p])) {
						return false;
					}
				}
			}

			for (p in y) {
				if (y.hasOwnProperty(p) && !x.hasOwnProperty(p)) {
					return false;
				}
			}
			return true;
		},

		tapMoneyLeft:function(){
			var that = this;
			let showArr = [];
			for (let i = 0; i < this.pickLeftData.length; i++){
				showArr.push(this.pickLeftData[i].name);
			}
			picker.pick({
			    items: showArr,
			    index: 0,
			  }, event => {
			    if (event.result === 'success') {
						let index = event.data;
						that.pickLeftTitle = that.pickLeftData[index].name;
						that.pickLeftCode = that.pickLeftData[index].code;

						let data = that.exchangeData;
						let arr = [];
						for (let i = 0; i < data.length; i++){
							if (data[i].OriginalCurrency == that.pickLeftData[index].code){
								let code = data[i].TargetCurrency;
								let dic = {
									'code': code,
									'name': MONEY_TYPE[code],
								}
								arr.push(dic);
							}
						}
						that.pickRightData = arr;
						that.pickRightTitle = that.pickRightData[0].name;
						that.pickRightCode = that.pickRightData[0].code;

			    }
			  })
		},
		tapMoneyRight:function(){
			var that = this;
			let showArr = [];
			for (let i = 0; i < this.pickRightData.length; i++){
				showArr.push(this.pickRightData[i].name);
			}
			picker.pick({
			    items: showArr,
			    index: 0,
			  }, event => {
			    if (event.result === 'success') {
						let index = event.data;
						that.pickRightTitle = that.pickRightData[index].name;
						that.pickRightCode = that.pickRightData[index].code;

			    }
			  })
		},

		onchangeMoney:function(event){
			this.currentMoney = event.value;
		},
		inputMoney:function(event){
			this.currentMoney = event.value;
		},
		onchangeResult:function(event){
			this.currentResult = event.value;
		},
		inputResult:function(event){
			this.currentResult = event.value;
		},
		count:function(){
			// 汇率计算结果
			let that = this;
			if(!that.currentMoney){
				that.showAlertTips('请填写金额');
				return
			}
			let leftCode = that.pickLeftCode;
			let rightCode = that.pickRightCode;
			let data = that.exchangeData;
			let rate;
			for (let i = 0 ; i < data.length; i++){
				if (data[i].OriginalCurrency == leftCode && data[i].TargetCurrency == rightCode){
					rate = data[i].ExchangeRate;
				}
			}
			that.currentResult = parseFloat(that.currentMoney * rate);

		},
		closeAlert:function(){
			this.alertShow = false;
		},
		showCountBox:function(e){
			this.alertShow = true;
		},

		inputAmount:function(event){
			this.MoneyNum = event.value;
		},
		onchangeAmount:function(event){
			this.MoneyNum = event.value;
		},

		onsubmitClick: function () {
			var that = this
			if (!/^(([1-9]{1}\d*)|(0{1}))(\.\d{0,2})?$/.test(that.MoneyNum)) {
        that.showAlertTips('存款金额小数点后最多保留2位小数')
        return
      }
      if (that.MoneyNum < 50) {
        that.showAlertTips('存款金额至少50美元！')
        return
      }

      that.isSubmitBtnClick = true
      var header = {'token': that.userToken};
			var saveurl = that.cmsApi + '/Injects/Bibfx?format=json&DepositAmount=' + that.MoneyNum;
			http.getByHeader(that.userToken,encodeURI(saveurl), function (response) {
				// console.log('输出存款结果:' + JSON.stringify(response));
        that.isSubmitBtnClick = false
				if (response.ok){
					if (response.data && response.data.Results && response.data.Results.length > 0) {
					  var json = {
					    'title': '支付',
					    'context': response.data.Results[0]
					  }
					  storage.setItem('app-url', JSON.stringify(json))
					  navigator.push({
					    url: bundleUrl + 'webview.js',
					    animated: 'true',
					    swipePop: 'true'
					  }, event => {})
					} else {
					  that.showAlertTips('提交失败，请重试')
					}
				}else{
					that.showAlertTips('网络失败，请稍后重试')
				}

      })
    },


  }
}
</script>

<style  src="../style/common.css" scoped></style>
<style scoped>
.align{
  margin-left: 25px;
  margin-right: 25px;
}

.item-row{
  position: absolute;
  left: 0px;
  right: 0px;
  top: 0px;
  flex-direction: row;
}

.line{
  flex: 1;
  height: 20px;
  border-bottom-width: 1px;
  border-bottom-color: #2e74e9;
}

.whiteline{
  flex: 1;
  height: 20px;
}

.grayline{
  flex: 1;
  height: 20px;
  border-bottom-width: 1px;
  border-bottom-color: #ABABAB;
  /* border-bottom-style: dashed; */
}

.circle{
  width: 40px;
  height: 40px;
  border-radius: 20px;
  border-color: #2e74e9;
  border-width: 1px;
  align-items: center;
  justify-content: center;
  background-color: white;
  margin-bottom: 15px;
}


.dashed{
  border-style: dashed;
  border-color: #AA9B6A;
}

.innerCircle{
  width: 30px;
  height: 30px;
  background-color: #2e74e9;
  border-radius: 15px;
  align-items: center;
  justify-content: center;
}

.gray{
  background-color: #ABABAB;
}

.topBorder{
 border-top-color:  #f1f1f1;
 border-top-width: 1px;
 border-top-style: solid;
}

.button{
  height: 90px;
  margin-bottom: 70px;
  background-color: #e9302e;
  border-radius: 8px;
  justify-content: center;
  align-items: center;
  margin-left: 30px;
  margin-right: 30px;
}
.button-next{
	height: 90px;
	width: 750px;
	/*margin-bottom: 70px;*/
	background-color: #2e74e9;
	/*border-radius: 8px;*/
	justify-content: center;
	align-items: center;
	/*margin-left: 30px;*/
	/*margin-right: 30px;*/
}
.button-next-gray{
	height: 90px;
	width: 750px;
	/*margin-bottom: 70px;*/
	background-color: #dddddd;
	/*border-radius: 8px;*/
	justify-content: center;
	align-items: center;
	/*margin-left: 30px;*/
	/*margin-right: 30px;*/
}

.text{
  color: white;
}

.alert-container{
	position: fixed;
	left: 0px;
	top: 0px;
	right: 0px;
	bottom: 0px;
	/*兼容H5异常*/
	z-index: 99999;
	justify-content: center;
	align-items: center;
	background-color: rgba(0, 0, 0, 0.6);

}
.alert-view{
	border-width: 2px;
	border-radius: 5px;

	width: 680px;
	height: 392px;
	margin-right: 0px;
	margin-left: 0px;
	padding: 20px;

	flex-flow: column nowrap;
	align-items:center;
	justify-content: space-around;
	background-color: white;

}
.alert-title{
	align-items: center;
	justify-content: center;
	flex-direction: column;
	height: 80px;
	color: #454950;
	font-size: 32px;
}

.alert-row{
	flex-direction: row;
	justify-content: space-between;
	align-items: center;
	margin: 20px 0;
	width: 610px;
	/* background-color: green; */
}

.alert-row-text{
	flex-direction: row;
	justify-content: flex-start;
	margin: 20px;
	/* background-color: orange; */
	align-self: flex-start;
}
.input-view{
	height: 70px;
	align-items: center;
	justify-content: center;
	margin-right: 20px;
	flex: 1;
	/* background-color: blue; */
}
.input{
	color:#9BA1AB;
	border-color: #D2D2D2;
	border-width: 1px;
	flex:1;
	height: 70px;
	/* width: 178px; */
	font-size: 28px;
	padding-left: 20px;
	align-items: center;
}
.pick-view{
	height: 70px;
	width: 174px;
	border-color: #D2D2D2;
	border-width: 1px;
	align-items: center;
	justify-content: space-around;
	margin-left: 20px;
	/* background-color: green; */
}
.gap{
	width: 40px;
	height: 70px;
	/* background-color: green; */
	margin-left: 20px;
	align-items: center;
	justify-content: center;
}
.input-down-select{
  width:30px;
  height:70px;
  /* backgroundColor:red; */
  margin-right: 20px;
	margin-left: 20px;
  align-items: center;
  justify-content: center;
}
.button-view{
	width: 236px;
	height: 70px;
	margin-left: 20px;
	background-color: #2e74e9;
	justify-content: center;
	align-items: center;
	border-radius: 5px;
}
.alert-close{
	position: absolute;
	right: 0px;
	top: 0px;
	width: 120px;
	height: 80px;
  padding-top: 20px;
  padding-right: 20px;
  justify-content: flex-start;
  align-items: flex-end;
	z-index: 1001;
}

.notice-controller{
  margin-bottom: 122px;
	padding: 30px;
	width: 750px;
	height: auto;
	/* background-color: gray; */
}
.notice-header{
	height: 50px;
	justify-content: space-between;
	align-items: center;
	flex-direction: row;
	/* background-color: orange; */
}
.notice-title{
	/* width: 200px; */
	justify-content: center;
	align-items: center;
}
.notice-count{
	/* width: 150px; */
	justify-content: center;
	align-items: center;
	/* background-color: red; */
}
.notice-body{
	height: auto;
	flex-direction: column;
}
.notice-item{
	height: auto;
	margin-top: 26px;
	margin-bottom: 26px;
	margin-left: 5px;
	margin-right: 5px;
	/* align-items: center; */
	/* background-color: green; */
	/* flex-wrap: wrap; */
}
.margin{
	margin: 0;
}

.info-controller{
	padding: 30px;
	width: 750px;
}
.info-title{
	padding-top: 10px;
	padding-bottom: 10px;
	/* width: 670px; */
}
.info-item{
	margin-top: 40px;
	margin-bottom: 20px;
	align-items: center;
}

.alert-show{
		position:absolute;
		left:0px;
		top:300px;
		right:0px;
		bottom:0px;
		align-items:center;
	}
	.alert-modul {
		height: 74px;
		border-radius: 37px;
		align-items: center;
		justify-content: center;
		padding-left: 60px;
		padding-right: 60px;
		/* background-color: rgba(0, 0, 0, 0.7); */
		background-color: #4c4c4c;
		opacity:0.68;
	}

</style>
