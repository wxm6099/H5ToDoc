<template>
<div class="">
  <status backgroundColor="#FFFFFF"></status>
  <navigation :title="title" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="goBack"></navigation>
  <!-- <div class="navbar">
    <text class="navbar-title"> {{title}} </text>
    <div @click="goBack" class="goback">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div>
  </div> -->
  <scroller class="scroller" show-scrollbar="false">
    <!-- <div class="flexV block">
      <div class="margin flexH">
        <text class="font28 color1 bold">开户提示</text>
      </div>
      <div class="margin flexV">
		<div class="flexH" style="margin-top: 18px;margin-bottom: 18px;">
			<div style="width:8px;height:8px;margin-top: 10px;border-radius: 4px;background-color: #454950" ></div>
			<text class="font26 color2" style="margin-left: 14px;width: 650px;"> 注册会员后，可免费申请模拟交易账户(内含20万美元体验金)，并可无限时收看直播。</text>
		</div>
		<div class="flexH" style="margin-top: 18px;margin-bottom: 18px;">
			<div style="width:8px;height:8px;margin-top: 10px;border-radius: 4px;background-color: #454950"></div>
			<text class="font26 color2" style="margin-left: 14px;width: 650px;"> 立即激活交易账号，即可登录MT5进行交易，并开通直播间发言功能，与分析师直接线上对话！</text>
		</div>
      </div>
    </div>
    <div class="tab flexH">
      <div class="center" :class="[(type == 0)?'tab-block-select':'tab-block']" @click="tabSelect(0)">
        <text :class="['font24','text-center',type == 0?'text-select':'text']">{{"铸博皇御环球金融\n-约130倍杠杆-\n1手1000美元保证金"}}</text>
      </div>
      <div class="center" :class="[(type == 1)?'tab-block-select':'tab-block']" @click="tabSelect(1)">
        <text :class="['font24','text-center',(type == 1)?'text-select':'text']">{{"铸博皇御贵金属\n-50倍杠杆-\n1手约2600美元保证金"}}</text>
      </div>
    </div> -->
    <div v-if="type == 1">
			<div class="padding" style="padding-top: 8px;">
			  <text class="font26 " style="line-height:36px; color: #ad9b68;">铸博皇御贵金属-香港金银业贸易场AA类79号行员</text>
			</div>
      <div class="padding paddingTop paddingBottom">
        <text class="font26 color4" style="line-height:36px;">每手保证金：合约价值的2%</text>
        <text class="font24 color2" style="line-height:36px;margin-top: 8px">(例如：金价为1200美元/盎司，每手保证金2400美元)</text>
        <text class="font26 color4" style="line-height:40px;margin-top: 16px ">请您亲身前往公司提交以下资料，以完成开户及注资流程。</text>
      </div>
      <div class="padding" style="backgroundColor: #ededed;height: 80px;justify-content:center">
        <text class="font28 color4">香港居民开户流程</text>
      </div>
      <div class="padding">
        <div class="cell bottomBorder flexH">
          <text class="font26 color2" style="margin-right:25px;">*</text>
          <text class="font26 color4">开户所需的证明文件</text>
        </div>
        <div class="cell bottomBorder flexH">
          <image class="circle" :src="circle"></image>
          <text class="font26 color4">身份证/护照</text>
        </div>
        <div class="cell bottomBorder flexH">
          <image class="circle" :src="circle"></image>
          <text class="font26 color4">银行资料</text>
        </div>
        <div class="cell bottomBorder flexH">
          <image class="circle" :src="circle"></image>
          <div class="width:650px;border-color:red;">
            <text style="width:650px;lines:2;" class="font26 color4">近三个月内印有申请人名字的住址证明（水、电、煤、电话单、银行账单、或保单）</text>
          </div>
        </div>
      </div>
      <div class="padding paddingTop" style="margin-bottom: 60px;">
          <text class="font26 color2">请客户携带以上证明文件亲临公司办理开户手续。</text>
          <text class="font26 color2">公司地址：香港佐敦庇利金街8号百利金商业中心25楼</text>
      </div>
      <!-- <div style="flex:1;backgroundColor: #ededed;">
        <div class="padding cell flexH" style="backgroundColor: white;marginTop:20px;marginBottom:70px;">
            <text class="font26 text">若您非香港居民，请点击此处</text>
            <text class="font26 underline color3" @click="onclickopenaccount">开立账户</text>
        </div>
      </div> -->
    </div>
    <div v-if="type != 1" class="margin flexV">
      <div class="flexH center" style="margin-top:50px;">
				<div class="item">
				  <text class="color4  font22 text-center">产品多元化</text>
				  <div class="center flexH">
            <text class="color4  font22 text-center"  style="line-height: 30px">杠杆高达</text>
				    <text class="color31 font22 text-center"  style="line-height: 30px">200</text>
            <text class="color4  font22 text-center"  style="line-height: 30px">倍</text>
				  </div>
				</div>
        <div class="item">
          <text class="color4  font22 text-center">安全交易商品牌</text>
          <div class="center flexH">
            <!-- <text class="color31 font22 text-center" style="line-height: 30px">30</text> -->
            <text class="color4  font22 text-center" style="line-height: 30px">全球投资者信赖</text>
          </div>
        </div>
        <div class="item">
          <div class="center flexH">
            <text class="color31 font22 text-center"  style="line-height: 30px">MT5</text>
            <text class="color4  font22 text-center"  style="line-height: 30px">交易系统</text>
          </div>
          <text class="text color4 font22 text-center">下单快 安全稳定</text>
        </div>
      </div>
			<div class="flexH infoItem">
			  <div class="flexH">
			    <text class="font24 color32">*</text>
			    <text class="font24 color4">手机号码</text>
			  </div>
			  <div class="input flexH" style="align-items: center;">
			    <div class="flexH select-phone-areacode" v-on:click="onclickphoneareacode()">
			      <text class="font24 color4" style="margin-left: 20px;">{{memberPhoneAreaCode}}</text>
			      <div class="input-down-select">
			        <image style="width:20px;height:16px" :src="assets+'auth/selectdown.png'"></image>
			      </div>
			    </div>
			    <input ref="phoneNum" class="input-size-phone" allowCopyPaste="true" type="number" :value="phoneNumberValue" :maxlength="phoneNumberLength"
			    :placeholder="phoneNumberPlaceholder" @input="inputphonenumber" @change="onchangememberphonenumber"></input>
			  </div>
			</div>
			<div class="flexH infoItem">
			  <div class="flexH">
			    <text class="font24 color32">*</text>
			    <text class="font24 color4">短信验证</text>
			  </div>
			  <div class="flexH" style="width:550px;height:70px">
			    <div class="input-phone-IDcode">
			      <input class="input-size" allowCopyPaste="true" type="number" maxlength=6 placeholder="输入短信验证码" :value="memberIDcode"  @change="onchangememberIDcode" @input="inputIDcode"></input>
			    </div>
			    <div :class="[isTimeDownTick?'send-phone-IDcode-gray':'send-phone-IDcode']" v-on:click="onclickphoneIDcode()">
			      <text :class="[isTimeDownTick?'send-phone-IDcode-graytext':'send-phone-IDcode-redtext']">{{getIDcode}}</text>
			    </div>
			  </div>
			</div>
      <div class="flexH infoItem">
        <div class="flexH">
          <text class="font24 color32">*</text>
          <text class="font24 color4">会员密码</text>
        </div>
        <div class="input flexH" style="align-items: center;">
          <input class="input-size-password" allowCopyPaste="false" :type="pwdInputType" :value="inputPassword" maxlength=20 placeholder="6-20位数字/字母/组合" @change="onchangememberpwd" @input="inputpwd"></input>
          <div class="password-show-hide" v-on:click="onclickshowpassword()">
            <image class="eyes" resize="contain" :src="assets+'auth/psdeyeclose.png'" v-if="!isShowPassword"></image>
            <image class="eyes" resize="contain" :src="assets+'auth/psdeyeopen.png'" v-else></image>
          </div>
        </div>
      </div>
      <div class="flexH infoItem" >
        <div class="flexH">
          <text class="font24 color32">*</text>
          <text class="font24 color4">确认密码</text>
        </div>
        <div class="input flexH" style="align-items: center;">
          <input class="input-size-password" allowCopyPaste="false" :type="confirmInputType" :value="surePassword" maxlength=20 placeholder="请再次输入您的密码" @change="onchangemembersurepwd" @input="inputsurepwd"></input>
          <div class="password-show-hide" v-on:click="onclickshowsurepassword()">
            <image class="eyes" resize="contain" :src="assets+'auth/psdeyeclose.png'" v-if="!isShowSurePassword"></image>
            <image class="eyes" resize="contain" :src="assets+'auth/psdeyeopen.png'" v-else></image>
          </div>
        </div>
      </div>
    </div>
  </scroller>
  <div v-if="type != 1" :class="[isSubmitBtnClick?'button-gray':'button']" v-on:click="onclicknext()">
       <text class="font32" style="color: white;text-align: center">确认并提交</text>
  </div>
  <div v-if="isShowAlert" class="alert-show">
    <div class="alert-modul">
      <text style="color:#FFFFFF;font-size:28px;"> {{alertTips}} </text>
    </div>
  </div>
</div>
</template>

<script scoped>
var appbasedata = require('../survey.json');
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var storage = require('../include/storage.js');
var http = require('../include/http.js');
var app = weex.requireModule('app');
const picker = weex.requireModule('picker');
var firebase = weex.requireModule('firebase');
var utils = require('../include/utils.js');
const jwt = require('jsonwebtoken');
import {
  ClientID
} from '../include/url.js';
module.exports = {
  components: {
    navigation: require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'checkbox': require('../components/checkbox.vue'),
  },
  data: function() {
    return {
      isAndroid:utils.isAndroid(),
      channelName:'',//渠道名
      isLiveRoom:false,//是否是直播间开户
      openAccountFrom:'',//开户来源名称
      assets: assetsUrl,
      title: '真实开户',
      type:0,//香港客户（1）  非香港客户（0）
      circle:assetsUrl+'circle.png',
      // selectedSexImg:assetsUrl+'radio/checked.png',
      // unselectedSexImg:assetsUrl+'radio/unchecked.png',
      serviceUrl:'',//客服url
      oauth:'',//单点地址
      bibApi:'',//网络请求基地址
      memberCode: '',
      memberCodeExist: false,//会员账号是否已存在
      memberCodeExistValue: '',//会员账号已存在的值
      memberName: '',
      memberNameExist: false,//会员昵称是否已存在
      memberNameExistValue: '',//会员昵称已存在的值
      surePassword:'',
      inputPassword:'',
      // isShowSexMan:false,
      // isShowSexWoman:false,
      // isShowSexOther:false,
      // memberSex:-1,//选择的性别（默认 空  1:男  2:女 3:其他）
      memberPassword: '',
      isShowPassword:false,
      memberSurePassword: '',
      isShowSurePassword:false,
      areaCodes:[],//手机号码区号名称数组
      memberPhoneAreaCode: '',//区号名称
      memberPhoneAreaCodeIndex: 0,//区号数组的下标
      memberPhoneNumber: '',
      phoneNumberValue:'',
      phoneNumberLength:11,//手机号码的位数
      phoneNumberPlaceholder:'填写您的手机号码',
      phoneCodeKey:'',//发送验证码的固定key
      getIDcode: '发送验证码',
      idCodeTimeTick:0,//验证码倒计时时长
      isTimeDownTick:false,
      memberIDcode: '',//用户输入的手机验证码
      membereMail: '',
      selectQuestions:[],//密保问题的数组
      memberQuestion: '',
      memberOtherQuestion: '',//自定义密保问题
      memberQuestionIndex: 0,//密保问题的数组下标
      memberQuestionNumber: 0,//密保问题的编号
      isOtherQuestion:false,//密保问题是否选择了"其他"
      memberAnswer: '',
      memberIntroducer:'',//推荐人（非必填）
      isShowAlert: false,
      alertTips: '',//弹窗提示语
      isSubmitBtnClick: false,//是否点击提交(下一步)按钮
      openAccountFromIn:'',//从哪里进入开户步骤
      deviceId:''          ,//设置ID
			comeform:'',
      pwdInputType:'password',
      confirmInputType:'password'
    }
  },
  created: function() {
    var that = this;
		this.comeform = utils.getQueryString(weex.config.bundleUrl,'comeform');


    this.setDeviceId();
    if (that.isAndroid) {
      if (app.bundleVersion()) {
        that.channelName = app.bundleVersion();
      }
    }else {
      if (app.channelName()) {
        if (app.bundleVersion()) {
          that.channelName = app.bundleVersion() + '.' + app.channelName();
        }else {
          that.channelName ='0.0.0.' + app.channelName();
        }
      }
    }
    for (var i = 0; i < appbasedata.phoneAreaCode.length; i++) {
      that.areaCodes.push(appbasedata.phoneAreaCode[i].name);//电话区号名称数组
    }
    that.memberPhoneAreaCode = that.areaCodes[that.memberPhoneAreaCodeIndex];
    for (var i = 0; i < appbasedata.secretQuestion.length; i++) {
      that.selectQuestions.push(appbasedata.secretQuestion[i].question);//密保问题数组
    }
    that.memberQuestion = that.selectQuestions[that.memberQuestionIndex];
    that.memberQuestionNumber = appbasedata.secretQuestion[that.memberQuestionIndex].number;

    storage.getItem('commonUrl',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.serviceUrl = commonUrl.feedback;
        that.bibApi = commonUrl.cmsApi;
				// that.bibApi = 'http://192.168.0.184:10102';
      }
    });
    storage.getItem('memberCenter',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var memberCenter = JSON.parse(value);
      if (memberCenter) {
        that.oauth = memberCenter.oauth;
      }
    });
    storage.getItem('user-original-openAccount',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var open = JSON.parse(value);
      if (open) {
        if (open.from == 'live') {
          that.isLiveRoom = true;
        }
        that.openAccountFrom = open.openName;
      }
    });
    storage.getItem('user_openaccount_from', function(value) {
      if (value ) {
        that.openAccountFromIn = value;
      }
    });
  },
  methods: {
    setDeviceId:function(){
      if ('' == this.deviceId || this.deviceId.length<5 ) {
         this.deviceId = app.deviceId();
      }
    },
    //埋点追踪方法(在input事件里面执行)
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    loadWebView: function(url, title = '') {
      if (url && url.length > 0) {
        var data = {
          title: title,
          url: url,
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "false"
        }, event => {})
      }
    },
    goBack:function(){
      navigator.pop({
        animated: "true"
      }, event => {

      });
    },
    //在线客服超链接
    onclickservice:function(){
      this.loadWebView(this.serviceUrl, '客服');
    },
    //开立账户超链接
    onclickopenaccount:function(){
      this.tabSelect(0);
    },
    //香港和非香港客户的切换
    tabSelect:function(index){
      this.type = index;
    },
    //会员账号 @input @onchange
    inputmembercode:function(event){
      // this.logEvent('input_member_account');
      this.memberCode = event.value;
    },
    onchangemembercode:function(event){
      var that = this;
      that.memberCode = event.value;
      if (/^[a-zA-Z0-9]{6,20}$/.test(that.memberCode)) {
        if (!/^\D/.test(that.memberCode)) {
          that.showAlertTips('请填写非数字开头的会员账号');
        }else {
          //检测会员账号api
          var memberCodeUrl = that.bibApi+'/CheckExist/IFXMCAccount?format=json&UserName='+that.memberCode;
          http.get(encodeURI(memberCodeUrl), function(response) {
            if (response.ok && response.data) {
              if (response.data.isOK) {
                that.memberCodeExist = true;
                that.memberCodeExistValue = that.memberCode;
                that.showAlertTips('该账号已被占用，请重新输入');
              }else {
                that.memberCodeExist = false;
                that.memberCodeExistValue = '';
              }
            }
          })
        }
      }else {
        that.showAlertTips('请填写6-20位大小写英文或数字的会员账号');
      }
    },
    //会员昵称 @input @onchange
    inputmembername:function(event){
      // this.logEvent('input_nickname');
      this.memberName = event.value;
    },
    onchangemembername:function(event){
      var that = this;
      that.memberName = event.value;
      if (!/^[\a-\z\A-\Z\u4E00-\u9FA5]{2,16}$/.test(that.memberName)) {
        that.showAlertTips('请填写2-16位英文/中文/组合的昵称');
      }else {
        if (that.memberName === that.memberCode) {
          that.showAlertTips('请填写与会员账号不同的昵称');
        }else {
          //检测会员昵称api
          var memberNameUrl = that.bibApi+'/CheckExist/IFXMCAccount?format=json&NickName='+that.memberName;
          http.get(encodeURI(memberNameUrl), function(response) {
            if (response.ok && response.data) {
              if (response.data.isOK) {
                that.memberNameExist = true;
                that.memberNameExistValue = that.memberName;
                that.showAlertTips('该昵称已被注册');
              }else {
                that.memberNameExist = false;
                that.memberNameExistValue = '';
              }
            }
          })
        }
      }
    },

    //会员密码 @input @onchange
    inputpwd:function(event){
      // this.logEvent('input_pwd');
      this.memberPassword = event.value;
    },
    onchangememberpwd:function(event){
      this.memberPassword = event.value;
      if (!/^[a-zA-Z0-9]{6,20}$/.test(this.memberPassword)) {
        this.showAlertTips('请填写6-20位大小写英文或数字的会员密码');
      }
    },
    //会员密码（显示隐藏按钮）
    onclickshowpassword:function(){
      this.isShowPassword = !this.isShowPassword;
      if (this.isShowPassword) {
        this.pwdInputType = 'text';
      }else {
        this.pwdInputType = 'password';
      }
    },
    //会员确认密码  @input @onchange
    inputsurepwd:function(event){
      // this.logEvent('input_re_pwd');
      this.memberSurePassword = event.value;
    },
    onchangemembersurepwd:function(event){
      this.memberSurePassword = event.value;
      if (/^[a-zA-Z0-9]{6,20}$/.test(this.memberPassword)) {
        if (this.memberPassword != this.memberSurePassword) {
          this.showAlertTips('确认密码和会员密码不一致');
        }
      }else {
        this.showAlertTips('请先填写6-20位大小写英文或数字的会员密码');
      }
    },
    //确认密码（显示隐藏按钮）
    onclickshowsurepassword:function(){
      this.isShowSurePassword = !this.isShowSurePassword;
      if (this.isShowSurePassword) {
        this.confirmInputType = 'text';
      }else {
        this.confirmInputType = 'password';
      }
    },
    //选择手机区号（列表显示隐藏）
    onclickphoneareacode:function(){
      var that =this;

      picker.pick({
          items: that.areaCodes,
          index:that.memberPhoneAreaCodeIndex,
        }, event => {

          if (event.result === 'success') {
            that.phoneNumberPlaceholder='';
            that.memberPhoneAreaCodeIndex = event.data;
            that.memberPhoneAreaCode = that.areaCodes[that.memberPhoneAreaCodeIndex];

            if (that.memberPhoneAreaCode === '中国大陆(+86)') {
              that.phoneNumberLength = 11;
              that.phoneNumberPlaceholder = '填写您的手机号码';
            }else if (that.memberPhoneAreaCode === '中国香港(+852)'|| that.memberPhoneAreaCode === '中国澳门(+853)') {
              that.phoneNumberLength = 8;
              that.phoneNumberPlaceholder = '填写您的手机号码';
            }else  if (that.memberPhoneAreaCode === '台湾(+886)') {
              that.phoneNumberLength = 10;
              that.phoneNumberPlaceholder = '填写您的手机号码';
            }else if (that.memberPhoneAreaCode === '韩国(+82)' || that.memberPhoneAreaCode === '日本(+81)') {
              that.phoneNumberLength = 11;
              that.phoneNumberPlaceholder = '填写您的手机号码';
            }else if (that.memberPhoneAreaCode === '马来西亚(+60)' || that.memberPhoneAreaCode === '泰国(+66)') {
              that.phoneNumberLength = 9;
              that.phoneNumberPlaceholder = '填写您的手机号码';
            }else if (that.memberPhoneAreaCode === '新加坡(+65)') {
              that.phoneNumberLength = 8;
              that.phoneNumberPlaceholder = '填写您的手机号码';
            }else if (that.memberPhoneAreaCode === '其他') {
              that.phoneNumberLength = 20;
              that.phoneNumberPlaceholder = '请填写国家代码+手机号码';
            }else {
              that.phoneNumberLength = 20;
              that.phoneNumberPlaceholder = '填写您的手机号码';
            }
            if (utils.isAndroid()){
                that.$refs.phoneNum.clearText();
            }
            that.phoneNumberValue = '';

          }

        })
    },
    //输入手机号码
    inputphonenumber:function(event){
      // this.logEvent('input_phone');
      this.memberPhoneNumber = event.value;
      if (this.phoneNumberValue != event.value) {
        this.phoneNumberValue = event.value;
      }
    },
    onchangememberphonenumber:function(event){
      this.memberPhoneNumber = event.value;
      this.getThePhoneNumberCode(this.memberPhoneNumber,this.memberPhoneAreaCode);
    },
    getThePhoneNumberCode:function(number,numberArea){
      if (numberArea === '中国大陆(+86)') {//匹配大陆手机号码的正则  ^[1][3-8]\d{9}$
        if (!/^(122|1[3-9][0-9])\d{8}$/.test(number)) {
          this.showAlertTips('请填写正确的手机号码');
          return false;
        }
      }else if (numberArea === '中国香港(+852)') {//   ^(5|6|8|9)\d{7}$
        if (!/^\d{8}$/.test(number)) {
          this.showAlertTips('请填写正确的手机号码');
          return false;
        }
      }else if (numberArea === '中国澳门(+853)') {//   ^[6]([8|6])\d{5}$
        if (!/^\d{8}$/.test(number)) {
          this.showAlertTips('请填写正确的手机号码');
          return false;
        }
      }else if (numberArea === '台湾(+886)') {//   ^[0][9]\d{8}$
        if (!/^\d{10}$/.test(number)) {
          this.showAlertTips('请填写正确的手机号码');
          return false;
        }
      }else if (numberArea === '其他') {  //     /^[0-9]*$/
        if (!/^[0-9]*$/.test(number)) {
          this.showAlertTips('请填写正确的手机号码和对应的区号');
          return false;
        }
      }
      return true;
    },
    //获取手机验证码按钮
    onclickphoneIDcode:function(){
      this.logEvent('btn_send_verification_code');
      var that = this;
      if (that.idCodeTimeTick>0 || that.isTimeDownTick) {
        return;
      }
      if (!that.memberPhoneNumber || !that.getThePhoneNumberCode(that.memberPhoneNumber,that.memberPhoneAreaCode)) {
        return;
      }
      var selectAreaCode = '';
      for (var i = 0; i < appbasedata.phoneAreaCode.length; i++) {
        if (appbasedata.phoneAreaCode[i].name === that.memberPhoneAreaCode) {
          selectAreaCode = appbasedata.phoneAreaCode[i].code;
        }
      }
      if (selectAreaCode === '') {
        this.showAlertTips('请选择手机区号');
        return ;
      }
      if (that.isTimeDownTick) {
        return ;
      }
      that.phoneCodeKey = 'lHU0M5ORcC52nzAdtxeiEbjb';
      var token = jwt.sign({
        Name:that.memberPhoneNumber,
        Sub:selectAreaCode
      },that.phoneCodeKey,{
        expiresIn:  300 //秒 到期时间
      });
      that.isTimeDownTick = true;
      var getcodeurl = that.bibApi+'/PhoneCode/ValidateAPI?format=json&Phone='+that.memberPhoneNumber+'&PhoneArea='+selectAreaCode;
      //发送验证码
      http.getByHeader(token,encodeURI(getcodeurl), function(response) {
        that.isTimeDownTick = false;
        if (response.ok) {
          that.idCodeTimeTick = 90;
          that.timecountdown();
        }
      })
    },
    //获取验证码倒计时
    timecountdown: function() {
      if (this.idCodeTimeTick <= 0) {
        this.idCodeTimeTick = 0
        this.getIDcode = '发送验证码';
      } else if (this.idCodeTimeTick > 0) {
        setTimeout(this.timecountdown.bind(this), 1000);
        this.idCodeTimeTick--;
        this.getIDcode = '已发送('+this.idCodeTimeTick+'s)';
      }
    },
    //输入手机验证码
    inputIDcode:function(event){
      // this.logEvent('input_phone_verification_code');
      this.memberIDcode = event.value;
    },
    onchangememberIDcode:function(event){
      var that = this;
      that.memberIDcode = event.value;
      if (/^\d{6}$/.test(that.memberIDcode)) {

      }else {
        that.showAlertTips('请填写正确的6位数字手机验证码');
      }
    },
    //输入邮箱地址  /^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/
    inputemail:function(event){
      // this.logEvent('input_email');
      this.membereMail = event.value;
    },
    onchangememberemail:function(event){
      this.membereMail = event.value;
      if (!/^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/.test(this.membereMail)) {
        this.showAlertTips('请填写正确的邮箱');
      }
    },
    //选择密保问题（列表显示隐藏）
    onclickselectquestion:function(){
      picker.pick({
          items: this.selectQuestions,
          index:this.memberQuestionIndex,
        }, event => {
          if (event.result === 'success') {
            this.memberQuestionIndex = event.data;
            this.memberQuestionNumber = appbasedata.secretQuestion[this.memberQuestionIndex].number;
            this.memberQuestion = this.selectQuestions[event.data];
            this.isOtherQuestion = false;
            if (this.memberQuestion === '其他') {
              this.isOtherQuestion = true;
            }
          }
        })
    },
    //输入密保问题
    inputwritequestion:function(event){
      // this.logEvent('input_security_question');
      this.memberOtherQuestion = event.value;
    },
    onchangwritequestion:function(event){
      if (!this.isOtherQuestion) {
        return;
      }
      this.memberOtherQuestion = event.value;
      if (this.memberOtherQuestion.length<=0) {
        this.showAlertTips('请填写密保问题');
      }
    },
    //输入密保问题答案
    inputanswer:function(event){
      // this.logEvent('input_question_answer');
      this.memberAnswer = event.value;
    },
    onchangememberanswer:function(event){
      this.memberAnswer = event.value;
      if (this.memberAnswer.length<=0) {
        this.showAlertTips('请填写密保问题答案');
      }
    },
    //输入推荐人（可以不填）
    inputintroducer:function(event){
      this.memberIntroducer = event.value;
    },
    onchangememberintroducer:function(event){
      this.memberIntroducer = event.value;
    },
    onclicknext:function(){
      this.logEvent('btn_next');

      if (false == utils.checkPwd(this.memberPassword)) {
        this.showAlertTips('请填写6-20位大小写英文或数字的会员密码');
        return;
      }
      if (this.memberPassword != this.memberSurePassword) {
        this.showAlertTips('请填写和会员密码一致的确认密码');
        return;
      }
      var selectAreaCode = '';
      for (var i = 0; i < appbasedata.phoneAreaCode.length; i++) {
        if (appbasedata.phoneAreaCode[i].name === this.memberPhoneAreaCode) {
          selectAreaCode = appbasedata.phoneAreaCode[i].code;
        }
      }
      if (!this.memberPhoneNumber) {
        this.showAlertTips('请填写手机号码');
        return;
      }else {
        if (!this.getThePhoneNumberCode(this.memberPhoneNumber,this.memberPhoneAreaCode)) {
          return;
        }
      }
      if (!/^\d{6}$/.test(this.memberIDcode)) {
        this.showAlertTips('请填写正确的6位数字手机验证码');
        return;
      }
//       if (!/^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/.test(this.membereMail)) {
//         this.showAlertTips('请填写正确的邮箱');
//         return;
//       }
//       if (this.memberQuestion === '请选择') {
//         this.showAlertTips('请选择密保问题');
//         return;
//       }
//       if (this.memberOtherQuestion.length<=0 && this.isOtherQuestion) {
//         this.showAlertTips('请填写密保问题');
//         return;
//       }
//       var questionOther = "";
//       if (this.isOtherQuestion) {
//         questionOther = this.memberOtherQuestion;
//       }
//       if (this.memberAnswer.length<=0) {
//         this.showAlertTips('请正确填写密保问题答案');
//         return;
//       }
      this.setDeviceId();
      var that = this;
      var baseurl = that.bibApi + '/Add/IFXMCAccount';
      // var body1 = "userAccount="+that.memberCode+"&nickName="+that.memberName+"&sex="+that.memberSex;
      // var body1 = "userAccount="+that.memberCode+"&nickName="+that.memberName+"&safeQuestionAnswer="+that.memberAnswer;
      // var body2 = "password="+that.memberPassword+"&ibno="+that.memberIntroducer+"&phoneArea="+selectAreaCode;
      // var body3 = "phone="+that.memberPhoneNumber+"&verCode="+that.memberIDcode+"&email="+that.membereMail;
      // var body4 = "safeQuestion="+that.memberQuestionNumber+"&AdMedium="+that.openAccountFrom+"&AdSource="+that.channelName;
      // var body5 = "safeQuestionOther="+questionOther+"&isLiveRoom="+that.isLiveRoom+"&comeFrom=GlobalApps&format=json";
      // let body = body1+"&"+body2+"&"+body3+"&"+body4+"&"+body5;

			let openAccountFrom = encodeURIComponent(this.openAccountFrom);
      let gacode = `comeFrom=GlobalApps&AdMedium=${openAccountFrom}&AdSource=${this.channelName}&GAID=${this.deviceId}`;
			let body = `phone=${that.memberPhoneNumber}&verCode=${that.memberIDcode}&phoneArea=${selectAreaCode}&password=${that.memberPassword}&isLiveRoom=${that.isLiveRoom}&format=json&${gacode}`;
      if (that.isSubmitBtnClick) {
        return;
      }
      that.isSubmitBtnClick = true;
      http.postForm(baseurl, body, function(response) {
        if (response.ok && response.data) {
          var resultOne = response.data;
          if (resultOne.isOK) {
            that.logEvent('User_sign_success');
            //账号注册成功后登录获取token
            var baseurl = that.oauth+'/account/token';  //  TO DO  password 代替 验证码
            // let body = `UserName=${that.memberPhoneNumber}&Password=${that.memberIDcode}&PhoneArea=${selectAreaCode}&IsMobileMsg=true&ClientID=${ClientID}`;
            let body = `UserName=${that.memberPhoneNumber}&Password=${that.memberPassword}&PhoneArea=${selectAreaCode}&IsMobileMsg=false&ClientID=${ClientID}`;
            // let body = "username="+that.memberCode+"&password="+that.memberPassword;
            http.postForm(baseurl, body, function(responseToken) {
              that.isSubmitBtnClick = false;
              if (responseToken.ok && responseToken.data) {
                if (responseToken.data.isOK) {
                  if (resultOne.results && responseToken.data.results) {
                    var data = {
                      userId: resultOne.results,
                      userName: responseToken.data.results.name,
                      userPwd:responseToken.data.results.enPwd,
                      token: responseToken.data.results.accessToken,
                      isOpen:true,
                    }//开户第一步完成 登录获取用户token并存储
										let user = {
										  userId: resultOne.results,
											userName: responseToken.data.results.name,
										  userPassWord:responseToken.data.results.enPwd,
											token: responseToken.data.results.accessToken,
										};//登录得到的用户信息可以保存下来

										storage.setItem('userInfo', JSON.stringify(user));
                    storage.setItem('user-logintoken-id', JSON.stringify(data));
                    storage.setItem('user_openaccount_from', that.openAccountFromIn);
										if (that.comeform == 'open_demo') {
											navigator.push({
											  url: bundleUrl + 'virtual.js',
											  animated: "true",
											  swipePop: "true",
												currentPop:'true'
											}, event => {})
											return;
										}
                    navigator.push({
                      url: bundleUrl + 'openAccount2.js',
                      animated: "true",
                      swipePop: "true",
                      disableBackPan: 'true',
                      currentPop:'true'
                    }, event => {})
                    return;
                  }
                }else{
									that.showAlertTips('登录异常，请重新登录');
								}
              }else {
                that.showAlertTips('注册完成，请退出并登陆个人中心完成后续操作');
              }
            })
          }else {
            that.isSubmitBtnClick = false;
            if (resultOne.responseStatus && resultOne.responseStatus.errorCode) {
              if (resultOne.responseStatus.errorCode === 'AccountExist') {
                that.showAlertTips('该账号已被注册');
              }else if (resultOne.responseStatus.errorCode === 'EmailExist') {
                that.showAlertTips('该邮箱已被注册');
              }else if (resultOne.responseStatus.errorCode === 'PhoneExist') {
                that.showAlertTips('该号码已被注册');
              }else if (resultOne.responseStatus.errorCode === 'NickNameExist') {
                that.showAlertTips('该昵称已被注册');
              }else if (resultOne.responseStatus.errorCode === 'verCodeIsNull') {
                that.showAlertTips('验证码不能为空');
              }else if (resultOne.responseStatus.errorCode === 'verCodeIsWrong') {
                that.showAlertTips('验证码错误');
              }else if (resultOne.responseStatus.errorCode === 'IntroducerNoExist') {
                that.showAlertTips('推荐人不存在');
              }else if (resultOne.responseStatus.errorCode === 'IntroducerLotNotEnough') {
                that.showAlertTips('亲爱的客户，您填写的账号有误');
              }else if (resultOne.responseStatus.errorCode === 'InBlackList') {
                that.showAlertTips('您好，注册信息无法成功提交，请咨询在线客服');
              }else {
                that.showAlertTips('开户失败，请确认所填信息无误，若无法成功提交，请咨询在线客服');
              }
            }else {
              // that.showAlertTips('开户失败，请确认所填信息无误，若无法成功提交，请咨询在线客服');
            }
          }
        }else {
          that.isSubmitBtnClick = false;
          that.showAlertTips('开户失败，请确认所填信息无误，若无法成功提交，请咨询在线客服');
        }
      })
    },
    showAlertTips: function(tips, time = 2000) {
      if (false == this.isShowAlert) {
        this.isShowAlert = true;
        this.alertTips = tips;
        setTimeout(() => {
          this.isShowAlert = false;
          // this.tips = '';
        }, time)
      }
    },
    checkBoxItemChecked(data){
      this.check = data.checked;
    }
  }
}
</script>


<style scoped>
.text {
  color: #333333;
  color: #9BA1AB;
}
.text-select {
  /* color: #ffffff; */
	color: #454950;
}

.center {
  align-items: center;
  justify-content: center;
}

.margin {
  margin-left: 30px;
  margin-right: 30px;
}

.padding{
  padding-left: 30px;
  padding-right: 30px;
}

.paddingTop{
  padding-top: 34px;
}
.paddingBottom{
  padding-bottom: 34px;
}

.block {
  background-color: #f4f4f4;
  border-bottom-style: solid;
  border-bottom-color: #e2e7eb;
  padding-top: 18px;
  padding-bottom: 18px;
}

.text-center{
  text-align: center;
}

.text-left{
  text-align:left;
}

.color1 {
  color: #454950;
  line-height: 36px;
}

.color2 {
  color: #9ba1ab;
}

.color3 {
  color: #e9302e;
}
.color31 {
  color: #da3f46;
}
.color32 {
  color: #f62b16;
  margin-right: 12px;
}

.color4 {
  color: #454950;
}

.underline {
  text-decoration: underline;
}

.tab {
  height: 136px;
  border-bottom-width: 1px;
  border-bottom-color: #CCCCCC;
  background-color: #ffffff;
  margin: 18px;
}

.tab-block-select {
  flex: 1;
  /* background-color: #e9302e; */
	background-color: #f3ecd7;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
}


.tab-block {
  flex: 1;
  background-color: #ffffff;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
}

.item {
  /* background-color: #f7f4eb; */
	background-color: #F8F8F8;
  margin-left: 4px;
  margin-right: 4px;
  padding-top: 18px;
  padding-bottom: 18px;
  flex: 1;
}

.infoItem {
  flex: 1;
  height: 70px;
  justify-content: space-between;
  align-items: center;
  margin-top: 40px;
}
.infoItem-sex {
  flex: 1;
  height: 70px;
  /* justify-content: space-between; */
  align-items: center;
  margin-top: 40px;
}

.input {
  height: 70px;
  width: 549px;
  border-color: #c6c6c6;
  border-width: 1px;
}
.sex-input{
  justify-content: center;
  align-items: center;
  height: 38px;
  width: 38px;
  margin-right: 20px;
  /* border-color: #c6c6c6;
  border-width: 1px;
  background-color: gray; */
}
.input-size {
  /* width: 500px; */
  flex:1;
  height: 70px;
  font-size: 24px;
  margin-left: 20px;
  margin-right: 20px;
}
.input-size-phone {
  /* width: 500px; */
  flex:1;
  height: 70px;
  font-size: 24px;
  margin-left: 10px;
  margin-right: 0px;
}
.input-down-select{
  width:30px;
  height:70px;
  /* backgroundColor:red; */
  margin-right: 20px;
  align-items: center;
  justify-content: center;
}
.input-size-password{
  /* width: 500px; */
  flex:1;
  height: 70px;
  font-size: 24px;
  margin-left: 20px;
  margin-right: 47px;
}
.password-show-hide{
  width:54px;
  height:70px;
  justify-content: center;
  align-items: center;
  margin-right: 20px;
  /* backgroundColor:red; */
}
.select-phone-areacode{
  width:250px;
  height:70px;
  justify-content: space-between;
  align-items: center;
  border-right-color: gray;
  border-right-width: 1px;
}
.input-phone-IDcode{
  width:366px;
  height:70px;
  border-left-color: #c6c6c6;
  border-right-color: #c6c6c6;
  border-top-color: #c6c6c6;
  border-bottom-color: #c6c6c6;
  border-width: 1px;
}
.send-phone-IDcode{
  width:184px;
  height:70px;
  justify-content: center;
  align-items: center;
  border-color: #2e74e9;
  border-width: 1px;
}
.send-phone-IDcode-gray{
  width:184px;
  height:70px;
  justify-content: center;
  align-items: center;
  border-color: gray;
  border-width: 1px;
}
.send-phone-IDcode-redtext{
  color: #2e74e9;
  font-size: 24px;
  line-height: 36px;
}
.send-phone-IDcode-graytext{
  color: gray;
  font-size: 24px;
  line-height: 36px;
}
.lines{
  lines:2;
}
.bold{
   font-weight: bold;
}
.button{
  width: 750px;
  height: 88px;
  margin-top: 70px;
  background-color: #2e74e9;
  /*border-radius: 8px;*/
  justify-content: center;
  align-items: center;
}

.button-gray{
  width:750px;
  height: 88px;
  margin-top: 70px;
  background-color: gray;
  /*border-radius: 8px;*/
  justify-content: center;
  align-items: center;
}

.cell{
  align-items: center;
  padding-top: 30px;
  padding-bottom: 30px;
  min-height: 100px;
}
.scroller{
    flex: 1;
}
.bottomBorder{
  border-bottom-width: 1px;
  border-bottom-color: #e1e1e1;
}

.circle{
  width: 16px;
  height: 16px;
  margin-right: 20px;
}
.alert-show{
  position:absolute;
  left:0px;
  top:464px;
  right:0px;
  bottom:0px;
  align-items:center;
}
.alert-modul {
  height: 74px;
  border-radius: 37px;
  align-items: center;
  justify-content: center;
  padding-left: 60px;
  padding-right: 60px;
  /* background-color: rgba(0, 0, 0, 0.7); */
  background-color: #4c4c4c;
  opacity:0.68;
}

.eyes{
  width:40px;
  height:40px;
}
</style>
<style  src="../style/common.css" scoped></style>
