<template>
<div class="">
  <div :class="[ipad?'content-ipad':'content']">
    <image v-if="!showDialog" :class="[ipad?'banner-ipad':'banner']" :src="banner" @click="bannerClick"></image>
    <div v-if="showDialog" style="position:absolute;left:0px;right:0px;top:0px;bottom:0px; justify-content:center;align-items:center;">
      <div style="align-items: center;justify-content: center">
        <image style="margin-bottom: 10px;height: 80px;width: 102px;overflow: hidden;align-items: center;" :src="netError"></image>
        <text style="margin-top: 30px;text-align: center;font-size: 28px;color: #454950;">数据加载失败</text>
        <text style="margin-top: 16px;text-align: center;font-size: 28px;color: #454950;">请检查您的手机是否联网</text>
        <div style="margin-top: 30px;width: 190px;height: 60px;border-width: 2px;border-color: #2e74e9;border-radius: 30px;justify-content: center;" @click="dialogConfirmBtnClick()">
          <text style="text-align: center;font-size: 28px;line-height:42px;color: #2e74e9;">刷新重试</text>
        </div>
      </div>
    </div>
  </div>
  <div :class="[ipad?'logo-ipad':'logo']">
    <image :class="[ipad?'logo-ipad':'logo']" v-if="logo" :src="logo"></image>
  </div>
  <div v-if="!showDialog" class="skip" @click="skip()">
    <text class="skip_text"> 跳过 </text>
    <text class="skip_text" v-if="timetick>=0">({{timetick}})</text>
  </div>
  <div v-if="isFirstdownload" class="center" style="background-color: white;position:absolute;left:0px;top:0px;right:0px;bottom:0px;">
    <slider class="first-slider" interval="3000" auto-play="true" index="0" infinite="false" scrollable="true">
      <div class="first-image-bg" v-for="(img,index) in firstImageList">
        <image v-if="ipad" class="first-image_ipad" resize="cover" :src="img.ipadsrc"></image>
        <image v-else class="first-image" resize="cover" :src="img.src"></image>
        <div v-if="index == firstImageList.length-1" :class="[isIphoneX?'first-button-bg-iphoneX':'first-button-bg']">
          <div class="first-button-div" @click="firstShowHomeView()">
            <text style="text-align: center;font-size: 44px;color: #fffefe;font-family: GEO415M;">进入皇御LIVE</text>
          </div>
        </div>
      </div>
      <indicator v-if="firstImageList.length > 1" class="first-indicator"></indicator>
    </slider>
  </div>
</div>
</template>

<script>
import {
  INITSERVER,
  QUOTESERVER
} from '../include/url.js';
var http = require('../include/http.js');
var storage = require('../include/storage.js');
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var dom = weex.requireModule('dom');
var navigator = weex.requireModule('navigator');
var app = weex.requireModule('app');
var utils = require('../include/utils.js');
var firebase = weex.requireModule('firebase');

module.exports = {
  data: function() {
    return {
      bundle: bundleUrl,
      assets: assetsUrl,
      alter: '温馨提示',
      content: '加载初始化文件失败，程序稍后重新加载？',
      confirmText: '好的',
      cancelText: '不了',
      poped: false,
      showDialog: false,
      banner: '', //广告图片
      logo: '', //背景图片
      netError: assetsUrl + 'net_error.png',
      link: '',
      title: '',
      timetick: 5,
      cmsApiHost: '',
      baseImgId: '',
      bannerId: '',
      tagsId: '',
      imageBaseUrl: '', //图片基地址
      skipClick: false, //记录是否点击了跳过按按
      bannerClicked: false,
      isFirstdownload: false, //是否首次下载安装app
      isIphoneX: utils.iphonex(), //判断是否是iphoneX
      firstImageList: [{
        id: '0',
        src: assetsUrl + 'startup_guide.jpg',
        ipadsrc: assetsUrl + 'startup_guide_ipad.jpg',
      }] //首次安装app的引导图片
    }
  },
  beforeCreate: function() {
    var self = this;

    storage.getItem('commonUrl', function(value) {
      if (value && value.length > 0) {
        var commonUrl = JSON.parse(value);
        if (commonUrl) {
          self.cmsApiHost = commonUrl.cmsApi;
          self.imageBaseUrl = commonUrl.imageBaseUrl;
        }
      }
      self.getConfigs();
    })
  },
  created: function() {
    var that = this;
    var domModule = weex.requireModule('dom');
    domModule.addRule('fontFace', {
      'fontFamily': "GEO415M",
      'src': "url('" + assetsUrl + "geo415m_0.ttf')",
    });
    if (this.ipad) {
      this.logo = assetsUrl + 'logo-ipad.jpg';
    } else {
      this.logo = assetsUrl + 'logo.jpg'; //背景图片
    }
    setTimeout(this.countdown.bind(this), 1500);
  },
  computed: {
    iphonex: function() {
      return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' || weex.config.env.deviceModel === 'iPhone11,2' || weex.config.env.deviceModel === 'iPhone11,4' || weex.config.env.deviceModel ===
        'iPhone11,6' || weex.config.env.deviceModel === 'iPhone11,8');
    },
    ipad: function() {
      return weex && /^iPad/.test(weex.config.env.deviceModel);
      // return weex && (weex.config.env.deviceModel.startsWith('iPad') || weex.config.env.deviceModel.startsWith('ipad'));
    }
  },
  methods: {
    //引导页进入皇御首页按钮
    firstShowHomeView: function() {
      if (firebase) {
        firebase.logEventWithName('Boot_page_access');
      }
      navigator.pop({
        animated: "false"
      }, res => {});
      navigator.push({
        url: bundleUrl + 'index.js',
        animated: "false"
      }, event => {
        if (this.isFirstdownload == true) {
          // this.isFirstdownload = false;
          //存储是否首次安装进入app
          storage.setItem('isFirstDownloadApp', false);
        }
      })
    },

    dialogCancelBtnClick() {
      this.showDialog = false;
      this.getConfigs();
    },
    dialogConfirmBtnClick() {
      // this.showDialog = false;
      if (this.timetick <= 0) {
        this.timetick = 5;
        this.countdown();
      }
      this.getConfigs();
    },
    dialogNoPromptClick(e) {
      this.isChecked = e.isChecked;
    },
    getConfigs: function() {
      var that = this;
      http.get(QUOTESERVER+ '?' + Date.now(), function(response) {
        if (response.ok && response.data) {
          storage.setItem('quote', JSON.stringify(response.data))
        }
      })
      http.get(INITSERVER + "?" + Date.now(), function(response) {
        if (response.ok && response.data) {
          for (var key in response.data) {
            storage.setItem(key, JSON.stringify(response.data[key]));
          }
          that.showView();
        } else {
          if (that.cmsApiHost) {
            that.showView();
          } else {
            that.showDialog = true;
          }
        }
      })
    },
    showView: function() {
      var self = this;
      //获取存储的是否首次安装进入app
      // storage.getItem('isFirstDownloadApp', function(value) {
      //   if (value && value === '0' || value === 'false') {
      self.isFirstdownload = false;
      self.loadConfigs();
      //   } else {
      //     self.isFirstdownload = true;
      //     if (firebase) {
      //       firebase.logEventWithName('Boot_page');
      //     }
      //   }
      // });
    },
    loadConfigs: function() {
      var that = this;
      storage.getItem('commonUrl',function(value) {
        if (value && value.length > 0) {
          var commonUrl = JSON.parse(value);
          if (commonUrl) {
            that.cmsApiHost = commonUrl.cmsApi;
            that.imageBaseUrl = commonUrl.imageBaseUrl;
            storage.getItem('nodeIdList', function(value) {
              var nodeIdList = JSON.parse(value);
              // that.baseImgId = nodeIdList.startupBaseImg;
              that.bannerId = nodeIdList.startupBanner;
              that.tagsId = nodeIdList.tags;
              that.getBanner();
            });
          }
        } else {
          //缓存加载失败
          that.showDialog = true;
        }
      });
    },
    getBanner: function() {
      var that = this;
      if ('' === this.cmsApiHost || this.cmsApiHost.length <= 5) {
        return
      }
      var url = this.cmsApiHost + '/ContentUnion/Site?format=json&ChannelIds=' + that.bannerId;
      http.get(url, function(response) {
        if (response.ok && response.data) {
          var results = response.data.Results;
          if (results && results.length > 0) {
            let images = results[0].appImageUrl.split(',');
            if (images && images.length >= 1) {
              if (false == that.ipad) {
                that.banner = images[0].replace('@', that.imageBaseUrl);
              } else if (images.length >= 2) {
                //ipad banner图
                that.banner = images[1].replace('@', that.imageBaseUrl);
              }
            }
            that.link = results[0].LinkUrl;
            that.title = results[0].Title;
          }
        }
        if (response.status < 200 || true != response.ok) {
          that.skipClick = true;
          if (!that.isFirstdownload) {
            setTimeout(that.popView.bind(this), 2000);
          }
        }
      }, 5000)
    },
    popView: function() {
      if (this.poped == true) {
        return;
      }
      this.poped = true;
      navigator.pop({
        animated: "false"
      }, res => {});
      navigator.push({
        url: bundleUrl + 'index.js',
        animated: "false"
      }, event => {
        if (this.isFirstdownload == true) {
          this.isFirstdownload = false;
          //存储是否首次安装进入app
          storage.setItem('isFirstDownloadApp', this.isFirstdownload);
        }
      })
    },
    skip: function() {
      if (firebase) {
        firebase.logEventWithName('Start_page_countdown');
      }
      this.showHomeView();
    },
    showHomeView: function() {
      if (this.skipClick == false) {
        this.skipClick = true;
        this.popView();
      }
    },
    countdown: function() {
      if (this.skipClick || this.bannerClicked) {
        return;
      }
      if (this.timetick <= 0 && this.cmsApiHost && this.cmsApiHost.length > 0 && !this.isFirstdownload) {
        this.showHomeView();
      } else if (this.timetick > 0) {
        setTimeout(this.countdown.bind(this), 1000);
        this.timetick--;
      }
    },
    bannerClick: function() {
      if (firebase) {
        firebase.logEventWithName('Startup_banner');
      }
      if (this.banner && this.banner.length > 0) {
        this.showHomeView();
        if (this.link && this.link.length > 0) {
          this.loadWebView(this.link);
        }
      }
    },
    loadWebView: function(url, title = '') {
      if (url && url.length > 0) {
        var data = {
          title: title,
          url: url,
          source: 'home'
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "false"
        }, event => {})
      }
    }
  },
}
</script>

<style scoped>
.wrap {
  width: 750px;
}

.content {
  flex: 1;
  align-items: center;
  justify-content: center;
  background-Color: #FFFFFF;
}

.center {
  align-items: center;
  justify-content: center;
}


.logo {
  background-color: #FFFFFF;
  width: 750px;
  height: 244px;
}

.banner {
  width: 750px;
  height: 1380px;
  resize: cover;
}

.content-ipad {
  flex: 1;
  align-items: center;
  justify-content: center;
  background-Color: #FFFFFF;
}

.logo-ipad {
  background-color: #FFFFFF;
  width: 750px;
  height: 190px;
}

.banner-ipad {
  width: 750px;
  height: 810px;
  resize: cover;
}

.skip {
  position: absolute;
  top: 66px;
  right: 30px;
  width: 138px;
  height: 60px;
  background-color: rgba(255, 255, 255, 0.3);
  /* background-color: red; */
  align-items: center;
  justify-content: center;
  flex-direction: row;
  border-radius: 30px;
  /* padding-left: 18px; */
}

.skip_text {
  font-size: 28px;
  color: white;
}



.first-slider {
  flex: 1;
  width: 750px;
  /*height: 1000px;*/
}

.first-image-bg {
  flex: 1;
  width: 750px;
  /*height: 700px;*/
}

.first-image {
  flex: 1;
  width: 750px;
  height: 1624px;
  /*height: 700px;*/
}

.first-image_ipad {
  flex: 1;
  width: 750px;
  height: 1000px;
  /*height: 700px;*/
}

.first-button-bg-iphoneX {
  position: absolute;
  align-items: center;
  bottom: 266px;
  width: 750px;
  height: 84px;
}

.first-button-bg {
  position: absolute;
  align-items: center;
  bottom: 156px;
  width: 750px;
  height: 84px;
}

.first-button-div {
  width: 350px;
  height: 84px;
  background-color: #e9302e;
  border-radius: 37px;
  justify-content: center;
  align-items: center
}

.first-indicator {
  position: absolute;
  bottom: 10px;
  left: 0px;
  width: 750px;
  height: 30px;
  item-color: gray;
  item-selected-color: red;
  item-size: 20px;
}
</style>
