<template>
<div style="flex-direction: column;" @foreground="foreground" @background="background">
  <wxtabbar ref="tabbar" :tabItems="tabItems" @tabBarOnClick="tabBarOnClick" selectedColor='#2e74e9' unselectedColor='#9ba1ab'></wxtabbar>
  <div v-if="(!logined || 0 == activity.type) && showActivity && (0 == index) && activity.src" class="container">
    <div @click="showActivity=false;openActivity(activity)">
      <image style="width:730px;height:380px" :src="activity.src"></image>
      <div style="position:absolute;top:0;right:0;width:100px;height:60px;align-items:center" @click="showActivity=false">
        <text style="color :#ffffff;font-size: 34px"> X </text>
      </div>
    </div>
  </div>
  <message></message>
  <!-- <scanGuide :show="showGuide"></scanGuide> -->
  <alertView v-if="showNotification" :src="assets+'img_lan.png'" :content="content" @cancel="showNotification=false;updateNotification()" @confirm="showNotification=false;setNotification()"></alertView>
  <version></version>
  <markAlertView :isShowScore="isShowScoreAlert" @leftBtn="scoreLeftBtn" @bottomBtn="scoreBottomBtn" @rightBtn="scoreRightBtn"></markAlertView>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var storage = require('../include/storage.js');
var firebase = weex.requireModule('firebase');
var app = weex.requireModule('app');
var timer = weex.requireModule('timer');
const jpush = weex.requireModule('jpush');
const media = weex.requireModule('mediaplayer');
var globalEvent = weex.requireModule('globalEvent');
var utils = require('../include/utils.js');
var http = require('../include/http.js');

module.exports = {
  data: function() {
    return {
      assets: assetsUrl,
      index: 0,
      platform: '',
      message: 0,
      type: '',
      title: '',
      content: '',
      data: '',
      cmsApiHost: '',
      tabItems: [{
          index: 0,
          title: '首页',
          icon: assetsUrl + 'tab_home_1.png',
          image: assetsUrl + 'tab_home_1.png',
          selectedImage: assetsUrl + 'tab_home_2.png',
          src: bundleUrl + 'home.js',
          visibility: 'visible',
          top: false,
        },
        {
          index: 1,
          title: '资讯',
          icon: assetsUrl + 'tab_info_1.png',
          image: assetsUrl + 'tab_info_1.png',
          selectedImage: assetsUrl + 'tab_info_2.png',
          src: bundleUrl + 'information.js',
          visibility: 'hidden',
          top: false,
        },
        {
          index: 2,
          title: '直播',
          icon: assetsUrl + 'tab_live_1.png',
          image: assetsUrl + 'tab_live_1.png',
          selectedImage: assetsUrl + 'tab_live_1.png',
          src: bundleUrl + 'empty.js',
          visibility: 'hidden',
          top: false,
        },
        {
          index: 3,
          title: '行情',
          icon: assetsUrl + 'tab_quote_1.png',
          image: assetsUrl + 'tab_quote_1.png',
          selectedImage: assetsUrl + 'tab_quote_2.png',
          src: bundleUrl + 'quotation.js',
          visibility: 'hidden',
          top: false,
        },
        {
          index: 4,
          title: '我的',
          icon: assetsUrl + 'tab_my_1.png',
          image: assetsUrl + 'tab_my_1.png',
          selectedImage: assetsUrl + 'tab_my_2.png',
          src: bundleUrl + 'my.js',
          visibility: 'hidden',
          top: false,
        }
      ],
      timerId: 0,
      activity: {
        type: 0, //1：为短期 0：为长期
        src: '',
        link: ''
      },
      imageBaseUrl: '',
      channelId: 0,
      showActivity: false,
      utm: '',
      logined: false,
      isShowScoreAlert: false, //是否显示评分弹窗
      scroeStarTimeIndex: 20 * 60 * 1000, //20分钟(首页评分倒计时时长)
      scroeStarTimeLive: 5 * 60 * 1000, //5分钟(直播间评分倒计时时长)
      scroeStarTime: 0, //评分弹窗的倒计时时长（毫秒）
      interval: 7 * 24 * 60 * 60 * 1000, //7*24*60分钟(弹窗的间隔时长)
      isLivePage: false, //是否在live页面
      showNotification: false,
      content: '尊敬的客户，直播实况、名师部署，以及赠金福利已为您准备好了，请开启消息推送功能，即时接收最新资讯。',
      showGuide: false
    }
  },
  components: {
    wxtabbar: require('../components/tabbar.vue'),
    version: require('./version.vue'),
    markAlertView: require('./markAlertView.vue'),
    alertView: require('../components/alertView.vue'),
    message: require('../components/message.vue'),
    scanGuide: require('./scanGuide.vue')
  },
  created: function() {
    // var baseURL = bundleUrl(this)
    var that = this;
    if (app) {
      app.setStatusBarStyle(0);
    }
    this.channelName = app.channelName();
    if (this.channelName) {
      this.utm = "ComeFrom=GlobalApps&utm_source=APP&utm_campaign=&utm_content=&utm_term=&utm_medium=" + this.channelName;
    }
    this.checkNotification();
    storage.getItem('userInfo', function(value) {
      if (value && value.length>2) {
        let user = JSON.parse(value);
        if (user.userName) {
          that.logined = true;
        } else {
          that.logined = false;
        }
      }
    });
    storage.getItem('commonUrl', function(value) {
      if (value && value.length > 0) {
        var commonUrl = JSON.parse(value);
        if (commonUrl) {
          that.cmsApiHost = commonUrl.cmsApi;
          that.imageBaseUrl = commonUrl.imageBaseUrl;

          that.getAvatar();
          that.checkEffectPwd()//检测密码是否已失效
        }
        storage.getItem('nodeIdList', function(value1) {
          if (value1 && value1.length > 0) {
            var nodeIdList = JSON.parse(value1);
            that.channelId = nodeIdList.homePromotion;
            that.getActivity();
          }
        });
      }
      that.showActivity = true;
      // that.uploadInfo();
    });

    storage.setItem('liveShowTips', JSON.stringify({
      "showTips": true,
      "mute": false
    })); //每次启动都需要重置标记
    setTimeout(() => {
        if(jpush){
          jpush.getAllTags(function(data) {
            if (data && 0 == data.code) {
              var tags = data.tags;
              if (undefined != tags) {
                storage.setItem('jpush', JSON.stringify(tags));
              }
            }
          });
        }
    }, 500);
    const Stack = new BroadcastChannel('showView')
    Stack.onmessage = function(event) {
      if ('live' === event.data) {
        that.$refs.tabbar.tabItemOnClick({
          index: 2
        })
      } else if ('information' === event.data) {
        that.$refs.tabbar.tabItemOnClick({
          index: 1
        })
      } else if ('quote' === event.data) {
        that.$refs.tabbar.tabItemOnClick({
          index: 3
        })
      }
    }
    media.stop();
    globalEvent.addEventListener("showView", function(e) {
      that.$refs.tabbar.tabItemOnClick({
        index: 2
      })
    });
    //ios的评分弹窗
    if (utils.iOS()) {
      if (that.isLivePage) {
        that.scroeStarTime = that.scroeStarTimeLive;
      } else {
        that.scroeStarTime = that.scroeStarTimeIndex;
      }
      that.onCountdown(); //评分倒计时
      const scoreStar = new BroadcastChannel('scoreStarChannel');
      scoreStar.onmessage = function(event) {
        var score = JSON.parse(event.data);
        that.isLivePage = score.isLivePage;
        if (that.isLivePage) { //进入直播间页面  更改未直播间倒计时时长
          that.scroeStarTime = that.scroeStarTimeLive;
        } else { //进入首页
          if (score.isShowScore) { //直播间进入首页 并且直播间倒计时结束
            that.isShowScoreAlert = true;
            var timestamp = Date.parse(new Date()) / 1000; //获取当前日期
            var score = {
              isScoreStar: false, //是否已评分
              isHadShowScore: true, //是否已弹出过评分弹窗
              isNeedShowScore: true, //是否需要弹出评分弹窗
              firstAlertTime: timestamp, //首次弹出评分弹窗的时间(时间戳 单位 秒)
            }; //用户评分信息
            storage.setItem('userScoreStar', JSON.stringify(score));
          } else { //直播间进入首页 并且直播间倒计时未结束时 更改为首页倒计时时长
            that.scroeStarTime = that.scroeStarTimeIndex;
          }
        }
      }
    }
  },
  methods: {
    //评分弹窗首页倒计时20分钟   直播间倒计时5分钟
    onCountdown: function() {
      var that = this;
      // console.log('输出首页倒计时的时间（毫秒）：'+that.scroeStarTime);
      if (that.scroeStarTime <= 0) {
        storage.getItem('userScoreStar', function(value) {
          if ('' == value || value == undefined || value.length <= 0) {
            if (that.isLivePage) {
              that.isShowScoreAlert = false;
              const scoreStar = new BroadcastChannel('scoreStarChannel');
              var data = {
                isLivePage: that.isLivePage,
                isShowScore: true,
              };
              scoreStar.postMessage(JSON.stringify(data));
            } else {
              that.isShowScoreAlert = true;
            }
            var timestamp = Date.parse(new Date()) / 1000; //获取当前日期
            var score = {
              isScoreStar: false, //是否已评分
              isHadShowScore: true, //是否已弹出过评分弹窗
              isNeedShowScore: true, //是否需要弹出评分弹窗
              firstAlertTime: timestamp, //首次弹出评分弹窗的时间(时间戳 单位 秒)
            }; //用户评分信息
            storage.setItem('userScoreStar', JSON.stringify(score));
            return;
          }
          var userScoreStar = JSON.parse(value);
          if (userScoreStar) {
            if (userScoreStar.isScoreStar) { //是否已评分
              if (userScoreStar.isNeedShowScore) {
                userScoreStar.isNeedShowScore = false;
              }
            } else {
              if (userScoreStar.isHadShowScore) { //是否已弹出过弹窗
                var historyTimestamp = userScoreStar.firstAlertTime; //获取评分弹窗的时间戳
                var nowTimestamp = Date.parse(new Date()) / 1000; //获取当前日期的时间戳
                var TimeDiff = (nowTimestamp - historyTimestamp) * 1000;
                if (TimeDiff > that.interval) { //超过7天
                  userScoreStar.isNeedShowScore = true;
                  userScoreStar.firstAlertTime = nowTimestamp;
                  if (that.isLivePage) {
                    that.isShowScoreAlert = false;
                    const scoreStar = new BroadcastChannel('scoreStarChannel');
                    var data = {
                      isLivePage: that.isLivePage,
                      isShowScore: true,
                    };
                    scoreStar.postMessage(JSON.stringify(data));
                  } else {
                    that.isShowScoreAlert = true;
                  }
                }
              }
            }
          }
          storage.setItem('userScoreStar', JSON.stringify(userScoreStar));
        })
      } else {
        that.scroeStarTime -= 1000;
        setTimeout(that.onCountdown.bind(that), 1000);
      }
    },
    //评分弹窗的底部“下次再说”按钮
    scoreLeftBtn: function() {
      this.isShowScoreAlert = false;
    },
    //评分弹窗的底部“有话要说”按钮
    scoreRightBtn: function() {
      this.isShowScoreAlert = false;
    },
    //评分弹窗的底部“赞”按钮
    scoreBottomBtn: function() {
      this.isShowScoreAlert = false;
    },
    foreground: function() {
      if (this.timerId > 0) {
        clearTimeout(this.timerId);
        this.timerId = 0;
      }
      this.checkNotification();
      this.getAvatar();
    },
    background: function() {
      if (this.timerId > 0) {
        clearTimeout(this.timerId);
        this.timerId = 0;
      }
      //进入后台3小时后自动退出app
      this.timerId = setTimeout(function() {
        app.exitApp(0);
      }, 10800000)
      this.checkEffectPwd()//检测密码是否已失效
    },
    tabBarOnClick: function(e) {
      var that = this;
      if (e.index == 2) {
        that.$refs.tabbar.tabItemOnClick({
          index: this.index
        });
        navigator.push({
          url: bundleUrl + 'live.js',
          animated: "false",
          swipePop: "true",
        }, event => {})
      } else {
        this.index = e.index;
      }

      if (0 == e.index) {
        this.logEvent('Main_HomePage');
      } else if (1 == e.index) {
        this.logEvent('Main_Quotes');
      } else if (2 == e.index) {
        this.logEvent('Main_Live');
      } else if (3 == e.index) {
        this.logEvent('Main_News');
      } else if (4 == e.index) {
        this.showGuide = true;
        this.logEvent('Main_User');
      }
    },
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    close: function() {
      this.message = 0;
    },
    cancel: function() {
      this.message = 0;
    },
    confirm: function() {
      this.message = 0;
      if ('Active' == this.type || 'Article' == this.type) {
        var url = this.data;
        var title = this.articleTitle;

        var para = {
          title: title,
          url: url,
          type: this.type
        }
        storage.setItem('app-url', JSON.stringify(para));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      } else if ('Video' == this.type || 'video' == this.type) {
        this.$refs.tabbar.tabItemOnClick({
          index: 2
        }); //进入直播
      }
    },
    uploadInfo: function() {
      var that = this;
      if (utils.isBlankString(that.cmsApiHost)) {
        return
      }
      storage.getItem('addIdfa', function(value) {
        if ('' == value || value.length <= 5) {
          let deviceId = app.deviceId();
          if ('' == deviceId || undefined == deviceId) {
            return;
          }
          let body = {};
          if (true == utils.isAndroid()) {
            body.AppId = 'com.bibfx.app';
            body.IMEI = deviceId;
            body.DeviceType = "android";
          } else {
            body.AppId = '1401922258';
            body.IDFA = deviceId;
            body.DeviceType = "iOS";
          }
          let idfaUrl = `${that.cmsApiHost}/SevenWheatTech/AppInfo/bibfx`
          http.post(idfaUrl, body, function(response) {
            // console.log("rd response:"+JSON.stringify(response));
            if (response.ok && response.data && (1 == response.data.result || 0 == response.data.result)) {
              storage.setItem('addIdfa', deviceId);
            }
          })
        }
      })
    },
    getActivity: function() {
      var that = this;
      if ('' === this.cmsApiHost || this.cmsApiHost.length <= 5 || undefined == that.channelId) {
        return
      }
      var url = this.cmsApiHost + '/ContentUnion/Site?format=json&OrderByDesc=AddDate&Take=1&ChannelIds=' + that.channelId;
      http.get(url, function(response) {
        if (response.ok && response.data) {
          var results = response.data.Results;
          if (results && results.length > 0) {
            that.activity.src = results[0].appImageUrl.replace('@', that.imageBaseUrl);
            that.activity.bundleJs = results[0].Keyword;
            that.activity.link = results[0].LinkUrl;
            that.activity.type = results[0].activityType; //1：为短期 0：为长期
          }
        }
      })
    },
    openActivity: function(activity) {
      this.logEvent('Home_ADpopups_sign');
      if (activity.bundleJs && activity.bundleJs.length > 4) {
        var data = {
          from: 'home',
          openName: 'Home_ADpopups_sign',
        }
        storage.setItem('user-original-openAccount', JSON.stringify(data));
        storage.setItem('user_openaccount_from', 'index');
        navigator.push({
          url: bundleUrl + activity.bundleJs,
          animated: "false",
          swipePop: "true",
        }, event => {})
      } else if (activity.link && activity.link.length > 4) {
        var param = {
          title: '',
          fontSize: 0,
          url: activity.link
        }
        storage.setItem('app-url', JSON.stringify(param));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    checkNotification: function() {
      let that = this;
      let pushEnable = app.notificationSettingTypes();
      if (pushEnable <= 0) {
        storage.getItem('notification', function(value) {
          if (value && value.length > 0) {
            var now = new Date();
            var duration = now.getTime() - value;
            if (duration >= that.interval) {//7天弹框
              that.showNotification = true;
            } else {
              that.showNotification = false;
            }
          } else {
            that.updateNotification();
          }
        });
      }
    },
    updateNotification: function() {
      let utc = new Date().getTime();
      storage.setItem('notification', '' + utc);
    },
    setNotification: function() {
      this.updateNotification();
      app.openAppSetting();
    },

    getAvatar:function(){
        let that = this;
        if (utils.isBlankString(that.cmsApiHost)) {
          return;
        }
        let url = that.cmsApiHost+'/LiveBasicSysConfig?format=json&&Channel=bibfx&&ConfigName=first_basicSettings';
        http.get(url, function(resp) {
          if (resp && resp.data && resp.data.Results) {
            let dic = JSON.parse(resp.data.Results[0].ConfigValue);

            let defaultPic = dic.defaultPic;
            let manImgUrls = dic.manImgUrls;
            let womanImgUrls = dic.womanImgUrls;

            let headImageInfo = {
              defaultPic: defaultPic,
              manImgUrls : manImgUrls,
              womanImgUrls: womanImgUrls
            }
            storage.setItem('headImageInfo', JSON.stringify(headImageInfo));
          }
        });
      },
      //检测密码是否已失效
      checkEffectPwd:function(){
        let that = this;
        let json = storage.getItemSync('userInfo');
        if (json && json.length > 2) {
           var info = JSON.parse(json);
          if (utils.isBlankString(that.cmsApiHost)) {
            return;
          }
          let url = that.cmsApiHost + '/UserAccounts/UserInfo';
          http.getByHeader(info.token,encodeURI(url), function (response) {
            if (response.data && response.data.IsOK && response.data.Results.length > 0) {
              let liveDic = response.data.Results[0];
              if (liveDic.UserProductResult && liveDic.UserProductResult.Password && info.userPassWord != liveDic.UserProductResult.Password) {
                storage.setItem('userInfo', '{}', function(callback) {});
          			storage.setItem('user-logintoken-id', '{}', function(callback) {});
                storage.setItem('token', '', function(callback) {});
              }
            }
          });
        }
      },

  }
}
</script>

<style scoped>
.container {
  position: fixed;
  left: 0px;
  top: 0px;
  right: 0px;
  bottom: 0px;
  /*兼容H5异常*/
  z-index: 99999;
  justify-content: center;
  align-items: center;
  background-color: rgba(0, 0, 0, 0.6);
}

.content {
  width: 500px;
  background-color: #FFFFFF;
  padding-top: 20px;
  border-radius: 10px;
}

.title {
  margin-top: 25px;
  justify-content: center;
  align-items: center;
  margin-left: 36px;
  margin-right: 36px;
}

.title-size {
  font-size: 32px;
  line-height: 48px;
  lines: 3;
}

.margin {
  margin-top: 20px;
  margin-bottom: 20px;
  margin-left: 36px;
  margin-right: 36px;
}

.version {
  flex: 1;
  height: 68px;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
}

.color {
  color: #454950;
}

.text-size {
  font-size: 28px;
  line-height: 42px;
  text-align: left;
}

.lines {
  lines: 15;
  text-overflow: ellipsis;
}

.footer {
  flex-direction: row;
  align-items: center;
  border-top-color: #F3F3F3;
  border-top-width: 1px;
}

.footer-btn {
  flex-direction: row;
  align-items: center;
  justify-content: center;
  flex: 1;
  height: 88px;
}

.border {
  border-right-color: #F3F3F3;
  border-right-width: 1px;
}

.cancel {
  color: #9ba1ab;
}

.confirm {
  color: #e9302e;
}

.btn-text {
  font-size: 28px;
  text-align: center;
}

.close {
  position: absolute;
  top: 0px;
  right: 0px;
  width: 100px;
  height: 80px;
  flex-direction: row;
  justify-content: flex-end;
}

.close-icon {
  width: 38px;
  height: 38px;
  margin-top: 14px;
  margin-right: 14px;
}
</style>
