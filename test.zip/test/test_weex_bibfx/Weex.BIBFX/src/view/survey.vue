<template>
 <div @viewappear="viewappear" @viewdisappear="viewdisappear">
   <status backgroundColor="#FFFFFF"></status>
   <navigation :title="title" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="goBack"></navigation>
   <!-- <div class="navbar">
     <text class="navbar-title"> {{title}} </text>
     <div @click="goBack" class="goback">
       <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
     </div>
   </div> -->
   <div style="flex-direction:row;marginTop:30px;marginBottom:30px;">
       <div style="align-items:center;flex:1">
         <div class="item-row">
           <div class="whiteline"></div>
           <div class="line"></div>
         </div>
         <div class="circle">
           <div class="innerCircle">
             <text class="font20 text" style="  text-align: center;">01</text>
           </div>
         </div>
         <text class="font30 gold" style="text-align: center;color:#2e74e9">填写资料</text>
       </div>
       <div style="align-items:center;flex:1">
         <div class="item-row">
           <div class="line"></div>
           <div class="line"></div>
         </div>
         <div class="circle">
           <div class="innerCircle">
             <text class="font20 text" style="  text-align: center;">02</text>
           </div>
         </div>
         <text class="font30 gold" style="text-align: center;color:#2e74e9">身份验证</text>
       </div>
       <div style="align-items:center;flex:1">
         <div class="item-row">
           <div class="line"></div>
           <div class="grayline"></div>
         </div>
         <div class="circle">
           <div class="innerCircle gold">
             <text class="font20 text" style="  text-align: center;">03</text>
           </div>
         </div>
         <text class="font30" style="text-align: center;color:#2e74e9">调查问卷</text>
       </div>
       <div style="align-items:center;flex:1">
         <div class="item-row">
           <div class="grayline"></div>
           <div class="grayline"></div>
         </div>
         <div class="circle dashed">
           <div class="innerCircle gray">
             <text class="font20 text" style="text-align: center;">04</text>
           </div>
         </div>
         <text class="font30" style="text-align: center;color:gray">存款激活</text>
       </div>
       <div style="align-items:center;flex:1">
         <div class="item-row">
           <div class="grayline"></div>
           <div class="whiteline"></div>
         </div>
         <div class="circle dashed">
           <div class="innerCircle gray">
             <text class="font20 text" style="text-align: center;">05</text>
           </div>
         </div>
         <text class="font30" style="text-align: center;color:gray">交易密码</text>
       </div>
     </div>
	   <div style="margin: 0px;height: 20px;background-color: #F1F1F1;"></div>
     <scroller alwaysScrollableVertical="false" show-scrollbar="false">
       <div class="align" style="paddingTop:50px;marginBottom:50px;" v-if="!isverify">
         <div style="flex-direction: column;">
           <text class="surveyTitle"> 依照监管部门规定,请填写以下内容</text>
         </div>
         <div class="surveyList" v-for="data  in dataObjs">
           <questioncheckbox :dataItem="data" :config="radioConfig" @checkBoxItemChecked="onCheckBoxItemChecked"></questioncheckbox>
         </div>
       </div>
       <div class="align" style="paddingTop:50px;marginBottom:50px;justify-items: center;align-items: center" v-else>

         <div style="justify-items: center;align-items: center;">
           <div style="width: 750px;margin-top: 146px;justify-items: center;align-items: center;">
               <image style="width: 480px;height:240px;" :src="verifyUrl"/>
           </div>
           <text class="verifyIng font32">正在审核中</text>
         </div>
				 <div style="margin-top: 36px;">
           <richtext class="verifyContent font28" @itemclick="onSubmit()">
             <span>风险评测结果正在审核中，请留意短信通知，如有任何疑问，请联系</span>
             <span style="text-decoration: underline;color:#2e74e9" pseudo-ref="service">在线客服。</span>
           </richtext>
				   <!-- <text class="verifyContent font28">风险评测结果正在审核中，请留意短信通知，如有任何疑问，请联系</text>
				   <div style="position:absolute;left:143px;bottom:0px;backgroundColor:white" @click="onSubmit()">
				     <text class="font28" style="color:#2e74e9;text-decoration: underline;line-height: 46px;">在线客服。</text>
				   </div> -->
				 </div>
				 <!-- <div style="margin-top: 36px;" v-else>
				   <text class="verifyContent font28">风险评测结果正在审核中，请留意短信通知，如有任何疑问，请联系</text>
				   <div style="position:absolute;left:133px;bottom:0px;backgroundColor:white" @click="onSubmit()">
				     <text class="font28" style="color:#2e74e9;text-decoration: underline;line-height: 46px;">在线客服。</text>
				   </div>
				 </div> -->
       </div>
       <!-- <div v-if="isverify" class="submitSevice" @click="onSubmit()">
           <text class="surveySubmit">联系客服</text>
       </div> -->
       <!--<div v-if="!isverify" :class="[isSubmitBtnClick?'submitStyle-gray':'submitStyle']" @click="onSubmit()">-->
           <!--<text class="surveySubmit">提交</text>-->
       <!--</div>-->
   </scroller>
   <div v-if="!isverify" :class="[isSubmitBtnClick?'submitStyle-gray':'submitStyle']" @click="onSubmit()">
     <text class="surveySubmit">提交</text>
   </div>
   <div v-if="isShowAlert" class="alert-show">
     <div class="alert-modul">
       <text style="color:#FFFFFF;font-size:28px;">{{alertTips}}</text>
     </div>
   </div>
   <dialog :show="showDialog" title="" :content="testDialog.text" :confirm="testDialog.rightBtn" :cancel="testDialog.leftBtn" @confirm="dialogRightBtnClick" @cancel="dialogLeftBtnClick"
     @close="dialogCloseBtnClick">
   </dialog>
   <!--<dialog :show="showDialogBack" title="提示" content="返回后，可登陆用户中心查看个人信息和审核状态！" confirm="确认返回" cancel="取消"-->
   <!--@confirm="dialogLeftBtnClickBack" @cancel="dialogRightBtnClickBack" @close="dialogCloseBtnClickBack">-->
   <!--</dialog>-->
   <dialog :show="showDialogBack" title="温馨提示" content="您尚未提交资料，返回后将清空内容，请确认是否继续退出？" confirm="继续填写" cancel="退出"
           @confirm="dialogRightBtnClickBack" @cancel="dialogLeftBtnClickBack" @close="dialogCloseBtnClickBack">
   </dialog>
 </div>
</template>
<script>
    var appdata = require('../survey.json');
    var assetsUrl = require('../include/base-url.js').assetsUrl();
    var bundleUrl = require('../include/base-url.js').bundleUrl();
    var storage = require('../include/storage.js');
    var navigator = weex.requireModule('navigator');
    var utils = require('../include/utils.js');
    var firebase = weex.requireModule('firebase');
    var http = require('../include/http.js');
    module.exports = {
        components: {
          'navigation': require('../components/navigationBar.vue'),
          'questioncheckbox': require('../components/questionCheckBox.vue'),
          'checkbox': require('../components/checkbox.vue'),
          'status': require('../components/statusbar.vue'),
          'dialog': require('../components/dialog.vue'),
        },
        data: function () {
            return {
                title: "调查问卷",
                userId:'',//
                userToken:'',
                serviceUrl: '',
                bibApi:'',//网络请求基地址
                dataObjs:appdata.survey,//调查问卷的问题和答案以及选择的答案
                assets: assetsUrl,
                promptUrl: assetsUrl + 'auth/selectTip.png',
                verifyUrl: assetsUrl + 'verifying.png',
                verifyStatus:'',//调查问卷的状态
                isverify: false,//是否在审核中
                isSubmitBtnClick: false,//是否点击提交(下一步)按钮
                // submitText: "提交",
                radioConfig:{
                checkedIcon:assetsUrl+'radio/checked.png',//选中图标
                unCheckedIcon:assetsUrl+'radio/unchecked.png',//未选中图标
                checkedMoreIcon:assetsUrl+'radio/checked_disabled.png',//多选图标
                answerSelectedColor:"#666666",//选中答案文字颜色
                answerColor:"#666666",//答案文字颜色
                questionColor:"#333333",//问题文字颜色
                tipTextColor:"#ff0000",//提示语文字颜色
                tipText:"请选择选项",//提示语文字
                tipImg:assetsUrl+'auth/selectTip.png',//提示语图标
                isChangeSelectedColor:false,//选中是否改变答案文字颜色
              },
              isAndroid:utils.isAndroid(),
              testDialog:{},
              testIng:{result:'审核中',text:'您的投资风险测评审核中，审核结果将以短信形式发送。如有任何疑问，请联系在线客服！',rightBtn:'确认',leftBtn:'在线客服'},
              testFailed:{result:'审核失败',text:'您的测评结果未达开户标准，请重新测试，或联系在线客服了解详情！',rightBtn:'重新测评',leftBtn:'在线客服'},
              showDialog: false,//审核结果弹窗
              showDialogBack: false,//返回提示弹窗
              isShowAlert: false,//提示弹窗
              alertTips: '',//弹窗提示语
              openAccountFrom:'',//从哪里进入开户步骤
            }
        },
        created: function () {
            var that = this;

            let isverify = utils.getQueryString(weex.config.bundleUrl, 'isverify');
            if (isverify == 1){
              that.isverify = true;
            }

            storage.getItem('user_openaccount_from', function(value) {
              if (value ) {
                that.openAccountFrom = value;
              }
            });
            storage.getItem('commonUrl',function (value) {
                if ('' == value || value == undefined || value.length <= 0) {
                    return
                }
                var commonUrl = JSON.parse(value);
                if (commonUrl) {
                    that.serviceUrl = commonUrl.feedback;
                    that.bibApi = commonUrl.cmsApi;
                    // that.testDialog = that.testFailed;
                    //获取调查问卷的问题
                    var surveyUrl = that.bibApi+'/MC/CommonConfig?Key=AppKYCQuestion';
                    http.get(encodeURI(surveyUrl), function(response) {
                      if (response.ok && response.data) {
                        if (response.data.IsOK && response.data.Results) {
                          that.dataObjs = JSON.parse(response.data.Results);
                        }
                      }
                    })

                    storage.getItem('user-logintoken-id', function(value) {
                      if (value ) {
                        var data = JSON.parse(value);
                        that.userId = data.userId;
                        that.userToken = data.token;
                        var surveyStatus = that.bibApi+'/IFXAccountDetails/IFXMC?format=json&NeedAttachmentIamges=false';
                        http.getByHeader(that.userToken,encodeURI(surveyStatus), function(responseStatus) {
                          if (responseStatus.ok && responseStatus.data) {
                            if (responseStatus.data.Results.length>0) {
                              var dataResult = responseStatus.data.Results[0];
                              //0:Default(默认) 1:NULL(无 None)   2:(Unprocessing)未处理  3:(Approving)审核中  4:(ApprovedPass)审核完成
                              //  4:(ApprovedFail)审核退回
                              that.verifyStatus = dataResult.Member.KycStatus;
                              //调查问卷的逻辑处理
                              if (that.verifyStatus == 'ApprovedFail') {
                                that.showDialog = true;
                                that.testDialog = that.testFailed;
                              }else if (that.verifyStatus == 'Unprocessing' || that.verifyStatus == 'Approving') {
                                that.showDialog = true;
                                that.testDialog = that.testIng;
                              }else {
                                that.showDialog = false;
                                that.testDialog = {};
                              }
                            }
                          }
                        })
                      }
                    });
                }
            });
        },
        methods: {
          //埋点追踪方法
          logEvent: function(name) {
            if (firebase) {
              firebase.logEventWithName(name);
            }
          },
          viewdisappear:function(){

          },
          viewappear:function(){
            var that = this;
            if (that.verifyStatus == 'ApprovedFail') {
              that.showDialog = true;
              that.testDialog = that.testFailed;
            }else if (that.verifyStatus == 'Unprocessing' || that.verifyStatus == 'Approving') {
              that.showDialog = true;
              that.testDialog = that.testIng;
            }else {
              that.showDialog = false;
              that.testDialog = {};
            }
          },
          //返回弹窗右上角按钮
          dialogCloseBtnClickBack() {
            this.showDialogBack = false;
          },
          //返回弹窗左下角按钮
          dialogLeftBtnClickBack() {
            this.showDialogBack = false;
            if (this.openAccountFrom === 'live') {
              navigator.pop({
                url: bundleUrl + 'live.js',
                animated: "false"
              }, event => {

              });
            }else {
              navigator.pop({
                url: bundleUrl + 'index.js',
                animated: "false"
              }, event => {

              });
            }
          },
          //返回弹窗右下角按钮
          dialogRightBtnClickBack() {
            this.showDialogBack = false;
          },
          goBack: function() {
            this.showDialogBack = true;
          },

          //弹窗右上角按钮
          dialogCloseBtnClick() {
            this.showDialog = false;
            if (this.testDialog.result === '审核中') {
              this.isverify = true;
            }
          },
          //弹窗左下角按钮
          dialogLeftBtnClick() {
            this.showDialog = false;
						this.loadWebView(this.serviceUrl, '客服');
          },
          //弹窗右下角按钮
          dialogRightBtnClick() {
            this.showDialog = false;
						if (this.testDialog.result === '审核中') {
						  this.isverify = true;
						}
          },
          //底部提交（联系客服）按钮
          onSubmit: function () {
              var that = this;
              var isShow = false;
              if (that.isverify) {
                that.loadWebView(that.serviceUrl, '客服');
              } else {
                that.logEvent('btn_kyc_submit');
                if (that.dataObjs.length == 0) {
                  that.showAlertTips('网络异常，请退出重试');
                }
                var dic_QandA = {};//问题和答案的字典
                for (var i = 0; i < that.dataObjs.length; i++) {
                  if (that.dataObjs[i].selected.length>0) {
                    that.dataObjs[i].isShowTip = false;
                    var arr = [];//多选答案的数组
                    for (var j = 0; j < that.dataObjs[i].selected.length; j++) {
                      arr.push(that.dataObjs[i].selected[j].answerCode);
                    }
                    dic_QandA[that.dataObjs[i].problemCode] = arr.join(',');
                  }else {
                    that.dataObjs[i].isShowTip = true;
                    isShow = true;
                  }
                }
                if (isShow) {
                  that.showAlertTips('请选择所有的选项');
                  return;
                }
                if (that.isSubmitBtnClick) {
                  return;
                }
                that.isSubmitBtnClick = true;
                var baseurl = that.bibApi + '/MemberQuestionsApproval/bibfxMC';
                var body = 'format=json&Json='+ JSON.stringify(dic_QandA);//结果json串
                http.postFormToken(that.userToken, baseurl, body, function(response) {
                  that.isSubmitBtnClick = false;
                  // console.log("bj 调查问卷提交结果:"+JSON.stringify(response));
                  if (response.ok && response.data) {
                    var result = response.data;
                    if (result.IsOK) {
                      that.showDialog = true;
                      that.testDialog = that.testIng;
                    }else {
                      that.showAlertTips('调查问卷提交失败，请重试');
                    }
                  }else {
                    that.showAlertTips('调查问卷提交失败，请重试');
                  }
                });
              }
          },
          showAlertTips: function(tips, time = 2000) {
            if (false == this.isShowAlert) {
              this.isShowAlert = true;
              this.alertTips = tips;
              setTimeout(() => {
                this.isShowAlert = false;
                // this.tips = '';
              }, time)
            }
          },
          loadWebView: function (url, title = '') {
              if (url && url.length > 0) {
                  var data = {
                      title: title,
                      url: url,
                  }
                  storage.setItem('app-url', JSON.stringify(data));
                  navigator.push({
                      url: bundleUrl + 'webview.js',
                      animated: "false"
                  }, event => {
                  })
              }
          },
          //选择答案
          onCheckBoxItemChecked(data) {
              for (var i = 0; i < this.dataObjs.length; i++) {
                if (this.dataObjs[i].id == data.questionId) {//对应问题
                  if (this.dataObjs[i].isSelectMore && !data.answer.isSelected) {//多选 并且是取消选中答案
                    for (var j = 0; j < this.dataObjs[i].selected.length; j++) {
                      if (this.dataObjs[i].selected[j].id == data.answer.id) {//已选答案id和选中取消的答案id相等
                        this.dataObjs[i].selected.splice(j,1,);
                      }
                    }
                  }else {//单选  或者多选的选中答案
                    if (this.dataObjs[i].isSelectMore) {//多选的选中答案
                      if (data.answer.answerCode == 'nothing') {//多选   选中nothing
                        this.dataObjs[i].selected.splice(0,this.dataObjs[i].selected.length,);
                        this.dataObjs[i].selected.push(data.answer);
                      }else {//多选   未选中nothing
                        if (this.dataObjs[i].selected.length==1 && this.dataObjs[i].selected[0].answerCode == 'nothing') {//已选nothing的基础上在选择其他答案
                          this.dataObjs[i].selected.splice(0,this.dataObjs[i].selected.length,);
                          this.dataObjs[i].selected.push(data.answer);
                        } else {
                          this.dataObjs[i].selected.push(data.answer);
                        }
                      }
                    } else {//单选的选中答案
                      this.dataObjs[i].selected.splice(0,this.dataObjs[i].selected.length,);
                      this.dataObjs[i].selected.push(data.answer);
                    }
                  }
                }
              }
          },
        }
    }
</script>

<style  src="../style/common.css" scoped>
</style>
<style scoped>
.align {
  margin-left: 25px;
  margin-right: 25px;
}
.item-row {
  position: absolute;
  left: 0px;
  right: 0px;
  top: 0px;
  flex-direction: row;
}
.line {
  flex: 1;
  height: 20px;
  border-bottom-width: 1px;
  border-bottom-color: #2e74e9;
}
.whiteline {
  flex: 1;
  height: 20px;
}
.grayline {
  flex: 1;
  height: 20px;
  border-bottom-width: 1px;
  border-bottom-color: #ABABAB;
  /* border-bottom-style: dashed; */
}
.circle {
  width: 40px;
  height: 40px;
  border-radius: 20px;
  border-color: #2e74e9;
  border-width: 1px;
  align-items: center;
  justify-content: center;
  background-color: white;
  margin-bottom: 15px;
}
.dashed {
  border-style: dashed;
  border-color: #AA9B6A;
}
.innerCircle {
  width: 30px;
  height: 30px;
  background-color: #2e74e9;
  border-radius: 15px;
  align-items: center;
  justify-content: center;
}
.gray {
  background-color: #ABABAB;
}
.text {
  color: white;
}
.topBorder {
  border-top-color: #f1f1f1;
  border-top-width: 1px;
  border-top-style: solid;
}
    .surveyTitle {
        color: #666666;
        line-height: 46px;
        font-size: 30px;
    }

    .surveyList {
        /* width: 750px; */
        margin-top: 24px;
    }

    .problem {
        color: #333333;
        font-size: 28px;
        line-height: 36px;
    }

    .answerItem {
      color: #666666;
      font-size: 28px;
    }

    .selectPrompt {
        color: #ff0000;
        font-size: 24px;
        text-align: center;
        padding-top: 5px;
    }

    .verifyContent {
        color: red;
				color: #9BA1AB;
        /* font-size: 28px; */
        line-height: 46px;
        margin-top: 10px;
        /* margin-left: 25px; */
        /* margin-right: 25px; */
    }

    .surveySubmit {
        color: white;
        font-size: 32px;
        text-align: center;
    }

    .ans {
        flex-wrap: wrap;
        margin-top: 20px;
        margin-left: 22px;
        margin-right: 22px;
    }

    .verifyIng {
        /* color: #999999; */
				color: #454950;
        /* font-size: 32px; */
        line-height: 36px;
        margin-top: 28px;
    }
    .submitStyle {
      height: 90px;
      width: 750px;
      /*margin-bottom: 70px;*/
      /* margin-top: 216px; */
      background-color: #2e74e9;
      /*border-radius: 8px;*/
      justify-content: center;
      align-items: center;
      /*margin-left: 25px;*/
      /*margin-right: 25px;*/
    }
    .submitStyle-gray{
      height: 90px;
      width: 750px;
      /*margin-bottom: 70px;*/
      background-color: gray;
      /*border-radius: 8px;*/
      justify-content: center;
      align-items: center;
      /*margin-left: 30px;*/
      /*margin-right: 30px;*/
    }
    .submitSevice{
      height: 90px;
      /* margin-bottom: 70px; */
      margin-top: 216px;
      background-color: #e9302e;
      border-radius: 8px;
      justify-content: center;
      align-items: center;
      margin-left: 30px;
      margin-right: 30px;
    }
    .alert-show{
      position:absolute;
      left:0px;
      top:464px;
      right:0px;
      bottom:0px;
      align-items:center;
    }
    .alert-modul {
      height: 74px;
      border-radius: 37px;
      align-items: center;
      justify-content: center;
      padding-left: 60px;
      padding-right: 60px;
      /* background-color: rgba(0, 0, 0, 0.7); */
      background-color: #4c4c4c;
      opacity:0.68;
    }
</style>
