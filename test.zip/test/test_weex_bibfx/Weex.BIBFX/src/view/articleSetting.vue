<template>
<div @viewdisappear="viewdisappear" style="background-color: #e4e4e4">
  <status backgroundColor="#FFFFFF"></status>
  <navigation :title="title" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="onBack()"></navigation>
  <!-- <div class="navbar">
    <text class="navbar-title"> {{title}} </text>
    <div v-on:click="onBack()" class="goback">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div>
  </div> -->
  <web v-if="url" :src="url+fontSize" class="webview"></web>
  <div :style="{backgroundColor:'#282828',height:iphonex?'250px':'160px'}">
    <div class="item">
      <text class="item-text">字体调整</text>
    </div>
    <div style="flex-direction:row;height:48px;width:750px;justify-content: space-between; align-items: center;">
      <div class="item-row"></div>
      <div style="margin-left:75px; width:100px;height:48px;justify-content:center;align-items:center;" @click="change(0)">
        <image style="width:10px;height:10px;" :src="assets+'icon1.png'"></image>
      </div>
      <div style="width:100px;height:48px;justify-content:center;align-items:center;" @click="change(1)">
        <image style="width:14px;height:14px;" :src="assets+'icon2.png'"></image>
      </div>
      <div style="margin-right:75px; width:100px;height:48px;justify-content:center;align-items:center;" @click="change(2)">
        <image style="width:18px;height:18px;" :src="assets+'icon3.png'"></image>
      </div>
      <text style="position:absolute;top:0px;left:50; width:48px;line-height: 48px;text-align:center;color:#ffffff;font-weight: bold;font-size:32px;">小</text>
      <text style="position:absolute;top:0px;right:50; width:48px;line-height: 48px;text-align:center;color:#ffffff;font-weight: bold;font-size:36px;">大</text>
      <image  style="position:absolute;top:0px;width:48px;height:48px;" v-bind:style="{left:left}" :src="assets+'icon.png'" @touchstart="touchstart" @touchmove="move" @touchend="touchend" @touchcancel="cancel"></image>
    </div>
  </div>
  <message></message>
</div>
</template>

<script>
var storage = require('../include/storage.js');
var assetsUrl = require('../include/base-url.js').assetsUrl();
var bundleUrl = require('../include/base-url.js').bundleUrl();
var animation = weex.requireModule('animation');
var modal = weex.requireModule('modal');
var navi = weex.requireModule('navigator');
var dom = weex.requireModule('dom');
const app = weex.requireModule('app');
var utils = require('../include/utils.js');
var navigator = weex.requireModule('navigator');
const jpush = weex.requireModule('jpush');
var firebase = weex.requireModule('firebase');

module.exports = {
  components: {
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'message': require('../components/message.vue'),
  },
  data: function() {
    return {
      title: '文章页字体设置',
      assets: assetsUrl,
      switchOn: assetsUrl + 'on.png',
      switchOff: assetsUrl + 'off.png',
      enable: true,
      isIOS: utils.iOS(),
      preview:assetsUrl + 'on.png',
      sizeIndex:1,
      left:350,
      fontSize:38,
      url:assetsUrl+'fontsize.html?fontSize=',
      iphoneX:false
    }
  },
  beforeCreate: function() {
    var self = this;
    this.iphoneX = utils.iphonex();
    storage.getItem('fontSetting', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        self.sizeIndex = 1;
        self.fontSize = 38;
        return
      }
      var seting = JSON.parse(value);
      self.enable = seting.enable;
      self.fontSize = seting.fontSize;
      self.change(seting.sizeIndex);
    });
  },
  created: function() {

  },
  methods: {
    onBack: function() {
      navi.pop({
        animated: "true"
      }, res => {});
    },
    viewdisappear: function() {
      storage.setItem('fontSetting',JSON.stringify({
        sizeIndex:this.sizeIndex,
        fontSize:this.fontSize
      }));
    },
    change:function(idx){
      if (idx>=0 && idx<=2) {
        this.left =100+idx*250;
        this.sizeIndex=idx;
        this.fontSize = 32+idx*4;
      }
    },
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    touchstart:function(e){
      this.pointX = e.changedTouches[0].screenX;
    },
    move: function(e) {
      this.offsetX = parseInt(e.changedTouches[0].screenX - this.pointX);
      this.left = this.left + this.offsetX;
      if (this.left<100) {
        this.left = 100;
      }else if (this.left >= 600){
        this.left = 600;
      }
      this.pointX = e.changedTouches[0].screenX;
    },
    touchend: function(e) {
      if (this.left <(100+125)) {
        this.left = 100;
        this.sizeIndex = 0;
        this.fontSize = 32;
      }else if(this.left >(625-125)){
        this.left = 600;
        this.sizeIndex = 2;
        this.fontSize = 42;
      }else {
        this.left = 350;
        this.sizeIndex = 1;
        this.fontSize = 38;
      }
    },
    cancel:function(e){
      if (this.left <(100+125)) {
        this.left = 100;
        this.sizeIndex = 0;
        this.fontSize = 32;
      }else if(this.left >(600-125)){
        this.left = 600;
        this.sizeIndex = 2;
        this.fontSize = 42;
      }else {
        this.left = 350;
        this.sizeIndex = 1;
        this.fontSize = 38;
      }
    }
  }
}
</script>

<style scoped>
.goback {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 120px;
  padding-left: 30px;
  justify-content: center;
}

.navbar-title {
  font-size: 36px;
  color: white;
  line-height: 54px;
  text-align: center;
}

.navbar {
  width: 750px;
  height: 88px;
  background-color: #2e74e9;
  align-items: center;
  justify-content: center;
}

.item {
  flex-direction: row;
  justify-content: center;
  align-items: center;
  padding-left: 26px;
  padding-right: 26px;
  margin-top: 24px;
}

.item-border-top{
  border-top-width: 1px;
  border-top-color: #c7c7c7;
}

.item-border-bottom{
  border-bottom-width: 1px;
  border-bottom-color: #c7c7c7;
}

.item-text {
  font-size: 28px;
  line-height: 34px;
  color: #ffffff;
  font-weight: bold;
}

.item-row{
  position: absolute;
  left: 125px;
  right: 125px;
  top: 22px;
  height: 4px;
  background-color: #c7c7c7;
}

.size-0{
  width: 408px;
  height: 228px;
}
.size-1{
  width: 578px;
  height: 324px;
}
.size-2{
  width: 680px;
  height: 381px;
}
.webview {
  flex: 1;
  width: 750px;
}
</style>
