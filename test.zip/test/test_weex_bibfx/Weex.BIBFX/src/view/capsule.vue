<template>
<div style="backgroundColor:white;">
  <status backgroundColor="#FFFFFF"></status>
  <navigation :title="title" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="goBack"></navigation>
  <!-- <div class="navibar">
    <text class="navbar-title"> {{title}} </text>
    <div @click="goBack" class="navbar-button">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div>
  </div> -->
  <div class="sortord">
    <div class="sortord-item" v-for="(item , index) in condition" @click="sort(index)">
      <text :class="[index == sortIndex?'title-highlight':'title-normal']"> {{item}}</text>
      <image class="sortord-icon" :src="assets+(index == sortIndex?'sortH.png':'sort.png')"></image>
    </div>
  </div>
  <list alwaysScrollableVertical="false">
    <cell class="topic border" v-for="(item , index) in topicItem" @click="showTopic(item)">
      <image class="topic-icon" :src="item.icon"></image>
      <text class="topic-title">#{{item.Title}} </text>
      <text v-if="0 == sortIndex" class="topic-count">{{item.time}} </text>
      <text v-if="1 == sortIndex" class="topic-count">{{(item.count == undefined || item.count == 0) ?'暂无文章':item.count+'篇'}} </text>
      <div class="topic-arrow">
        <image class="arrow" :src="assets+'arrow1.png'"></image>
      </div>
    </cell>
  </list>
  <message></message>
</div>
</template>

<script scoped>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var storage = require('../include/storage.js');
var firebase = weex.requireModule('firebase');
var http = require('../include/http.js');
module.exports = {
  components: {
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'message': require('../components/message.vue'),
  },
  computed: {
    iphonex: function() {
      return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' || weex.config.env.deviceModel === 'iPhone11,2' || weex.config.env.deviceModel === 'iPhone11,4' || weex.config.env.deviceModel === 'iPhone11,6' || weex.config.env.deviceModel === 'iPhone11,8');
    }
  },
  data: function() {
    return {
      assets: assetsUrl,
      title: '话题胶囊',
      sortIndex: 0,
      condition: ['最近更新', '文章更多'],
      topicItem: [],
      cmsApiHost:'',
      imageBaseUrl:'',
      tagsId:'',
    }
  },
  beforeCreate:function(){


  },
  created: function() {
    var selfThis = this;
    this.logEvent('Tag_page');
    storage.getItem('commonUrl', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        selfThis.cmsApiHost = commonUrl.cmsApi; //接口基址
        selfThis.imageBaseUrl = commonUrl.imageBaseUrl;
      }
    });
    storage.getItem('nodeIdList', function(value) {
        var nodeIdList = JSON.parse(value);
        if (nodeIdList){
            selfThis.tagsId = nodeIdList.tags;
            selfThis.getTags();
        }
    });

  },
  methods: {
    goBack: function() {
      navigator.pop({
        animated: "true"
      }, res => {});
    },
    logEvent:function(name){
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    getTags: function() {
      var that = this;
      if ('' === that.cmsApiHost || that.cmsApiHost.length <= 5) {
        return
      }
      var url =   that.cmsApiHost +'/ContentUnion/Site?format=json&OrderByDesc=LastUpdate&ChannelIds=' + that.tagsId;
      http.get(url, function(response) {
        if (response.ok && response.data) {
          var results = response.data.Results;
          if (results && results.length > 0) {
            storage.setItem("topic", JSON.stringify(results));
          } else {
            storage.setItem("topic", '[]');
          }
        }
        that.getCaheData();
      })
    },
    getCaheData:function(){
        var  selfThis=this;
         storage.getItem("topic", function(data) {
          if (data) {
            selfThis.topicItem = JSON.parse(data);
            for (var i = 0; i < selfThis.topicItem.length; i++) {
              let images = selfThis.topicItem[i].appImageUrl.split(',', 3);

              if (images && images.length >= 3) {
                selfThis.topicItem[i].icon = images[2].replace('@', selfThis.imageBaseUrl);
              }
              if (selfThis.topicItem[i].LastUpdate && selfThis.topicItem[i].LastUpdate.length>0) {
                selfThis.topicItem[i].time = selfThis.showTime(parseInt(selfThis.topicItem[i].LastUpdate.replace('/Date(','').replace(')/','').substring(0,13)));
              }else {
                selfThis.topicItem[i].time = selfThis.showTime(0)
              }
            }
          }
        });
     },
    compare: function(obj1, obj2) {
      var val1 = this.sortIndex?obj1.count:obj1.LastUpdate;
      var val2 = this.sortIndex?obj2.count:obj2.LastUpdate;
      if (val1 == undefined || val2 == undefined) {
        return 1;
      }
      if (1 == this.sortIndex) {
        val1 = ~~(val1);
        val2 = ~~(val2);
      }

      if (val1 > val2) {
        return -1;
      } if (val1 = val2) {
        return 0;
      } else {
        return 1;
      }
    },
    sort: function(type) {
      this.sortIndex = type;
      this.topicItem.sort(this.compare);
      if (0 == this.sortIndex) {
        this.logEvent('Tag_page_latest');
      }else {
        this.logEvent('Tag_page_sum');
      }
    },
    showTime: function (time) {
        if (time == undefined || time == '' || 0 == time) {
          return '暂无文章';
        }
        var date = new Date(time);
        var now = new Date();
        var duration = (now.getTime() - date.getTime()) / 1000;
        if (duration < 60) {
            return duration+'秒前更新';
        } else if (duration < 3600) {
            return Math.floor(duration / 60) + '分钟前更新';
        } else if (duration < 86400) {
            return Math.floor(duration / 3600) + '小时前更新';
        } else if (duration < 172800) {
            return '1天前更新';
        } else {
            return (date.getMonth() + 1) + '月' + date.getDate() + '日更新';
        }
    },
    showTopic: function(topic) {
      let id = topic.Id;
      if (id >0 || id.length > 0) {
        storage.setItem('tags', JSON.stringify({
          'title': topic.Title,
          'id': topic.Id
        }));
        navigator.push({
          url: bundleUrl + 'topic.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
  }
}
</script>

<style scoped>
.navibar {
  height: 88px;
  background-color: #2e74e9;
  align-items: center;
  justify-content: center;
}

.navbar-title {
  font-size: 36px;
  line-height: 54px;
  text-align: center;
  color: white;
}

.navbar-button {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 120px;
  padding-left: 30px;
  justify-content: center;
}

.sortord {
  flex-direction: row;
  border-bottom-width: 20px;
  border-bottom-color: #f1f1f1;
  border-bottom-style: solid;
  justify-content: space-around;
}

.sortord-item {
  flex-direction: row;
  align-items: center;
  justify-content: center;
  height: 88px;
}

.title-normal {
  text-align: center;
  text-overflow: ellipsis;
  font-size: 28px;
  color: #454950;
}

.title-highlight {
  text-align: center;
  text-overflow: ellipsis;
  font-size: 28px;
  /*color: #e9302e;*/
  color: #2e74e9;
}

.sortord-icon {
  width: 44px;
  height: 44px;
}

.topic {
  height: 132px;
  padding-left: 30px;
  padding-right: 30px;
  flex-direction: row;
  align-items: center;
}

.topic-icon {
  width: 72px;
  height: 72px;
  margin-right: 30px;
}

.topic-title {
  font-size: 32px;
  color: #454950;
  margin-right: 14px;
}

.topic-count {
  font-size: 28px;
  color: #9ba1ab;
}

.topic-arrow {
  flex-direction: row;
  flex: 1;
  justify-content: flex-end;
  align-items: center;
}

.arrow {
  width: 12px;
  height: 22px;
}

.border {
  border-bottom-color: #f1f1f1;
  border-bottom-width: 1px;
  border-bottom-style: solid;
}
</style>
