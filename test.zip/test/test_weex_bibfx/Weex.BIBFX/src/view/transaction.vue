<template >
  <div style="backgroundColor:#ECECF2">
    <status backgroundColor="white"></status>
    <div class="container">
      <image :src="leftItemSrc" class="left-image" v-on:click="onclickleftitem"></image>
      <div class="center">
          <text class="transaction-text">交易</text>
      </div>
      <image :src="rightItemSrc" class="right-image" v-on:click="onclickrightitem"></image>
    </div>
    <image :src="tranSrc" class="trans-image"></image>
    <div class="trans-bottom">
          <div class="cell" style="height:88px;">
                <text style="color:#6D757E;font-size: 28px;" >开户教程</text>
          </div>
          <div class="cell" style="height:88px; background-color: #E25534;">
              <text style="color:#FFFFFF;font-size: 28px;">极速开户</text>
          </div>
          <div class="cell" style="height:88px;">
              <text style="color:#6D757E;font-size: 28px;" >已有黄金编码,去登录</text>
          </div>
    </div>
  </div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var dom = weex.requireModule('dom')
var navi = weex.requireModule('navigator')
module.exports =  {
  components: {
    'status': require('../components/statusbar.vue'),
  },
  data: function() {
    return {
      string: require('../include/string.js'),
      assets: assetsUrl,
      leftItemSrc: assetsUrl + 'title_ic_kefu.png',
      rightItemSrc: assetsUrl + 'title_ic_news.png',
      tranSrc: assetsUrl + 'trans.png',
      progress: 0,
      index: 0,
    }
  },
  methods:{
    showview: function(index) {
      this.progress = index * 130;
      this.index = index;
    },
  }
}
</script>

<style lang="css">
.container {
  flex-direction: row;
  top: 0;
  left: 0;
  right: 0;
  width: 750;
  height: 88;
  justify-content: space-between;
  align-items: center;
  background-color: #FBFBFB;
}

.left-image {
  width: 88;
  height: 88;
}

.right-image {
  width: 88;
  height: 88;
}

.center {
  width: 260px;
  height: 60px;
  justify-content: center;
  align-items: center;
}

.transaction-text {
  flex: 1;
  text-align: center;
  font-size: 34px;
  color: #00173D;
}
.trans-image{
  width: 750px;
  height: 683px;
}

.trans-bottom{
  width: 750px;
  align-items: center;
  margin-top: 88px;
}

.cell{
  width: 550px;
  height: 88px;
  justify-content: center;
  align-items: center;
  border-radius: 44px;
}
</style>
