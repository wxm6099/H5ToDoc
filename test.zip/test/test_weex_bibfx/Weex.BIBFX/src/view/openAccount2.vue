<template>
  <div class="" @viewappear="viewAppear">
    <status backgroundColor="#FFFFFF"></status>
    <navigation :title="title" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="goBack"></navigation>
    <!-- <div class="navbar">
        <text class="navbar-title"> {{title}}</text>
        <div @click="goBack" class="goback">
            <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
        </div>
    </div> -->
    <div style="flex-direction:row;marginTop:34px;marginBottom:34px;">
      <div style="align-items:center;flex:1">
        <div class="item-row">
          <div class="whiteline"></div>
          <div class="grayline"></div>
        </div>
        <div class="circle">
          <div class="innerCircle">
            <text class="font20 text-item" style="  text-align: center;">01</text>
          </div>
        </div>
        <text class="font30 gold" style="text-align: center;color:#2e74e9">填写资料</text>
      </div>
      <div style="align-items:center;flex:1">
        <div class="item-row">
          <div class="grayline"></div>
          <div class="grayline"></div>
        </div>
        <div class="circle dashed">
          <div class="innerCircle gray">
            <text class="font20 text-item" style="  text-align: center;">02</text>
          </div>
        </div>
        <text class="font30 gold" style="text-align: center;color:gray">身份验证</text>
      </div>
      <div style="align-items:center;flex:1">
        <div class="item-row">
          <div class="grayline"></div>
          <div class="grayline"></div>
        </div>
        <div class="circle dashed">
          <div class="innerCircle gray">
            <text class="font20 text-item" style="  text-align: center;">03</text>
          </div>
        </div>
        <text class="font30" style="text-align: center;color:gray">调查问卷</text>
      </div>
      <div style="align-items:center;flex:1">
        <div class="item-row">
          <div class="grayline"></div>
          <div class="grayline"></div>
        </div>
        <div class="circle dashed">
          <div class="innerCircle gray">
            <text class="font20 text-item" style="text-align: center;">04</text>
          </div>
        </div>
        <text class="font30" style="text-align: center;color:gray">存款激活</text>
      </div>
      <div style="align-items:center;flex:1">
        <div class="item-row">
          <div class="grayline"></div>
          <div class="whiteline"></div>
        </div>
        <div class="circle dashed">
          <div class="innerCircle gray">
            <text class="font20 text-item" style="text-align: center;">05</text>
          </div>
        </div>
        <text class="font30" style="text-align: center;color:gray">交易密码</text>
      </div>
    </div>
    <div style="margin: 0px;height: 20px;background-color: #F1F1F1;"></div>
    <scroller class="scroller" show-scrollbar="false">
      <!-- <div class="align" style="paddingTop:50px;padding-bottom: 36px;" v-if="!isOpenIn"> -->
      <div class="align" style="paddingTop:50px;padding-bottom: 36px;">
        <text class="tips font26">补充以下个人资料并成功注资,即能开立MT5交易账户,开启投资创富之路!</text>
      </div>
      <div class="topBorderLine align"></div>

      <div class="margin flexV" style="margin-bottom: 50px">

        <div class="flexH infoItem">
          <div class="flexH">
            <text class="font24 color32">*</text>
            <text class="font24 text" style="margin-right:42px">姓</text>
            <text class="font24 text" style="margin-right:5px">名</text>
          </div>
          <div class="input flexH" style="align-items: center;">
            <div class="flexH select-id-areacode" v-on:click="onclickSex()">
              <text class="font24" style="margin-left: 20px;">{{sexDataShow.text}}</text>
              <div class="input-down-select">
                <image style="width:16px;height:12px" :src="assets+'auth/selectdown.png'"></image>
              </div>
            </div>
            <input ref="inputname" class="input-size" type="text"
                   :disabled="disableStatusDic.realName_status" maxlength=20 placeholder="请填写与身份证上一致的姓名"
                   :value="userName" @change="onchangename" @input="inputname"></input>
            <div class="input-down-select" @click="onrecognize(0)">
              <image style="width: 30px;height:30px;" :src="assets+'scan_ID.png'"></image>
            </div>
          </div>
        </div>

        <div class="flexH infoItem">
          <div class="flexH">
            <text class="font24 color32">*</text>
            <text class="font24 text" style="margin-right:42px">证</text>
            <text class="font24 text" style="margin-right:5px">件</text>
          </div>
          <div class="input flexH" style="align-items: center;">
            <div class="flexH select-id-areacode" v-on:click="onclickcerttype()">
              <text class="font24" style="margin-left: 20px;">{{certTypeTitle}}</text>
              <div class="input-down-select">
                <image style="width:16px;height:12px" :src="assets+'auth/selectdown.png'"></image>
              </div>
            </div>
            <input ref="inputcertType" class="input-size" type="text"
                   :disabled="disableStatusDic.realName_status" :maxlength=certMaxlength placeholder="请填写正确的身份证号码"
                   :value="userIDCardCode" @change="onchangeidcardcode" @input="inputidcode"
                   @blur="blurcardcode"></input>
          </div>
        </div>

        <div class="flexH infoItem">
          <div class="flexH">
            <text class="font24 color32">*</text>
            <text class="font24 text">银行账号</text>
          </div>
          <div class="input flexH">
            <input ref="inputbanknum" class="input-size" type="number"
                   :disabled="disableStatusDic.bankCode_status" :value="bankCode" maxlength=19
                   @change="onchangebankcode" @input="inputbankcode" @blur="blurbankcode"></input>
            <div class="input-down-select"  @click="onrecognize(1)">
              <image style="width: 30px;height:30px;" :src="assets+'scan_bank.png'"></image>
            </div>
          </div>
        </div>

        <div class="flexH infoItem">
          <div class="flexH">
            <text class="font24 color32">*</text>
            <text class="font24 text">银行名称</text>
          </div>
          <div class="input flexH" style="align-items: center;justify-content: space-between;"
               v-on:click="onclickbankname()">
            <text class="font24" style="margin-left: 20px;">{{bankName}}</text>
            <div class="input-down-select">
              <image style="width:15px;height:12px" :src="assets+'auth/selectdown.png'"></image>
            </div>
          </div>

        </div>
        <div class="flexH infoItem" v-if="isOtherBankName">
          <div class="flexH" style="background-color:red">
            <text class="font24 text" style="backgroundColor:gray"></text>
          </div>
          <div class="input">
            <input class="input-size" type="text" maxlength=50 placeholder="请填写银行名称"
                   :disabled="disableStatusDic.bankOtherName_status" :value="bankOtherName"
                   @change="onchangwritebankname" @input="inputwritebankname"></input>
          </div>
        </div>

        <div class="flexH infoItem">
          <div class="flexH">
            <text class="font24 color32">*</text>
            <text class="font24 text">所属支行</text>
          </div>
          <div class="flexH input-view">
            <div class="input-auto flexH" v-on:click="onclickbranchBank()">
              <text class="font24" style="margin-left: 20px;">{{branchAddress.province}}</text>
              <div class="input-down-select">
                <image style="width:15px;height:12px" :src="assets+'auth/selectdown.png'"></image>
              </div>
            </div>
            <template v-if="branchAddress.province!='台湾' && branchAddress.province!='中国(香港)' && branchAddress.province!='中国(澳门)'">
              <div v-if="branchAddress.province!='其他'" class="flexH input-view-w">
                <div class="input-auto flexH" v-on:click="onclickbranchBankTwo()">
                  <text class="font24" style="margin-left: 20px;">{{branchTwoAddress.city}}</text>
                  <div class="input-down-select">
                    <image style="width:15px;height:12px" :src="assets+'auth/selectdown.png'"></image>
                  </div>
                </div>
                <div class="input-auto flexH" v-on:click="onclickbranchBankThree()">
                  <text class="font24" style="margin-left: 20px;">{{branchThreeAddress.area}}</text>
                  <div class="input-down-select">
                    <image style="width:15px;height:12px" :src="assets+'auth/selectdown.png'"></image>
                  </div>
                </div>
              </div>
              <!--    填写其他地址    -->
              <div class="input-other" v-if="branchAddress.province=='其他'">
                <input class="input-size-other" type="text" maxlength=200 placeholder="请填写支行区域地址" @change="onchangeOtherAddress" @input="inputOtherAddress" :value="branchAddressOther"></input>
              </div>
            </template>

          </div>
        </div>

        <div class="flexH infoItem-branch" v-if="branchBankData.length > 1">
          <div class="flexH">
          </div>
          <div class="input flexH" style="align-items: center;" v-on:click="onclickbranchBankName()">

            <text class="font24 branch-bank-text">{{branchBankName}}</text>

            <div class="input-down-select">
              <image style="width:15px;height:12px" :src="assets+'auth/selectdown.png'"></image>
            </div>
          </div>
        </div>

        <div class="flexH infoItem-branch" v-if="branchBankData.length <= 1">
          <div class="flexH">
          </div>
          <div class="input">
            <input ref="inputbranchBankName" class="input-size" type="text" :value="branchBankName"
                   :disabled="disableStatusDic.bankBranchName_status" maxlength=200 placeholder="请填写支行名称"
                   @change="onchangebranchbankname" @input="inputbranchbankname"></input>
          </div>
        </div>

        <!--                <div class="flexH infoItem">-->
        <!--                    <div class="flexH">-->
        <!--                        <text class="font24 text" style="margin-right:24px;margin-left:26px">推荐人</text>-->
        <!--                    </div>-->
        <!--                    <div class="input">-->
        <!--                        <input ref="inputintroduce" class="input-size" allowCopyPaste="true" type="text"-->
        <!--                               :disabled="disableStatusDic.inputintroduce_status" :value="memberIntroducer" maxlength=50-->
        <!--                               return-key-type="done" placeholder="如无推荐人无需填写" @change="onchangememberintroducer"-->
        <!--                               @input="inputintroducer"></input>-->
        <!--                    </div>-->
        <!--                </div>-->

        <div style="margin-top:50px;flex-direction: row;">
          <text class="font28" style="color:#adadad">注：带</text>
          <text class="font28" style="color:red">*</text>
          <text class="font28" style="color:#adadad">为必填项</text>
        </div>
        <div style="margin-top:30px;background-color:#f7f7f6;height:400px;border-color: #dddddd;border-width: 1px;">
          <web v-if="agreement" ref="webview" :src="agreement" style="height:300px;flex:1"></web>
        </div>
        <div style="margin-top:32px;">
          <text class="font26" style="color:#999999;line-height:42px">请阁下细阅《客户协议》及其他相关文件并确保完全明白及理解全部内容。如有需要，请联络我们的客服查阅开户申请手续。</text>
        </div>
        <div class="flexH" style="margin-top:20px;" v-on:click="onclickprotocol()">
          <div class="protocol">
            <image style="width:30px;height:30px" :src="assets+'checkbox/checked.png'"
                   v-if="isShowProtocol"></image>
          </div>
          <text class="font26" style="color:#999999;line-height:42px;width:645px;">我已详阅并明白同意以上《客户协议》及其他有关文件之全部内容。（有关文件包括但不限于《交易细则》、《风险披露声明》、《客户告鉴》、《个人资料隐私政策》、《个人资料收集声明》）。</text>
        </div>
      </div>

    </scroller>
    <div class="flexH button-view">
      <div class="button" style="background-color: white;" v-on:click="onclickReload()">
        <text class="font32 " style="color: #2e74e9;">重置</text>
      </div>
      <div v-if="showNext" class="button" style="width:375px;background-color: #2e74e9;"
           v-on:click="onclicknext()">
        <text class="font32 text-select">下一步</text>
      </div>
    </div>
    <div v-if="isShowAlert" class="alert-show">
      <div class="alert-modul">
        <text style="color:#FFFFFF;font-size:28px;"> {{alertTips}}</text>
      </div>
    </div>
    <dialog :show="showDialogBack" title="温馨提示" content="您尚未提交资料，返回后将清空内容，请确认是否继续退出？" confirm="继续填写" cancel="退出"
            @confirm="dialogLeftBtnClickBack" @cancel="dialogRightBtnClickBack" @close="dialogCloseBtnClickBack">
    </dialog>
  </div>
</template>

<script scoped>
  var allArea = require('../chainArea.json');
  var appbasedata = require('../survey.json');
  var bundleUrl = require('../include/base-url.js').bundleUrl();
  var assetsUrl = require('../include/base-url.js').assetsUrl();
  var navigator = weex.requireModule('navigator');
  var app = weex.requireModule('app');
  var webview = weex.requireModule('webview');
  var storage = require('../include/storage.js');
  var http = require('../include/http.js');
  const picker = weex.requireModule('picker');
  var firebase = weex.requireModule('firebase');
  var utils = require('../include/utils.js');


  module.exports = {
    components: {
      navigation: require('../components/navigationBar.vue'),
      'status': require('../components/statusbar.vue'),
      'dialog': require('../components/dialog.vue'),
    },
    data: function () {
      return {
        isAndroid: utils.isAndroid(),
        assets: assetsUrl,
        title: '填写资料',
        userId: '',//提交基本资料的用户id（前一个页面的参数）
        userToken: '',//提交基本资料的用户登陆token（前一个页面的参数）
        isOpenIn: false,//是否是开户第一步进入
        bibApi: '',//网络请求基地址
        agreement: '',//协议地址
        serviceUrl: '',//客服url
        isShowProtocol: false,
        isShowAlert: false,
        alertTips: '',//弹窗提示语
        userName: '',
        selectedSexImg: assetsUrl + 'radio/checked.png',
        unselectedSexImg: assetsUrl + 'radio/unchecked.png',
        isShowSexMan: false,
        isShowSexWoman: false,
        isShowSexOther: false,
        memberSex: 1,//选择的性别（默认 空  1:男  2:女 3:其他）
        certTypes: [],
        certTypeTitle: '',//证件类型
        certTypeIndex: 0,
        certTypeNumber: 1,//证件的编号
        certMaxlength:18,
        userIDCardCode: '',
        accountName: '',
        bankCode: '',  // 银行账号
        bankNames: [],
        bankNamesCodes: appbasedata.bankName,
        bankName: '建、工、招、农行取款2小时到账',
        bankOtherName: '',  // 当银行列表选其他时，用户输入的银行名称
        bankNameIndex: 0,
        isOtherBankName: false,
        branchAddressAreas: ['请选择'],
        branchAddressAreasCode: [{"province": '请选择', "code": 'none'}],
        branchAddress: {"province": '请选择', "code": 'none'},
        branchAddressIndex: 0,
        branchAddressOther:'',//省份选择其他时的 支行地址
        branchTwoAddressAreas: ['请选择'],
        branchTwoAddressAreasCode: [{"city": '请选择', "code": 'none'}],
        branchTwoAddress: {"city": '请选择', "code": 'none'},
        branchTwoAddressIndex: 0,
        branchThreeAddressAreas: ['请选择'],
        branchThreeAddressAreasCode: [{"area": '请选择', "code": 'none'}],
        branchThreeAddress: {"area": '请选择', "code": 'none'},
        branchThreeAddressIndex: 0,
        branchBankName: '',  // 支行名称
        isSubmitBtnClick: false,//是否点击提交(下一步)按钮
        showDialogBack: false,//返回提示弹窗
        openAccountFrom: '',//从哪里进入开户步骤

        sexData: [
          {"id": "11", "text": "先生", "code": "1"},
          {"id": "22", "text": "女士", "code": "2"},
          // {"id":"33","text":"其他","code":"3"},
        ],
        sexIndex: 0,
        sexDataShow: {"id": "1", "text": "先生", "code": "1"},

        showNext: true,

        memberIntroducer: '',  // 推荐人
        bankNameCode: '',

        // branchBankData:['中国农业银行有限公司有限公司有限公司有限公有限公司','中国农业银行支行'],
        branchBankData: [],

        disableStatusDic: {
          sex_status: false,
          realName_status: false,
          certType_status: false,
          certNo_status: false,
          bankCode_status: false,
          bankName_status: false,
          bankOtherName_status: false,
          province_status: false,
          city_status: false,
          area_status: false,
          bankBranchName_status: false,
          inputintroduce_status: false,
        },

        cryptStatusDic: {
          certNo_status: false,
          bankCode_status: false,
          bankOtherName_status: false,
          bankBranchName_status: false,
        }


// 			IDfrontStatus: false,
// 			IDbackStatus: false,
// 			bankStatus: false,

      }
    },
    created: function () {
      var that = this;
      storage.getItem('commonUrl', function (value) {
        if ('' == value || value == undefined || value.length <= 0) {
          return;
        }
        var commonUrl = JSON.parse(value);
        if (commonUrl) {
          that.bibApi = commonUrl.cmsApi;
          that.serviceUrl = commonUrl.feedback;
          that.agreement = commonUrl.agreement;
        }
      });
      storage.getItem('user-logintoken-id', function (value) {
        if (value) {
          var data = JSON.parse(value);
          that.userId = data.userId;
          that.userToken = data.token;
          that.isOpenIn = data.isOpen;
        }
      });
      storage.getItem('user_openaccount_from', function (value) {
        if (value) {
          that.openAccountFrom = value;
        }
      });
      //银行名称的列表数据
      for (var i = 0; i < appbasedata.bankName.length; i++) {
        that.bankNames.push(appbasedata.bankName[i].bank);
      }
      //省份的列表数据(大陆省份)
      for (var code in allArea.mainland) {
        if (allArea.mainland.hasOwnProperty(code)) {
          that.branchAddressAreas.push(allArea.cityArea[code]);
          var pro = {"province": allArea.cityArea[code], "code": code};
          that.branchAddressAreasCode.push(pro);
        }
      }
      //省份的列表数据(海外省份)
      for (var code in allArea.outerSea) {
        if (allArea.outerSea.hasOwnProperty(code)) {
          that.branchAddressAreas.push(allArea.cityArea[code]);
          var pro = {"province": allArea.cityArea[code], "code": code};
          that.branchAddressAreasCode.push(pro);
        }
      }
      //证件类型的类表数据
      for (var i = 0; i < appbasedata.certType.length; i++) {
        that.certTypes.push(appbasedata.certType[i].certtype);//电话区号
      }
      that.certTypeTitle = that.certTypes[that.certTypeIndex];
      that.certTypeNumber = appbasedata.certType[that.certTypeIndex].number;
    },
    methods: {
      viewAppear: function () {
        let that = this;
        //
        storage.getItem('userInfo', function (data) {

          if (data) {
            let value = JSON.parse(data);

            let realName = value.realName;
            let sex = value.sex;

            let certType = value.certType;
            let certNo = value.certNo;

            let bindBankNo = value.bindBankNo; // 银行卡号
            let bindSubBankName = value.bindSubBankName; // 支行名称
            let bindBank = value.bindBank;	//银行简称
            let bindSubBankOther = value.bindSubBankOther;	//支行其他

            let bindSubBankArea = value.bindSubBankArea;	// 省
            let bindSubBankAreaCity = value.bindSubBankAreaCity;	//  市
            let bindSubBankAreaCounty = value.bindSubBankAreaCounty;	// 区

            let iB_NO = value.iB_NO;

            let attachmentStatus = value.attachmentStatus;
            let IDfrontStatus = value.IDfrontStatus;
            let IDbackStatus = value.IDbackStatus;
            let bankStatus = value.bankStatus;


            if (sex) {
              for (let i = 0; i < that.sexData.length; i++) {
                if (sex == that.sexData[i].code) {
                  that.sexDataShow = that.sexData[i];
                }
              }
              that.memberSex = that.sexDataShow.code;
            }
            if (realName) {
              that.userName = realName;
            }
            if (certType) {
              that.certTypeNumber = certType;
              for (let i = 0; i < appbasedata.certType.length; i++) {
                if (appbasedata.certType[i].number == certType) {
                  that.certTypeTitle = appbasedata.certType[i].certtype;
                }
              }
              // that.certTypeTitle = certType;
            }
            if (certNo) {
              that.cryptStatusDic.certNo_status = true;
              certNo = certNo.replace(/{[A-Za-z0-9_-\u4e00-\u9fa5]+}/, '******');
              that.userIDCardCode = certNo;
            }

            if (bindBankNo) {
              that.cryptStatusDic.bankCode_status = true;
              bindBankNo = bindBankNo.replace(/{[A-Za-z0-9_-\u4e00-\u9fa5]+}/, '******');
              that.bankCode = bindBankNo;
            }

            if (bindBank) {
              let judge = false;
              for (let i = 0; i < appbasedata.bankName.length; i++) {
                if (bindBank == appbasedata.bankName[i].code) {
                  that.bankNameCode = appbasedata.bankName[i].code;
                  that.bankName = appbasedata.bankName[i].bank;
                  judge = true;
                  break;
                }
              }
              if (judge == false) {
                that.isOtherBankName = true;
                that.bankNameCode = appbasedata.bankName[appbasedata.bankName.length - 1].code;
                that.bankName = appbasedata.bankName[appbasedata.bankName.length - 1].bank;
                that.bankOtherName = bindBank;
              }
            }
            // if (bindSubBankOther) {
            //   that.cryptStatusDic.bankOtherName_status = true;
            //   bindSubBankOther = bindSubBankOther.replace(/{[A-Za-z0-9_-\u4e00-\u9fa5]+}/, '******');
            //   that.bankOtherName = bindSubBankOther;
            // }
            if (bindSubBankArea) {
              that.branchAddress.code = bindSubBankArea;
              that.branchAddress.province = allArea.cityArea[bindSubBankArea];
              if (bindSubBankArea == 'other') {
                that.branchAddressOther = bindSubBankAreaCity;
              } else {
                if (bindSubBankAreaCity) {
                  that.branchTwoAddress.code = bindSubBankAreaCity;
                  that.branchTwoAddress.city = allArea.cityArea[bindSubBankAreaCity];
                }
                if (bindSubBankAreaCounty) {
                  that.branchThreeAddress.code = bindSubBankAreaCounty;
                  that.branchThreeAddress.area = allArea.cityArea[bindSubBankAreaCounty];
                }
              }
            }

            if (bindSubBankName) {
              that.cryptStatusDic.bankBranchName_status = true;
              bindSubBankName = bindSubBankName.replace(/{[A-Za-z0-9_-\u4e00-\u9fa5]+}/, '******');
              that.branchBankName = bindSubBankName;
            }
            if (iB_NO) {
              that.memberIntroducer = iB_NO;
            }

            if (attachmentStatus) {

              // if (that.memberIntroducer){
              //   that.disableStatusDic.inputintroduce_status = true;
              // }

              that.isShowProtocol = true;

              if (IDfrontStatus) {
                that.disableStatusDic.sex_status = true;
                that.disableStatusDic.realName_status = true;
                that.disableStatusDic.certType_status = true;
                that.disableStatusDic.certNo_status = true;
              }

              if (IDbackStatus) {

              }

              if (bankStatus) {
                that.disableStatusDic.bankCode_status = true;
                that.disableStatusDic.bankName_status = true;
                that.disableStatusDic.bankOtherName_status = true;
                that.disableStatusDic.province_status = true;
                that.disableStatusDic.city_status = true;
                that.disableStatusDic.area_status = true;
                that.disableStatusDic.bankBranchName_status = true;

              }

            }

          }
        });


        storage.getItem('recognizeResult', function (value) {
          if (value) {
            let data = JSON.parse(value);
            if (data.bankNumber) {
              that.bankCode = data.bankNumber; // 银行卡
            }
            if (data.bankName) {
              // 对code和 name 设置初始值，其他；若遍历成功匹配，则再次赋值
              let code = appbasedata.bankName[appbasedata.bankName.length - 1].code;
              let name = appbasedata.bankName[appbasedata.bankName.length - 1].bank;
              // 模糊匹配
              for (let i = 0; i < appbasedata.bankName.length; i++) {
                if (data.bankName.indexOf(appbasedata.bankName[i].bank) > -1 || appbasedata.bankName[i].bank.indexOf(data.bankName) > -1) {
                  name = appbasedata.bankName[i].bank;
                  code = appbasedata.bankName[i].code;
                  break;
                }
              }
              that.bankNameCode = code;
              that.bankName = name;
            }

            if (data.name){
              that.userName = data.name;
            }
            if (data.sex) {
              let sexText;
              if (data.sex == '男'){
                sexText = '先生';
              }
              if (data.sex == '女'){
                sexText = '女士';
              }
              for (let i = 0; i < that.sexData.length; i++) {
                if (sexText == that.sexData[i].text) {
                  that.sexDataShow = that.sexData[i];
                }
              }
              that.memberSex = that.sexDataShow.code;
            }

            if (data.IDNumber) {
              that.userIDCardCode = data.IDNumber;
            }

            storage.setItem('recognizeResult', '');
          }
        });
      },

      //埋点追踪方法(在input事件里面执行)
      logEvent: function (name) {
        if (firebase) {
          firebase.logEventWithName(name);
        }
      },
      goBack: function () {
        this.showDialogBack = true;
      },
      //直播间登录
      onliveroom: function () {
        storage.setItem('user-original-fromLogin', 'livebyopen');
        navigator.push({
          url: bundleUrl + 'userLogin.js',
          animated: "true",
          swipePop: "true",
        }, event => {
        })
      },
      //用户中心登录
      onusercenter: function () {
        storage.setItem('user-original-fromLogin', 'indexbyopen');
        navigator.push({
          url: bundleUrl + 'userLogin.js',
          animated: "true",
          swipePop: "true",
        }, event => {
        })
      },
      //在线客服超链接
      onclickservice: function () {
        this.loadWebView(this.serviceUrl, '客服');
      },
      loadWebView: function (url, title = '') {
        if (url && url.length > 0) {
          var data = {
            title: title,
            url: url,
          }
          storage.setItem('app-url', JSON.stringify(data));
          navigator.push({
            url: bundleUrl + 'webview.js',
            animated: "false"
          }, event => {
          })
        }
      },
      //弹窗右上角按钮
      dialogCloseBtnClickBack() {
        this.showDialogBack = false;
      },
      //弹窗左下角按钮
      dialogLeftBtnClickBack() {
        this.showDialogBack = false;
      },
      //弹窗右下角按钮
      dialogRightBtnClickBack() {
        this.showDialogBack = false;
        if (this.openAccountFrom === 'live') {
          navigator.pop({
            url: bundleUrl + 'live.js',
            animated: "false"
          }, event => {

          });
        } else {
          navigator.pop({
            url: bundleUrl + 'index.js',
            animated: "false"
          }, event => {

          });
        }
      },
      //姓名 @input @change
      inputname: function (event) {
        // this.logEvent('input_real_name');
        this.userName = event.value;
        this.accountName = this.userName;
      },
      onchangename: function (event) {
        this.userName = event.value;
        //姓名可以使汉字和. 或者 大小写英文和空格和.
        // if (!/^([\u4e00-\u9fa5\·]{1,50}|(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{1,50})$/.test(this.userName)) {
        //   this.showAlertTips('填写姓名的格式不正确');
        // }

        if (false ==  utils.checkName(this.userName)){
          this.showAlertTips('填写姓名的格式不正确');
        }
      },
      onclickSex: function () {
        var that = this;
        if (that.disableStatusDic.sex_status) {
          return;
        }

        let sexTextArr = [];
        let sexIndexArr = [];
        for (let i = 0; i < that.sexData.length; i++) {
          sexTextArr.push(that.sexData[i].text);
          sexIndexArr.push(that.sexData[i].id);
        }
        picker.pick({
          items: sexTextArr,
          index: that.sexIndex,
        }, event => {
          if (event.result === 'success') {
            that.sexIndex = event.data;
            that.sexDataShow = that.sexData[that.sexIndex];
            that.memberSex = that.sexDataShow.code;
          }
        })
      },
      //证件区域 列表选择
      onclickcerttype: function () {
        var that = this;
        if (that.disableStatusDic.sex_status) {
          return;
        }
        picker.pick({
          items: that.certTypes,
          index: that.certTypeIndex,
        }, event => {
          if (event.result === 'success') {
            that.certTypeIndex = event.data;
            that.certTypeTitle = that.certTypes[that.certTypeIndex];
            if (that.certTypeNumber != appbasedata.certType[that.certTypeIndex].number) {//证件区域不一样时 清空证件号码
              that.userIDCardCode = '';
              that.cryptStatusDic.certNo_status = false;
            }
            that.certTypeNumber = appbasedata.certType[that.certTypeIndex].number;

            if (that.certTypeIndex != 0) {
              that.certMaxlength = 50;  // 当选择非大陆地区，不显示下一步；
            } else {
              that.certMaxlength = 18;
            }
          }
        })
      },
      //身份证号码 @input  @change
      inputidcode: function (event) {
        // this.logEvent('input_id_number');
        if (this.disableStatusDic.certNo_status) {
          return
        }
        if (this.cryptStatusDic.certNo_status&&this.userIDCardCode.length!=event.value.length) {
          this.userIDCardCode = '';
          this.cryptStatusDic.certNo_status = false;
          return;
        }
        this.userIDCardCode = event.value;
      },
      blurcardcode: function () {
        if (this.disableStatusDic.certNo_status) {
          return
        }
      },
      onchangeidcardcode: function (event) {
        if (this.disableStatusDic.certNo_status) {
          return
        }
        // this.userIDCardCode = event.value;
        if (this.certTypeTitle === "中国大陆") {
          if (!this.Check18CertNO(this.userIDCardCode)) {
            this.showAlertTips('请输入正确的身份证号码');
          }
        }
      },
      //检测18位身份证号码的正确性
      Check18CertNO: function (sId) {
        // 中国大陆地区 判断18位身份证号是否正确
        var aCity = {
          11: '北京', 12: '天津', 13: '河北', 14: '山西', 15: '内蒙古',
          21: '辽宁', 22: '吉林', 23: '黑龙江',
          31: '上海', 32: '江苏', 33: '浙江', 34: '安徽', 35: '福建', 36: '江西', 37: '山东',
          41: '河南', 42: '湖北', 43: '湖南', 44: '广东', 45: '广西', 46: '海南',
          50: '重庆', 51: '四川', 52: '贵州', 53: '云南', 54: '西藏',
          61: '陕西', 62: '甘肃', 63: '青海', 64: '宁夏', 65: '新疆'
        };
        try {
          var iSum = 0;
          if (!/^\d{17}(\d|x)$/i.test(sId)) {
            return false;
          }
          sId = sId.replace(/x$/i, 'a');
          if (aCity[parseInt(sId.substr(0, 2))] == null) {
            return false;
          }
          let sBirthday = sId.substr(6, 4) + '-' + Number(sId.substr(10, 2)) + '-' + Number(sId.substr(12, 2));
          var d = new Date(sBirthday.replace(/-/g, '/'));
          if (sBirthday !== (d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate())) {
            return false;
          }
          for (var i = 17; i >= 0; i--) {
            iSum += (Math.pow(2, i) % 11) * parseInt(sId.charAt(17 - i), 11);
          }
          if (iSum % 11 !== 1) {
            return false;
          }
          return true;
        } catch (e) {
          return false;
        }
      },
      // //账户姓名 @input  @change
      // inputaccountname:function(event){
      //   // this.logEvent('input_bank_account_name');
      //   this.accountName = event.value;
      // },
      // onchangeaccountname:function(event){
      //   this.accountName = event.value;
      //   if (this.userName != this.accountName) {
      //     this.showAlertTips('持卡人姓名必须与个人信息一致');
      //   }
      // },
      //银行卡号 @input  @change
      inputbankcode: function (event) {
        // this.logEvent('input_bank_account');

        if (this.disableStatusDic.bankCode_status) {
          return;
        }

        if (this.cryptStatusDic.bankCode_status&&this.bankCode.length!=event.value.length) {
          this.bankCode = '';
          this.cryptStatusDic.bankCode_status = false;
          return;
        }
        this.bankCode = event.value;
      },
      onchangebankcode: function (event) {
        if (this.disableStatusDic.bankCode_status) {
          return;
        }
        this.bankCode = event.value;
        var reg = /^\d{0,20}$/;
        if (!reg.test(this.bankCode)) {
          this.showAlertTips('请输入正确的银行卡号');
        }
      },
      blurbankcode: function (event) {
        if (this.disableStatusDic.bankCode_status) {
          return;
        }
        let that = this;
        // 停止输入银行卡号时，对银行卡请求 归属地信息
        that.getAddressForBank();
      },
      getAddressForBank: function () {
        let that = this;
        let url = this.bibApi + '/BankCardValidate/MCAPI';
        let Apiversion = '2.0';
        let CardNo = this.bankCode;
        url = `${url}?CardNo=${CardNo}`;

        http.get(url, function (response) {

          if (response.ok) {
            if (response.data && response.data.IsOK && response.data.Results) {
              let Results = response.data.Results;
              let Province = Results.Province;
              let ProvinceCN = Results.ProvinceCN;
              let City = Results.City;
              let CityCN = Results.CityCN;
              let BankName = Results.BankName;

              let Abbreviation = Results.Abbreviation;

              for (let i = 0; i < appbasedata.bankName.length; i++) {
                if (Abbreviation == appbasedata.bankName[i].code) {
                  that.bankNameCode = Abbreviation;
                  that.bankName = BankName;
                }
              }

              if (that.bankNameCode === 'Other') {
                that.bankName = '其他';
                // that.bankNameCode = 'Other';
                that.isOtherBankName = true;
              } else {
                that.isOtherBankName = false;
              }

              //
              that.branchBankName = '';
              that.branchBankData = [];

              // that.branchAddressAreas = ['请选择'];
              // that.branchAddressAreasCode = [{"province": '请选择', "code": 'none'}];
              that.branchAddress = {"province": '请选择', "code": 'none'};

              that.branchTwoAddressAreas = ['请选择'];
              that.branchTwoAddressAreasCode = [{"city": '请选择', "code": 'none'}];
              that.branchTwoAddress = {"city": '请选择', "code": 'none'};

              that.branchThreeAddressAreas = ['请选择'];
              that.branchThreeAddressAreasCode = [{"area": '请选择', "code": 'none'}];
              that.branchThreeAddress = {"area": '请选择', "code": 'none'};

              if (Province) {
                that.branchAddress.province = ProvinceCN;
                that.branchAddress.code = Province;

                //二级市区域的列表(大陆)
                for (var code in allArea.mainland[that.branchAddress.code]) {
                  if (allArea.mainland[that.branchAddress.code].hasOwnProperty(code)) {
                    that.branchTwoAddressAreas.push(allArea.cityArea[code]);
                    var city = {"city": allArea.cityArea[code], "code": code};
                    that.branchTwoAddressAreasCode.push(city);
                  }
                }
                //二级市区域的列表(海外)
                for (var code in allArea.outerSea[that.branchAddress.code]) {
                  if (allArea.outerSea[that.branchAddress.code].hasOwnProperty(code)) {
                    that.branchTwoAddressAreas.push(allArea.cityArea[code]);
                    var city = {"city": allArea.cityArea[code], "code": code};
                    that.branchTwoAddressAreasCode.push(city);
                  }
                }
              }
              if (City) {
                that.branchTwoAddress.city = CityCN;
                that.branchTwoAddress.code = City;

                //三级区和县的区域列表（大陆）
                if (allArea.mainland[that.branchAddress.code] && allArea.mainland[that.branchAddress.code][that.branchTwoAddress.code]) {
                  var landArea = allArea.mainland[that.branchAddress.code][that.branchTwoAddress.code];
                  for (var i = 0; i < landArea.length; i++) {
                    var code = landArea[i];
                    that.branchThreeAddressAreas.push(allArea.cityArea[code]);
                    var area = {"area": allArea.cityArea[code], "code": code};
                    that.branchThreeAddressAreasCode.push(area);
                  }
                }
                //三级区和县的区域列表（海外）
                if (allArea.outerSea[that.branchAddress.code] && allArea.outerSea[that.branchAddress.code][that.branchTwoAddress.code]) {
                  var seaArea = allArea.outerSea[that.branchAddress.code][that.branchTwoAddress.code];
                  for (var i = 0; i < seaArea.length; i++) {
                    var code = seaArea[i];
                    that.branchThreeAddressAreas.push(allArea.cityArea[code]);
                    var area = {"area": allArea.cityArea[code], "code": code};
                    that.branchThreeAddressAreasCode.push(area);
                  }
                }
              }

            }
          } else {
            // that.showAlertTips('网络失败，请稍后重试');
          }

        })
      },

      getBranchBank: function () {
// 			http://demo.fantasysz.com:16601/BankOutlefs/IFXMCAPI?BANKNAME_EN=ABC&PROVINCE=100_13_00_00&CITY=100_13_01_00&DISTRICT=100_13_01_01
        let that = this;
        let url = this.bibApi + '/BankOutlefs/MCAPI';
        let dic = {
          ID: '',
          BANKCODE: '',
          BANKNAME: '',
          BANKNAME_EN: that.bankNameCode,
          SUBBANKNAME: '',
          PROVINCE: that.branchAddress.code,
          CITY: that.branchTwoAddress.code,
          DISTRICT: that.branchThreeAddress.code,
          ADDRESS: '',
          TEL: ''
        }
        let str = '';
        for (let key in dic) {
          if (dic[key]) {
            if (str) {
              str = `${str}&`
            }
            str = `${str}${key}=${dic[key]}`;
          }
        }
        url = `${url}?${str}`;

        http.get(url, function (response) {

          if (response.ok) {
            if (response.data && response.data.Results) {
              let Results = response.data.Results;
              let arr = [];
              for (let i = 0; i < Results.length; i++) {
                let subBankName = Results[i].SUBBANKNAME;
                arr.push(subBankName);
              }
              that.branchBankData = arr;
              // that.branchBankName = arr[0];
            }
          } else {
            // that.showAlertTips('网络失败，请稍后重试');
          }
        })

      },

      //select 银行名称
      onclickbankname: function () {
        var that = this;
        if (that.disableStatusDic.bankName_status) {
          return
        }
        picker.pick({
          items: that.bankNames,
          index: that.bankNameIndex,
        }, event => {
          if (event.result === 'success') {
            that.bankNameIndex = event.data;
            that.bankName = that.bankNames[that.bankNameIndex];
            that.bankNameCode = that.bankNamesCodes[that.bankNameIndex].code;
            if (that.bankName === '其他') {
              that.isOtherBankName = true;
            } else {
              that.isOtherBankName = false;
            }

            that.branchBankName = '';
            that.cryptStatusDic.bankBranchName_status = false;

            that.getBranchBank();

          }
        })
      },
      //输入推荐人（可以不填）
      inputintroducer: function (event) {
        this.memberIntroducer = event.value;
      },
      onchangememberintroducer: function (event) {
        this.memberIntroducer = event.value;
      },

      //银行名称 @input  @change
      inputwritebankname: function (event) {
        // this.logEvent('input_bank_name');
        if (this.cryptStatusDic.bankOtherName_status) {
          this.bankOtherName = '';
          this.cryptStatusDic.bankOtherName_status = false;
          return;
        }
        this.bankOtherName = event.value;
      },
      onchangwritebankname: function (event) {
        this.bankOtherName = event.value;
        if (/\d/.test(this.bankOtherName)) {
          this.showAlertTips('请输入正确的银行名称');
        }
      },
      //支行区域（一级  省）
      onclickbranchBank: function () {
        var that = this;
        if (that.disableStatusDic.province_status) {
          return;
        }
        picker.pick({
          items: that.branchAddressAreas,
          index: that.branchAddressIndex,
        }, event => {
          if (event.result === 'success') {
            // that.logEvent('select_bank_province');
            that.branchAddressIndex = event.data;
            that.branchAddress.province = that.branchAddressAreas[event.data];//一级区域的省
            // if (that.branchAddress.province == '其他') {
            //   that.branchAddressOther = ''
            //   return
            // }
            that.branchTwoAddress.city = '请选择';//二级区域的市
            that.branchThreeAddress.area = '请选择';//三级区域的区
            for (var i = 0; i < that.branchAddressAreasCode.length; i++) {
              if (that.branchAddressAreasCode[i].province === that.branchAddress.province) {
                that.branchAddress.code = that.branchAddressAreasCode[i].code;//一级区域的省代码
                that.branchTwoAddress.code = 'none';//二级区域的市代码
                that.branchThreeAddress.code = 'none';//三级区域的区代码
              }
            }
            that.branchTwoAddressAreas = ['请选择'];
            that.branchTwoAddressAreasCode = [{"city": '请选择', "code": 'none'}];
            that.branchThreeAddressAreas = ['请选择'];
            that.branchThreeAddressAreasCode = [{"area": '请选择', "code": 'none'}];
            //二级市区域的列表(大陆)
            for (var code in allArea.mainland[that.branchAddress.code]) {
              if (allArea.mainland[that.branchAddress.code].hasOwnProperty(code)) {
                that.branchTwoAddressAreas.push(allArea.cityArea[code]);
                var city = {"city": allArea.cityArea[code], "code": code};
                that.branchTwoAddressAreasCode.push(city);
              }
            }
            //二级市区域的列表(海外)
            for (var code in allArea.outerSea[that.branchAddress.code]) {
              if (allArea.outerSea[that.branchAddress.code].hasOwnProperty(code)) {
                that.branchTwoAddressAreas.push(allArea.cityArea[code]);
                var city = {"city": allArea.cityArea[code], "code": code};
                that.branchTwoAddressAreasCode.push(city);
              }
            }
          }
        })
      },
      //支行区域（二级）
      onclickbranchBankTwo: function () {
        var that = this;
        if (that.disableStatusDic.city_status) {
          return;
        }
        picker.pick({
          items: this.branchTwoAddressAreas,
          index: this.branchTwoAddressIndex,
        }, event => {
          if (event.result === 'success') {
            // that.logEvent('select_bank_city');
            that.branchTwoAddressIndex = event.data;
            that.branchTwoAddress.city = that.branchTwoAddressAreas[event.data];
            that.branchThreeAddress.area = '请选择';//三级区域的区
            for (var i = 0; i < that.branchTwoAddressAreasCode.length; i++) {
              if (that.branchTwoAddressAreasCode[i].city === that.branchTwoAddress.city) {
                that.branchTwoAddress.code = that.branchTwoAddressAreasCode[i].code;//二级区域的市和市代码
                that.branchThreeAddress.code = 'none';//三级区域的区代码
              }
            }
            that.branchThreeAddressAreas = ['请选择'];
            that.branchThreeAddressAreasCode = [{"area": '请选择', "code": 'none'}];
            //三级区和县的区域列表（大陆）
            if (allArea.mainland[that.branchAddress.code] && allArea.mainland[that.branchAddress.code][that.branchTwoAddress.code]) {
              var landArea = allArea.mainland[that.branchAddress.code][that.branchTwoAddress.code];
              for (var i = 0; i < landArea.length; i++) {
                var code = landArea[i];
                that.branchThreeAddressAreas.push(allArea.cityArea[code]);
                var area = {"area": allArea.cityArea[code], "code": code};
                that.branchThreeAddressAreasCode.push(area);
              }
            }
            //三级区和县的区域列表（海外）
            if (allArea.outerSea[that.branchAddress.code] && allArea.outerSea[that.branchAddress.code][that.branchTwoAddress.code]) {
              var seaArea = allArea.outerSea[that.branchAddress.code][that.branchTwoAddress.code];
              for (var i = 0; i < seaArea.length; i++) {
                var code = seaArea[i];
                that.branchThreeAddressAreas.push(allArea.cityArea[code]);
                var area = {"area": allArea.cityArea[code], "code": code};
                that.branchThreeAddressAreasCode.push(area);
              }
            }
          }
        })
      },
      //支行区域（三级）
      onclickbranchBankThree: function () {
        var that = this;
        if (that.disableStatusDic.area_status) {
          return;
        }
        picker.pick({
          items: that.branchThreeAddressAreas,
          index: that.branchThreeAddressIndex,
        }, event => {
          if (event.result === 'success') {
            // that.logEvent('select_bank_area');
            that.branchThreeAddressIndex = event.data;
            that.branchThreeAddress.area = that.branchThreeAddressAreas[event.data];
            for (var i = 0; i < that.branchThreeAddressAreasCode.length; i++) {
              if (that.branchThreeAddressAreasCode[i].area === that.branchThreeAddress.area) {
                that.branchThreeAddress.code = that.branchThreeAddressAreasCode[i].code;//二级区域的市和市代码
              }
            }
            that.getBranchBank();
            that.branchBankName = '';
            that.cryptStatusDic.bankBranchName_status = false;
          }
        })
      },
      //input 银行支行区域  地址
      inputOtherAddress: function (event) {
        this.branchAddressOther = event.value;
      },
      onchangeOtherAddress: function (event) {
        this.branchAddressOther = event.value;
        if (!this.branchAddressOther) {
          this.showAlertTips('请填写支行区域地址');
        }
      },
      // 支行列表
      onclickbranchBankName: function () {
        var that = this;
        if (that.disableStatusDic.bankBranchName_status){
          return;
        }

        picker.pick({
          items: that.branchBankData,
          index: 0,
        }, event => {
          if (event.result === 'success') {
            let index = event.data;
            that.branchBankName = that.branchBankData[index];
          }
        })
      },

      //input 银行支行名称
      inputbranchbankname: function (event) {
        // this.logEvent('input_bank_addr');
        if (this.disableStatusDic.bankBranchName_status){
          return;
        }
        if (this.cryptStatusDic.bankBranchName_status && this.branchBankName.length!=event.value.length) {
          this.cryptStatusDic.bankBranchName_status = false;
          this.branchBankName = '';
          return;
        }

        this.branchBankName = event.value;
      },
      onchangebranchbankname: function (event) {
        this.branchBankName = event.value;
        if (!this.branchBankName) {
          this.showAlertTips('请填写正确的支行名称');
        }
        // if (/\d/.test(this.branchBankName)) {
        //   this.showAlertTips('请输入正确的支行名称');
        // }
      },
      //弹窗事件
      showAlertTips: function (tips, time = 2000) {
        if (false == this.isShowAlert) {
          this.isShowAlert = true;
          this.alertTips = tips;
          setTimeout(() => {
            this.isShowAlert = false;
            // this.tips = '';
          }, time)
        }
      },
      //选择协议按钮事件
      onclickprotocol: function () {
        this.logEvent('check_btn_agree');
        this.isShowProtocol = !this.isShowProtocol;
      },
      //下一步事件
      onclicknext: function () {

        this.logEvent('btn_submit');
        var that = this;

        if (false == utils.checkName(this.userName)){
          this.showAlertTips('填写姓名的格式不正确');
          return;
        }

        if (that.userIDCardCode) {
          if (!that.cryptStatusDic.certNo_status) {
            if (!that.disableStatusDic.certNo_status) {
              if (that.certTypeTitle === "中国大陆") {
                if (!that.Check18CertNO(that.userIDCardCode)) {
                  that.showAlertTips('请填写正确的证件号码');
                  return;
                }
              }
            }
          }

        } else {
          that.showAlertTips('请填写证件号码');
          return;
        }

        if (that.bankCode) {
          if (!that.cryptStatusDic.bankCode_status) {
            if (!that.disableStatusDic.bankCode_status) {
              if (!/^\d{12,20}$/.test(that.bankCode)) {
                that.showAlertTips('请填写正确的银行卡号');
                return;
              }
            }
          }
        } else {
          that.showAlertTips('请填写银行卡号');
        }

        var bankNameCode = that.bankNameCode;

        if (that.bankName === '建、工、招、农行取款2小时到账') {
          that.showAlertTips('请选择银行名称');
          return;
        } else {
          for (var i = 0; i < that.bankNamesCodes.length; i++) {
            if (that.bankNamesCodes[i].bank === that.bankName) {
              bankNameCode = that.bankNamesCodes[i].code;
            }
          }
        }
        if (bankNameCode === '') {
          that.showAlertTips('请选择银行名称');
          return;
        } else if (bankNameCode === 'Other') {
          if (!that.cryptStatusDic.bankOtherName_status) {
            if (!that.disableStatusDic.bankOtherName_status) {
              if (that.isOtherBankName && !that.bankOtherName) {
                that.showAlertTips('请填写正确的银行名称');
                return;
              }
            }
          }
        }
        if (that.branchAddress.code === 'none') {
          that.showAlertTips('请选择支行区域');
          return;
        }
        //////////////////////////////// 结果校验
        if (that.branchAddress.province!='台湾' && that.branchAddress.province!='中国(香港)' && that.branchAddress.province!='中国(澳门)') {

          if (that.branchAddress.code === 'other'){
            if (!that.branchAddressOther) {
              that.showAlertTips('请填写支行区域地址');
              return;
            }
          } else {
            if (that.branchTwoAddress.code === 'none') {
              that.showAlertTips('请选择支行二级区域');
              return;
            }
            if (that.branchThreeAddress.code === 'none') {
              that.showAlertTips('请选择支行三级区域');
              return;
            }
          }

        }
        //////////////////////////////// 结果校验
        if (!that.cryptStatusDic.bankBranchName_status) {
          if (!that.disableStatusDic.bankBranchName_status) {
            if (!that.branchBankName) {
              that.showAlertTips('请填写正确的支行名称');
              return;
            }
          }
        }
        if (!that.isShowProtocol) {
          that.showAlertTips('请勾选用户协议');
          return;
        }

        var baseurl = that.bibApi + '/EditUserBank';

        let newBody = {
          format: 'json',
          isMobile: true,
          userID: that.userId
        };
        newBody.Sex = that.memberSex;
        newBody.name = that.userName;
        newBody.nationalArea = that.certTypeNumber;
        if (!that.cryptStatusDic.certNo_status) {
          newBody.certNo = that.userIDCardCode;
        }
        if (!that.cryptStatusDic.bankCode_status) {
          newBody.bindBankNo = that.bankCode;
        }
        newBody.bindBank = that.bankNameCode;

        if (!that.cryptStatusDic.bankOtherName_status) {
          newBody.TxtOtherBindBank = that.bankOtherName;
        }

        newBody.bindSubBankArea = that.branchAddress.code;
        if (that.branchAddress.code != 'other' || that.branchAddress.province!='台湾' && that.branchAddress.province!='中国(香港)' && that.branchAddress.province!='中国(澳门)') {
          newBody.bindSubBankAreaCity = that.branchTwoAddress.code;
          newBody.bindSubBankAreaCounty = that.branchThreeAddress.code;
        }

        if (!that.cryptStatusDic.bankBranchName_status) {
          newBody.bindSubBankName = that.branchBankName;
        }

        newBody.ibno = that.memberIntroducer;

        newBody.BindSubBankOther = that.branchAddressOther;

        let str = '';
        for (let key in newBody) {
          if (newBody[key]) {
            if (str) {
              str = `${str}&`
            }
            str = `${str}${key}=${newBody[key]}`;
          }
        }

        // console.log("bj 开户第二步结果:HHHHHHHHHHH:" + str);

        if (that.isSubmitBtnClick) {
          return;
        }
        that.isSubmitBtnClick = true;
        http.putForm(baseurl, str, function (response) {
          that.isSubmitBtnClick = false;
          // console.log("bj 开户第二步提交结果wwwwwwwwww:"+JSON.stringify(response));
          if (response.ok && response.data) {
            var result = response.data;
            if (result.IsOK) {
              storage.setItem('user_openaccount_from', that.openAccountFrom);
              navigator.push({
                url: bundleUrl + 'authentication.js',
                animated: "true",
                swipePop: "true",
                disableBackPan: 'true',
                currentPop: 'true'
              }, event => {
              })
              storage.getItem('userInfo', function (value) {
                if (value) {
                  var data = JSON.parse(value);
                  data.sex = that.memberSex;
                  storage.setItem('userInfo', JSON.stringify(data));
                }
              });

            } else {
              if (result.ResponseStatus && result.ResponseStatus.ErrorCode) {
                if (result.ResponseStatus.ErrorCode === 'CardNoExist') {
                  that.showAlertTips('该身份证号码已被注册，如需查询，请联系客服处理');
                } else if (result.ResponseStatus.ErrorCode === 'SoYoung') {
                  that.showAlertTips('开户投资必须年满18周岁');
                } else if (result.ResponseStatus.ErrorCode === 'AlreadyDone') {
                  that.showAlertTips('该客户已开户完成，若无法成功提交，请咨询在线客服');
                } else if (result.ResponseStatus.ErrorCode === 'IntroducerNoExist'){
                  if (result.Message){
                    that.showAlertTips(result.Message);
                  }else {
                    that.showAlertTips('对不起，推荐人不存在！');
                  }
                }else if (result.ResponseStatus.ErrorCode === 'InBlackList') {
                  that.showAlertTips('您好，注册信息无法成功提交，请咨询在线客服');
                }else {
                  that.showAlertTips('提交失败，请确认所填信息无误，若无法成功提交，请咨询在线客服');
                }
              }
            }
          } else {
            that.showAlertTips('资料提交失败，请重试');
          }
        })
      },
      onclickReload: function (e) {
        let that = this;
        that.isShowProtocol = false
        if (that.userName && !that.disableStatusDic.realName_status) {
          that.sexDataShow = that.sexData[0];
          that.memberSex = that.sexDataShow.code;
          that.userName = '';
        }
        if (that.userIDCardCode && !that.disableStatusDic.bankCode_status) {
          that.certTypeTitle = that.certTypes[that.certTypeIndex];
          that.certTypeNumber = appbasedata.certType[that.certTypeIndex].number;
          that.userIDCardCode = '';
          that.cryptStatusDic.certNo_status = false;
        }
        if (that.bankName) {
          that.bankName = '建、工、招、农行取款2小时到账';
          that.isOtherBankName = false;
          that.bankCode = '';
          that.bankNameCode = '';
          that.bankOtherName = '';
          that.cryptStatusDic.bankCode_status = false;
        }
        if (that.branchBankName && !that.disableStatusDic.bankBranchName_status) {
          that.branchBankName = '';
          that.cryptStatusDic.bankBranchName_status = false;
          that.branchThreeAddress = {"area": '请选择', "code": 'none'}
          that.branchTwoAddress = {"city": '请选择', "code": 'none'}
          that.branchAddress = {"province": '请选择', "code": 'none'}
        }
        if (that.memberIntroducer && !that.disableStatusDic.inputintroduce_status) {
          that.memberIntroducer = '';
        }
        if (that.isAndroid) {
          if (!that.disableStatusDic.realName_status) {
            that.$refs.inputname.clearText();
            that.$refs.inputname.blur();
          }
          if (!that.disableStatusDic.certType_status) {
            that.$refs.inputcertType.clearText();
            that.$refs.inputcertType.blur();
          }
          if (!that.disableStatusDic.bankCode_status) {
            that.$refs.inputbanknum.clearText();
            that.$refs.inputbanknum.blur();
          }
          if (!that.disableStatusDic.bankBranchName_status) {
            that.$refs.inputbranchBankName.clearText();
            that.$refs.inputbranchBankName.blur();
            that.branchThreeAddress = {"area": '请选择', "code": 'none'}
            that.branchTwoAddress = {"city": '请选择', "code": 'none'}
            that.branchAddress = {"province": '请选择', "code": 'none'}
          }
          if (!that.disableStatusDic.inputintroduce_status) {
            that.$refs.inputintroduce.clearText();
            that.$refs.inputintroduce.blur();
          }
        }
      },
      // 扫描身份证 or 银行卡
      onrecognize: function (e) {
        // 0 身份证
        // 1 银行卡
        var that = this;
        let dic = {};
        if (e) {
          dic = {title: '扫描银行卡', tips: '请将银行卡正面放入框内,并调整好光线', scanType: 1}
        } else {
          dic = {title: '扫描证件', tips: '请将身份证正面放入框内,并调整好光线', scanType: 0}
        }

        let str = JSON.stringify(dic);
        storage.setItem('recognize', str);
        if (utils.isAndroid()&& app){
          app.isCheckCameraPermission(function (value) {
            if (value) {
              that.startRecognize();
            }
          });
        }
        if (!utils.isAndroid()){
          that.startRecognize();
        }
      },
      startRecognize:function () {
        navigator.push({
          url: bundleUrl + 'recognize.js',
          animated: "true",
          swipePop: "true",
          disableBackPan: 'true',
        }, event => {
        })
      }

    }
  }
</script>

<style src="../style/common.css" scoped>
</style>
<style scoped>
  .text-item {
    color: white;
  }

  .item-row {
    position: absolute;
    left: 0px;
    right: 0px;
    top: 0px;
    flex-direction: row;
  }

  .line {
    flex: 1;
    height: 20px;
    border-bottom-width: 1px;
    border-bottom-color: #AA9B6A;
  }

  .whiteline {
    flex: 1;
    height: 20px;
  }

  .grayline {
    flex: 1;
    height: 20px;
    border-bottom-width: 1px;
    border-bottom-color: #ABABAB;
    /* border-bottom-style: dashed; */
  }

  .circle {
    width: 40px;
    height: 40px;
    border-radius: 20px;
    border-color: #2e74e9;
    border-width: 1px;
    align-items: center;
    justify-content: center;
    background-color: white;
    margin-bottom: 15px;
  }

  .dashed {
    border-style: dashed;
    border-color: #AA9B6A;
  }

  .innerCircle {
    width: 30px;
    height: 30px;
    background-color: #2e74e9;
    border-radius: 15px;
    align-items: center;
    justify-content: center;
  }

  .gray {
    background-color: #ABABAB;
  }

  .align {
    margin-left: 25px;
    margin-right: 25px;
  }

  .topBorderLine {
    background-color: #f1f1f1;
    height: 1px;
  }

  .tips {
    /*font-size: 28px;*/
    /*line-height: 46px;*/
    color: #454950;
  }

  .text {
    color: white;
  }

  .text {
    color: #333333;
  }

  .text-select {
    color: #ffffff;
  }

  .margin {
    margin-left: 30px;
    margin-right: 30px;
  }

  .color3 {
    color: #e9302e;
  }

  .color32 {
    color: #f62b16;
    margin-right: 12px;
  }

  .infoItem {
    flex: 1;
    /*width: 750px;*/
    height: 70px;
    justify-content: space-between;
    align-items: center;
    margin-top: 40px;
  }

  .infoItem-branch {
    flex: 1;
    height: 70px;
    justify-content: space-between;
    align-items: center;
    margin-top: 16px;
  }

  .input-view {
    width: 550px;
    height: 70px;
  }
  .input-view-w {
    width: 366px;
    height: 70px;
  }

  .input-auto {
    height: 70px;
    width: 183px;
    border-color: #DDDDDD;
    border-width: 1px;
    margin: 0;
    /* flex: 1; */
    align-items: center;
    justify-content: space-between;
  }

  .input {
    height: 70px;
    width: 550px;
    border-color: #DDDDDD;
    border-width: 1px;
  }
  .input-other {
    height: 70px;
    width: 366px;
    border-color: #DDDDDD;
    border-width: 1px;
  }
  .input-size-other {
    width: 326px;
    /* flex: 1; */
    height: 70px;
    font-size: 24px;
    margin-left: 20px;
    margin-right: 10px;
  }
  .sex-input {
    justify-content: center;
    align-items: center;
    height: 38px;
    width: 38px;
    margin-right: 20px;
  }

  .input-size {
    /* width: 500px; */
    flex: 1;
    height: 70px;
    font-size: 24px;
    margin-left: 20px;
    margin-right: 20px;
  }

  .input-down-select {
    width: 30px;
    height: 70px;
    /*backgroundColor:green;*/
    margin-right: 14px;
    margin-left: 5px;
    align-items: center;
    justify-content: center;
  }

  .select-id-areacode {
    width: 180px;
    height: 70px;
    justify-content: space-between;
    align-items: center;
    border-right-color: #dddddd;
    border-right-width: 1px;
  }

  .protocol {
    margin-top: 6px;
    background-color: #f7f7f6;
    height: 30px;
    width: 30px;
    border-color: #b6b6b6;
    border-width: 1px;
    border-radius: 5px;
    margin-right: 11px;
    align-items: center;
    justify-content: center;
  }

  .button-view {
    height: 88px;
    justify-content: space-between;
    align-items: center;
  }

  .button {
    height: 88px;
    justify-content: center;
    align-items: center;
    flex: 1;
    border-width: 1px;
    border-color: #2e74e9;
  }

  .button-gray {
    height: 88px;
    background-color: gray;
    justify-content: center;
    align-items: center;
    flex: 1;
  }

  .alert-show {
    position: absolute;
    left: 0px;
    top: 464px;
    right: 0px;
    bottom: 0px;
    align-items: center;
  }

  .alert-modul {
    height: 74px;
    border-radius: 37px;
    align-items: center;
    justify-content: center;
    padding-left: 60px;
    padding-right: 60px;
    /* background-color: rgba(0, 0, 0, 0.7); */
    background-color: #4c4c4c;
    opacity: 0.68;
  }

  .branch-bank-text {

    margin-left: 20px;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    lines: 1;
    width: 480px;
    line-height: 70px;
    text-align: center;
  }
</style>
