<template>
<div @viewappear="viewAppear">
  <image v-if="iOS" class="banner" style="position: absolute;top: 0px;" ref="banner" resize="cover" :src="bannerbg"></image>
  <scroller ref="scroller" show-scrollbar="false" offset-accuracy=1 scrollDirection="vertical" alwaysScrollableVertical="true" @scroll="scroll" @scrollend="scrollend">
    <div>
      <div class="screenwidth banner">
        <image v-if="!iOS" class="banner" resize="cover" :src="bannerbg"></image>
        <div style="position:absolute;left:30px;right:30px;bottom:32px;justify-content: flex-end;align-items:center;">
          <image class="avatar" resize="contain" :src="banner"></image>
          <text class="name">{{lecturer.name}}{{lecturer.subTitle?'·'+lecturer.subTitle:''}} </text>
          <text class="words" v-if="lecturer.summary">{{lecturer.summary}} </text>
          <div style="flex-direction:row;" v-if="tags && tags.length>0">
            <div class="lecturer-tags" v-for="item in tags">
              <image style="width:22px;height:44px;" :src="assets+'tags.png'"></image>
              <div class="lecturer-tags" style="backgroundColor:rgba(255,255,255,0.3)">
                <text class="tags">{{item}} </text>
              </div>
            </div>
          </div>
        </div>
        <div v-if="onair" class="onair" @click="showLiveView();logEvent('Teacher_page_LIVE')" >
              <image style="width:37px;height:31px;margin-left:30px;" resize="contain" :src="assets+'online.gif'"></image>
        </div>
      </div>
      <!--  本周课程 -->
      <div class="lesson" v-if="lessons.length>0">
        <div class="group-head">
          <text class="group-title"> 课程预告 </text>
        </div>
        <div class="lesson-item" v-for="(item,index) in lessons" v-if="index < showItems" @click="courseclick(item)">
          <div style="flex:1;flex-direction:row;justify-content:space-between;align-items:center;">
            <text class="size1 color1">{{item.date}} {{item.week}}</text>
            <div style="flex-direction: row;width:200px;align-items:center;justify-content: flex-end;">
              <image style="width:32px;height:32px;" resize="contain" :src="assets+(item.status == 2?'playing.png':'play.png')"></image>
              <text :class="['size1',(item.status == 2)?'color2':'color1']"> {{formatStatus(item.status)}}</text>
            </div>
        </div>
          <div style="flex:1;flex-direction:row;justify-content:space-between;align-items:center;">
            <text class="size1 color3">{{item.title}} {{item.time}}</text>
          </div>
        </div>
        <div class="lesson-more screenwidth" v-if="lessons && lessons.length >3 && lessons.length!=showItems" @click="showLessons">
          <image style="width:24px;height:24px;":src="assets+'plus.png'"></image>
          <text class="more"> 点击查看更多</text>
        </div>
      </div>
      <div style="height:16px;width:750px;background-color:#e1e1e1;" v-if="lessons.length>0"> </div>
      <!-- 最新策略 -->
      <div class="group-newest" v-if="newest.title">
        <div class="group-head">
          <!-- <image class="group-icon-left" :src="assets+'right.png'"></image> -->
          <text class="group-title"> 最新策略 </text>
          <!-- <image class="group-icon" :src="assets+'right.png'"></image> -->
        </div>
        <div class="newest" @click="commentClick(newest.link)" v-if="newest.title">
          <text class="newest-titile">{{newest.title}} {{newest.subtitle}}</text>
          <text class="newest-content">{{newest.content}}</text>
          <div class="newest-bottom">
            <text class="newest-more">{{'更多>>'}}</text>
            <!-- <div style="flex-direction:row; overflow:hidden;flex:1;margin-right:20px;">
              <text class="newest-tag" v-for="tag in newest.tag" @click="showTopic(tag)">{{tag}} </text>
            </div> -->
            <text class="newest-time" v-if="newest.time">发布于 {{newest.time}}</text>
          </div>
        </div>
      </div>
      <div style="height:16px;width:750px;background-color:#e1e1e1;" v-if="newest.title"> </div>
      <div class="group-newest" v-if="comments.length>0">
        <div class="group-head">
          <text class="group-title"> 往期策略 </text>
        </div>
        <div class="strategy">
          <div style="height:80px;flex-direction:row;align-items:center;justify-content:space-between;" v-for="(item,index) in comments" v-if="index!=0" @click="commentClick(item.link)">
            <text class="strategy-item-title">{{item.title}} </text>
            <text class="strategy-item-time"> {{item.time}}</text>
          </div>
          <div class="loading" v-if="loadinging || loadingComments">
            <loading-indicator class="loading-indicator"></loading-indicator>
            <text class="loading-indicator-text">{{loadingTips}} </text>
          </div>
          <div v-else class="loading" @click="loadmore();logEvent('Teacher_page_strategy')">
            <image v-if="totalItem != comments.length" style="width:24px;height:24px;":src="assets+'plus.png'"></image>
            <text class="more"> {{totalItem != comments.length?' 点击查看更多':'没有更多了'}} </text>
          </div>
        </div>
      </div>
    </div>
  </scroller>
  <div :class="[iphonex?'bottom-ipx':'bottom']">
    <div style="flex:1;justify-content:center;align-items:center;background-color:#2e74e9" @click="showLiveView();logEvent('Teacher_page_LIVE')">
      <text class="size3" style="color:white"> 进入直播间 </text>
    </div>
  </div>
  <div v-if="isLoadError" style="position:absolute;left:0px; top:0px;right:0px; bottom:0px;background-color: white;justify-content: center;align-items: center">
    <loadError @refreshNetWorkError="refreshNetWorkError"></loadError>
  </div>
  <div class="head-title">
    <!-- <status backgroundColor="#E93030" style="opacity:{{opacity}}"></status> -->
    <status backgroundColor="#FFFFFF" :style="{opacity:(true == isLoadError)?'1':opacity }"></status>
    <div class="navbar">
      <div :style="{opacity:(true == isLoadError)?'1':opacity }" style="position: absolute;left: 0px;top: 0px;right: 0px;bottom: 0px;background-color: #FFFFFF;"></div>
      <text class="navbar-title"> 老师专栏 </text>
      <div @click="goBack" class="goback">
        <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
        <!-- <text class="navbar-title-left"> 返回 </text> -->
      </div>
    </div>
  </div>
  <message></message>
</div>
</template>

<script>
const bundleUrl = require('../include/base-url.js').bundleUrl();
const assetsUrl = require('../include/base-url.js').assetsUrl();
const animations = weex.requireModule('animation');
const navigator = weex.requireModule('navigator')
const storage = require('../include/storage.js');
const utils = require('../include/utils.js');
const http = require('../include/http.js');
const dom = weex.requireModule('dom');
const app = weex.requireModule('app');
const firebase = weex.requireModule('firebase');

module.exports = {
  components: {
    'status': require('../components/statusbar.vue'),
    'loadError': require('../components/loadError.vue'),
    'message': require('../components/message.vue'),
  },
  data: function() {
    return {
      assets: assetsUrl,
      commentsId: 0, //栏目ID
      bannerbg: assetsUrl + 'lecturerbg.png',
      banner: '',
      tags: [],
      lecturer: {},
      lessons: [],
      onair: false, //直播标记
      showItems: 3, //显示信息条信，默认值：3
      pageSize: 10,
      pageIndex: 0,
      totalItem: 0, //服务器上评论总条线
      comments: [], //实盘评论
      refreshing: false, //刷新中
      loadinging: false, //加载中
      loadingTips: '上拉加载',
      loadingLesson: false,
      loadingComments: false,
      top: 0,
      bannerHeight: 566,
      scrollerH: 0,
      opacity: 0,
      isLoadError: false, //网络加载出错
    }
  },
  computed: {
    newest: function() {
      var topic = {}
      if (this.comments.length > 0) {
        topic.title = this.comments[0].title;
        topic.content = this.comments[0].content;
        topic.time = this.comments[0].time;
        topic.tag = this.comments[0].tag;
        topic.link = this.comments[0].link;
      } else {
        topic.title = '';
        topic.content = '';
        topic.time = '';
        topic.tag = [];
        topic.link = '';
      }
      return topic;
    },
    iOS: function() {
      const {
        platform
      } = weex.config.env;
      return platform.toLowerCase() === 'ios';
    },
    iphonex: function() {
      return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' || weex.config.env.deviceModel === 'iPhone11,2' || weex.config.env.deviceModel === 'iPhone11,4' || weex.config.env.deviceModel ===
        'iPhone11,6' || weex.config.env.deviceModel === 'iPhone11,8');
    }
  },
  mounted: function() {
    setTimeout(this.getRect.bind(this), 1000);
  },
  created: function() {
    var that = this;
    var ms = new Date();
    this.dateStr = utils.dateFormat(ms.getTime(), 'yyyy-MM-dd');
    var day = ms.getDay();
    if (6 <= day) {
      //星期六  则需要取到下周六的课程
      this.days = 8;
    } else {
      this.days = 7 - ms.getDay();
    }

    this.logEvent('Teacher_page');
    storage.getItem('commonUrl', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.cmsApiHost = commonUrl.cmsApi; //接口基址
        that.imageBaseUrl = commonUrl.imageBaseUrl; //图片基址
        that.contentBaseUrl = commonUrl.contentBaseUrl; //文章基址
        storage.getItem("lecturer", function(data) {
          if (data) {
            that.lecturer = JSON.parse(data);
            that.getLecturer();
            that.getLessons();
          }
        });
        storage.getItem("nodeIdList", function(data) {
          if (data) {
            var nodeIdList = JSON.parse(data);
            that.commentsId = nodeIdList.strategy;
            that.getComments(that.commentsId);
          }
        });
      }
    });
    storage.getItem('topic', function(value) {
      if (value && value.length > 0) {
        that.topicTags = JSON.parse(value);
      }
    });
  },
  methods: {
    // 接收网络错误的点击事件的回调
    refreshNetWorkError: function() {
      this.refresh();
    },
    getRect: function() {
      var el = this.$refs.scroller;
      if (el) {
        var that = this;
        dom.getComponentRect(el, function(callBack) {
          that.scrollerH = parseInt(callBack.size.height);
          if (utils.isAndroid())
            that.scrollerH += 3;
          // console.log("mounted " + JSON.stringify(callBack.size));
        });
      }
    },
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    scrollend: function(e) {
      if (this.loadinging) {
        this.loadingTips = "正在加载";
        this.loadmore();
      }
    },
    scroll: function(e) {
      if (e.contentOffset.y < 0) {
        this.top = e.contentOffset.y;
        if (utils.isAndroid()) {
          this.opacity = 1;
        } else {
          this.opacity = -e.contentOffset.y / 200;
        }
        this.height = this.bannerHeight;
        if (this.scrollerH - e.contentOffset.y >= e.contentSize.height && !this.loadinging) {
          this.loadinging = true;
          this.loadingTips = "上拉加载";
        }
      } else {
        this.top = 0;
        this.opacity = 0;
        this.height = this.bannerHeight + e.contentOffset.y;
      }
      var bannerEl = this.$refs.banner;
      if (bannerEl) {
        animations.transition(bannerEl, {
          styles: {
            height: this.height,
            transform: 'translateY(' + this.top + 'px) ',
          },
          duration: 0, //ms
          timingFunction: 'linear',
          delay: 0, //ms
        }, function() {})
      }
    },
    viewAppear: function() {
      if (app) {
        app.setStatusBarStyle(0);
      }
    },
    goBack: function() {
      this.logEvent('Teacher_page_back');
      navigator.pop({
        animated: "true"
      }, res => {});
    },
    showLessons: function() {
      this.logEvent('Teacher_page_schedule_more');
      this.showItems = this.lessons.length;
    },
    getLecturer: function() {
      var that = this;
      if (that.cmsApiHost && that.lecturer.channelId) {
        var url = that.cmsApiHost + '/ContentUnion/Site?format=json&ChannelId=' + that.lecturer.channelId + "&Title=" + this.lecturer.name;
        http.get(encodeURI(url), function(response) {
          that.isLoadError = false;
          if (response.status < 200) {
            that.isLoadError = true;
          }
          if (response.ok && response.data) {
            var results = response.data.Results;
            if (results && results.length > 0) {
              that.lecturer.subTitle = results[0].SubTitle;
              if (results[0].Tags) {
                // that.tags = results[0].Tags.split(',');
                that.tags = results[0].Tags.split(/[,\s，]/);
              }
              that.lecturer.summary = results[0].appsummary;
              // if (results[0].appteacherbanner) {
              //   that.banner =  results[0].appteacherbanner.replace('@', that.imageBaseUrl);
              // }
              if (results[0].apphometeacher) {
                that.banner = results[0].apphometeacher.replace('@', that.imageBaseUrl);
              }
            }
          }
        });
      }
    },
    getLessons: function() {
      var that = this;
      if (that.loadingLesson) {
        return;
      }
      that.loadingLesson = true;
      var url = this.cmsApiHost + '/Live/LessonsGroup?format=json&channel=bibfx&days=' + this.days + '&DateTime=' + this.dateStr + "&NameContains=" + this.lecturer.name;
      http.get(encodeURI(url), function(response) {
        that.isLoadError = false;
        if (response.status < 200) {
          that.isLoadError = true;
        }
        that.loadingLesson = false;
        that.refreshing = false;
        that.loadinging = false;
        that.loadingFinish();
        if (response.ok && response.data) {
          that.lessons.splice(0, that.lessons.length);
          var data = response.data;
          that.onair = false;
          for (var i = 0; i < data.length; i++) {
            var array = data[i].lessons;
            for (var j = 0; j < array.length; j++) {
              var item = {};
              item.week = data[i].week;
              item.startTime = parseInt(array[j].StartTime.replace('/Date(', '').replace(')/', '').substring(0, 13)); // /Date(1522566000000-0000)/
              item.endTime = item.startTime + array[j].TimeSpan; //TimeSpan
              item.date = utils.dateFormat(item.startTime, "MM月dd日")
              item.title = array[j].Title;
              item.time = utils.dateFormat(item.startTime, 'hh:mm') + ' - ' + utils.dateFormat(item.endTime, 'hh:mm');
              item.status = that.status(item.startTime, item.endTime);
              if (2 == item.status) {
                that.onair = true;
              }
              that.lessons.push(item);
            }
          }
        }
      });
    },
    getComments: function(channelId = 0) {
      var that = this;
      if (that.loadingComments) {
        return;
      }
      that.loadingComments = true;
      var url = this.cmsApiHost + '/ContentUnion/Site?format=json&OrderByDesc=AddDate&ContentNum=100&Take=' + (this.pageIndex > 0 ? this.pageSize : 6)  + '&Skip=' + (this.pageIndex > 0 ? that.comments.length : 0) + '&channelId=' + channelId + '&Author=' + this.lecturer.name;

      http.get(utils.encodeURLParams(url), function(response) {
        that.refreshing = false;
        that.loadinging = false;
        that.loadingComments = false;

        that.isLoadError = false;
        if (response.status < 200) {
          that.isLoadError = true;
        }
        that.loadingFinish();
        if (response.ok && response.data) {
          var results = response.data.Results;
          if (response.data.Total) {
            that.totalItem = response.data.Total;
          }
          if (results && results.length > 0) {
            if (0 == that.pageIndex) {
              that.comments.splice(0, that.comments.length);
            }
            for (var i = 0; i < results.length; i++) {
              var item = {};
              item.id = results[i].Id
              item.author = results[i].Author;
              item.title = results[i].Title;

              item.content = results[i].ContentNoHtmlTag;
              // item.tag = results[i].Tags;
              if (results[i].Tags) {
                item.tag = results[i].Tags.split(',');
              } else {
                item.tag = [];
              }
              item.time = that.showTime(results[i].AddDate);
              item.link = results[i].ContentFilePathRule;
              that.comments.push(item);
            }
            that.pageIndex++;
          }
        }
      });
    },
    showTime: function(time) {
      // var date = new Date(time.replace(new RegExp(/-/gm), "/"));
      //   time的格式   /Date(1509935433000-0000)/
      var stamp = time.replace('/Date(', '').replace(')/', '').substring(0, 13);
      var date = new Date(parseInt(stamp));
      var now = new Date();
      var duration = (now.getTime() - date.getTime()) / 1000;
      if (duration < 60) {
        return '刚刚';
      } else if (duration < 3600) {
        return Math.floor(duration / 60) + '分钟前';
      } else if (duration < 86400) {
        return Math.floor(duration / 3600) + '小时前';
      } else if (duration < 172800) {
        return '1天前';
      } else {
        return (date.getMonth() + 1) + '月' + date.getDate() + '日';
      }
    },
    status: function(start, end) {
      var ms = Date.now();
      if (ms > end) {
        return 3;
      }
      if (ms < start) {
        return 1;
      }
      return 2;
    },
    formatStatus: function(type) {
      switch (type) {
        case 1:
          return "未开始";
          break;
        case 2:
          return "直播中";
          break;
        case 3:
          return "已结束";
          break;
        default:
          return "";
      }
    },
    commentClick: function(link) {
      this.logEvent('Teacher_page_article');
      if (link && link.length > 4 && this.contentBaseUrl && this.contentBaseUrl.length > 6) {
        var data = {
          title: '',
          url: this.contentBaseUrl + link,
          type: 'article'
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    refresh: function(e) {
      // console.log("refresh 111111 "+this.loadingLesson+' '+ this.loadingComments);
      var that = this;
      if (false == this.loadingLesson && false == this.loadingComments) {
        that.refreshing = true;
        // setTimeout(() => {
        //   that.refreshing = false;
        //   console.log("refresh 33333333");
        // }, 500)
        setTimeout(() => {
          that.pageIndex = 0;
          that.showItems = 3;
          that.getLessons();
          that.getComments(this.commentsId);
        }, 1000)
      }
    },
    loadmore: function(e) {
      if (false == this.loadingComments) {
        this.loadinging = true;
        this.getComments(this.commentsId);
        // setTimeout(() => {}, 300)
      }
    },
    loadingFinish: function() {
      // if (false == this.loadingLesson && false == this.loadingComments) {
      //   setTimeout(() => {
      //     this.refreshing = false;
      //   }, 500)
      // }
    },
    showLiveView: function() {
      const Steve = new BroadcastChannel('showView');
      Steve.postMessage('live')
      this.back();
    },
    showRankList: function() {
      navigator.push({
        url: bundleUrl + 'ranklist.js',
        animated: "true",
        swipePop: "true",
      }, event => {})
    },
    courseclick: function(item) {
      let ms = new Date().getTime();
      //直播中的课程，跳到直播业页
      if (ms >= item.startTime && ms <= item.endTime) {
        this.logEvent('Teacher_page_schedule_OnLive');
        this.showLiveView();
      }
    },
    showTopic: function(topic) {
      if (this.topicTags == undefined || this.topicTags.length <= 0) {
        return;
      }
      let id = 0;
      let title = topic.replace(/^#|#$/g, '');
      for (var i = 0; i < this.topicTags.length; i++) {
        if (title == this.topicTags[i].Title) {
          id = this.topicTags[i].Id;
        }
      }

      if (id <= 0) {
        return;
      }
      if (id > 0 || id.length > 0) {
        storage.setItem('tags', JSON.stringify({
          'title': title,
          'id': id
        }));
        navigator.push({
          url: bundleUrl + 'topic.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
  }
}
</script>

<style scoped>
.screenwidth {
  width: 750px;
}

.banner {
  width: 750px;
  height: 566px;
}

.avatar {
  width: 160px;
  height: 160px;
  border-radius: 80px;
  margin-bottom: 20px;
}

.head-title {
  position: absolute;
  top: 0px;
  left: 0px;
  right: 0px;
}

.navbar {
  width: 750px;
  height: 88px;
  align-items: center;
  justify-content: center;
}

.navbar-title {
  font-size: 36px;
  color: #242424;
}

.navbar-title-left {
  font-size: 32px;
  color: #242424;
}

.goback {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 200px;
  padding-left: 30px;
  flex-direction: row;
  align-items: center;
}

.name {
  font-size: 36px;
  line-height: 54px;
  color: white;
  font-style: normal;
  font-weight: bold;
  lines: 1;
  text-overflow: ellipsis;
  /* margin-bottom: 24px; */
}

.words {
  font-size: 26px;
  line-height: 40px;
  color: white;
  font-style: normal;
  font-weight: normal;
  margin-bottom: 16px;
  text-overflow: ellipsis;
  text-align: center;
  lines:2;
}

.lecturer-tags {
  height: 44px;
  margin-right: 10px;
  flex-direction: row;
  align-items: center;
  border-top-right-radius: 5px;
  border-bottom-right-radius: 5px;
}

.tags {
  font-size: 24px;
  color: #2E74E9;
  margin-left: 10px;
  margin-right: 10px;
  font-style: normal;
  font-weight: normal;
  text-align: center;
}

.lesson {
  width: 750px;
  background-color: #FFFFFF;
}

.group-head {
  width: 750px;
  flex-direction: row;
  align-items: center;
  margin-top: 36px;
  margin-bottom: 8px;
  border-left-color: #2E74E9;
  border-left-width: 4px;
}

.group-icon-left {
  width: 2px;
  height: 20px;
}

.group-icon {
  width: 76px;
  height: 14px;
}

.group-title {
  font-size: 36px;
  margin-left: 18px;
  margin-right: 18px;
  color: #242424;
}

.lesson-item {
  /* width: 750px; */
  height: 126px;
  margin-left: 30px;
  margin-right: 30px;
  padding-top: 25px;
  padding-bottom: 25px;
  border-bottom-color: #e1e1e1;
  border-bottom-width: 1px;
  border-bottom-style: solid;
}

.size1 {
  font-size: 28px;
}

.size2 {
  font-size: 24px;
}

.size3 {
  font-size: 34px;
}

.color1 {
  color: #9ba1ab;
}

.color2 {
  color: #2E74E9;
}

.color3 {
  color: #333333;
}
.lesson-more {
  height: 112px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
}

.more {
  font-size: 30px;
  color: #999999;
  text-align: center;
}

.group-newest {
  width: 750px;
  background-color: #FFFFFF;
}

.newest {
  margin-left: 30px;
  margin-right: 30px;
  background-color: #FFFFFF;
}

.newest-titile {
  font-size: 32px;
  line-height: 64px;
  color: #454950;
  margin-top: 26px;
  /* margin-bottom: 26px; */
}

.newest-content {
  font-size: 28px;
  color: #9ba1ab;
  line-height: 45px;
  lines: 3;
  text-overflow: ellipsis;
}

.newest-bottom {
  flex-direction: row;
  justify-content: space-between;
  margin-top: 8px;
  margin-bottom: 8px;
}

.newest-tag {
  font-size: 28px;
  line-height: 56px;
  color: #e9302e;
  text-overflow: ellipsis;
  lines: 1;
}

.newest-more {
  font-size: 28px;
  line-height: 56px;
  color: #2E74E9;
  text-align: left;
  lines: 1;
}

.newest-time {
  font-size: 28px;
  line-height: 56px;
  color: #9ba1ab;
  /* width: 200px; */
  text-align: right;
  lines: 1;
}

.strategy {
  padding-left: 30px;
  padding-right: 30px;
  background-color: #FFFFFF;
}

.strategy-title {
  font-size: 32px;
  line-height: 64px;
  font-weight: bold;
  color: #454950;
  margin-top: 50px;
}

.strategy-item-title {
  font-size: 28px;
  color: #454950;
  lines: 1;
  flex: 1;
  /* margin-top: 40px; */
  text-overflow: ellipsis;
}

.strategy-item-time {
  font-size: 28px;
  color: #2E74E9;
  width: 150px;
  lines: 1;
  text-align: right;
  /* margin-top: 40px; */
}

.bottom {
  bottom: 0px;
  width: 750px;
  height: 100px;
  flex-direction: row;
}

.bottom-ipx {
  bottom: 0px;
  width: 750px;
  height: 134px;
  flex-direction: row;
}

.refresh {
  width: 750px;
  /*height: 80px;*/
  height: 2px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
}

.indicator-text {
  color: white;
  font-size: 30px;
  margin-left: 8px;
  text-align: center;
}

.indicator {
  height: 50px;
  width: 50px;
  color: white;
}

.loading {
  flex: 1;
  height: 80px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
}

.loading-indicator-text {
  color: #9ba1ab;
  font-size: 30px;
  margin-left: 8px;
  text-align: center;
}

.loading-indicator {
  height: 50px;
  width: 50px;
  color: #9ba1ab;
}

.onair{
  position: absolute;
  right: 0px;
  bottom: 240px;
  width: 86px;
  height: 60px;
  justify-content: center;
  background-color: rgba(255, 255, 255, 0.5);
  border-top-left-radius: 30px;
  border-bottom-left-radius: 30px;
}

</style>
