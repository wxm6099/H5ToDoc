<template>
<div @viewappear="viewappear" @viewdisappear="viewDisappear" v-cloak>
  <status backgroundColor="#FFFFFF"></status>
  <div class="navbar">
    <div v-if="isFinancialCalendar" class="navbar-left" v-on:click="clickNavLeftButton">
      <text class="navbar-left-title">筛选</text>
      <image v-if="!isSearchConditionClicked" class="navbar-left-img" resize="contain" :src="calendar_nav_left_down"></image>
      <image v-else class="navbar-left-img" resize="contain" :src="calendar_nav_left_up"></image>
    </div>
    <div class="alignCenter" @click="isFinancialCalendar=false">
      <text :class="['navbar-title',isFinancialCalendar?'normalTitleColor':'focusTitleColor']">资讯</text>
      <div v-if="!isFinancialCalendar" style="width:30px;height:4px;background-color:#2E74E9"></div>
    </div>
    <div class="alignCenter" @click="showCalendar">
      <text :class="['navbar-title',isFinancialCalendar?'focusTitleColor':'normalTitleColor']">日历</text>
      <div v-if="isFinancialCalendar" style="width:30px;height:4px;background-color:#2E74E9"></div>
    </div>
    <div  v-if="isFinancialCalendar" @click="clickNavRightButton" class="navbar-right">
      <image style="width: 48px; height: 48px" resize="contain" :src="calendar_nav_right"></image>
    </div>
  </div>
  <div style="flex: 1;width: 750px">
    <div class="channel">
      <scroller ref="channelScroller" class="scroller wrap" show-scrollbar="false" scrollDirection="horizontal">
        <div :class="['channel-item','wrap',index == channelIndex?'channel-highlight':'channel-normal'] " v-for="(item , index) in channel" ref="channel" @click="channelClick(index)">
          <text :class="[index == channelIndex?'highlight':'normal']"> {{item.title}}</text>
        </div>
      </scroller>
    </div>
    <cycleslider class="content" auto-play="false" infinite="false" scroll-direction="horizontal" @change="changePage" :index="channelIndex">
      <div style="width:750px;" v-for="(items,idx) in channel">
        <list v-if="items.title != '财经日历'" show-scrollbar="false" scrollDirection="vertical" alwaysScrollableVertical="true">
          <refresh class="refresh" @refresh="onrefresh" :display="items.refreshing ? 'show' : 'hide'">
            <loading-indicator class="indicator"></loading-indicator>
            <text class="indicator-text">{{items.refreshing?"正在刷新":"下拉刷新"}}</text>
          </refresh>
          <cell class="content-item-news" v-if="true == items.title.includes('快讯')" v-for="(item ,index) in items.contents">
            <financialNews :news="item" :index="index"></financialNews>
          </cell>
          <!-- <cell v-if="0 == idx" class="capsule background0" @click="showCapsule">
            <image class="icon" :src="capsule"></image>
            <text class="capsule-title">{{capsuleText}} </text>
            <text class="capsule-detail"> 话题胶囊</text>
            <image class="arrow" :src="assets+'arrow.png'"></image>
          </cell> -->
          <cell v-if="false == items.title.includes('快讯')" class="content-item" :class="[(index % 2) ?'background1':'background0']" v-for="(item ,index) in items.contents" @click="commentClick(item.link)">
            <div style="flex:1;justify-content:space-between;">
              <text v-if="item.src" class="content-title-img">{{item.title}}</text>
              <text v-else class="content-title">{{item.title}}</text>
              <text v-if="!item.src" class="content-subtitle">{{item.content}}</text>
              <div style="flex-direction:row;align-items: center">
                <text class="content-date">{{item.time}}</text>
                <div style="background-color: #9ba1ab;width: 1px;height: 28px;margin-left: 12px;" v-if="item.tag.length>0"></div>
                <div class="content-tag-red" style="flex-direction:row;" v-if="item.tag.length>0">
                  <text v-for="tag in item.tag" class="content-tag-red" @click="showTopic(tag);logEvent('News_headline_Tag')">{{tag}} </text>
                </div>
              </div>
            </div>
            <div class="content-image" style="margin-left:30px;" v-if="item.src">
              <image class="content-image" resize="contain" :src="item.src"></image>
            </div>
          </cell>
          <loading v-if="items.pageIndex>0" class="refresh" @loading="onloading" :display="items.loadinging ? 'show' : 'hide'">
            <loading-indicator class="indicator"></loading-indicator>
            <text class="indicator-text">{{items.loadinging?"正在加载":"上拉加载"}}</text>
          </loading>
        </list>
        <div :class="['updateItems',items.updateItems>0?'updateItems-show':'updateItems-hide']">
          <div class="modul">
            <text style="color:#FFFFFF;font-size:28px;"> 本次更新{{items.updateItems}}条数据 </text>
          </div>
        </div>
      </div>
    </cycleslider>
    <calendar :class="[isFinancialCalendar?'calendarShow':'calendarHide']" :filterParams="filterParams"></calendar>
    <div v-if="isSelectCalendarClicked" style="position:absolute;left:0px; top:0px;right:0px; bottom:0px;background-color: #ffffff">
      <selectcalendar @selectCalendar="selectCalendar"></selectcalendar>
    </div>
    <div v-if="isSearchConditionClicked" style="position:absolute;left:0px; top:0px;right:0px; bottom:0px;background-color: #ffffff">
      <filter @confirmClick="onFilterConfirm"></filter>
    </div>
    <div v-if="isLoadError" style="position:absolute;left:0px; top:0px;right:0px; bottom:0px;background-color: white;justify-content: center;align-items: center">
      <loadError @refreshNetWorkError="refreshNetWorkError"></loadError>
    </div>
  </div>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var dom = weex.requireModule('dom')
var navigator = weex.requireModule('navigator')
var app = weex.requireModule('app')
var storage = require('../include/storage.js');
var http = require('../include/http.js');
var url = require('../include/url.js');
var modal = weex.requireModule('modal');
var firebase = weex.requireModule('firebase');

module.exports = {
  components: {
    'nav': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'financialNews': require('../components/financialNews.vue'),
    'calendar': require('../components/financialCalendar.vue'),
    'selectcalendar': require('../components/selectCalendar.vue'),
    'filter': require('./filter.vue'),
    'loadError': require('../components/loadError.vue'),
  },
  data: function() {
    return {
      assets: assetsUrl,
      calendar_nav_right: assetsUrl + 'calendar_nav.png',
      calendar_nav_left_up: assetsUrl + 'calendar_select_up.png',
      calendar_nav_left_down: assetsUrl + 'calendar_select_down.png',
      capsule: assetsUrl+'capsule.png',
      arrow: assetsUrl + 'arrow.png',
      title: '资讯',
      width: 0,
      position: 20,
      channelIndex: -1,
      lastIndex: 0,
      showMenu: false,
      channel: [], //栏目
      loadingData: false, //加载中
      pageIndex: 0,
      total: 0,
      contentOffset: 0,
      yearAndMonthAndDay: '', //首次进入7×24快讯的年月日
      isFinancialCalendar: false, //是否是财经日历的channel
      isSelectCalendarClicked: false, //是否点击了选择日历日期按钮
      isSearchConditionClicked: false, //是否点击了筛选按钮
      calendarSelectMonth: 0, //财经日历的月份
      filterParams:{},//日历筛选参数字典
      first: true, //android 防止多次调用viewappear
      inited: false,
      isLoadError: false, //网络加载出错
      duration:2000,
      modulStyle:{bottom:'0px',opacity:0}
    }
  },
  beforeCreate:function(){
    var that = this;
    that.first = true
    storage.getItem('commonUrl',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.cmsApiHost = commonUrl.cmsApi; //接口基址
        that.imageBaseUrl = commonUrl.imageBaseUrl; //图片基址
        that.contentBaseUrl = commonUrl.contentBaseUrl; //文章基址
      }
      storage.getItem('contentIdList', function(value) {
        var contentIdList = JSON.parse(value);
        that.topicCapsule = contentIdList.topicCapsule;//id未配置正确
        that.getCapsule();
      });
      storage.getItem('channel', function(data) {
        if (undefined == data || '' == data) {
          return;
        }
        var channels = JSON.parse(data);
        for (var i = 0; i < channels.length; i++) {
          channels[i].pageIndex = -1;
          channels[i].contents = [];
          channels[i].refreshing = false;
          channels[i].loadinging = true;
          channels[i].updateItems = 0;
          channels[i].lastId = 0;
          that.channel.push(channels[i]);
          that.getContent(i);
        }
        // that.getContent(0);
      });
      storage.getItem('topic', function(value) {
        if (value && value.length > 0) {
          that.tags = JSON.parse(value);
        }
      });
    });
  },
  mounted: function() {
    // setTimeout(this.channelClick.bind(this), 300);
    setTimeout(this.getComponentRect.bind(this), 1000);
  },
  created: function() {
    var that = this;
    that.first = true
    //处理导航栏日历按钮上的月份
    var month = new Date().getMonth() + 1;
    month = month < 10 ? '0' + month : month;
    that.calendarSelectMonth = month;
    // 接收日历选择的日期广播的值
    const calendar = new BroadcastChannel('selectCalendarDayNumber');
    calendar.onmessage = function(event) {
      var selectDay = new Date(event.data);
      var selectDate = new Date(selectDay);
      var month = selectDate.getMonth() + 1;
      month = month < 10 ? '0' + month : month;
      that.calendarSelectMonth = month;
      that.isSelectCalendarClicked = !that.isSelectCalendarClicked;
    }


    // // 接收网络错误的广播
    // const Network = new BroadcastChannel('GloballyRefreshNetwork');
    // Network.onmessage = function(event) {
    //   if (!that.isFinancialCalendar) {
    //     that.onrefresh();
    //   }
    // };
    // 接收广播传递财经日历的网络状态是否正常的状态
    const financialNetwork = new BroadcastChannel('financialNetworkError');
    financialNetwork.onmessage = function(event) {
      if (event.data == 'yes') {
        that.isLoadError = true;
      } else if (event.data == 'no') {
        that.isLoadError = false;
      }
    };
  },
  methods: {
      // 接收网络错误的点击事件的回调
      refreshNetWorkError:function(){
          if (!this.isFinancialCalendar) {
              this.onrefresh();
          }
      },
    viewappear: function() {
      var that = this;

      if (!that.first) {
        return
      }

      if (weex.supports('@module/app')) {
        weex.requireModule('app').setStatusBarStyle(0);
      }
      that.isSelectCalendarClicked = false;
      that.isSearchConditionClicked = false;
      var index = (this.channelIndex > 0) ? this.channelIndex : 0;
      storage.getItem("informationindex", function(e) {
        if (e && e.length > 0) {
          for (var i = 0; i < that.channel.length; i++) {
            if (that.channel[i].title == e) {
              index = i;
            }
          }
          storage.setItem("informationindex", '');
        }
        if (!that.inited) {
          that.inited = true;
          setTimeout(() => {
            that.channelClick(index)
          }, 500);
        } else {
          that.channelClick(index);
        }
      })
    },
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    selectCalendar: function(Calendar) {
      this.logEvent('News_calendar_date_today');
    },
    //点击标签的事件
    showTopic: function(topic) {
      if (this.tags == undefined || this.tags.length<=0) {
        return;
      }
      let id = 0;
      let title = topic.replace(/^#|#$/g,'');
      for (var i = 0; i < this.tags.length; i++) {
        if (title == this.tags[i].Title) {
          id = this.tags[i].Id;
        }
      }
      if (id <= 0) {
        return;
      }
      if (id >0 || id.length > 0) {
        storage.setItem('tags', JSON.stringify({
          'title': title,
          'id': id
        }));
        navigator.push({
          url: bundleUrl + 'topic.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    onrefresh: function(e) {
      var channelItem = this.channel[this.channelIndex];
      if (false == channelItem.refreshing) {
        channelItem.refreshing = true;
        setTimeout(() => {
          channelItem.pageIndex = 0;
          this.getContent(this.channelIndex);
        }, 500)
      }
    },
    onloading: function(e) {
      var channelItem = this.channel[this.channelIndex];
      if (false == channelItem.loadinging && false == channelItem.loadingData) {
        channelItem.loadinging = true;
        setTimeout(() => {
          this.getContent(this.channelIndex);
        }, 500)
      }
    },
    clickNavLeftButton: function() {
      this.isSearchConditionClicked = !this.isSearchConditionClicked;
      this.isSelectCalendarClicked = false;
      this.logEvent('News_calendar_choosing');
    },

    clickNavRightButton: function() {
      this.isSelectCalendarClicked = !this.isSelectCalendarClicked;
      this.isSearchConditionClicked = false;
      this.logEvent('News_calendar_date');
    },

    getComponentRect: function() {
      var that = this;
      for (let i = 0; i < this.channel.length; i++) {
        var el = this.$refs.channel[i];
        if (el == undefined) {
          continue;
        }
        dom.getComponentRect(el, function(callBack) {
          that.channel[i].left = callBack.size.left;
          that.channel[i].right = callBack.size.right;
          that.channel[i].width = callBack.size.width;
        });
      }
    },
    showCalendar:function(){
      this.isFinancialCalendar = true;
      // 广播传递选择的日历的日期值
      const calendar = new BroadcastChannel('androidDefaultCalendarDate');
      calendar.postMessage(new Date());
    },
    changePage: function(e) {
      if (e.index != this.channelIndex) {
        this.channelIndex = e.index;
        this.highlight();

        // 判断选择的item是否是财经日历
        this.isFinancialCalendar = false;
        if (this.channel[this.channelIndex].pageIndex < 0) {
          this.channel[this.channelIndex].pageIndex = 0;
          this.getContent(this.channelIndex);
        }
      }
      if (-1 != this.lastIndex) {
        this.lastIndex = this.channelIndex;
      }
    },
    scrollPage: function(e) {
      var ratio = parseFloat(e.offsetXRatio);
      if (0 == ratio) {
        this.lastIndex = this.channelIndex;
      }

      if (-1 == this.lastIndex) {
        return;
      }
      if (ratio > 0) { //向右滑
        let offset = this.channel[Math.max(this.channelIndex - 1, 0)].width * ratio
        let index = Math.max(this.channelIndex - 1, 0);
        this.position = this.channel[this.channelIndex].left - offset;
        this.width = this.channel[this.channelIndex].width - Math.abs(ratio) * (this.channel[this.channelIndex].width - this.channel[index].width);
      } else {
        let offset = this.channel[this.channelIndex].width * ratio;
        let index = Math.min(this.channelIndex + 1, this.channel.length - 1);
        this.position = this.channel[this.channelIndex].left - offset;
        this.width = this.channel[this.channelIndex].width - Math.abs(ratio) * (this.channel[this.channelIndex].width - this.channel[index].width);
      }
    },
    //高亮选中的栏目
    highlight: function() {
      var that = this;
      if (undefined == this.$refs.channel) {
        return;
      }
      var el = this.$refs.channel[this.channelIndex];
      if (el == undefined) {
        return;
      }
      this.$refs.channelScroller.getContentOffset(function(contentOffset) {
        dom.getComponentRect(el, function(callBack) {
          if (callBack.result == true) {
            if (contentOffset.x <= 0) {
              that.channel[that.channelIndex].left = callBack.size.left - contentOffset.x;
            } else {
              that.channel[that.channelIndex].left = callBack.size.left;
            }
            that.channel[that.channelIndex].width = callBack.size.width;
            that.channel[that.channelIndex].right = callBack.size.right;
            that.position = that.channel[that.channelIndex].left;
            that.width = that.channel[that.channelIndex].width;
            var offset = -that.channel[that.channelIndex].left;
            if ((that.channel[that.channelIndex].left + that.width / 2) > 375) {
              offset = (that.channel[that.channelIndex].width - 750) / 2;
            }
            if (el) {
              dom.scrollToElement(el, {
                offset: offset,
                animated: false
              });
            }
          }
        });
      });
    },
    channelClick: function(index = 0) {
      var that = this;
      if (index >= this.channel.length || index == this.channelIndex) {
        return;
      }
      this.lastIndex = -1;
      this.channelIndex = index;
      this.highlight();
      // 判断选择的item是否是财经日历
      this.isFinancialCalendar = false;
      if (this.channel[this.channelIndex].pageIndex < 0) {
        this.channel[this.channelIndex].pageIndex = 0
        this.getContent(index);
      }
      this.logChannelEvent(this.channel[this.channelIndex].title);
    },
    logChannelEvent:function(title){
      if (title == '皇御环球头条') {
        this.logEvent('News_tab_headline');
      } else if (title == '讲师直播策略') {
        this.logEvent('News_tab_strategy');
      } else if (title == '汇商股指评论') {
        this.logEvent('News_tab_analyst');
      } else if (true == title.includes('快讯')) {
        this.logEvent('News_tab_livenews');
      } else if (title == '财经日历') {
        this.logEvent('News_tab_calendar');
      }
    },
    viewDisappear: function() {
      this.first = true;
    },
    getContent: function(index) {
      var that = this;
      var channelItem = that.channel[index];
      if (channelItem.loadingData) {
        return;
      }

      if (channelItem.title == '财经日历') {
        channelItem.pageIndex = -1;
        return;
      }

      if (channelItem.title.includes('快讯')) {
        channelItem.loadingData = true;
        if (0 > channelItem.pageIndex) {
            channelItem.pageIndex = 0;
            channelItem.updateItems = 0;
        }
        var url = this.cmsApiHost + '/News/CalendarWithNews?format=json&Take=10&OrderByDesc=AddDate&Skip=' + (channelItem.pageIndex>0?channelItem.contents.length:0);
        http.get(url, function(response) {
          channelItem.refreshing = false;
          channelItem.loadinging = false;
          channelItem.loadingData = false;
          that.isLoadError = false;
          if (response.status < 200) {
            that.isLoadError = true;
          }
          if (response.ok && response.data) {
            var results = response.data.Results;
            if (results && results.length > 0) {
              if (0 == channelItem.pageIndex) {
                channelItem.contents.splice(0, channelItem.contents.length);
                channelItem.updateItems = 0;
                // channelItem.pageIndex++;
              }
              for (var i = 0; i < results.length; i++) {
                var item = {};
                item.id = results[i].ID || results[i].Id;
                item.title = results[i].TitleNoTag;
                item.content = results[i].ContentNoTag;
                item.importance = results[i].Importance;//重要性
                item.predictedValue = results[i].PredictedValue;//预测值
                item.forcastValue = results[i].ForcastValue;    //前值
                item.publishedValue = results[i].PublishedValue;//PublishedValue
                item.isPublished = results[i].IsPublished;      //是否发布
                item.bullishOrBearish = results[i].BullishOrBearish; //看涨或看跌  (利多,利空, 影响较小,未公布)
                if ('利多' == item.bullishOrBearish) {
                  item.color ='green';
                } else if ('利空' == item.bullishOrBearish){
                  item.color ='red';
                } else {
                  item.color ='yellow';
                }

                if (results[i].RelationSymbol) {
                  item.symbol = results[i].RelationSymbol.replace(/-/g,'');
                }

                item.newsType = results[i].NewsType;
                item.star = results[i].Star;
                item.AddDate = results[i].AddDate;
                item.LastEditDate = results[i].LastEditDate;
                var dicDate = that.getTheDateTime(item.AddDate);
                item.numYMD = dicDate.numYMD;
                item.year = dicDate.year;
                item.month = dicDate.month;
                item.numDay = dicDate.numDay;
                item.shoreTime = dicDate.numHMS;
                item.showDayAndMonth = false;
                if (i == 0 && channelItem.pageIndex == 1) {
                  item.showDayAndMonth = true;
                  that.yearAndMonthAndDay = item.numYMD;
                } else {
                  var stringYMD = item.numYMD;
                  if (stringYMD != that.yearAndMonthAndDay) {
                    item.showDayAndMonth = true;
                    that.yearAndMonthAndDay = stringYMD;
                  }
                }
                channelItem.contents.push(item);
              }

              if (0 == channelItem.pageIndex ) {
                let id = 0;
                let count = 0;
                channelItem.updateItems = 0;
                for (var i = 0; i < channelItem.contents.length; i++) {
                  if (i == 0) {
                    id = channelItem.contents[i].id;
                  }
                  if (channelItem.lastId == channelItem.contents[i].id) {
                    id = channelItem.contents[i].id;
                    break;
                  }
                  count ++;
                }

                if (count>0) {
                  channelItem.updateItems = count;
                  setTimeout(() => {
                    channelItem.updateItems = 0;
                  }, that.duration);
                }
                channelItem.lastId = id;
              }else {
                channelItem.updateItems = 0;
              }
              channelItem.pageIndex++;
              that.channel.splice(0, 0);
            }
          }
        });
        return;
      }
      channelItem.loadingData = true;
      if (0 > channelItem.pageIndex) {
          channelItem.pageIndex = 0;
          channelItem.updateItems = 0;
      }
      var url = this.cmsApiHost + '/ContentUnion/Site?format=json&OrderByDesc=IsTop,AddDate&Take=10&ContentNum=100&Skip=' + (channelItem.pageIndex>0 ? channelItem.contents.length:'0') + '&ChannelIds=' + channelItem.ids;
      http.get(url, function(response) {
        channelItem.refreshing = false;
        channelItem.loadinging = false;
        channelItem.loadingData = false;
        that.isLoadError = false;
        if (response.status < 200) {
          that.isLoadError = true;
        }
        if (response.ok && response.data) {
          var results = response.data.Results;
          if (results && results.length > 0) {
            if (0 == channelItem.pageIndex) {
              channelItem.contents.splice(0, channelItem.contents.length);
              channelItem.updateItems = 0;
            }
            for (var i = 0; i < results.length; i++) {
              var item = {};
              item.id = results[i].Id
              item.author = results[i].Author;
              item.title = results[i].Title;
              item.content = results[i].ContentNoHtmlTag;
              if (/^http/.test(results[i].LinkUrl)) {
                item.link = results[i].LinkUrl;
              } else {
                item.link = that.contentBaseUrl + results[i].ContentFilePathRule;
              }
              if (results[i].Tags) {
                item.tag = results[i].Tags.split(',');
              } else {
                item.tag = [];
              }
              if (results[i].appImageUrl && results[i].appImageUrl.length > 0) {
                  item.src = results[i].appImageUrl.replace('@', that.imageBaseUrl);
              } else {
                item.src = '';
              }
              item.time = that.showTime(results[i].AddDate);
              channelItem.contents.push(item);
            }
            if (0 == channelItem.pageIndex ) {
              let id = 0;
              let count = 0;
              for (var i = 0; i < channelItem.contents.length; i++) {
                if ( 0 == i) {
                    id = channelItem.contents[i].id;
                }
                if (channelItem.lastId == channelItem.contents[i].id) {
                  id = channelItem.contents[i].id;
                  break;
                }
                count ++;
              }
              if (count>0) {
                channelItem.updateItems = count;
                setTimeout(() => {
                  channelItem.updateItems = 0;
                }, that.duration);
              }
              channelItem.lastId = id;
            }else {
              channelItem.updateItems = 0;
            }
            channelItem.pageIndex++;
            that.channel.splice(0, 0);
          }
        }
      },10000);
    },
    logCommentEvent:function(title){
      if (title == '皇御环球头条') {
        this.logEvent('News_headline_Article');
      } else if (title == '讲师直播策略') {
        this.logEvent('News_strategy_Article');
      } else if (title == '汇商股指评论') {
        this.logEvent('News_analyst_Article');
      }
    },
    commentClick: function(link) {
      this.logCommentEvent(this.channel[this.channelIndex].title);
      if (link && link.length > 4 && this.contentBaseUrl && this.contentBaseUrl.length > 6) {
        var data = {
          // title: this.channel[this.channelIndex].title,
          title: '',
          url: link,
          type:'comment'
        }
        data.title = this.channel[this.channelIndex].title;


        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    showTime: function(time) {
      // var date = new Date(time.replace(new RegExp(/-/gm), "/"));
      var date = new Date(parseInt(time.replace('/Date(','').replace(')/','').substring(0,13)));
      var now = new Date();
      var duration = (now.getTime() - date.getTime()) / 1000;
      if (duration < 60) {
        return '刚刚';
      } else if (duration < 3600) {
        return Math.floor(duration / 60) + '分钟前';
      } else if (duration < 86400) {
        return Math.floor(duration / 3600) + '小时前';
      } else if (duration < 172800) {
        return '1天前';
      } else {
        return (date.getMonth() + 1) + '月' + date.getDate() + '日';
      }
    },

    getTheDateTime: function(strDate) {
      //strDate的类型严格为：/Date(1527132678000+0800)/
      var time = strDate.slice(6, 19);
      var date = new Date(parseInt(time));
      var year = date.getFullYear();
      var month = date.getMonth() + 1;
      var numMonth = month < 10 ? '0' + month : month;
      var day = date.getDate();
      var numDay = day < 10 ? '0' + day : day;
      var hour = date.getHours();
      var numHour = hour < 10 ? '0' + hour : hour;
      var minute = date.getMinutes();
      var numMinute = minute < 10 ? '0' + minute : minute;
      var second = date.getSeconds();
      var numSecond = second < 10 ? '0' + second : second;
      var week = date.getDay();
      var YMD = year + '-' + month + '-' + day;
      var numYMD = year + '-' + numMonth + '-' + numDay;
      var HMS = hour + ':' + minute + ':' + second;
      var numHMS = numHour + ':' + numMinute + ':' + numSecond;
      var dic = {
        year: year,
        month: month,
        numMonth: numMonth,
        day: day,
        numDay: numDay,
        hour: hour,
        numHour: numHour,
        minute: minute,
        numMinute: numMinute,
        second: second,
        numSecond: numSecond,
        week: week,
        YMD: YMD,
        numYMD: numYMD,
        HMS: HMS,
        numHMS: numHMS,
      };
      return dic;
    },
    onFilterConfirm: function(filter) {
      this.filterParams = filter;
      this.isSearchConditionClicked = false;

    },
    defaultCapsule: function() {
      this.capsule = this.assets + 'capsule.png';
      this.capsuleText = '今日值得看,全天热度文章';
    },
    getCapsule: function() {
      var that = this;
      var url = this.cmsApiHost + '/ContentUnion/Site?format=json&id=' + that.topicCapsule;
      http.get(url, function(response) {
        that.isLoadError = false;
        if (response.status < 200) {
          that.isLoadError = true;
        }
        if (response.ok && response.data && response.data.Results && response.data.Results.length > 0) {
          var result = response.data.Results[0];
          if (result) {
            // that.capsule = result.appImageUrl.replace('@', that.imageBaseUrl);
            that.capsuleText = result.Summary;
          } else {
            that.defaultCapsule();
          }
        } else {
          that.defaultCapsule();
        }
      });
    },
    showCapsule: function() {
      this.logEvent('Headline_page_tag');
      navigator.push({
        url: bundleUrl + 'capsule.js',
        animated: "true",
        swipePop: "true",
      }, event => {})
    }
  },
}
// export default {
//     components: {FinancialCalendar}
// }
</script>

<style scoped>
.wrap {
  overflow: hidden;
  flex-direction: row;
}

.navbar {
  width: 750px;
  height: 88px;
  background-color: #FFFFFF;
  align-items: center;
  justify-content: center;
  flex-direction: row;
  border-bottom-color: #f1f1f1;
  border-bottom-width: 1px;
}

.navbar-title {
  font-size: 36px;
  line-height: 84px;
  text-align: center;
  margin-left: 24px;
  margin-right: 24px;
}

.normalTitleColor{
  color: #333333;
}

.focusTitleColor{
  color: #2E74E9;
}

.background0 {
  background-color: #ffffff;
}

.background1 {
  background-color: #fcfcfc;
}

.navbar-left {
  position: absolute;
  top: 0px;
  left: 20px;
  bottom: 0px;
  flex-direction: row;
  justify-content: center;
  align-items: center;
}

.navbar-left-title {
  font-size: 32px;
  /* color: #242424; */
  color: #6c6e70;
}

.navbar-left-img {
  margin-left: 5px;
  width: 14px;
  height: 8px
}

.navbar-right {
  position: absolute;
  top: 0px;
  right: 20px;
  bottom: 0px;
  width: 70px;
  /*padding-right: 30px;*/
  justify-content: center;
  align-items: center;
}

.navbar-right-calendar-month {
  position: absolute;
  bottom: 17px;
  right: 0px;
  width: 40px;
  height: 30px;
  text-align: center;
  font-size: 28px;
  color: #abafbc;
}

.channel {
  width: 750px;
  flex-direction: row;
  border-bottom-width: 20px;
  border-bottom-color: #e8e8e8;
}

.scroller {
  width: 750px;
  height: 88px;
  flex-direction: row;
  padding-left: 32px;
  padding-right: 32px;
  align-items: center;
  justify-content: space-between;
  /* margin-right: 5px; */
}

.channel-item {
  padding-left: 20px;
  padding-right: 20px;
  height: 60px;
  justify-content: center;
  align-items: center;
  border-radius: 30px;
}

.channel-highlight{
  background-color: #2E74E9;
}

.channel-normal{
  background-color: #FFFFFF;
}

.content {
  flex: 1;
  flex-direction: row;
  background-color: #e8e8e8;
}

.content-item {
  width: 750px;
  /* height: 240px; */
  flex-direction: row;
  padding-left: 30px;
  padding-right: 30px;
  padding-top: 28px;
  padding-bottom: 30px;
  border-bottom-width: 1px;
  border-bottom-color: #f1f1f1;
}

.content-item-news {
  width: 750px;
  /*height: 240px;*/
  /*padding-left: 30px;*/
  /*padding-right: 30px;*/
  /*padding-top: 40px;*/
  /*padding-bottom: 40px;*/
  /*border-bottom-width: 1px;*/
  /*border-bottom-color: sandybrown;*/
}

.calendarShow {
  width: 750px;
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
}

.calendarHide{
  width: 750px;
  position: absolute;
  top: 0px;
  left: 750px;
  bottom: 0px;
}

.content-title-img {
  font-size: 32px;
  line-height: 64px;
  color: #454950;
  lines: 2;
  text-overflow: ellipsis;
}

.content-title {
  font-size: 32px;
  line-height: 64px;
  color: #454950;
  lines: 1;
  text-overflow: ellipsis;
}

.content-subtitle {
  font-size: 28px;
  line-height: 45px;
  height: 90px;
  color: #9ba1ab;
  text-overflow: ellipsis;
  lines: 2;
}

.content-date {
  font-size: 28px;
  line-height: 56px;
  color: #9ba1ab;
  lines: 1;
}

.content-tag-red {
  font-size: 28px;
  /*color: #e9320e;*/
  color: #2e74e9;
  width: auto;
  /* height: 45px; */
  line-height: 56px;
  margin-left: 10px;
  margin-right: 10px;
  text-overflow: ellipsis;
  lines: 1;
}

.content-image {
  width: 284px;
  height: 182px;
}

.normal {
  font-size: 28px;
  color: #454950;
}

.highlight {
  font-size: 28px;
  color: #FFFFFF;
}

.refresh {
  width: 750px;
  height: 80px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
}

.indicator-text {
  color: #888888;
  font-size: 30px;
  margin-left: 8px;
  text-align: center;
}

.indicator {
  height: 50px;
  width: 50px;
  color: gray;
}

.capsule {
  flex-direction: row;
  height: 88px;
  padding-left: 30px;
  padding-right: 30px;
  align-items: center;
  border-bottom-width: 1px;
  border-bottom-color: #f1f1f1;
}

.icon {
  width: 42px;
  height: 42px;
  margin-right: 20px;
}

.capsule-title {
  flex: 1;
  font-size: 28px;
  color: #46494f;
  lines: 1;
  text-overflow: ellipsis;
}

.capsule-detail {
  margin-left: 20px;
  font-size: 28px;
  color: #9ba1ab;
  text-align: right;
  lines: 1;
}

.arrow {
  width: 12px;
  height: 22px;
  margin-left: 20px;
}

.modul {
  height: 74px;
  border-radius: 37px;
  align-items: center;
  justify-content: center;
  padding-left: 60px;
  padding-right: 60px;
  background-color: rgba(0, 0, 0, 0.7);
}

.updateItems{
  position:absolute;
  left:0px;
  right:0px;
  align-items:center;
  justify-content:center;
  transition-property: bottom, opacity;
  transition-timing-function: linear;
}

.updateItems-show{
  opacity: 1;
  bottom:60px;
  transition-duration: 0.3s;
}

.updateItems-hide{
  opacity: 0;
  bottom:-74px;
  transition-duration: 0.1s;
}
.alignCenter{
  align-items: center;
}

</style>
