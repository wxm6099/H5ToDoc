<template scoped>
<div :style="{'padding-bottom': iphonex?'34px':'0px'}">
  <image  class="banner" style="position: absolute;top: 0px" ref="banner" resize="cover" :src="bg"></image>
  <list style="overflow:hidden" show-scrollbar="false" offset-accuracy="2" scrollDirection="vertical" alwaysScrollableVertical="true" @scroll="scroll" loadmoreoffset=20 @loadmore="onloading">
    <cell :class="[iphonex?'banner-ipx':'banner']">
      <div style="width:750px;height:320px;justify-content:flex-end;padding:30px;backgroundColor:rgba(255,255,255,0)">
        <text class="topic-text">文章{{topic.total}}篇</text>
      </div>
      <div style="width:750px;height:226px;align-items:center;backgroundColor:white;">
        <text class="introduce">{{topic.content}}</text>
      </div>
      <div style="position:absolute;left:0px;right:0px;bottom:180px;align-items:center;">
        <image style="width:200px;height:200px;border-radius:30px" :src="banner"></image>
      </div>
    </cell>
    <cell class="topic-group">
      <div class="topic-group-head">
        <text class="topic-group-title">文章</text>
      </div>
    </cell>
    <cell class="topic-item" :class="[(index % 2) ?'background1':'background0']" v-for="(item,index) in articles" @click="onNewsClick(item.link)">
      <div class="topic-item-head" style="flex-direction:row;align-items:center;">
        <image class="topic-head-icon" resize="contain" :src="item.icon"></image>
        <text class="topic-head-font">{{item.author}}</text>
        <text class="topic-head-font">{{item.time}}</text>
      </div>
      <div class="topic-item-content">
        <div style="flex:1;justify-content:flex-start;height:160px;">
          <div style="flex:1;justify-content:center;">
            <text v-if="item.image" class="topic-content-title-img">{{item.title}} {{item.subtitle?item.subtitle:''}}</text>
            <text v-else class="topic-content-title">{{item.title}} {{item.subtitle?item.subtitle:''}}</text>
          </div>
          <div v-if="!item.image" style="flex:1;">
            <text class="topic-content-text">{{item.content}}</text>
          </div>
        </div>
        <div v-if="item.image" class="topic-content-picture" style="margin-left:25px;">
          <image class="topic-content-picture" resize="contain" :src="item.image"></image>
        </div>
      </div>
    </cell>
    <cell v-if="loadingData">
      <div class="refresh">
        <loading-indicator class="indicator"></loading-indicator>
        <text class="indicator-text">正在加载</text>
      </div>
    </cell>
  </list>

  <div v-if="isLoadError" style="position:absolute;left:0px; top:0px;right:0px; bottom:0px;background-color: white;justify-content: center;align-items: center">
    <loadError @refreshNetWorkError="refreshNetWorkError"></loadError>
  </div>
  <div class="head-title">
    <image  v-if="iOS" class="banner" style="position: absolute;" v-bind:style="{top:top,height:height}" resize="cover" :src="bg"></image>
    <status backgroundColor="#FFFFFF" :style="{opacity:(true == isLoadError)?'1':bgopacity }"></status>
    <!--<status v-if="!iOS" backgroundColor="#E93030" style="opacity:{{opacity}}"></status>-->
    <div class="navbar">
      <div :style="{opacity:(true == isLoadError)?'1':bgopacity }" style="position: absolute;left: 0px;top: 0px;right: 0px;bottom: 0px;background-color: #FFFFFF"></div>
      <text class="navbar-title" :style="{opacity:(true == isLoadError)?'1':opacity }"> {{topic.title}} </text>
      <div @click="goBack" class="goback">
        <image style="width: 20px; height: 36px" resize="contain" :src="assets + 'back1.png'"></image>
      </div>
      <div @click="showCapsule" class="navbar-right">
        <image style="width: 36px; height: 36px" resize="contain" :src="assets + 'link.png'"></image>
      </div>
    </div>
  </div>
  <message></message>
</div>
</template>

<script scoped>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var animations = weex.requireModule('animation');
var navigator = weex.requireModule('navigator')
var storage = require('../include/storage.js');
var utils = require('../include/utils.js');
var http = require('../include/http.js');

module.exports = {
  components: {
    'status': require('../components/statusbar.vue'),
    'loadError': require('../components/loadError.vue'),
    'message': require('../components/message.vue'),
  },
  computed: {
    iOS: function() {
      const {
        platform
      } = weex.config.env;
      return platform.toLowerCase() === 'ios';
    },
    iphonex: function() {
      return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' || weex.config.env.deviceModel === 'iPhone11,2' || weex.config.env.deviceModel === 'iPhone11,4' || weex.config.env.deviceModel === 'iPhone11,6'|| weex.config.env.deviceModel === 'iPhone11,8' );
    }
  },
  data: function() {
    return {
      assets: assetsUrl,
      pageSize: 5,
      pageIndex: 0,
      loadingData: false, //接口读取数据
      loading: false, //上拉加载显示
      refreshing: false, //下拉刷新显示
      top:0,
      height: 546,
      opacity: 0, //状态栏透明度
      bgopacity:0,
      bg: '',
      banner: '',
      topic: {
        title: '',
        content: '',
        id: 0,
        total: 0,
        focus: 0,
      },
      articles: [],
      isLoadError: false, //网络加载出错
    }
  },
  created: function() {
    // this.crow = url(assetsUrl+'crown1.png');
    var that = this;
    if (weex.supports('@module/app')) {
      weex.requireModule('app').setStatusBarStyle(0);
    }

    storage.getItem('commonUrl',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.cmsApiHost = commonUrl.cmsApi; //接口基址
        that.imageBaseUrl = commonUrl.imageBaseUrl; //图片基址
        that.contentBaseUrl = commonUrl.contentBaseUrl; //文章基址
        storage.getItem("tags", function(data) {
          if (data) {
            var json = JSON.parse(data);
            that.topic.title = json.title;
            that.topic.id = json.id;
            that.getcontent();
            that.getArticles();
          }
        });

      }
    });
    // // 接收网络错误的广播
    // const Network = new BroadcastChannel('GloballyRefreshNetwork');
    // Network.onmessage = function(event) {
    //     that.refresh();
    // };
  },
  methods: {
    // 接收网络错误的点击事件的回调
    refreshNetWorkError:function(){
        this.refresh();
    },
    scroll: function(e) {
      // if (false == this.iOS) {
      //   return;
      // }
      if (e.contentOffset.y < -3) {
        // console.log("y:"+e.contentOffset.y);
          if (utils.isAndroid()) {
          this.opacity = 1;
          this.bgopacity =1;
        } else {
          this.opacity = -e.contentOffset.y / 200;
          this.bgopacity =0;
        }
        if (e.contentOffset.y <= -380) {
          this.top = -380;
          return;
        } else {
          this.top = Math.ceil(e.contentOffset.y);
        }
        this.height = 546;
      } else {
        this.top = 0;
        this.opacity = 0;
        this.bgopacity = 0;
        this.height = Math.ceil(546 + e.contentOffset.y);
      }
      // console.log("scroll top:" + this.top + " height:" + this.height);
      var bannerEl = this.$refs.banner;
      animations.transition(bannerEl, {
        styles: {
          height: this.height,
          transform: 'translateY(' + this.top + 'px) ',
        },
        duration: 10, //ms
        timingFunction: 'linear',
        delay: 0, //ms
      }, function() {})
    },
    goBack: function() {
      navigator.pop({
        animated: "true"
      }, res => {});
    },
    showCapsule:function(){
      navigator.push({
        url: bundleUrl + 'capsule.js',
        animated: "true",
        swipePop: "true",
      }, event => {})
    },
    showTime: function(time) {
      // var date = new Date(time.replace(new RegExp(/-/gm), "/"));
      var date = new Date(parseInt(time.replace('/Date(','').replace(')/','').substring(0,13)));
      var now = new Date();
      var duration = (now.getTime() - date.getTime()) / 1000;
      if (duration < 60) {
        return '刚刚';
      } else if (duration < 3600) {
        return Math.floor(duration / 60) + '分钟前';
      } else if (duration < 86400) {
        return Math.floor(duration / 3600) + '小时前';
      } else if (duration < 172800) {
        return '1天前';
      } else {
        return (date.getMonth() + 1) + '月' + date.getDate() + '日';
      }
    },
    refresh: function(e) {
      if (false == this.loadingData) {
        this.refreshing = true;
        setTimeout(() => {
          this.refreshing = false;
        }, 500)

        setTimeout(() => {
          this.pageIndex = 0;
          this.getArticles();
        }, 1000)
      }
    },
    onloading: function() {

      if (false == this.loadingData) {

        this.loading = true;
        setTimeout(() => {
          this.loading = false;
        }, 500)

        setTimeout(() => {
          // this.pageIndex = 0;
          this.getArticles();
        }, 1000)
      }
    },
    getcontent: function() {
      var that = this;
      var url = this.cmsApiHost + '/ContentUnion/Site?format=json&id=' + that.topic.id;
      http.get(url, function(response) {
        that.isLoadError = false;
        if (response.status < 200) {
          that.isLoadError = true;
        }

        if (response.ok && response.data && response.data.Results && response.data.Results.length > 0) {
          var result = response.data.Results[0];
          that.topic.content = result.ContentNoHtmlTag;
          if (result.appImageUrl) {
            let images = result.appImageUrl.split(',', 3);
            if (images && images.length >= 3) {
              that.bg = images[0].replace('@', that.imageBaseUrl);
              that.banner = images[1].replace('@', that.imageBaseUrl);
            }

            //
          }
        }
      },20000);
    },
    getArticles: function() {
      var that = this;
      if (that.loadingData) {
        return;
      }
      that.loadingData = true;
      var url = this.cmsApiHost + '/ContentUnion/Site?format=json&OrderByDesc=AddDate&Take=10&Skip=' + (that.pageIndex>0?that.articles.length:0) +'&Tags=' + encodeURIComponent(that.topic.title);
      http.get(url, function(response) {
        that.isLoadError = false;
        if (response.status < 200) {
          that.isLoadError = true;
        }
        that.loadingData = false;
        if (response.ok && response.data) {
          var results = response.data.Results;
          if (response.data.Total) {
            that.topic.total = response.data.Total;
          }
          if (results && results.length > 0) {
            if (0 == that.pageIndex) {
              that.articles.splice(0, that.articles.length);
            }
            for (var i = 0; i < results.length; i++) {
              var item = {};
              item.id = results[i].Id
              if (results[i].authorPic) {
                item.icon = results[i].authorPic;
              }else {
                item.icon = that.assets+'n1.png';
              }

              item.author = results[i].Author;
              item.title = results[i].Title;
              item.content = results[i].ContentNoHtmlTag;
              item.tag = results[i].Tags;
              if (/^http/.test(results[i].LinkUrl)) {
                item.link = results[i].LinkUrl;
              } else {
                item.link = that.contentBaseUrl + results[i].ContentFilePathRule;
              }
              if (results[i].appImageUrl) {
                let images = results[i].appImageUrl.split(',');
                if (images && images.length >= 1) {
                  if (images[0] && images[0].indexOf('@') >= 0) {
                    item.image = images[0].replace('@', that.imageBaseUrl);
                  }else {
                    item.image = images[0];
                  }
                }else {
                  item.image = '';
                }
              }
              // if (results[i].appImageUrl && results[i].appImageUrl.length > 0) {
              //   item.image = results[i].appImageUrl.replace('@', that.imageBaseUrl);
              // } else {
              //   item.image = '';
              // }
              item.time = that.showTime(results[i].AddDate);
              that.articles.push(item);
            }
            that.pageIndex++;
          }
        }
      },2000);
    },
    onNewsClick: function(link) {
      if (link && link.length > 4 && this.contentBaseUrl && this.contentBaseUrl.length > 6) {
        var data = {
          title: '',
          url: link,
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
  }
}
</script>

<style scoped>
.screenwidth {
  width: 750px;
}

.head-title {
  position: absolute;
  top: 0px;
  left: 0px;
  right: 0px;
  overflow: hidden;

}

.navbar {
  width: 750px;
  height: 88px;
  align-items: center;
  justify-content: center;

}

.navbar-title {
  font-size: 36px;
  color: #242424;
}

.goback {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 200px;
  padding-left: 30px;
  flex-direction: row;
  align-items: center;
}

.navbar-right {
  position: absolute;
  top: 0px;
  right: 0px;
  bottom: 0px;
  width: 120px;
  padding-right: 30px;
  justify-content: center;
  align-items: flex-end;
}

.absolute {
  position: absolute;
  top: 0px;
  left: 0px;
}

.banner {
  width: 750px;
  height: 546px;
}

.banner-ipx {
  width: 750px;
  height: 560px;
  justify-content: flex-end;
}

.topic-title {
  font-size: 36px;
  line-height: 64px;
  margin-bottom: 10px;
  color: #e9302e;
  lines: 1;
  text-overflow: ellipsis;
}

.topic-focus {
  border-radius: 5px;
  width: 110px;
  height: 46px;
  border-color: #e9302e;
  border-width: 1px;
  justify-content: center;
  align-items: center;
}

.topic-text {
  font-size: 28px;
  line-height: 45px;
  color: #ffffff;
  margin-right: 15px;
  /* box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1); */
  /* text-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1); */
}

.introduce {
  text-overflow: ellipsis;
  lines: 3;
  color: #9ba1ab;
  font-size: 28px;
  line-height: 42px;
  text-align: center;
  padding-left: 30px;
  padding-right: 30px;
  padding-top: 60px;
}

.topic-group {
  border-top-width: 20px;
  border-top-color: #f1f1f1;
  background-color: #ffffff;
}

.topic-group-head {
  margin-top: 35px;
  margin-bottom: 0px;
  width: 750px;
  height: 40px;
  flex-direction: row;
  align-items: center;
}

.topic-group-title {
  font-size: 36px;
  margin-left: 30px;
  color: #1b222c;
  text-align: center;
}

.topic-item {
  width: 750px;
  padding-top: 32px;
  padding-bottom: 36px;
  border-bottom-width: 1px;
  border-bottom-color: #F1F1F1;
  border-bottom-style: solid;
}

.topic-item-head {
  width: 750px;
  /* height: 72px; */
  padding-left: 30px;
  padding-right: 30px;
  flex-direction: row;
  align-items: center;
}

.topic-head-icon {
  width: 66px;
  height: 66px;
  margin-right: 24px;
}

.topic-head-font {
  font-size: 28px;
  line-height: 45px;
  color: #9ba1ab;
  width: auto;
  height: 45px;
  margin-right: 12px;
  text-align: center;
}

.topic-item-content {
  width: 750px;
  /* height: 160px; */
  flex-direction: row;
  padding-left: 30px;
  padding-right: 30px;
}

.topic-content-title-img {
  font-size: 32px;
  line-height: 64px;
  text-overflow: ellipsis;
  lines: 2;
  color: #454950;
}

.topic-content-title {
  font-size: 32px;
  line-height: 64px;
  text-overflow: ellipsis;
  lines: 1;
  color: #454950;
}

.topic-content-text {
  font-size: 28px;
  line-height: 45px;
  text-overflow: ellipsis;
  lines: 2;
  color: #9ba1ab;
}

.topic-content-picture {
  width: 284px;
  height: 182px;
}

.refresh {
  width: 750px;
  height: 80px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
}

.indicator-text {
  color: #888888;
  font-size: 30px;
  margin-left: 8px;
  text-align: center;
}

.indicator {
  height: 50px;
  width: 50px;
  color: gray;
}

.background0 {
  background-color: #ffffff;
}

.background1 {
  background-color: #fcfcfc;
}
</style>
