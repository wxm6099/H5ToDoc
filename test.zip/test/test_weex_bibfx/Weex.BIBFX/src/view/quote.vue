<template>
<div :class="[isIphoneX==true ? 'wrap-iphoneX' : 'wrap']" @viewappear="viewappearquote" @viewdisappear="viewdisappearquote">
  <status backgroundColor="#FFFFFF"></status>
  <navigation :title="nameChannel" textColor="#242424" :leftImg="leftItemSrc" @leftClick="onclickleftitem();logEvent(codeChannel+'_page_back')"></navigation>
  <div style="height: 336px;width: 750px;flex-direction: row;align-items: center;background-color: #ffffff;">
    <div style="width: 300px;height: 336px;justify-content: center;align-items: center;">
      <div>
        <text  :class="['quote-data-bid-u',nowsell-open>=0?'quote-data-bid-u':'quote-data-bid-d']">{{nowsell}}</text>
      </div>
      <div style="margin-top: 10px;justify-content: center;align-items: center">
        <text :class="['quote-data-u',nowsell-open>=0?'quote-data-u':'quote-data-d']" >{{change}}</text>
      </div>
      <div style="margin-top: 10px;justify-content: center;align-items: center" >
        <text :class="['quote-data-u',nowsell-open>=0?'quote-data-u':'quote-data-d']">{{Prochange}}%</text>
      </div>
    </div>
    <div style=" width: 1px;height: 200px;background-color: #eeeeee"></div>
    <div class="product-div">
      <div class="num-div" style="border-bottom-width: 1px;border-bottom-color: #eeeeee;border-right-width: 1px;border-right-color: #eeeeee">
        <text class="color-gray1 font28" >最高</text>
        <text class="font28 color-gray" style="margin-top: 10px" >{{high}}</text>
      </div>
      <div class="num-div">
        <text class="color-gray1 font28">最低</text>
        <text class="font28 color-gray" style="margin-top: 10px">{{low}}</text>
      </div>
    </div>
    <div class="product-div">
      <div  class="num-div">
        <text class="color-gray1 font28">今开</text>
        <text class="font28 color-gray" style="margin-top: 10px">{{open}}</text>
      </div>
      <div class="num-div" style="border-top-width: 1px;border-top-color: #eeeeee;border-left-width: 1px;border-left-color: #eeeeee">
        <text class="color-gray1 font28">昨收</text>
        <text class="font28 color-gray"style="margin-top: 10px">{{Yclose}}</text>
      </div>
    </div>
  </div>
  <div style="background-color: #f1f1f1;width: 750px;height: 20px"></div>
  <div class="quote-type">
    <scroller ref="typeScroller" class="quote-type-scroller" show-scrollbar="false" scrollDirection="horizontal">
      <div ref="typeChannel" class="quote-type-item" v-for="item in string.quotetypechannel" @click="typechannelClick(item.id);logEvent(codeChannel+'_page_'+item.type)">
        <div style="width: 114px;height: 66px;justify-content: center;align-items: center;">
          <text :class="[item.id == typeChannelIndex?'quote-type-selected':'quote-type-normal']">{{item.name}}</text>
        </div>
        <div v-if="item.id == typeChannelIndex" class="quote-type-red-div"></div>
      </div>
    </scroller>
  </div>
  <div style="background-color: #d4d4d4;width: 750px;height: 1px"></div>
  <fullChart ref="quoteKLineChartView" style="flex:1; background-color: #ffffff" :typeChannelIndex="typeChannelIndex" :quoteData="arr_quoteDatas" CandleNumber="45" @indexChange="indexChange" :socketLine="nowsell"></fullChart>
  <div class="quote-tips">
    <text class="quote-tips-text">— 以上报价有延迟，数据仅供参考，请以交易平台为准 —</text>
  </div>
  <div class="quote-bottom">
    <div class="quote-bottom-text-icon-left" v-on:click="onclickleftbottomitem();logEvent(codeChannel+'_page_MT4')">
      <image v-if="true == showMt4 || isAndroid" class="quote-bottom-image-MT4" :src="bottomLeftSrc"></image>
      <text v-if="true == showMt4 || isAndroid" class="quote-bottom-text">MT5交易</text>
    </div>
    <div class="quote-bottom-text-icon-right" v-on:click="onclickrightbottomitem();logEvent(codeChannel+'_page_screen')">
      <image class="quote-bottom-image-full" :src="bottomRightSrc"></image>
    </div>
  </div>
  <message></message>
</div>
</template>

<script>
const storage = require('../include/storage.js');
const bundleUrl = require('../include/base-url.js').bundleUrl();
const assetsUrl = require('../include/base-url.js').assetsUrl();
const navi = weex.requireModule('navigator');
const http = require('../include/http.js');
const utils = require('../include/utils.js');
const url = require('../include/url.js');
const app = weex.requireModule('app');
const dom = weex.requireModule('dom');
const firebase = weex.requireModule('firebase');
const localBundleVersion = require('../include/base-url.js').bundleVersion;

export default {
  name: "quote"
}


module.exports = {
  components: {
    navigation: require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'message': require('../components/message.vue'),
  },
  data: function() {
    return {
      string: require('../include/string.js'),
      assets: assetsUrl,
      kline: assetsUrl + 'kline.html',

      leftItemSrc: assetsUrl + 'back1.png',
      rightItemSrc: assetsUrl + 'quote_refresh.png',
      bottomLeftSrc: assetsUrl + 'quote_MT4.png',
      bottomRightSrc: assetsUrl + 'quote_full_screen.png',
      arrData: [], //k线图的数据源
      // dicIndexData: {}, //指标图的数据源
      timeNumber: 1, //数据请求的时间间隔的次数
      arr_quoteDatas: [], //指标和k线数据合并后的集合数组

      nowbuy: 0.0000, //当时买入价
      nowsell: 0.0000, //最新报价(当时卖价)
      change: '+' + 0.00, //涨跌
      Prochange: '+' + 0.00, //涨跌幅
      high: 0.0000, //最高报价
      low: 0.0000, //最低报价
      open: 0.0000, //开盘价
      Yclose: 0.0000, //昨天收盘价
      fixed:2,
      typeChannelIndex: -1, //默认选中k线类型编号
      codeChannel: 'Gold',
      typeChannel: 'H1', //默认选中的k线类型名称代码
      nameChannel: '', //代号名称
      indexName: ['MACD', 'RSI', 'KDJ', 'BOLL', 'MA', 'OSMA', 'SRS'], //默认选中指标
      utc: 0, //本地时区
      startTime: new Date().getTime(), //k线数据开始时间点
      endtTime: new Date().getTime(), //k线数据结束时间点
      stringStartTime: '', //k线数据开始时间点
      stringEndtTime: '', //k线数据结束时间点
      // loadingDataIndex: false, //网络加载中
      loadingDataKLine: false, //网络加载中
      // loadIndexError: false, //网络加载指标数据失败
      loadKLineError: false, //网络加载k线数据失败
      isFullScreenClose: false, //是否跳转横屏时关闭竖屏
      isIphoneX: false, //判断是否是iphoneX
      isAndroid: utils.isAndroid(),
      timer:0,
      showMt4:true
    }
  },
  created: function() {
    var selfThis = this;

    selfThis.isIphoneX = utils.iphonex();
    // let bundleVersion = storage.getItemSync('bundleVersion');
    // if (bundleVersion >= localBundleVersion) {
    //   this.showMt4 = true;
    // }

    //行情页传递的数据
    storage.getItem('topproductdata',function(value) {
      var dataP = JSON.parse(value);
      selfThis.fixed = dataP.fixed== 0 ? 2 : dataP.fixed;
      selfThis.nowbuy = parseFloat(dataP.Ask.length == 0 ? selfThis.nowbuy : dataP.Ask).toFixed(selfThis.fixed);
      selfThis.nowsell = parseFloat(dataP.Bid.length == 0 ? selfThis.nowsell : dataP.Bid).toFixed(selfThis.fixed);
      selfThis.open = parseFloat(dataP.Open.length == 0 ? selfThis.open : dataP.Open).toFixed(selfThis.fixed);
      selfThis.Yclose = parseFloat(dataP.YClose.length == 0 ? selfThis.Yclose : dataP.YClose).toFixed(selfThis.fixed);
      selfThis.high = parseFloat(dataP.High.length == 0 ? selfThis.high : dataP.High).toFixed(selfThis.fixed);
      selfThis.low = parseFloat(dataP.Low.length == 0 ? selfThis.low : dataP.Low).toFixed(selfThis.fixed);
      if (!utils.isBlankString(dataP.symbol)) {
        selfThis.codeChannel = dataP.symbol;
      }else if (!utils.isBlankString(dataP.Symbol)){
        selfThis.codeChannel = dataP.Symbol;
      }else {
        selfThis.codeChannel = '';
      }
      selfThis.nameChannel = dataP.symbolName.length == 0 ? selfThis.nameChannel : dataP.symbolName;
      selfThis.change = selfThis.nowsell - selfThis.open;
      var pro = (selfThis.change / selfThis.nowsell) * 100;
      selfThis.change = selfThis.change >= 0 ? '+' + selfThis.change.toFixed(selfThis.fixed) : selfThis.change.toFixed(selfThis.fixed);
      pro = pro.toFixed(selfThis.fixed);
      selfThis.Prochange = selfThis.nowsell - selfThis.open >= 0 ? '+' + pro : pro;


      //获取网络请求的基址
      storage.getItem('commonUrl',function(value) {
        if ('' == value || value == undefined || value.length <= 0) {
          return
        }
        var commonUrl = JSON.parse(value);
        if (commonUrl) {
          selfThis.cmsApiHost = commonUrl.cmsApi; //接口基址
          selfThis.Indicators = commonUrl.Indicators; //指标的网络地址
          //网络基址数据加载成功后 执行k线类型方法
          selfThis.typechannelClick();
        }
      });
    });

    //websocket推送数据
    const wsData = new BroadcastChannel('bibfx');
    wsData.onmessage = function(event) {
      var dataPP = JSON.parse(event.data);

      if (selfThis.codeChannel.toString() == dataPP.Symbol.toString() && false == selfThis.isFullScreenClose) {
        selfThis.nowbuy = parseFloat(dataPP.Ask.length == 0 ? selfThis.nowbuy : dataPP.Ask).toFixed(selfThis.fixed);
        selfThis.nowsell = parseFloat(dataPP.Bid.length == 0 ? selfThis.nowsell : dataPP.Bid).toFixed(selfThis.fixed);
        selfThis.open = parseFloat(dataPP.Open.length == 0 ? selfThis.open : dataPP.Open).toFixed(selfThis.fixed);
        selfThis.high = parseFloat(dataPP.High.length == 0 ? selfThis.high : dataPP.High).toFixed(selfThis.fixed);
        selfThis.low = parseFloat(dataPP.Low.length == 0 ? selfThis.low : dataPP.Low).toFixed(selfThis.fixed);
        selfThis.Yclose = parseFloat(dataPP.YClose.length == 0 ? selfThis.Yclose : dataPP.YClose).toFixed(selfThis.fixed);
        selfThis.change = selfThis.nowsell - selfThis.open;
        var pro = 100 * (selfThis.change / selfThis.nowsell);
        pro = pro.toFixed(selfThis.fixed);
        selfThis.change = selfThis.change >= 0 ? '+' + selfThis.change.toFixed(selfThis.fixed) : selfThis.change.toFixed(selfThis.fixed);
        selfThis.Prochange = selfThis.nowsell - selfThis.open >= 0 ? '+' + pro : pro;
      }
    }
    selfThis.nowsell = selfThis.nowsell.toFixed(4);
    selfThis.high = selfThis.high.toFixed(4);
    selfThis.low = selfThis.low.toFixed(4);
    selfThis.open = selfThis.open.toFixed(4);
    selfThis.Yclose = selfThis.Yclose.toFixed(4);
    var globalEvent = weex.requireModule('globalEvent');
    globalEvent.addEventListener("ScrollKlineChart", function(e) {
      selfThis.ScrollKlineChart(e);
    });
  },

  methods: {
    logEvent: function(name) {
      if (name == '' || /^_|_$/.test(weex.config.env.deviceModel)) {
        return;
      }
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    indexChange: function(e) {
      if (e.index >= 0 && e.index < this.indexName.length) {
        this.logEvent(this.codeChannel + '_page_' + this.indexName[e.index])
      }
    },
    viewappearquote: function() {
      var selfThis = this;
      if (app) {
        app.showStatusBar(true);
        app.setStatusBarStyle(0);
      }
      if (true == selfThis.isFullScreenClose) {
        selfThis.isFullScreenClose = false;
        storage.getItem("quoteKlineType", function(value) {
          if (value && value.length > 0) {
            selfThis.typechannelClick(parseInt(value));
          }
        });
      }
      if (utils.isAndroid()) {
        selfThis.$refs.quoteKLineChartView.rotationLive();
      }
    },
    viewdisappearquote: function() {
      var selfThis = this;
      //k线类型的参数(storage存储竖屏传值给横屏的k线类型值)
      if (!selfThis.isFullScreenClose) {
        storage.setItem("quoteKlineType", selfThis.typeChannelIndex + "");
        // selfThis.typeChannelIndex = -1;
      }
    },

    getTheKLineData: function(value, timeNumber, startTimeStamp) {
        //                    true, 1 ,当前时间
      var selfThis = this;
      if (value) { //首次进入  开始时间即时当前时间
        selfThis.starttime = startTimeStamp;
        selfThis.endtime = selfThis.starttime;
        switch (selfThis.typeChannelIndex) {
          case 0:
            //小时 (距离starttime推前8天  24*8=192  个点)
            selfThis.endtime = selfThis.starttime - 8 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          case 1:
            //日k(距离starttime推前150天  150*1=150  个点)
            selfThis.endtime = selfThis.starttime - 150 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          case 2:
            //周k(距离starttime推前3年  52*3=156  个点)
            selfThis.endtime = selfThis.starttime - 3 * 365 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          case 3:
            //月k(距离starttime推前10年  12*10=120  个点)
            selfThis.endtime = selfThis.starttime - 10 * 365 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          case 4:
            //1分(距离starttime推前4小时  1*4*60=240  个点)
            selfThis.endtime = selfThis.starttime - 1 * 4 * 60 * 60 * 1000 * timeNumber;
            break;
          case 5:
            //5分(距离starttime推前1天  1*24*60/5=288  个点)
            selfThis.endtime = selfThis.starttime - 1 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          case 6:
            //15分(距离starttime推前3天  3*24*60/15=288  个点)
            selfThis.endtime = selfThis.starttime - 3 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          case 7:
            //30分(距离starttime推前4天  4*24*60/30=192  个点)
            selfThis.endtime = selfThis.starttime - 4 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          case 8:
            //4小时(距离starttime推前25天  25*24/4=150  个点)
            selfThis.endtime = selfThis.starttime - 25 * 24 * 60 * 60 * 1000 * timeNumber;
            break;
          default:
            //case以外的情况
        }
      } else { //非首次进入  开始时间为时当前时间减去时间间隔（小时的k线 要多减去一小时）/Date(1527458400000+0800)/
        if (!selfThis.loadKLineError ) { //防止加载更多数据因网络问题加载失败后时间却后移，数据出现断层
          switch (selfThis.typeChannelIndex) {
            case 0:
              //小时 (距离starttime推前8天  24*8=192  个点)
              // selfThis.starttime = selfThis.endtime - 60 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 60 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 8 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            case 1:
              //日k(距离starttime推前150天  150  个点)
              // selfThis.starttime = selfThis.endtime - 24 * 60 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 24 * 60 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 150 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            case 2:
              //周k(距离starttime推前3年  52*3=156  个点)
              // selfThis.starttime = selfThis.endtime - 7 * 24 * 60 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 7 * 24 * 60 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 3 * 365 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            case 3:
              //月k(距离starttime推前10年  12*10=120  个点)
              // selfThis.starttime = selfThis.endtime - 30 * 24 * 60 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 30 * 24 * 60 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 10 * 365 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            case 4:
              //1分(距离starttime推前4小时  1*4*60=240  个点)
              // selfThis.starttime = selfThis.endtime - 5 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 1 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 1 * 4 * 60 * 60 * 1000 * timeNumber;
              break;
            case 5:
              //5分(距离starttime推前1天  1*24*60/5=288  个点)
              // selfThis.starttime = selfThis.endtime - 5 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 5 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 1 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            case 6:
              //15分(距离starttime推前3天  3*24*60/15=288  个点)
              // selfThis.starttime = selfThis.endtime - 15 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 15 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 3 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            case 7:
              //30分(距离starttime推前4天  4*24*60/30=192  个点)
              // selfThis.starttime = selfThis.endtime - 30 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 30 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 4 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            case 8:
              //4小时(距离starttime推前25天  25*24/4=150  个点)
              // selfThis.starttime = selfThis.endtime - 4 * 60 * 60 * 1000;
              selfThis.starttime = timeNumber > 1 ? startTimeStamp : startTimeStamp - 4 * 60 * 60 * 1000;
              selfThis.endtime = selfThis.starttime - 25 * 24 * 60 * 60 * 1000 * timeNumber;
              break;
            default:
              //case以外的情况
              break;
          }
        }
      }

      // selfThis.loadingDataIndex = true;
      //获得指标图的数据集
      // selfThis.dicIndexData = {};
      selfThis.arrData = [];
      selfThis.utc = -(new Date().getTimezoneOffset() / 60);
      selfThis.stringStartTime = utils.dateFormat(selfThis.starttime, 'yyyy-MM-dd hh:mm:ss');
      selfThis.stringEndTime = utils.dateFormat(selfThis.endtime, 'yyyy-MM-dd hh:mm:ss');
      // var typeurl = selfThis.cmsApiHost + '/Quotes/MultIndicators?SymbolName=' + selfThis.codeChannel + '&UTC=' + selfThis.utc + '&IndicatorNames=MACD,RSI,KDJ,BOLL,MA,OSMA&Period=' + selfThis.typeChannel + '&DateTimeBetween=' + selfThis.stringEndTime +
      //   ',' + selfThis.stringStartTime + '&isapp=1';
      // http.get(encodeURI(typeurl), function(response) {
      //   selfThis.loadingDataIndex = false;
      //   if (response.ok && response.data) {
      //     // selfThis.loadIndexError = false;
      //     var results = response.data;
      //     selfThis.dicIndexData = results;
      //     if (selfThis.dicIndexData.MACD.length > 45 && selfThis.arrData.length > 45) {
      //       selfThis.arr_quoteDatas = selfThis.uniteQuoteAndIndex(selfThis.arrData, selfThis.dicIndexData); //指标和报价合并
      //     }
      //   } else {
      //     // selfThis.loadIndexError = true;
      //   }
      // })

      selfThis.loadingDataKLine = true;
      var kurl = selfThis.cmsApiHost + '/Quotes/Line?DateTimeBetween=' + selfThis.stringEndTime + ',' + selfThis.stringStartTime + '&Symbol=' + selfThis.codeChannel + '&UTC=' + selfThis.utc + '&type=' + selfThis.typeChannel + '&isapp=1';
      http.get(encodeURI(kurl), function(response) {
        selfThis.loadingDataKLine = false;
        if (response.ok && response.data && response.data.Results) {
          selfThis.loadKLineError = false;
          var results = response.data.Results;
          if (results && results.length >= 0) {
            //当数据不足一屏所画蜡烛图个数时 向前延长数据请求时间间隔  但是最多6次就可以了
            if (selfThis.timeNumber <= 6) {
              if (results.length > 45) { //45为竖屏下  一屏需要花的蜡烛图根数

                selfThis.arrData = results;
                //当k线数据和指标数据都返回后传送数据
                // if (selfThis.dicIndexData.MACD && selfThis.dicIndexData.MACD.length > 45) {
                  selfThis.arr_quoteDatas = selfThis.arrData; //指标和报价合并
                  selfThis.arrData = [];
                // }
              } else {
                //当数据少于45条时  并且是月k（数据只有51条） 不用延长时间间隔
                if (selfThis.typeChannel == 'MN' && results.length > 0) {
                  selfThis.arrData = results;
                  //当k线数据和指标数据都返回后传送数据
                  // if (selfThis.dicIndexData.MACD && selfThis.dicIndexData.MACD.length > 45) {
                    selfThis.arr_quoteDatas = selfThis.arrData; //指标和报价合并
                    selfThis.arrData = [];
                  // }
                } else {
                  //当数据少于45条时  延长数据请求的时间间隔
                  selfThis.timeNumber = selfThis.timeNumber + 1;
                  if (value) {
                    var stamp = new Date().getTime(); //当前时间转换的时间戳
                    selfThis.getTheKLineData(true, selfThis.timeNumber, stamp);
                  } else {
                    //左滑加载更多历史数据不足时 延长请求时间间隔 传入上一次请求数据的开始时间戳
                    selfThis.getTheKLineData(false, selfThis.timeNumber, selfThis.starttime);
                  }
                }
              }
            } else { //如果超过6次   不管多少条数据都执行返回数据
              selfThis.arrData = results;
            }
          }
          if (selfThis.typeChannelIndex!=4){
            if (selfThis.timer) {
              clearTimeout(selfThis.timer);
            }
             selfThis.startTimer();
          }
        } else {
          selfThis.loadKLineError = true;
        }
      })
    },

    uniteQuoteAndIndex: function(quotes, idnexs) {
      var selfThis = this;
      var macd = idnexs.MACD;
      var kdj = idnexs.KDJ;
      var rsi = idnexs.RSI;
      var boll = idnexs.BOLL;
      var ma = idnexs.MA;
      var osma = idnexs.OSMA;
      let macd_i = 0;
      var kdj_i = 0;
      var rsi_i = 0;
      var boll_i = 0;
      var ma_i = 0;
      var osma_i = 0;
      var arrQuotes = [];
      var kline_macd_Macd = '0';
      var kline_macd_Signal = '0';
      var kline_rsi_RSI = '0';
      var kline_rsi_Pos = '0';
      var kline_rsi_Neg = '0';
      var kline_kdj_Main = '0';
      var kline_kdj_Signal = '0';
      var kline_kdj_Highes = '0';
      var kline_kdj_Lowes = '0';
      var kline_boll_Upper ='0';
      var kline_boll_Moving ='0';
      var kline_boll_Lower ='0';
      var kline_ma_Line = '0';
      var kline_osma_Osma = '0';
      var kline_osma_Signal = '0';
      for (var i = 0; i < quotes.length; i++) {
        var dic_quote = quotes[i];
        dic_quote.UTC = selfThis.utc;
        var time_quote = dic_quote.DateTime; //  /Date(1531760400000-0000)/
        var tamp_quote = time_quote.replace('/Date(', '').replace(')/', '').substring(0, 13);
        dic_quote.timestamp = tamp_quote;
        var t = this.formatDateTime(parseInt(tamp_quote));
        //报价和macd指标匹配时间值
        var isMacdEqual = false; //macd与报价的时间是否匹配
        for (let j = macd_i; j < macd.length; j++) {
          var dic_macd = macd[j];
          var time_macd = dic_macd.DateTime;
          var tamp_macd = time_macd.replace('/Date(', '').replace(')/', '').substring(0, 13);
          var ttt = this.formatDateTime(parseInt(tamp_macd));
          // console.log('输出k线时间'+t+'输出macd时间'+ttt);
          if (parseInt(tamp_quote) == parseInt(tamp_macd)) {
            dic_quote.macd_Macd = String((JSON.parse(dic_macd.Value)).Macd) == null ? kline_macd_Macd : String((JSON.parse(dic_macd.Value)).Macd);
            if ( String((JSON.parse(dic_macd.Value)).Macd) == null) {
              kline_macd_Macd = dic_quote.macd_Macd;
            }
            dic_quote.macd_Signal = String((JSON.parse(dic_macd.Value)).Signal) == null ? kline_macd_Signal : String((JSON.parse(dic_macd.Value)).Signal);
            if (String((JSON.parse(dic_macd.Value)).Signal) != null) {
              kline_macd_Signal = dic_quote.macd_Signal;
            }
            macd_i = j + 1;
            isMacdEqual = true;
            break;
          } else if (parseInt(tamp_quote) < parseInt(tamp_macd)) {
            macd_i = j;
            if ('0' == kline_macd_Macd) {
              for (let index = j; index < macd.length; index++) {
                var _macd = macd[index];
                if (String((JSON.parse(_macd.Value)).Macd) == null) {
                  continue;
                }
                kline_macd_Macd =  String((JSON.parse(_macd.Value)).Macd);
                kline_macd_Signal =  String((JSON.parse(_macd.Value)).Signal);
                break;
              }
            }
            break;
          }
        }
        if (!isMacdEqual) {
          dic_quote.macd_Macd = kline_macd_Macd;
          dic_quote.macd_Signal = kline_macd_Signal;
        }
        //报价和rsi指标匹配时间值
        var isRsiEqual = false; //rsi与报价的时间是否匹配
        for (let k = rsi_i; k < rsi.length; k++) {
          var dic_rsi = rsi[k];
          var time_rsi = dic_rsi.DateTime;
          var tamp_rsi = time_rsi.replace('/Date(', '').replace(')/', '').substring(0, 13);
          if (parseInt(tamp_quote) == parseInt(tamp_rsi)) {
            dic_quote.rsi_RSI = String((JSON.parse(dic_rsi.Value)).RSI) == null ? kline_rsi_RSI : String((JSON.parse(dic_rsi.Value)).RSI);
            kline_rsi_RSI = dic_quote.rsi_RSI;
            dic_quote.rsi_Pos = String((JSON.parse(dic_rsi.Value)).Pos) == null ? kline_rsi_Pos : String((JSON.parse(dic_rsi.Value)).Pos);
            kline_rsi_Pos = dic_quote.rsi_Pos;
            dic_quote.rsi_Neg = String((JSON.parse(dic_rsi.Value)).Neg) == null ? kline_rsi_Neg : String((JSON.parse(dic_rsi.Value)).Neg);
            kline_rsi_Neg = dic_quote.rsi_Neg;
            rsi_i = k + 1;
            isRsiEqual = true;
            break;
          } else if (parseInt(tamp_quote) < parseInt(tamp_rsi)) {
            rsi_i = k;
            if ('0' == kline_rsi_RSI) {
              for (let index = k; index < rsi.length; index++) {
                var _rsi = rsi[index];
                if (String((JSON.parse(_rsi.Value)).RSI) == null) {
                  continue;
                }
                kline_rsi_RSI =  String((JSON.parse(_rsi.Value)).RSI);
                kline_rsi_Pos =  String((JSON.parse(_rsi.Value)).Pos);
                kline_rsi_Neg =  String((JSON.parse(_rsi.Value)).Neg);
                break;
              }
            }
            break;
          }
        }
        if (!isRsiEqual) {
          dic_quote.rsi_RSI = kline_rsi_RSI;
          dic_quote.rsi_Pos = kline_rsi_Pos;
          dic_quote.rsi_Neg = kline_rsi_Neg;
        }
        //报价和kdj指标匹配时间值
        var isKdjEqual = false; //kdj与报价的时间是否匹配
        for (let m = kdj_i; m < kdj.length; m++) {
          var dic_kdj = kdj[m];
          var time_kdj = dic_kdj.DateTime;
          var tamp_kdj = time_kdj.replace('/Date(', '').replace(')/', '').substring(0, 13);
          if (parseInt(tamp_quote) == parseInt(tamp_kdj)) {
            dic_quote.kdj_Main = String((JSON.parse(dic_kdj.Value)).Main) == null ? kline_kdj_Main : String((JSON.parse(dic_kdj.Value)).Main);
            kline_kdj_Main = dic_quote.kdj_Main;
            dic_quote.kdj_Signal = String((JSON.parse(dic_kdj.Value)).Signal) == null ? kline_kdj_Signal : String((JSON.parse(dic_kdj.Value)).Signal);
            kline_kdj_Signal = dic_quote.kdj_Signal;
            dic_quote.kdj_Highes = String((JSON.parse(dic_kdj.Value)).Highes) == null ? kline_kdj_Highes : String((JSON.parse(dic_kdj.Value)).Highes);
            kline_kdj_Highes = dic_quote.kdj_Highes;
            dic_quote.kdj_Lowes = String((JSON.parse(dic_kdj.Value)).Lowes) == null ? kline_kdj_Lowes : String((JSON.parse(dic_kdj.Value)).Lowes);
            kline_kdj_Lowes = dic_quote.kdj_Lowes;
            kdj_i = m + 1;
            isKdjEqual = true;
            break;
          } else if (parseInt(tamp_quote) < parseInt(tamp_kdj)) {
            kdj_i = m;
            if ('0' == kline_kdj_Main) {
              for (let index = m; index < kdj.length; index++) {
                var _kdj = kdj[index];
                if (String((JSON.parse(_kdj.Value)).RSI) == null) {
                  continue;
                }
                kline_kdj_Main =  String((JSON.parse(_kdj.Value)).Main);
                kline_kdj_Signal =  String((JSON.parse(_kdj.Value)).Signal);
                kline_kdj_Highes =  String((JSON.parse(_kdj.Value)).Highes);
                kline_kdj_Lowes =  String((JSON.parse(_kdj.Value)).Lowes);
                break;
              }
            }
            break;
          }
        }
        if (!isKdjEqual) {
          dic_quote.kdj_Main = kline_kdj_Main;
          dic_quote.kdj_Signal = kline_kdj_Signal;
          dic_quote.kdj_Highes = kline_kdj_Highes;
          dic_quote.kdj_Lowes = kline_kdj_Lowes;
        }
        //报价和boll指标匹配时间值
        var isBollEqual = false; //boll与报价的时间是否匹配
        for (let n = boll_i; n < boll.length; n++) {
          var dic_boll = boll[n];
          var time_boll = dic_boll.DateTime;
          var tamp_boll = time_boll.replace('/Date(', '').replace(')/', '').substring(0, 13);
          if (parseInt(tamp_quote) == parseInt(tamp_boll)) {
            dic_quote.boll_Upper = String((JSON.parse(dic_boll.Value)).Upper) == null ? kline_boll_Upper : String((JSON.parse(dic_boll.Value)).Upper);
            dic_quote.boll_Moving = String((JSON.parse(dic_boll.Value)).Moving) == null ? kline_boll_Moving : String((JSON.parse(dic_boll.Value)).Moving);
            dic_quote.boll_Lower = String((JSON.parse(dic_boll.Value)).Lower) == null ? kline_boll_Lower : String((JSON.parse(dic_boll.Value)).Lower);

            kline_boll_Moving = dic_quote.boll_Moving;
            kline_boll_Upper = dic_quote.boll_Upper;
            kline_boll_Lower = dic_quote.boll_Lower;

            boll_i = n + 1;
            isBollEqual = true;
            break;
          } else if (parseInt(tamp_quote) < parseInt(tamp_boll)) {
            boll_i = n;
            if ('0' == kline_boll_Upper) {
              for (let index = n; index < boll.length; index++) {
                var _boll = boll[index];
                if (String((JSON.parse(_boll.Value)).Upper) == null || String((JSON.parse(_boll.Value)).Moving) == null || String((JSON.parse(_boll.Value)).Lower) == null) {
                  continue;
                }
                kline_boll_Upper =  String((JSON.parse(_boll.Value)).Upper);
                kline_boll_Moving =  String((JSON.parse(_boll.Value)).Moving);
                kline_boll_Lower =  String((JSON.parse(_boll.Value)).Lower);
                break;
              }
            }
            break;
          }
        }
        if (!isBollEqual) {
          dic_quote.boll_Upper = kline_boll_Upper;
          dic_quote.boll_Moving = kline_boll_Moving;
          dic_quote.boll_Lower = kline_boll_Lower;
        }
        //报价和ma指标匹配时间值
        var isMaEqual = false; //ma与报价的时间是否匹配
        for (let r = ma_i; r < ma.length; r++) {
          var dic_ma = ma[r];
          var time_ma = dic_ma.DateTime;
          var tamp_ma = time_ma.replace('/Date(', '').replace(')/', '').substring(0, 13);
          if (parseInt(tamp_quote) == parseInt(tamp_ma)) {
            dic_quote.ma_Line = String((JSON.parse(dic_ma.Value)).Line) == null ? kline_ma_Line : String((JSON.parse(dic_ma.Value)).Line);
            kline_ma_Line = dic_quote.ma_Line;
            ma_i = r + 1;
            isMaEqual = true;
            break;
          } else if (parseInt(tamp_quote) < parseInt(tamp_ma)) {
            ma_i = r;
            if ('0' == kline_ma_Line) {
              for (let index = r; index < ma.length; index++) {
                var _ma = ma[index];
                if (String((JSON.parse(_ma.Value)).Line) == null) {
                  continue;
                }
                kline_ma_Line =  String((JSON.parse(_ma.Value)).Line);
                break;
              }
            }
            break;
          }
        }
        if (!isMaEqual) {
          dic_quote.ma_Line = kline_ma_Line;
        }
        //报价和osma指标匹配时间值
        var isOsmaEqual = false; //osma与报价的时间是否匹配
        for (let s = osma_i; s < osma.length; s++) {
          var dic_osma = osma[s];
          var time_osma = dic_osma.DateTime;
          var tamp_osma = time_osma.replace('/Date(', '').replace(')/', '').substring(0, 13);
          if (parseInt(tamp_quote) == parseInt(tamp_osma)) {
            dic_quote.osma_Osma = String((JSON.parse(dic_osma.Value)).Osma) == null ? kline_osma_Osma : String((JSON.parse(dic_osma.Value)).Osma);
            kline_osma_Osma = dic_quote.osma_Osma;
            dic_quote.osma_Signal = String((JSON.parse(dic_osma.Value)).Signal) == null ? kline_osma_Signal : String((JSON.parse(dic_osma.Value)).Signal);
            kline_osma_Signal = dic_quote.osma_Signal;
            osma_i = s + 1;
            isOsmaEqual = true;
            break;
          } else if (parseInt(tamp_quote) < parseInt(tamp_osma)) {
            osma_i = s;
            if ('0' == kline_osma_Osma) {
              for (let index = s; index < osma.length; index++) {
                var _osma = osma[index];
                if (String((JSON.parse(_osma.Value)).Osma) == null ||  String((JSON.parse(_osma.Value)).Signal) == null) {
                  continue;
                }
                kline_osma_Osma =  String((JSON.parse(_osma.Value)).Osma);
                kline_osma_Signal =  String((JSON.parse(_osma.Value)).Signal);
                break;
              }
            }
            break;
          }else {
            continue;
          }
        }
        if (!isOsmaEqual) {
          dic_quote.osma_Osma = kline_osma_Osma;
          dic_quote.osma_Signal = kline_osma_Signal;
        }
        arrQuotes.push(dic_quote);
      }
      return arrQuotes;
    },

    formatDateTime: function(inputTime) {
      var date = new Date(inputTime); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
      var y = date.getFullYear();
      var m = date.getMonth() + 1;
      m = m < 10 ? ('0' + m) : m;
      var d = date.getDate();
      d = d < 10 ? ('0' + d) : d;
      var h = date.getHours();
      h = h < 10 ? ('0' + h) : h;
      var minute = date.getMinutes();
      var second = date.getSeconds();
      minute = minute < 10 ? ('0' + minute) : minute;
      second = second < 10 ? ('0' + second) : second;
      return y + '-' + m + '-' + d + ' ' + h + ':' + minute + ':' + second;
    },


    //点击了左上角的返回按钮
    onclickleftitem: function() {
      navi.pop({
        animated: "true"
      }, event => {});
    },
    //点击了左下角的mt4按钮
    onclickleftbottomitem: function() {
      if (false == this.showMt4 && !this.isAndorid) {
        return;
      }
      if (utils.isAndroid()) {
        weex.requireModule('app').openMt4();
      } else {
        if (app.canOpenURL("metatrader5://")) {
          app.openURL("metatrader5://com.bibfx.app");
        } else {
          app.openURL(url.MT4);
        }
      }
    },
    //点击了右下角的全屏按钮
    onclickrightbottomitem: function() {

      this.isFullScreenClose = true;
      //storage存储竖屏传值给横屏的k线类型值
      storage.setItem("quoteKlineType", this.typeChannelIndex + "");

      navi.push({
        disableBackPan: 'true',
        orientation: 'horizontal',
        url: bundleUrl + 'quoteFullScreen.js',
        animated: "false",
      }, event => {

      })
    },


    //切换K线图的类型的方法
    typechannelClick: function(index = 0) {
      var selfThis = this;
      if (selfThis.loadingDataKLine) {
        return;
      }
      if (index >= this.string.quotetypechannel.length || index == this.typeChannelIndex || index < 0) {
        return;
      }
      this.typeChannelIndex = index;
      this.selectedTypeHighlight(); //高亮选中的栏目
      this.typeChannel = this.string.quotetypechannel[index].type;
      this.timeNumber = 1;
      var stamp = new Date().getTime(); //当前时间转换的时间戳
      this.getTheKLineData(true, this.timeNumber, stamp); //请求网络数据

    },
    loadMoreData(){
       var selfThis=this;
       var startTime =utils.dateFormat(selfThis.starttime, 'yyyy-MM-dd hh:mm:ss');
       var endTime =selfThis.timestampToDate(new Date().getTime());
       // var typeurl = selfThis.cmsApiHost + '/Quotes/MultIndicators?SymbolName=' + selfThis.codeChannel + '&UTC=' + selfThis.utc + '&IndicatorNames=MACD,RSI,KDJ,BOLL,MA,OSMA&Period=' + selfThis.typeChannel + '&DateTimeBetween=' +startTime+
       //  ',' + endTime + '&isapp=1';
       // var indexData= [];
       // http.get(encodeURI(typeurl), function(resp) {
       //    indexData= resp;

          var kurl = selfThis.cmsApiHost + '/Quotes/Line?DateTimeBetween=' + startTime + ',' + endTime + '&Symbol=' + selfThis.codeChannel + '&UTC=' + selfThis.utc + '&type=' + selfThis.typeChannel + '&isapp=1';
          http.get(encodeURI(kurl), function(response) {
                if (response.ok && response.data) {
                    // if (indexData.MACD && indexData.MACD.length > 0) {
                        var data = response.data.Results;
                        if (undefined != selfThis.$refs.quoteKLineChartView)
                            selfThis.$refs.quoteKLineChartView.setloadMoreData(data);
                    // }
                }
          })
       // })
       //

    },
    //高亮选中的栏目
    selectedTypeHighlight: function() {
      var that = this;
      if (undefined == this.$refs.typeChannel) {
        return;
      }
      var el = this.$refs.typeChannel[this.typeChannelIndex];
      if (el == undefined) {
        return;
      }

      this.$refs.typeScroller.getContentOffset(function(contentOffset) {
        dom.getComponentRect(el, function(callBack) {
          if (callBack.result == true) {
            if (contentOffset.x <= 0) {
              that.string.quotetypechannel[that.typeChannelIndex].left = callBack.size.left - contentOffset.x;
            } else {
              that.string.quotetypechannel[that.typeChannelIndex].left = callBack.size.left;
            }
            that.string.quotetypechannel[that.typeChannelIndex].width = callBack.size.width;
            that.string.quotetypechannel[that.typeChannelIndex].right = callBack.size.right;
            // that.blockposition = that.string.quotetypechannel[that.typeChannelIndex].left;
            var blockwidth = that.string.quotetypechannel[that.typeChannelIndex].width;
            var offset = -that.string.quotetypechannel[that.typeChannelIndex].left;
            if ((that.string.quotetypechannel[that.typeChannelIndex].left + blockwidth / 2) > 375) {
              offset = (that.string.quotetypechannel[that.typeChannelIndex].width - 750) / 2;
            }
            if (el) {
              dom.scrollToElement(el, {
                offset: offset,
                animated: false
              });
            }
          }
        });
      });
    },


    //k线左右滑动的代理方法
    ScrollKlineChart: function(e) {
      var selfThis = this;
      if (selfThis.loadingDataKLine) {
        //正在加载数据时  滑动更新加载数据直接返回
        return;
      }
      //k线左右滑动的代理方法
      if (e.isRight) { //右滑加载更多历史k线数据
        selfThis.timeNumber = 1;
        //正常左滑加载更多历史数据时 传入上一次请求数据的结束时间戳
        selfThis.getTheKLineData(false, selfThis.timeNumber, selfThis.endtime);
      } else {
        selfThis.timeNumber = 1;
        //左滑刷新最新k线数据
        var stamp = new Date().getTime(); //当前时间转换的时间戳
        selfThis.getTheKLineData(true, selfThis.timeNumber, stamp);
      }
    },
    startTimer :function(){
      if (this.typeChannelIndex==4){
         return;
      }
      this.loadMoreData();
      this.timer = setTimeout(this.startTimer.bind(this), 300000);
    },
    timestampToDate: function(timestamp) {
      var date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
      var Y = date.getFullYear() + '-';
      var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
      var D = date.getDate() + ' ';
      var h = date.getHours() + ':';
      var m = date.getMinutes() + ':';
      var s = date.getSeconds();
      return Y + M + D + h + m + s;
      // return Y + M + D;
    },

  },
}
</script>

<style lang="css">
    .wrap-iphoneX {
        padding-bottom: 34px;
        flex: 1;
        background-color: #f1f1f1;
    }
    .wrap {
        flex: 1;
        background-color: #f1f1f1;
    }

    .quote-nav {
        flex-direction: row;
        width: 750px;
        height: 88px;
        justify-content: center;
        align-items: center;
        /*background-color: #E93030;*/
        background-color: #2e74e9;
    }

    .quote-nav-left {
        position: absolute;
        flex-direction: row;
        width: 60px;
        height: 88px;
        left: 10px;
        justify-content: center;
        align-items: center;
    }

    .quote-nav-left-image {
        width: 20px;
        height: 36px;
    }

    .quote-nav-center {
        align-items: center;
        justify-content: center;
    }

    .quote-nav-center-title {
        text-align: center;
        font-size: 32px;
        color: #FFFFFF;
        font-weight: normal;
    }

    .quote-view {
        height: 316px;
        padding-left: 0px;
        padding-right: 0px;
        flex-direction: row;
        justify-content: space-between;
        align-items: stretch;
        background-color: #ffffff;
    }
    .quote-view-main-price {
        margin-top:25px;
        margin-left:40px;
        justify-content:center;
        align-items: center;
        width: 316px;
    }

    .quote-view-text-now-price-in {
        font-size: 60px;
        color: #32a80a;
        font-weight: bold;
    }
    .quote-view-text-now-price-out {
        font-size: 60px;
        color: #eb290f;
        font-weight: bold;
    }

    .quote-view-text-change-range-in {
        font-size: 30px;
        color: #32a80a;
        /*margin-top: 26px;*/
    }
    .quote-view-text-change-range-out {
        font-size: 30px;
        color: #eb290f;
        /*margin-top: 26px;*/
    }
    .quote-view-four-price-bg {
        flex-direction: row;
        /*margin-top:18px;*/
        justify-content: center;
      align-items: center;
      width: 316px;
        /*margin-right: 30px;*/
    }
    .quote-view-two-price-bg {
        width:142px;
        align-items: flex-start;
    }

    .quote-view-text-title-bg {
        width: 100px;
        height: 28px;
        background-color: #f4f4f4;
        border-radius: 5px;
        justify-content: center;
        align-items: center;
    }

    .quote-view-text-title {
        font-size: 28px;
        line-height: 30px;
        color: #8b9099;
        text-align: center;
    }

    .quote-view-text-number-bg {
        height: 36px;
        align-items: flex-start;
        justify-content: center;
    }
    .quote-view-text-number {
        font-size: 28px;
        line-height: 30px;
        color: #454950;
        text-align: left;
    }

    .quote-type {
        height: 76px;
        padding-left: 0px;
        padding-right: 0px;
        flex-direction: row;
        justify-content: flex-start;
        align-items: stretch;
        background-color: #ffffff;
    }
    .quote-type-scroller {
        overflow: hidden;
        flex: 1;
        height: 76px;
        flex-direction: row;
        padding-left: 0px;
        padding-right: 0px;
    }

    .quote-type-item {
        overflow: hidden;
        width: 114px;
        height: 76px;
        justify-content: center;
        align-items: center;
    }

    .quote-type-normal {
        font-size: 28px;
        line-height: 32px;
        color: #454950;
        text-align: center;
    }

    .quote-type-selected {
        font-size: 28px;
        line-height: 32px;
        /*color: #e9302e;*/
        color: #2e74e9;
        text-align: center;
    }

    .quote-type-red-div {
        position: absolute;
        bottom: 0px;
        left:37px;right: 37px;
        height: 4px;
        /*background-color: #e9302e;*/
        background-color: #2e74e9;
    }

    .quote-tips {
        position: relative;
        left: 0px;
        right: 0px;
        bottom: 0px;
        height: 50px;
        background-color: #ffffff;
        justify-content: center;
        align-items: center;
        flex-direction: row;
    }

    .quote-tips-text {
        font-size: 24px;
        color: #8b9099;
        text-align: center;
    }

    .quote-bottom {
        position: relative;
        left: 0px;
        right: 0px;
        bottom: 0px;
        height: 70px;
        justify-content: space-between;
        flex-direction: row;
        background-color: #f1f1f1;
    }
    .quote-bottom-image-MT4 {
        width: 26px;
        height: 30px;
    }
    .quote-bottom-image-full {
        width: 38px;
        height: 38px;
    }

    .quote-bottom-text-icon-left {
        margin-left: 30px;
        width: 300px;
        flex-direction: row;
        justify-content: flex-start;
        align-items: center;
        overflow: hidden;
    }

    .quote-bottom-text-icon-right {
        margin-right: 20px;
        width: 58px;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        overflow: hidden;
    }

    .quote-bottom-text {
        margin-left: 8px;
        justify-content: flex-start;
        font-size: 28px;
        color: #454950;
    }
    .quote-data-bid-u{
        font-size: 48px;
        color: #32a80a;
    }
    .quote-data-bid-d{
        font-size: 48px;
        color: #eb290f;
    }
    .quote-data-u{
        font-size: 28px;
        color: #32a80a;
    }
    .quote-data-d{
        font-size: 28px;
        color: #eb290f;
    }
    .num-div{
        width: 225px;
        height: 168px;
        justify-content: center;
        align-items: center;
    }
    .product-div{
        width: 225px;
        height: 336px;
    }
    .font28{
        font-size: 28px;
    }
    .color-gray{
       color: #454950
    }
     .color-gray1{
       color: #8b9099
    }
</style>
