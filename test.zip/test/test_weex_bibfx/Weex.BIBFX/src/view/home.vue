<template>
<div @viewdisappear="viewDisappear" @viewappear="viewAppear" @foreground="becomeActive" @background="enterBackground">
  <status backgroundColor="white" @click="scrollTop"></status>
  <div class="navibar" @click="scrollTop">
    <text class="title bold"> {{title}} </text>
    <div @click="service()" class="navbar-button-l">
      <image style="width: 40px; height: 36px" resize="contain" :src="assets+'onlinecs.png'"></image>
    </div>
    <div @click="showNotice()" class="navbar-button-r">
      <image style="width: 40px; height: 36px" resize="contain" :src="assets+'home_notice.png'"></image>
    </div>
  </div>
  <div style="flex:1;">
    <list ref="homeList" show-scrollbar="false" loadmoreoffset=10>
      <refresh class="refresh" @refresh="refresh" :display="(refreshing || pullingdown)? 'show' : 'hide'">
        <loading-indicator class="indicator"></loading-indicator>
        <text class="indicator-text">{{refreshing?"正在刷新":"下拉刷新"}}</text>
      </refresh>
      <cell>
        <slider style="width:750px;height:470px;" infinite="true" interval="3000" auto-play="true">
          <div style="width:750px;height:422px;" @click="liveClick">
            <image style="width:750px;height:422px;" resize="cover" :src="live.banner"></image>
            <div class="live-info-bottom flexRow alignCenter" v-if="course&&course.length>0">
                <image v-if="courseIndex >=0" style="width:29px;height:26px;marginLeft:20px;" :src="assets+'live.gif'"></image>
                <text class="online-text" lines='1'>{{(courseIndex >=0 && course.length > 0)?liveTips:live.content}}</text>
            </div>
            <div v-if="(live.index >= 0 || courseIndex >=0 )&& course.length > 0" style="position: absolute;left:0px;right:0px;top:0px;bottom:0px;justify-content: center;align-items: center;" @click="liveClick">
              <image class="wifiplay" :src="wifistopimg"></image>
            </div>
          </div>
          <div style="width:750px;height:422px;" v-for="item in banners" @click="showBanner(item,idx+1)">
            <image style="width:750px;height:422px;" resize="cover" :src="item.image"></image>
          </div>
          <indicator class="banner-indicator"></indicator>
        </slider>
      </cell>
      <cell class="center screenWidth" style="background-color:#FFFFFF;">
        <div class="screenWidth flexRow  marginTop marginBottom" style="padding-left:24px;">
          <div class="quote" v-for="item,index in quotes" @click="showQuote(item,index)">
            <image style="position:absolute;top:0px;left:0px;" class="quote" :src="quote"></image>
            <text class="bold" style="marginTop:20px;lines:1;color:#666666;font-size:30px;line-height:48px;"> {{item.symbolName}}</text>
            <div class="flexRow alignCenter" style="height:66px;">
              <text class="bold" style="lines:1;font-size:36px; text-overflow:ellipsis;" :class="[item.Bid>=item.Open?'riseColor':'downColor']">{{Number(item.Bid).toFixed(symbolName[item.Symbol].fixed)}}</text>
              <image style="width:14px;height:21px;marginLeft:10px;" :src="assets+(item.Bid<item.Open?'drop.png':'rise.png')"></image>
            </div>
            <text style="lines:1;font-size:24px;line-height:36px;text-overflow:ellipsis" :class="[item.Bid>=item.Open?'riseColor':'downColor']">{{item.change}}%</text>
            <text style="lines:1;font-size:24px;line-height:48px;color:#999999;text-overflow:ellipsis">点差{{((item.Ask - item.Bid)*symbolName[item.Symbol].mul).toFixed(1)}}</text>
          </div>
        </div>
        <div class="marginBottom flexRow center" v-if="quotes.length>0" @click="showQuote()">
          <image style="width:24px;height:24px;" :src="assets+'plus.png'"></image>
          <text style="marginLeft:10px;color:#999999;font-size:30px;">点击查看更多</text>
        </div>
      </cell>
      <cell class="buttons">
        <div style="flex-direction:row;margin-top:20px;margin-bottom:20px;height:90px;justify-content: center;">
          <div style="width:344px;height:90px;backgroundColor: #2e74e9;border-radius:10px;justify-content: center;align-items: center" @click="fastdeposit">
            <text style="font-size: 36px;line-height:54px; color: white;text-align:center;">快速注资</text>
          </div>
          <div style="margin-left:20px;width:344px;height:90px;backgroundColor:#f04341;border-radius:10px;justify-content: center;align-items: center" @click="openAccount">
            <text style="font-size: 36px;line-height:54px;color: white;text-align:center;">立即开户</text>
          </div>
        </div>
      </cell>
      <!--金牌讲师-->
      <cell class="lecturer">
        <div class="screenWidth flexRow " style="height:110px;align-items:center;justify-content: space-between;">
          <!-- <text class="flag" style="#333333;font-size:36px; line-height:40px;"> 金牌讲师</text> -->
          <text class="flag group-title">金牌讲师</text>
          <div class="flexRow" style="width:120px;height:110px;marginRight:20px;align-items:center;" @click="onCourseClick(-2)">
            <image style="width:33px;height:33px;" resize="contain" :src="assets+'course.png'"></image>
            <text style="color:#999999;font-size:24px; line-height:40px;"> 课程表</text>
          </div>
        </div>
        <scroller class="lecturer-scroller" show-scrollbar="false" scrollDirection="horizontal">
          <div class="lecturer-item" v-for="item in lecturer" @click="onLecturerClick(item,'gold');logEvent('HomePage_teachers')">
            <image style="position:absolute;left:0px;top:0px;width:230px;height:330px;" :src="terbg"></image>
            <image class="radius" style="width:220px;height:220px;overflow:hidden;" resize="cover" :src="item.banner"></image>
            <text class="lecturer-item-name"> {{item.name}}</text>
            <text class="lecturer-item-title"> {{item.subTitle}}</text>
          </div>
        </scroller>
      </cell>
      <cell class="buttons screenWidth flexRow " style="height:110px;align-items:center;">
        <text class="flag group-title">资讯要闻</text>
      </cell>
      <cell v-if="promotions.length>0" class="screenWidth" @click="onNewsClick(promotions[0])">
        <div class="flexRow leftline" style="marginLeft:40px;marginRight:30px;">
          <div class="borderline" style="width:24px;marginTop:47px;"></div>
          <div style="flex:1;overflow:hidden;">
            <div class="flexRow" style="height:30px;marginTop:32px;align-items:center;">
              <text class="newsTime">{{promotions[0].formatTime}}</text>
              <text style="marginLeft:20px;font-size:24px;line-height:30px;text-align:center;width:82px;height:30px;border-radius:15px;" class="promotions">优惠</text>
            </div>
            <div style="height:75px;margin-top:30px;marginBottom:30px;overflow:hidden;">
              <text class="bold" lines="2" style="font-size:28px;color:#333333;">{{promotions[0].title}}</text>
            </div>
          </div>
          <image class="newImage" resize="cover" :src="promotions[0].image"></image>
        </div>
        <div style="position:absolute;top:40px;left:32px;width:16px;height:16px;border-width:4px;border-radius:8px;border-color:#EEEEEE;backgroundColor:#F14342;"></div>
      </cell>
      <cell class="screenWidth" v-for="(item,index) in news" @click="onNewsClick(item)">
        <div class="flexRow leftline" style="marginLeft:40px;marginRight:30px;">
          <div class="borderline" style="width:24px;marginTop:47px;"></div>
          <div style="flex:1;overflow:hidden;">
            <div class="flexRow" style="height:30px;marginTop:32px;align-items:center;">
              <text class="newsTime">{{item.formatTime}}</text>
              <text v-if="item.channelName" style="marginLeft:20px;font-size:24px;line-height:30px;text-align:center;width:82px;height:30px;border-radius:15px;" :class="[('优惠'==item.channelName)?'promotions':'comments']">{{item.channelName}}</text>
            </div>
            <div style="min-height:96px;margin-top:16px;overflow:hidden;">
              <text class="bold" lines="2" style="text-overflow: ellipsis;font-size:28px;line-height:48px;color:#333333;">{{item.title}}</text>
            </div>
          </div>
          <image v-if="item.image" class="newImage" resize="contain" :src="item.image"></image>
        </div>
        <div style="position:absolute;top:40px;left:32px;width:16px;height:16px;border-width:4px;border-radius:8px;border-color:#EEEEEE;" :style="{'backgroundColor':('优惠'==item.channelName?'#F14342':'#2E74E9')}"></div>
      </cell>
      <cell @click="getNews" class="screenWidth flexRow" style="height:108px;align-items:center;justify-content:center;">
        <image style="width:35px;height:29px;margin-right:20px;" resize="contain" :src="assets+'fresh.png'"></image>
        <text style="color:#999999;font-size:30px; line-height:45px;">换一换</text>
      </cell>
      <cell class="board">
        <div class="screenWidth" style="marginTop:20px;backgroundColor:#FFFFFF">
          <div class="flexRow center" style="marginTop:28px;marginBottom:16px;">
            <div style="width:110px;height:2px;background-color:#CCCCCC;"></div>
            <text class="bold" style="marginLeft:20px;marginRight:20px;font-size:28px;lines-height:48px;color:#333333;">铸博皇御已安全运营</text>
            <div style="width:110px;height:2px;background-color:#CCCCCC;"></div>
          </div>
          <div class="flexRow center" style="height:36px;marginBottom:26px;">
            <text class="boardText">{{safeTime.Year}}</text>
            <text class="boardTime">年</text>
            <text class="boardText">{{safeTime.Days}}</text>
            <text class="boardTime">天</text>
            <text class="boardText">{{safeTime.Hours}}</text>
            <text class="boardTime">时</text>
            <text class="boardText">{{safeTime.Minutes}}</text>
            <text class="boardTime">分</text>
          </div>
        </div>
        <slider class="screenWidth" style="height:340px;backgroundColor:#FFFFFF;">
          <div class="flexRow screenWidth">
            <div style="width:250px;align-items:center;">
              <image style="width:110px;height:110px;" :src="assets+'safe1.png'"></image>
              <text style="marginTop:26px;font-size:24px;line-height:36px;color:#333333;font-weight: bold;">安全交易典范</text>
              <text style="font-size:20px;line-height:40px;color:#666666;text-align:center;">{{'权威资质全球认可\n诚信经营市场信赖'}}</text>
            </div>
            <div style="width:250px;align-items:center;">
              <image style="width:110px;height:110px;" :src="assets+'safe2.png'"></image>
              <text style="marginTop:26px;font-size:24px;line-height:36px;color:#333333;font-weight: bold;">顶级客户保障</text>
              <text style="font-size:20px;line-height:40px;color:#666666;text-align:center;">{{'资金独立管理\n个人隐私高度加密'}}</text>
            </div>
            <div style="width:250px;align-items:center;">
              <image style="width:110px;height:110px;" :src="assets+'safe3.png'"></image>
              <text style="marginTop:26px;font-size:24px;line-height:36px;color:#333333;font-weight: bold;">极速资金存取</text>
              <text style="font-size:20px;line-height:40px;color:#666666;text-align:center;">{{'支持24小时资金存取\n专人跟进到账更快捷'}}</text>
            </div>
          </div>
          <div class="flexRow screenWidth">
            <div style="width:250px;align-items:center;">
              <image style="width:110px;height:110px;" :src="assets+'safe4.png'"></image>
              <text style="marginTop:26px;font-size:24px;line-height:36px;color:#333333;font-weight: bold;">极致优惠专享</text>
              <text style="font-size:20px;line-height:40px;color:#666666;text-align:center;">{{'新客送$50000\n$30金银回赠'}}</text>
            </div>
            <div style="width:250px;align-items:center;">
              <image style="width:110px;height:110px;" :src="assets+'safe5.png'"></image>
              <text style="marginTop:26px;font-size:24px;line-height:36px;color:#333333;font-weight: bold;">非凡投资服务</text>
              <text style="font-size:20px;line-height:40px;color:#666666;text-align:center;">{{'24小时全天候在线客服\n原油外汇金银全时段直播'}}</text>
            </div>
            <div style="width:250px;align-items:center;">
              <image style="width:110px;height:110px;" :src="assets+'safe6.png'"></image>
              <text style="marginTop:26px;font-size:24px;line-height:36px;color:#333333;font-weight: bold;">MT5交易系统</text>
              <text style="font-size:20px;line-height:40px;color:#666666;text-align:center;">{{'更快捷的下单速度\n更稳定的交易体验'}}</text>
            </div>
          </div>
          <indicator class="board-indicator"></indicator>
        </slider>
      </cell>
    </list>
    <wxc-loading :show="logining" loading-text="加载中" needMask=fasle></wxc-loading>
  </div>
  <div :class="['toast',showToast?'toast-show':'toast-hide']">
    <div class="modul">
      <text style="color:#FFFFFF;font-size:28px;"> {{tips}} </text>
    </div>
  </div>
</div>
</template>

<script>
var http = require('../include/http.js');
var storage = require('../include/storage.js');
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var dom = weex.requireModule('dom');
var animations = weex.requireModule('animation');
var navigator = weex.requireModule('navigator');
var utils = require('../include/utils.js');
var firebase = weex.requireModule('firebase');
var app = weex.requireModule('app');
const websocket = weex.requireModule('webSocket');

const currentYear = new Date(new Date().getFullYear().toString() + '/03/12 00:00:00');

import {
  TYPE_TEACHER,
  TYPE_ANCHOR,
  TYPE_LESSION_NORMAL,
  TYPE_LESSION_TEACHERS,
  TYPE_LESSION_ANCHOR
} from '../include/type.js'

module.exports = {
  components: {
    'status': require('../components/statusbar.vue'),
    'loadError': require('../components/loadError.vue'),
    "wxc-loading": require('../components/wxc-loading.vue'),
  },
  data: function() {
    return {
      string: require('../include/string.js'),
      assets: assetsUrl,
      title: '皇御环球金融',
      isShow: true,
      noCourse: '',
      timeTableSrc: assetsUrl + 'tablebg.png',
      liveSrc: assetsUrl + 'livebg.png',
      lineSrc1: assetsUrl + 'live1.png',
      lineSrc2: assetsUrl + 'live2.png',
      onlineicon: assetsUrl + 'online.png',
      bangssrc: assetsUrl + 'bangs.png',
      wifistopimg: assetsUrl + 'homeplaying.png',
      arrow: assetsUrl + 'down.png',
      left: assetsUrl + 'left.png',
      right: assetsUrl + 'right.png',
      quote: assetsUrl + 'home_quote.png',
      terbg: assetsUrl + 'home_terbg.png',
      more: assetsUrl + 'more.png', //了解更多
      bangsShow: false,
      logining: true,
      showToast: false,
      symbols: '',
      quotesSocket: '',
      quotes: [],
      quoteName: '',
      course: [],
      courseIndex: -1, //当前高亮的课程
      courseStart: 0, //记录当天课程开始时间
      courseEnd: 0, //记录当天课程结束时间
      liveType: TYPE_LESSION_NORMAL, //显示的课程模式
      liveTips: '', //显示直播时间
      liveBanner: [], //直播Banner,
      liveTeacher: '',
      live: {
        banner: '',
        title: '',
        name: '',
        content: '',
        online: 0,
        index: -1, //用于标记当前显示哪张banner
      },
      banners: [],
      lecturer: [],
      promotions: [], //优惠活动
      news: [], //新闻数据
      height: 1,
      nodeIdLive: '',
      nodeIdBanner: 0,
      nodeIdTecher: '',
      nodeIdNews: '',
      commentsId: "0",
      strategyId: "0",
      newsId: "0",
      newsPageSize: 3, //每页请求数据的条数
      newsPageIndex: 0,
      loading: false, //是否正在加载更多头条
      refreshing: false, //刷新中
      pullingdown: false, //是否下拉中
      longPull: false, //标记是否长按操作
      deg: 0,
      isLoadError: false, //网络加载出错
      outofview: false, //标记是否进入后台
      timerId: 0, //定时器ID,防止多个定时器的问题
      android: utils.isAndroid(),
      netTips: "当前网络不给力,请稍候再试！",
      tips: '',
      duration: 1000,
      feedback: "",
      trueAccountUrl: '', //开户链接
      utm: '',
      settings: {},
      symbolName: {
        "EURUSD": {
          symbolName: "欧元美元",
          symbol: "EURUSD",
          mul: 10000,
          fixed: 5
        },
        "GBPUSD": {
          symbolName: "英镑美元",
          symbol: "GBPUSD",
          mul: 10000,
          fixed: 5
        },
        "USDJPY": {
          symbolName: "美元日元",
          symbol: "USDJPY",
          mul: 100,
          fixed: 3
        },
        "AUDUSD": {
          symbolName: "澳元美元",
          symbol: "AUDUSD",
          mul: 10000,
          fixed: 5
        },
        "NZDUSD": {
          symbolName: "纽元美元",
          symbol: "NZDUSD",
          mul: 10000,
          fixed: 5
        },
        "USDCAD": {
          symbolName: "美元加元",
          symbol: "USDCAD",
          mul: 10000,
          percent: 100,
          fixed: 5
        },
        "USDCHF": {
          symbolName: "美元瑞郎",
          symbol: "USDCHF",
          mul: 10000,
          percent: 100,
          fixed: 5
        },
      },
      safeTime: {
        Year: 0,
        Days: 0,
        Month: 0,
        Hours: 0,
        Minutes: 0
      }
    }
  },
  beforeCreate: function() {
    var that = this;
    storage.getItem('defaultSetting', function(value) {
      if (!utils.isBlankString(value) && value.length > 2) {
        let defaultSetting = JSON.parse(value);
        that.liveTeacher = defaultSetting.homeLiveBanner;
      }
    })
  },
  created: function() {
    var domModule = weex.requireModule('dom');
    domModule.addRule('fontFace', {
      'fontFamily': "GEO415M",
      'src': "url('" + assetsUrl + "geo415m_0.ttf')",
    });
    if (weex.supports('@module/app')) {
      app.setStatusBarStyle(0);
      this.channelName = app.channelName();
    }

    if (this.channelName) {
      this.utm = "ComeFrom=GlobalApps&utm_source=APP&utm_campaign=&utm_content=&utm_term=&utm_medium=" + this.channelName;
    }
    for (var key in this.symbolName) {
      if (utils.isBlankString(this.symbols)) {
        this.symbols = key;
      } else {
        this.symbols = this.symbols + ' ' + key;
      }
    }
    http.setTimeout(15000);
    this.loadCache();
    this.loadConfigs();
    this.showLiveTime(this.timerId); //显示直播时间
  },
  methods: {
    // 接收网络错误的点击事件的回调
    refreshNetWorkError: function() {
      this.refresh();
    },
    viewAppear: function(e) {
      if (weex.supports('@module/app')) {
        weex.requireModule('app').setStatusBarStyle(0);
      }
      if (true == this.outofview) {
        this.outofview = false;
        this.timerId++;
        this.showLiveTime(this.timerId);
      }
    },
    viewDisappear: function(e) {
      this.cacheData();
      this.outofview = true;
      this.timerId++;
    },
    becomeActive: function(e) {
      if (true == this.outofview) {
        this.outofview = false;
        this.timerId++;
        this.showLiveTime(this.timerId);
      }
    },
    enterBackground: function(e) {
      this.cacheData();
      this.outofview = true;
      this.timerId++;
    },
    hideBangs: function() {
      this.bangsShow = false;
    },
    showBangs: function() {
      this.bangsShow = true;
      this.courseIndex = -1;
    },
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    loadCache: function() {
      var that = this;
      storage.getItem('app-homeCache', function(value) {
        if (value && value.length > 0) {
          var homeCache = JSON.parse(value);
          if (homeCache) {
            if (that.course.length <= 0) {
              that.course = homeCache.course;
            }
            that.live = homeCache.live;
            that.live.index = -1;
            that.lecturer = homeCache.lecturer;
            that.news = homeCache.news;
          }
        }
      });
    },
    cacheData: function() {
      var cache = {
        course: this.course,
        live: this.live,
        lecturer: this.lecturer,
        news: this.news,
      }
      storage.setItem('app-homeCache', JSON.stringify(cache));
    },
    loadConfigs: function() {
      var that = this;
      storage.getItem('commonUrl', function(value) {
        if ('' == value || value == undefined || value.length <= 0) {
          return
        }
        var commonUrl = JSON.parse(value);
        if (commonUrl) {
          that.cmsApiHost = commonUrl.cmsApi; //接口基址
          that.imageBaseUrl = commonUrl.imageBaseUrl; //图片基址
          that.contentBaseUrl = commonUrl.contentBaseUrl; //文章基址
          that.feedback = commonUrl.feedback; //客服800连接
          that.quotesSocket = commonUrl.quoteSocketUrl;
          that.deposit = commonUrl.deposit;
          that.getLastQuotes();
          storage.getItem("setting", function(data) {
            if (data) {
              that.settings = JSON.parse(data);
              that.getPromotions();
            }
          });
          storage.getItem('nodeIdList', function(value) {
            if (utils.isBlankString((value)) || value.length <= 2) {
              return;
            }
            var nodeIdList = JSON.parse(value);
            that.nodeIdLive = nodeIdList.homeLiveBanner;
            that.nodeIdBanner = nodeIdList.homeBanner;
            that.nodeIdTecher = nodeIdList.homeTeacherInfo;
            that.nodeIdNews = nodeIdList.homeTopNews;
            that.commentsId = nodeIdList.comments;
            that.strategyId = nodeIdList.strategy;
            that.newsId = nodeIdList.news;
            that.noCourseId = nodeIdList.homeNoLessons;
            that.tagsId = nodeIdList.tags;
            // that.getNoCourse();
            that.getLessons(); //获取课程信息
            that.getLiveBanner(); //获取直播信息
            that.getHomeBanner(); //获取首页直播
            that.getLecturer(); //获取老师信息
            that.getPromotions(); //获取优惠活动
            that.getNews(); //获取新闻
            that.getTags();
          });
          if (utils.isAndroid()) {
            that.connectWebSocket(that.timerId);
            that.setupWebsocket();
          } else {
            that.setupWebsocket();
            that.connectWebSocket(that.timerId);
          }
        }
      });

      // storage.getItem('topic', function(value) {
      //   if (value && value.length > 0) {
      //     that.tags = JSON.parse(value);
      //   }
      // });
    },
    showTime: function(time) {
      // var date = new Date(time.replace(new RegExp(/-/gm), "/"));
      //   time的格式   /Date(1509935433000-0000)/
      var date = new Date(parseInt(time.replace('/Date(', '').replace(')/', '').substring(0, 13)));
      var now = new Date();
      var duration = (now.getTime() - date.getTime()) / 1000;
      if (duration < 60) {
        return '刚刚';
      } else if (duration < 3600) {
        return Math.floor(duration / 60) + '分钟前';
      } else if (duration < 86400) {
        return Math.floor(duration / 3600) + '小时前';
      } else if (duration < 172800) {
        return '1天前';
      } else {
        // return (date.getMonth() + 1) + '月' + date.getDate() + '日';
        return (date.getMonth() + 1) + '/' + date.getDate() ;
      }
    },
    dateFormat: function(time, fmt) {
      var date = new Date(time);
      var o = {
        "M+": date.getMonth() + 1, //月份
        "d+": date.getDate(), //日
        "h+": date.getHours(), //小时
        "m+": date.getMinutes(), //分
        "s+": date.getSeconds(), //秒
        "q+": Math.floor((date.getMonth() + 3) / 3), //季度
        "S": date.getMilliseconds() //毫秒
      };
      if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
      for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
      return fmt;
    },
    getNoCourse: function() {
      var that = this;
      var url = that.cmsApiHost + '/ContentUnion/Site?format=json&Fields=Id,AddDate,Summary&id=' + that.noCourseId;
      http.get(url, function(response) {
        that.isLoadError = false;
        if (response.status < 200) {
          that.isLoadError = true;
        }
        if (response.ok && response.data && response.data.Results && response.data.Results.length > 0) {
          var result = response.data.Results[0];
          if (result.Summary) {
            that.noCourse = result.Summary;
          } else {
            that.noCourse = '周一至周五\n15小时名师超长在线教学！';
          }
        } else {
          that.noCourse = '周一至周五\n15小时名师超长在线教学！';
        }
      })
    },
    getLessons: function() {
      var that = this;
      if (that.cmsApiHost) {
        var date = new Date();
        var ms = date.getTime();
        var dateStr = that.dateFormat(ms, 'yyyy-MM-dd');
        var url = that.cmsApiHost + '/Live/LessonsGroup?format=json&channel=bibfx&DateTime=' + dateStr;
        http.get(url, function(response) {
          if (response.status < 200) {
            that.showTips(that.netTips);
          }
          if (response.ok && response.data) {
            var results = response.data;
            if (results && results.length > 0) {
              that.course.splice(0, that.course.length);
              for (var i = 0; i < results[0].lessons.length; i++) {
                var lesson = results[0].lessons[i];
                var course = {};
                if (lesson.Name) {
                  course.names = lesson.Name;
                  var names = lesson.Name.split("/");
                  course.name = names[0];
                }
                if (lesson.HeadUrls) {
                  for (var j = 0; j < lesson.HeadUrls.length; j++) {
                    if ("appHomeLessons" == lesson.HeadUrls[j].Key) {
                      course.icon = lesson.HeadUrls[j].Url; //老师头像
                      break;
                    }
                  }
                }
                if (lesson.Title) {
                  course.title = lesson.Title;
                }

                // if (lesson.UserAccountExTitle) {
                //   course.exTitle = lesson.UserAccountExTitle;
                // }

                if (lesson.TimeSpan) {
                  course.duration = lesson.TimeSpan
                }
                if (lesson.StartTime) { //"StartTimestamp": 1532307600000,
                  course.startTime = parseInt(lesson.StartTime.slice(6, -7));
                  course.endTime = course.startTime + course.duration; //duration 单位：分钟
                }
                if (course.startTime > 0 && course.endTime > course.startTime) {
                  course.time = that.dateFormat(course.startTime, 'hh:mm') + '-' + that.dateFormat(course.endTime, 'hh:mm')
                }
                if (ms >= course.startTime && ms <= course.endTime) {
                  course.active = true;
                } else {
                  course.active = false;
                }
                // if (lesson.Tag) {  //字段不存在
                //   course.tags = lesson.Tag;
                // }
                course.type = TYPE_LESSION_NORMAL;
                //双人课程代码，暂时屏蔽
                // if (lesson.Teachers && lesson.Teachers.length>=2) {
                //   if (TYPE_TEACHER == lesson.Teachers[1].Type || TYPE_TEACHER == lesson.Teachers[1].type) {
                //     course.type = TYPE_LESSION_TEACHERS;
                //   }else {
                //     course.type = TYPE_LESSION_ANCHOR;
                //   }
                // }

                if (utils.isBlankString(lesson.Name)) {
                  course.teacher = '';
                } else {
                  course.teacher = lesson.Name.split("/", 1)[0];
                }
                that.course.push(course);
              }
            }
          } else {
            // that.course.splice(0, that.course.length);
            that.course.splice(0, 0);
          }
        });
      }
    },
    getLiveBanner: function() {
      var that = this;
      if (that.cmsApiHost && this.nodeIdLive.length > 0) {
        var url = that.cmsApiHost + '/ContentUnion/Site?format=json&Fields=Id,AddDate,Content,ContentNoHtmlTag,ChannelId,Title,SubTitle,ImageUrl&ChannelId=' + this.nodeIdLive;
        http.get(url, function(response) {
          if (response.status < 200) {
            that.showTips(that.netTips);
          }
          if (response.ok && response.data) {
            var results = response.data.Results;
            if (results && results.length > 0) {
              that.liveBanner.splice(0, that.liveBanner.length);
              for (var i = 0; i < results.length; i++) {
                var temp = results[i];
                var item = {};
                if (temp) {
                  if (temp.Id) {
                    item.id = temp.Id;
                  } else {
                    item.id = 0;
                  }
                  if (temp.Title) {
                    item.title = temp.Title;
                  } else {
                    item.title = '';
                  }
                  if (temp.SubTitle) {
                    item.subTitle = temp.SubTitle;
                  }
                  if (temp.ContentNoHtmlTag) {
                    item.content = temp.ContentNoHtmlTag;
                  } else {
                    item.content = "";
                  }
                  if (temp.ImageUrl && temp.ImageUrl.length > 0) {
                    item.banner = temp.ImageUrl.replace('@', that.imageBaseUrl);
                  } else {
                    item.banner = "";
                  }

                  that.liveBanner.push(item);
                }
              }
              // console.log('---- getLiveBanner liveBanner' + JSON.stringify(that.liveBanner));
            }
          }
        });
      }
    },
    getHomeBanner: function() {
      if (utils.isBlankString(this.nodeIdBanner)) {
        console.log("channel nodeIdBanner undefined");
        return;
      }
      let url = this.cmsApiHost + '/Content/Site?format=json&OrderByDesc=Taxis&channelId=' + this.nodeIdBanner;
      let that = this;
      http.get(url, function(response) {
        if (response.data && response.data.Results && response.data.Results.length > 0) {
          that.banners.splice(0, that.banners.length);
          for (var i = 0; i < response.data.Results.length; i++) {
            that.banners.push({
              title: response.data.Results[i].Title,
              image: response.data.Results[i].appImageUrl.replace('@', that.imageBaseUrl),
              link: response.data.Results[i].LinkUrl
            })
          }
        }
      })
    },
    getLecturer: function() {
      var that = this;
      if (that.cmsApiHost && this.nodeIdTecher.length > 0) {
        var url = that.cmsApiHost + '/ContentUnion/Site?ChannelIds=' + this.nodeIdTecher + '&format=json&OrderByDesc=analystDataWeekProfit';

        http.get(url, function(response) {
          if (response.status < 200) {
            that.showTips(that.netTips);
          }
          if (response.ok && response.data) {
            var results = response.data.Results;
            if (results && results.length > 0) {
              that.lecturer.splice(0, that.lecturer.length);
              for (var i = 0; i < results.length; i++) {
                var temp = results[i];
                if (temp) {
                  var item = {
                    id: '',
                    title: '',
                    subTitle: '',
                    amount: '',
                    icon: ''
                  };
                  if (temp.Id) {
                    item.id = temp.Id;
                  }
                  if (temp.Title) {
                    item.name = temp.Title;
                    item.teacher = temp.Title;
                  }
                  if (temp.SubTitle) {
                    item.subTitle = temp.SubTitle;
                  }
                  if (undefined != temp.analystDataWeekProfit) {
                    item.amount = temp.analystDataWeekProfit;
                  }
                  if (temp.Tags) {
                    item.tags = temp.Tags;
                  }
                  if (temp.Summary) {
                    item.summary = temp.Summary;
                  }

                  if (temp.apphometeacher && temp.apphometeacher.length > 0) {
                    item.icon = temp.apphometeacher.replace('@', that.imageBaseUrl);
                  }

                  if (temp.appHomeTeacher && temp.appHomeTeacher.length > 0) {
                    item.icon = temp.appHomeTeacher.replace('@', that.imageBaseUrl);
                  }

                  if (temp.appteacherbanner && temp.appteacherbanner.length > 0) {
                    item.banner = temp.appteacherbanner.replace('@', that.imageBaseUrl);
                  }

                  if (temp.appTeacherBanner && temp.appTeacherBanner.length > 0) {
                    item.banner = temp.appTeacherBanner.replace('@', that.imageBaseUrl);
                  }

                  if ('1' != temp.activityType && 1 !== temp.activityType) {
                    that.lecturer.push(item);
                  }
                }
              }
            }
          }
        });
      }
    },
    getPromotions: function() {
      let that = this;
      let promotion = this.settings['推广优惠'];
      if (undefined == promotion || utils.isBlankString(promotion.title)) {
        return;
      }
      let url = this.cmsApiHost + '/ContentUnion/Site?format=json&OrderByDesc=AddDate&Take=1&Skip=0&Tags=' + encodeURIComponent(promotion.title);
      http.get(url, function(response) {
        if (response.ok && response.data) {
          var results = response.data.Results;
          if (results && results.length > 0) {

            for (var i = 0; i < results.length; i++) {
              var item = {};
              item.id = results[i].Id
              if (results[i].authorPic) {
                item.icon = results[i].authorPic;
              }

              item.author = results[i].Author;
              item.title = results[i].Title;
              item.content = results[i].ContentNoHtmlTag;
              item.tag = results[i].Tags;
              if (/^http/.test(results[i].LinkUrl)) {
                item.link = results[i].LinkUrl;
              } else {
                item.link = that.contentBaseUrl + results[i].ContentFilePathRule;
              }
              if (results[i].appImageUrl) {
                let images = results[i].appImageUrl.split(',');
                if (images && images.length >= 1) {
                  if (images[0] && images[0].indexOf('@') >= 0) {
                    item.image = images[0].replace('@', that.imageBaseUrl);
                  } else {
                    item.image = images[0];
                  }
                } else {
                  item.image = '';
                }
              }
              item.channelName = '优惠'
              if (results[i].AddDate) {
                item.time = results[i].AddDate;
                item.formatTime = that.showTime(results[i].AddDate);
              } else {
                item.time = '';
              }
              that.promotions.push(item);
            }
          }
        }
      }, 2000);
    },
    getNews: function() {
      var that = this;
      if (that.loading) {
        return;
      }
      if (that.cmsApiHost && this.nodeIdNews.length > 0) {
        that.loading = true;
        var url = that.cmsApiHost + '/ContentUnion/Site?format=json&OrderByDesc=IsTop,AddDate&ChannelIds=' + this.nodeIdNews + "&Take=" + this.newsPageSize + "&Skip=" + (this.newsPageSize * that.newsPageIndex) +
          '&Fields=Id,AddDate,IsTop,ChannelId,authorPic,appImageUrl,Author,Title,Content,ContentNoHtmlTag,LinkUrl,analystDataWeekRate_Union,Tags,ContentFilePathRule';
        http.get(url, function(response) {
          that.logining = false;
          if (response.status < 200) {
            that.showTips(that.netTips);
          }
          if (response.ok && response.data) {
            var results = response.data.Results;
            if (results && results.length > 0) {
              that.updateItems = 0;
              that.news.splice(0, that.news.length);
              for (var i = 0; i < results.length; i++) {
                var temp = results[i];
                var item = {};
                if (temp.Id) {
                  item.id = temp.Id
                } else {
                  item.id = 0;
                }

                item.channelId = temp.ChannelId;
                if (item.channelId == that.commentsId) {
                  item.channelName = '评论'
                } else if (item.channelId == that.strategyId) {
                  item.channelName = '策略'
                } else if (item.channelId == that.newsId) {
                  item.channelName = '资讯'
                } else {
                  item.channelName = ''
                }

                if (temp.authorPic) {
                  item.icon = temp.authorPic;
                } else {
                  item.icon = '';
                }

                if (temp.appImageUrl && temp.appImageUrl.length > 0) {
                  item.image = temp.appImageUrl.replace('@', that.imageBaseUrl);
                } else {
                  item.image = '';
                }
                if (temp.Author) {
                  item.name = temp.Author;
                } else {
                  item.name = '';
                }
                if (temp.AddDate) {
                  item.time = temp.AddDate;
                  item.formatTime = that.showTime(temp.AddDate);
                } else {
                  item.time = '';
                }
                if (temp.Title) {
                  item.title = temp.Title
                } else {
                  item.title = '';
                }
                if (temp.ContentNoHtmlTag) {
                  item.content = temp.ContentNoHtmlTag
                } else {
                  item.content = '';
                }
                if (/^http/.test(temp.LinkUrl)) {
                  item.link = temp.LinkUrl;
                } else if (temp.ContentFilePathRule) {
                  item.link = that.contentBaseUrl + temp.ContentFilePathRule;
                } else {
                  item.link = '';
                }
                if (temp.analystDataWeekRate_Union) {
                  item.rate = temp.analystDataWeekRate_Union;
                }
                if (temp.Tags) {
                  item.tag = temp.Tags.split(',');
                } else {
                  item.tag = [];
                }
                that.news.push(item);
              }
              if (0 == that.newsPageIndex) {
                var id = 0;
                for (var i = 0; i < that.news.length; i++) {
                  if (0 == i) {
                    id = that.news[i].id;
                  }
                  if (that.lastId == that.news[i].id) {
                    id = that.news[i].id;
                    break;
                  }
                  that.updateItems++;
                }
                that.lastId = id;
              } else {
                that.updateItems = 0;
              }
              that.newsPageIndex++;
              if (that.updateItems > 0) {
                that.showTips("本次更新" + that.updateItems + "条数据", that.duration);
              }
            } else {
              that.$refs.homeList.resetLoadmore();
            }
          } else {
            that.$refs.homeList.resetLoadmore();
          }
          that.loading = false;
        })
      }
    },
    loadmore: function() {
      if (this.loading) {
        return;
      }
      this.logEvent('HomePage_load');
      this.getNews();
    },
    scrollStart: function(e) {
      this.start = e.contentOffset.y;
    },
    scrollend: function(e) {
      if (e.contentOffset.y <= -275 && this.height == 275) {
        var that = this;
        let offset = Math.abs(e.contentOffset.y) - 275;
        this.height = 1;
        this.animations(0, function() {
          dom.scrollToElement(that.$refs.table, {
            offset: offset,
            animated: 'false'
          });
        });
      }
      if (e.contentOffset.y == 0) {
        this.hideBangs();
      }
    },
    onScroll: function(e) {
      if (e.contentOffset.y >= 220 && this.refreshing == false && this.height < 100) {
        this.longPull = true;
      }
      if (e.contentOffset.y >= 0 && this.start <= 0) {
        this.hideBangs();
      }

      this.start = e.contentOffset.y;
    },
    refresh: function(e) {
      var that = this;
      if (true == this.longPull) {
        this.height = 275;
        this.animations(100, function() {
          that.longPull = false;
          that.refreshing = false;
          that.pullingdown = false;
        });
        this.logEvent('HomePage_longpull');
        return;
      }
      if (false == that.loading) {
        that.refreshing = true;
        setTimeout(() => {
          that.refreshing = false;
          that.pullingdown = false;
        }, 500)

        setTimeout(() => {
          that.logEvent('HomePage_pull');
          that.newsPageIndex = 0;
          // that.getNoCourse(); //获取无课程提示信息
          that.getLessons(); //获取课程信息
          that.getLecturer(); //获取老师信息
          that.getLiveBanner();
          that.getHomeBanner();
          that.getNews();
          that.getTags();
        }, 1000)
      }
    },
    formatTime: function(second, type = 0) {
      if (0 == type) {
        return [parseInt(second / 3600), parseInt(second / 60 % 60), parseInt(second % 60)].join(":").replace(/\b(\d)\b/g, "0$1");
      } else {
        return [parseInt(second / 3600), parseInt(second / 60 % 60)].join(":").replace(/\b(\d)\b/g, "0$1");
      }

    },
    highLightCourse: function(index) {
      if (this.courseIndex == index || index >= this.course.length) {
        return;
      }

      this.courseIndex = index;
    },
    showLiveView: function() {
      const Steve = new BroadcastChannel('showView');
      Steve.postMessage('live')
    },
    liveClick: function() {
      this.logEvent('HomePage_LIVE');
      this.showLiveView();
    },
    showCourse: function() {
      navigator.push({
        url: bundleUrl + 'course.js',
        animated: "true",
        // swipePop: "true",
      }, event => {})
    },
    showSchedule: function() {
      this.logEvent('NavBar_rest_more');
      this.showCourse();
    },
    showBanner: function(banner, idx = 0) {
      if (idx >= 10) {
        this.logEvent(`HomePage_banner_${idx}`);
      } else if (idx > 0) {
        this.logEvent(`HomePage_banner_0${idx}`);
      }
      var json = {
        'title': banner.title,
        'url': banner.link
      }
      storage.setItem('app-url', JSON.stringify(json));
      navigator.push({
        url: bundleUrl + 'webview.js',
        animated: "true",
      });
    },
    showLiveBanner: function(name) {
      var index = 0;
      if (name && name.length > 0) {
        for (index = 0; index < this.liveBanner.length; index++) {
          if (name == this.liveBanner[index].title) {
            break;
          }
        }
      }
      if (index == this.live.index) {
        return;
      }
      if (index == this.liveBanner.length) {
        index = 0;
      }

      if (index >= 0 && index < this.liveBanner.length) {
        this.live.title = this.liveBanner[index].title;
        this.live.banner = this.liveBanner[index].banner;
        this.live.content = this.liveBanner[index].content;
        this.live.online = this.liveBanner[index].id;
        this.live.index = index;
      }
    },
    showLiveTime: function(id) {
      if (true == this.outofview || id != this.timerId) {
        return;
      }
      let date = new Date();
      let ms = date.getTime();
      this.safeTime.Year = date.getFullYear() - 2013;
      this.safeTime.Hours = date.getHours();
      this.safeTime.Minutes = date.getMinutes();
      let hasTimestamp = ms - currentYear;
      this.safeTime.Days = parseInt(hasTimestamp / 86400000);

      if (this.course.length == 0) {
        this.liveTips = '直播未开始 ';
        this.showLiveBanner("周末无课");
      } else {
        for (var i = 0; i < this.course.length; i++) {
          var course = this.course[i];
          if (ms >= course.endTime) {
            course.active = false;
            if (i == this.course.length - 1) {
              this.liveTips = '直播已结束 ';
              this.showLiveBanner(this.liveTeacher);
            }
            continue;
          }


          var interval = ms - course.startTime;
          if (interval >= 0) {
            course.active = true;
            this.liveTips = '直播中 ' + this.formatTime(interval / 1000);
            this.highLightCourse(i);
            this.showLiveBanner(course.name);
            break;
          } else {
            let second = Math.abs(interval / 1000);
            this.liveTips = '距开始只剩 ' + this.formatTime(second, 0);
            course.active = false;
            if (second <= 3600) {
              this.showLiveBanner(course.name);
            } else {
              this.showLiveBanner(this.liveTeacher);
            }
            break;
          }
        }
      }

      if (false == this.outofview && id == this.timerId) {
        var self = this;
        setTimeout(function() {
          self.showLiveTime(id);
        }, 1000);
      }
    },
    onCourseClick: function(index) {
      this.height = 1;
      this.animations(1000);
      if (index == this.courseIndex) {
        this.logEvent('NavBar_OnLive');
        this.showLiveView();
      } else {
        this.logEvent('NavBar_schedule');
        this.showCourse();
      }
    },
    onLecturerClick: function(item, type) {
      if (type == 'gold') {
        if (item.teacher == '赵老师') {
          this.logEvent('ranking_page_01');
        } else if (item.teacher == '阳光老师') {
          this.logEvent('ranking_page_02');
        } else if (item.teacher == '晴天老师') {
          this.logEvent('ranking_page_03');
        } else if (item.teacher == '飞扬老师') {
          this.logEvent('ranking_page_04');
        } else if (item.teacher == '彭老师') {
          this.logEvent('ranking_page_05');
        } else if (item.teacher == '天元老师') {
          this.logEvent('ranking_page_06');
        } else if (item.teacher == '金缠老师') {
          this.logEvent('ranking_page_07');
        } else if (item.teacher == '鸿文老师') {
          this.logEvent('ranking_page_08');
        } else if (item.teacher == '量子老师') {
          this.logEvent('ranking_page_09');
        } else if (item.teacher == '龙玥老师') {
          this.logEvent('ranking_page_10');
        } else if (item.teacher == '筱曼老师') {
          this.logEvent('ranking_page_11');
        } else if (item.teacher == '马老师') {
          this.logEvent('ranking_page_12');
        } else if (item.teacher == '青锋老师') {
          this.logEvent('ranking_page_13');
        }
      }
      this.height = 1;
      this.animations(1000);
      if (item.active) {
        this.showLiveView();
        this.logEvent('NavBar_OnLive');
        return;
      }

      if (utils.isBlankString(item.teacher)) {
        return;
      }

      if (TYPE_LESSION_TEACHERS == item.type) {
        this.showRankList();
      } else {
        storage.setItem('lecturer', JSON.stringify({
          name: item.teacher,
          channelId: this.nodeIdTecher
        }));
        navigator.push({
          url: bundleUrl + 'lecturer.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    onNewsClick: function(item) {
      if (utils.isBlankString(item.link) || utils.isBlankString(this.contentBaseUrl)) {
        return;
      }
        var data = {
          title: '',
          url: item.link,
          type: 'news'
        }

        if (item.channelName == '评论') {
          data.title = '汇商股指评论'
        } else if (item.channelName == '策略') {
          data.title = '讲师直播策略'
        } else if (item.channelName == '资讯') {
          data.title = '最新公告'
        }

        this.logEvent('HomePage_headline_article');
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
    },
    newsHeadClick: function(item) {
      if (undefined == this.commentsId || this.commentsId.length <= 0 || item.channelId != this.commentsId) {
        return;
      }
      this.logEvent('HomePage_headline_author');
      this.onLecturerClick(item, 'head');
    },
    showRankList: function() {
      this.logEvent('HomePage_teacher_more');
      navigator.push({
        url: bundleUrl + 'ranklist.js',
        animated: "true",
        swipePop: "true",
      }, event => {})
    },
    showTopic: function(topic) {
      if (this.tags == undefined || this.tags.length <= 0) {
        return;
      }
      let id = 0;
      let title = topic.replace(/^#|#$/g, '');
      for (var i = 0; i < this.tags.length; i++) {

        if (title == this.tags[i].Title) {
          id = this.tags[i].Id;
          break;
        }
      }

      if (id <= 0) {
        return;
      }
      this.logEvent('HomePage_headline_Tag');
      if (id > 0 || id.length > 0) {
        storage.setItem('tags', JSON.stringify({
          'title': title,
          'id': id
        }));
        navigator.push({
          url: bundleUrl + 'topic.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    animations: function(duration, callback) {
      var that = this;
      animations.transition(this.$refs.table, {
        styles: {
          width: 750,
          height: this.height,
        },
        duration: duration, //ms
        timingFunction: 'linear',
        needLayout: true,
      }, function() {
        that.rotate();
        if (callback) {
          callback();
        }
      });
    },
    rotate: function() {
      this.deg = this.deg + 180;
      animations.transition(this.$refs.arrowIcon, {
        styles: {
          transform: 'rotate(' + this.deg + 'deg)',
          transformOrigin: 'center center',
        },
        duration: 200, //ms
        timingFunction: 'linear',
        needLayout: true
      }, function() {});
      if (this.deg >= 1080) {
        this.deg = 0;
      }
    },
    touch: function(e) {
      this.logEvent('HomePage_NavBar');
      if (false == this.bangsShow) {
        if (1 == this.height) {
          this.height = 275;
        } else {
          this.height = 1;
        }
        this.animations(150);
      } else {
        this.scrollTop(false);
      }
    },
    showTips: function(tips, time = 2000) {
      if (false == this.showToast) {
        this.showToast = true;
        this.tips = tips;
        setTimeout(() => {
          this.showToast = false;
          // this.tips = '';
        }, time)
      }
    },
    getTags: function() {
      var that = this;
      if ('' === this.cmsApiHost || this.cmsApiHost.length <= 5) {
        return
      }
      var url = this.cmsApiHost + '/ContentUnion/Site?format=json&OrderByDesc=LastUpdate&ChannelIds=' + that.tagsId;
      http.get(url, function(response) {
        if (response.ok && response.data) {
          var results = response.data.Results;
          if (results && results.length > 0) {
            storage.setItem("topic", JSON.stringify(results));
            that.tags = results;
          } else {
            storage.setItem("topic", '[]');
          }
        }
      })
    },
    scrollTop: function(animated = true) {
      dom.scrollToElement(this.$refs.table, {
        offset: 0,
        animated: true
      });
    },
    showNotice: function() {
      let newItem = this.settings['最新公告'];
      if (newItem) {
        storage.setItem('tags', JSON.stringify(newItem));
        navigator.push({
          url: bundleUrl + 'topic.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    openAccount: function() {
      this.logEvent('HomePage_register');
      var data = {
        from: 'home',
        openName: 'HomePage_sign',
      }
      storage.setItem('user-original-openAccount', JSON.stringify(data));
      storage.setItem('user_openaccount_from', 'index');
      navigator.push({
        url: bundleUrl + 'openAccount.js', //survey  openAccount userLogin  authentication
        animated: "true",
        swipePop: "true",
      }, event => {})
    },
    service: function() {
      this.logEvent('HomePage_service');
      if (this.feedback && this.feedback.length > 4) {
        var data = {
          title: '客服',
          fontSize: 0,
          // url: utils.appendURLParams(this.feedback,this.utm)
          url: this.feedback
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    onSocketOpen: function(e) {
      this.sendWebSocketStr();
    },
    onmessage: function(e) {
      if (false == this.outofview && !utils.isBlankString(e.data)) {
        var quote = JSON.parse(e.data);
        if (quote) {
          this.updateQuote(quote);
        }
      }
      // console.log("weex: onmessage:"+JSON.stringify(e));
    },
    onerror: function(e) {
      var that = this;
      if (true == that.outofview || e.data == "closed") {
        return;
      }
      let id = that.timerId;
      if (0 == that.connecting) {
        that.connecting = 1;
        setTimeout(() => {
          that.connecting = 0;
          that.connectWebSocket(id)
        }, 10000);
      }
    },
    setupWebsocket: function() {
      var that = this;
      websocket.onopen(this.onSocketOpen);
      websocket.onmessage(this.onmessage);
      websocket.onerror(this.onerror);
    },
    connectWebSocket: function(id = 0) {
      if (true == this.outofview || id != this.timerId) {
        return;
      }
      websocket.WebSocket(this.quotesSocket, '');
    },
    sendWebSocketStr: function() {
      websocket.send("Symbols " + this.symbols);
    },
    sortQuote: function(a, b) {
      var value1 = Math.abs(a.change);
      var value2 = Math.abs(b.change);
      if (value1 > value2) {
        return -1;
      } else if (value1 < value2) {
        return 1;
      }
      return 0;
    },
    updateQuote: function(quote) {
      // var quote = JSON.parse(data);
      if (undefined == quote) {
        return;
      }
      if (this.quoteName.indexOf(quote.Symbol) >= 0) {
        for (var index = 0; index < this.quotes.length; index++) {
          if (quote.Symbol == this.quotes[index].Symbol) {
            quote.symbolName = this.symbolName[quote.Symbol].symbolName
            quote.fixed = this.symbolName[quote.Symbol].fixed
            quote.change = utils.calculationchange(parseFloat(quote.Bid), parseFloat(quote.Open), 2);
            this.quotes.splice(index, 1, quote);
            break;
          }
        }
      } else if (this.quotes.length < 3) {
        quote.symbolName = this.symbolName[quote.Symbol].symbolName
        quote.fixed = this.symbolName[quote.Symbol].fixed
        quote.change = utils.calculationchange(parseFloat(quote.Bid), parseFloat(quote.Open), 2);
        this.quotes.push(quote);
        this.quotes.sort(this.sortQuote);
        this.quoteName = quote.Symbol + ',' + this.quoteName;
      } else {
        for (var index = 0; index < this.quotes.length; index++) {
          var dv = this.sortQuote(quote, this.quotes[index])
          if (dv < 0) {
            quote.symbolName = this.symbolName[quote.Symbol].symbolName
            quote.fixed = this.symbolName[quote.Symbol].fixed
            quote.change = utils.calculationchange(parseFloat(quote.Bid), parseFloat(quote.Open), 2);
            this.quotes.splice(index, 0, quote);
            break;
          }
        }
        if (this.quotes.length > 3) {
          this.quotes.splice(3, 1);
        }
      }
      this.quoteName = ''
      for (let i = 0; i < this.quotes.length; i++) {
        this.quoteName = this.quoteName + ',' + this.quotes[i].Symbol
      }
    },
    getLastQuotes: function() {
      var that = this;
      var url = that.cmsApiHost + "/Quotes/Last?SymbolNames=" + this.symbols.replace(/\s/g, ',');
      http.get(encodeURI(url), function(response) {
        if (response.ok && response.data && response.data.length > 0) {
          for (var i = 0; i < response.data.length; i++) {
            if (utils.isBlankString(response.data[i].SymbolName)) {
              continue;
            }
            let quote = {
              Ask: response.data[i].Ask,
              Bid: response.data[i].Bid,
              High: response.data[i].High,
              Low: response.data[i].Low,
              Open: response.data[i].Open,
              YClose: response.data[i].YClose,
              Buy: response.data[i].Buy,
              Sell: response.data[i].Sell,
              symbol: response.data[i].SymbolName,
              "Symbol": response.data[i].SymbolName,
              symbolName: that.symbolName[response.data[i].SymbolName].SymbolName
            }

            that.updateQuote(quote);
            if (that.quotes.length > 0) {
              storage.setItem('homeQuote', JSON.stringify(that.quotes));
            }
          }
        } else {
          if (that.quotes.length < 3) {
            let homeQuote = storage.getItemSync('homeQuote');
            if (utils.isBlankString(homeQuote)) {
              return;
            }
            let homeQuotes = JSON.parse(homeQuote);
            for (var i = 0; i < homeQuotes.length; i++) {
              that.updateQuote(homeQuotes[i]);
            }
          }
        }
      });
    },
    showQuote: function(quote, index) {
      if (undefined == quote) {
        this.logEvent('HomePage_currency_more');
        const Steve = new BroadcastChannel('showView');
        Steve.postMessage('quote')
      } else {
        if (index == 0) {
          this.logEvent('HomePage_currency_01');
        } else if (index == 1) {
          this.logEvent('HomePage_currency_02');
        } else if (index == 2) {
          this.logEvent('HomePage_currency_03');
        }
        storage.setItem('topproductdata', JSON.stringify(quote));
        navigator.push({
          url: bundleUrl + 'quote.js',
          animated: "false",
        }, event => {

        })
      }
    },
    fastdeposit: function() {
      this.logEvent('HomePage_deposit');
      if (this.deposit && this.deposit.length > 0) {
        var data = {
          title: '账户注资',
          url: utils.appendURLParams(this.deposit,this.utm) ,
          source: 'fastdeposit',
          from: 'fastdeposit'
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'memberCenter.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    }
  }
}
</script>

<style scoped>
.wrap {
  overflow: hidden;
}

.screenWidth {
  width: 750px;
}

.flexRow {
  flex-direction: row;
}

.test {
  border-color: red;
  border-width: 1px;
}

.alignCenter {
  align-items: center;
}

.center {
  justify-content: center;
  align-items: center;
}

.marginLeft {
  margin-left: 30px;
}

.marginTop {
  margin-top: 20px;
}

.marginRight {
  margin-right: 8px;
}

.marginBottom {
  margin-bottom: 30px;
}

.navibar {
  height: 88px;
  background-color: #FFFFFF;
  align-items: center;
  justify-content: center;
}

.title {
  font-size: 30px;
  line-height: 60px;
  text-align: center;
  color: #333333;
}

.timetable {
  width: 750px;
  height: 1px;
}

.time-image {
  width: 750px;
  height: 275px;
}

.live {
  width: 626px;
  height: 266px;
}

.scroller {
  position: absolute;
  top: 0px;
  left: 0px;
  right: 0px;
  height: 275px;
  flex-direction: row;
  /* background-color: rgba(0, 0, 0, 0); */
}

.item {
  width: 365px;
  height: 275px;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.time {
  width: 365px;
  font-size: 30px;
  lines: 1;
  text-align: center;
  flex: 1;
  text-overflow: ellipsis;
}

.course {
  font-size: 30px;
  lines: 1;
  text-overflow: clip;
  margin-left: 12px;
  text-align: left;
  flex: 1;
  text-overflow: ellipsis;
  background-color: red;
}

.teacher {
  width: 192px;
  height: 142px;
  justify-content: center;
  overflow: hidden;
}

.tname {
  position: absolute;
  /* top: 24px; */
  right: 18px;
  width: 24px;
  font-size: 22px;
  text-align: right;
  text-overflow: ellipsis;
}

.newImage {
  margin-top: 32px;
  margin-left: 44px;
  width: 240px;
  height: 140px;
  border-radius: 4px;
}

.textcolor1 {
  color: #2e74e9;
}

.textcolor2 {
  color: #9ba1ab;
}

.live-info {
  position: absolute;
  top: 38px;
  left: 24px;
  right: 24px;
  border-radius: 14px;
}

.live-info-bottom {
  position: absolute;
  left: 0px;
  right: 0px;
  bottom: 0px;
  height: 70px;
  background-color: rgba(0, 30, 79, 0.5);
  /* padding-left: 10px;
  padding-right: 10px; */
  /* border-bottom-left-radius: 14px;
  border-bottom-right-radius: 14px; */
}

.live-online {
  width: 34px;
  height: 30px;
}

.online-text {
  font-size: 26px;
  line-height: 40px;
  color: #FFFFFF;
  text-align: center;
  margin-left: 20px;
}

.bangs {
  position: absolute;
  top: 0px;
  left: 0px;
  right: 0px;
}

.bangs-size {
  width: 750px;
  height: 62px;
  background-color: rgba(255, 255, 0255, 0);
}

.bangs-time {
  position: absolute;
  top: 0px;
  left: 0px;
  right: 0px;
  bottom: 0px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 0255, 0);
}

.arrow {
  width: 18px;
  height: 12px;
  margin-left: 10px;
  margin-right: 10px;
}

.buttons {
  width: 750px;
  border-top-color: #F1F1F1;
  border-top-width: 20px;
  border-top-style: solid;
  background-color: #FFFFFF;
}

.lecturer {
  width: 750px;
  height: 470px;
  border-top-color: #F1F1F1;
  border-top-width: 20px;
  border-top-style: solid;
  background-color: #FFFFFF;
}

.lecturer-head {
  width: 750px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
}

.lecturer-icon-left {
  transform: 'rotate(180deg)';
  width: 76px;
  height: 14px;
}

.lecturer-icon {
  width: 76px;
  height: 14px;
}

.lecturer-title {
  font-size: 32px;
  line-height: 48px;
  margin-left: 18px;
  margin-right: 18px;
  color: #242424;
}

.lecturer-scroller {
  flex-direction: row;
  padding-left: 35px;
}

.lecturer-item {
  background-color: #ffffff;
  width: 230px;
  height: 330px;
  align-items: center;
  margin-right: 20px;
  border-radius: 10px;
  overflow: hidden;
}

.lecturer-padding {
  margin-top: 36px;
}

.lecturer-margin {
  margin-top: 32px;
}

.lecturer-item-name {
  margin-top: 14px;
  font-size: 24px;
  line-height: 36px;
  color: #333333;
  text-align: center;
}

.lecturer-item-title {
  font-size: 20px;
  line-height: 30px;
  color: #999999;
  text-align: center;
  text-overflow: ellipsis;
}

.lecturer-item-rate {
  font-size: 24px;
  color: #9ba1ab;
  height: 28px;
  /* text-align: center; */
}

.lecturer-item-symbol {
  font-size: 24px;
  color: #9ba1ab;
  /* text-align: center; */
}

.lecturer-item-number {
  padding-top: 10px;
  font-size: 28px;
  color: #e9302e;
  font-family: GEO415M;
}

.news {
  width: 750px;
  padding-top: 38px;
  border-top-color: #F1F1F1;
  border-top-width: 20px;
  border-top-style: solid;
  background-color: #FFFFFF;
}

.news-item {
  width: 750px;
  padding-top: 38px;
  padding-bottom: 40px;
  border-bottom-width: 1px;
  border-bottom-color: #F1F1F1;
  border-bottom-style: solid;
}

.background0 {
  background-color: #ffffff;
}

.background1 {
  background-color: #fcfcfc;
}

.news-item-head {
  width: 750px;
  /* height: 40px; */
  padding-left: 20px;
  padding-right: 20px;
  flex-direction: row;
  align-items: center;
}

.news-head-icon {
  width: 50px;
  height: 50px;
}

.news-head-font1-black {
  font-size: 28px;
  line-height: 42px;
  lines: 1;
  color: #242424;
  width: auto;
  text-align: center;
  margin-left: 20px;
  /* height: 28px; */
  /* margin-right: 8px; */
}

.news-head-font1 {
  font-size: 28px;
  line-height: 42px;
  lines: 1;
  color: #c4c7d0;
  width: auto;
  text-align: center;
  margin-left: 20px;
  /* height: 28px; */
  /* margin-right: 8px; */
}

.news-head-font2 {
  font-size: 32px;
  lines: 1;
  font-family: GEO415M;
  color: #e9302e;
  width: auto;
  /* height: 34px; */
}

.news-item-content {
  width: 750px;
  /* height: 160px; */
  flex-direction: row;
  padding-left: 20px;
  padding-right: 20px;
  margin-top: 22px;
}

.news-content-font1 {
  font-size: 32px;
  color: #242424;
  width: auto;
  line-height: 64px;
  lines: 1;
  text-overflow: ellipsis;
}

.news-content-font11 {
  font-size: 32px;
  color: #242424;
  width: auto;
  line-height: 64px;
  lines: 2;
  text-overflow: ellipsis;
}

.wifiplay {
  height: 114px;
  width: 114px;
}

.news-content-font2 {
  font-size: 28px;
  color: #abafbc;
  width: auto;
  line-height: 45px;
  height: 90px;
  text-overflow: ellipsis;
  lines: 2;
}

.news-content-font3 {
  font-size: 28px;
  color: #2e74e9;
  width: auto;
  /* height: 45px; */
  line-height: 42px;
  margin-right: 15px;
  text-overflow: ellipsis;
  lines: 1;
  /* margin-bottom: 0;
        bottom: 0; */
}

.news-content-picture {
  width: 284px;
  height: 182px;
}

.refresh {
  width: 750px;
  height: 60px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 0);
}

.indicator-text {
  color: #888888;
  font-size: 30px;
  margin-left: 8px;
  text-align: center;
}

.indicator {
  height: 50px;
  width: 50px;
  color: gray;
}

.modul {
  height: 74px;
  border-radius: 37px;
  align-items: center;
  justify-content: center;
  padding-left: 60px;
  padding-right: 60px;
  background-color: rgba(0, 0, 0, 0.7);
}

.toast {
  position: absolute;
  left: 0px;
  right: 0px;
  align-items: center;
  justify-content: center;
  transition-property: bottom, opacity;
  transition-timing-function: linear;
}

.toast-show {
  opacity: 1;
  bottom: 60px;
  transition-duration: 0.3s;
}

.toast-hide {
  opacity: 0;
  bottom: -74px;
  transition-duration: 0.1s;
}

.navbar-button-l {
  position: absolute;
  top: 0px;
  left: 30px;
  bottom: 0px;
  width: 120px;
  justify-content: center;
  align-items: flex-start;
}

.navbar-button-r {
  position: absolute;
  top: 0px;
  right: 30px;
  bottom: 0px;
  width: 120px;
  justify-content: center;
  align-items: flex-end;
}

.board {
  width: 750px;
  border-top-color: #F1F1F1;
  border-top-width: 20px;
  border-top-style: solid;
}

.boardText {
  font-size: 30px;
  line-height: 36px;
  font-weight: bold;
  text-align: center;
  color: #2E74E9;
  margin-left: 10px;
  margin-right: 10px;
}

.boardTime {
  font-size: 30px;
  line-height: 36px;
  color: #999999;
  text-align: center;
}

.banner-indicator{
  height: 10px;
  item-color: #CCCCCC;
  item-selected-color: #2E74E9;
  item-size: 10px;
  position: absolute;
  bottom: 20px;
  left: 0px;
  right: 0px;
}

.board-indicator {
  height: 10px;
  position: absolute;
  bottom: 45px;
  left: 0px;
  right: 0px;
  item-color: #CCCCCC;
  item-selected-color: #2E74E9;
  item-size: 10px;
}

.radius {
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
}

.flag {
  border-left-color: #2E74E9;
  border-left-width: 4px;
  border-left-style: solid;
}

.bold {
  font-weight: bold;
}

.quote {
  width: 238px;
  height: 252px;
  align-items: center;
  overflow: hidden;
  border-radius: 10px;
}

.riseColor {
  color: #24B267;
}

.downColor {
  color: #F04341;
}

.borderline {
  border-top-color: #EEEEEE;
  border-top-width: 2px;
  border-top-style: solid;
}

.leftline {
  border-left-color: #EEEEEE;
  border-left-width: 2px;
  border-left-style: solid;
}

.promotions {
  background-color: rgba(241, 67, 66, 0.1);
  color: #F14342;
}

.comments {
  background-color: rgba(46, 116, 233, 0.1);
  color: #2E74E9;
}

.group-head {
  width: 750px;
  flex-direction: row;
  align-items: center;
  border-left-color: #2E74E9;
  border-left-width: 4px;
}

.group-title {
  font-size: 36px;
  line-height: 40px;
  padding-left: 28px;
  padding-right: 28px;
  color: #242424;
}

.newsTime{
  font-size:24px;
  line-height:30px;
  text-align:center;
  width:110px;
  height:30px;
    color:#999999;
  background-color:#EEEEEE;
  border-radius:15px;
}
</style>
