<template >
<div @viewappear="viewAppear">
  <status backgroundColor="white"></status>
  <div class="navbar-bg">
    <text class="navbar-titleText"> {{title}} </text>
    <div @click="goBack" class="goback">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back2.png'"></image>
    </div>
  </div>

  <div class="loginway-view">
		<div :class="['loginway-account', loginWay == 0 ? 'select' : '']"  @click="tapLoginWay(0)">
			<text :class="[loginWay == 0 ? 'text-red':'text-gray']">手机号登录</text>
		</div>
		<div :class="['loginway-phone', loginWay == 1 ? 'select' : '']"  @click="tapLoginWay(1)">
			<text :class="[loginWay == 1 ? 'text-red':'text-gray']">动态码登录</text>
  	</div>
  </div>

  <div class="account1-bg flexH" style="justify-content: center;background-color: white;">
    <div class="select-id-areacode flexH" v-on:click="onclickphoneareacode()">
      <text class="font24" style="margin-left: 20px; color: #9BA1AB;">{{memberPhoneAreaCode}}</text>
      <div class="input-down-select">
        <image style="width:16px;height:8px" :src="assets+'auth/selectdown.png'"></image>
      </div>
    </div>
    <div class="input-view">
      <input ref="phoneNum" class="input-size" allowCopyPaste="true" type="number" :value="memberPhoneNumber" placeholder="请填写您的手机号码" :maxlength="phoneNumberLength" @input="inputphonenumber" @change="onchangememberphonenumber"></input>
    </div>
  </div>
  <div class="pwd-bg flexH" v-if="loginWay == 1">
    <input  class="input-size" allowCopyPaste="false" type="number" maxlength="6" :value="memberIDcode" placeholder="填写您收到的短信验证码" @change="onchangememberIDcode" @input="inputIDcode"></input>
    <div class="input-down-select" v-on:click="onclickphoneIDcode()">
      <text :class="[isTimeDownTick?'send-code-text-gray':'send-code-text-red']">{{getIDcode}}</text>
    </div>
  </div>
  <div class="pwd-bg" v-if="loginWay == 0">
    <input ref="password" class="input-size" allowCopyPaste="false" type="password" maxlength="20" :value="memberPassword" placeholder="密码" @input="inputPwd" @change="onchangememberpwd"></input>
  </div>

	<!-- <div v-if="loginWay == 1">
		<div class="account1-bg flexH" style="justify-content: center;background-color: white;">
		  <div class="select-id-areacode flexH" v-on:click="onclickphoneareacode()">
		    <text class="font24" style="margin-left: 20px; color: #9BA1AB;">{{memberPhoneAreaCode}}</text>
		    <div class="input-down-select">
		      <image style="width:16px;height:8px" :src="assets+'auth/selectdown.png'"></image>
		    </div>
		  </div>
			<div class="input-view">
				<input ref="phoneNum" class="input-size" allowCopyPaste="true" type="number" :value="memberPhoneNumber" :maxlength="phoneNumberLength" @input="inputphonenumber" @change="onchangememberphonenumber"></input>
			</div>
		</div>
		<div class="pwd-bg flexH">
		  <input  class="input-size" allowCopyPaste="false" type="number" maxlength="6" :value="memberIDcode" placeholder="短信验证码" @change="onchangememberIDcode" @input="inputIDcode"></input>
			<div class="input-down-select" v-on:click="onclickphoneIDcode()">
			  <text :class="[isTimeDownTick?'send-code-text-gray':'send-code-text-red']">{{getIDcode}}</text>
			</div>
		</div>
	</div> -->

	<!-- <div v-if="loginWay == 0">
		<div class="account-bg flexH" style="background-color: white;">
		  <input  class="input-size" allowCopyPaste="true" type="text" maxlength="20" :value="memberCode" placeholder="手机号/会员账号" @input="inputmembercode" @change="onchangemembercode"></input>
			<div class="input-down-select">
			  <image style="width: 40px;height: 40px;" :src="assets+'auth/user.png'"></image>
			</div>
		</div>
		<div class="pwd-bg">
		  <input ref="password" class="input-size" allowCopyPaste="false" type="password" maxlength="20" :value="memberPassword" placeholder="密码" @input="inputPwd" @change="onchangememberpwd"></input>
		</div>
	</div> -->

  <div :class="[isLoginBtnClick?'button-login-gray':'button-login']" @click="login">
    <text class="font32 text">登录</text>
  </div>
  <div class="flexH" style="justify-content: center;align-items: center;margin-top:38px;">
    <div class="button-register" @click="register">
      <text class="font28 text-red">用户注册</text>
    </div>
    <div style="background-color:#c7cfdb;width:1px;height:44px"></div>
    <div class="button-find" @click="findPassword">
      <text class="font28 text-gray">忘记密码</text>
    </div>
  </div>
  <div v-if="isShowAlert" class="alert-show">
    <div class="alert-modul">
      <text style="color:#FFFFFF;font-size:28px;"> {{alertTips}} </text>
    </div>
  </div>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var storage = require('../include/storage.js');
const app = weex.requireModule('app');
var utils = require('../include/utils.js');
var firebase = weex.requireModule('firebase');
var http = require('../include/http.js');

var appbasedata = require('../survey.json');
const picker = weex.requireModule('picker');
const jwt = require('jsonwebtoken');
import {ClientID,LiveClientID} from '../include/url.js';
module.exports = {
  components: {
    'status': require('../components/statusbar.vue'),
  },
  data:function(){
    return{
      title:"登录皇御环球金融",
      assets:assetsUrl,
      oauth:'',//单点地址
      bibApi:'',//网络请求基地址
      forgetPwd:'',//忘记密码url
      memberCenterUrl: '', //用户中心地址
      utm:'',
      memberPassword:'',				// 用户密码
      isShowAlert: false,
      alertTips: '',//弹窗提示语
      isLoginBtnClick: false,//是否点击登录按钮
      fromLogin:'',//从哪里进入登录页面
      loginWay: 0,	// 0 表示账户登录 	1 表示手机登录
      areaCodes:[],//手机号码区号名称数组
      memberPhoneAreaCode: '中国大陆(+86)',//区号名称
      memberPhoneAreaCodeIndex: 0,//区号数组的下标
			phoneNumberPlaceholder:'填写您的手机号码',
			phoneNumberLength:11,//手机号码的位数
			phoneNumberValue:'',	// 手机号码
			memberPhoneNumber: '',

			memberCode: '',
      selectAreaCode :'',
			phoneCodeKey:'',//发送验证码的固定key
			getIDcode: '发送验证码',
			idCodeTimeTick:0,//验证码倒计时时长
			isTimeDownTick:false,
			memberIDcode: '',//用户输入的手机验证码
			comeform: ''
    }
  },
  created: function() {
    var that = this;
    this.comeform = utils.getQueryString(weex.config.bundleUrl,'comeform');
    this.channelName = app.channelName();
    if (this.channelName) {
      this.utm = "?ComeFrom=GlobalApps&utm_source=APP&utm_campaign=&utm_content=&utm_term=&utm_medium=" + this.channelName;
    }
    if (weex.supports('@module/app')) {
      app.setStatusBarStyle(0);
    }
    storage.getItem('memberCenter', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var memberCenter = JSON.parse(value);
      if (memberCenter) {
        that.oauth = memberCenter.oauth;
        that.forgetPwd = memberCenter.forgetPwd;
        that.memberCenterUrl = memberCenter.memberCenterUrl;

      }
    });
    storage.getItem('commonUrl',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.bibApi = commonUrl.cmsApi;
      }
    });
	for (var i = 0; i < appbasedata.phoneAreaCode.length; i++) {
	  that.areaCodes.push(appbasedata.phoneAreaCode[i].name);//电话区号名称数组
	}
  },
  methods:{
    //埋点追踪方法(在input事件里面执行)
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    goBack:function(){
      navigator.pop({
        animated: "true"
      }, event => {

      });
    },
    viewAppear: function(e) {
      if (weex.supports('@module/app')) {
        weex.requireModule('app').setStatusBarStyle(0);
      }
    },
    //弹窗事件
    showAlertTips: function(tips, time = 2000) {
      if (false == this.isShowAlert) {
        this.isShowAlert = true;
        this.alertTips = tips;
        setTimeout(() => {
          this.isShowAlert = false;
          // this.tips = '';
        }, time)
      }
    },
		inputmembercode:function(event){
		  // this.logEvent('input_member_account');
			let that = this;
			that.memberCode = event.value;
		},
		onchangemembercode:function(event){
		  var that = this;
		  // 账号登录  只能是 数字字母 6~20 位
			if (false == utils.checkAccount(that.memberCode)) {
			  that.showAlertTips('请填写正确的会员账号');
			  return;
			}
		},

    inputPwd:function(event){
			let that = this;
			this.memberPassword = event.value;
    },
		onchangememberpwd:function(event){
			let that = this;
		  // 密码登录  只能是 数字字母 6~20 位
			if (false == utils.checkPwd(that.memberPassword)) {
			  that.showAlertTips('请填写正确的密码');
			  return;
			}
		},


    login:function(){
      var that = this;
      if (that.isLoginBtnClick) {
        return;
      }
	    if (that.loginWay == 0){

				// if (!that.memberCode) {
				//   that.showAlertTips('请填写会员账号');
				// 	return;
				// }
				// if (false == utils.checkAccount(that.memberCode)) {
				//   that.showAlertTips('请填写正确的会员账号');
				//   return;
				// }
        if (!that.phoneNumberValue){
					that.showAlertTips('请填写正确的手机号码');
					return;
				}

				if (!that.memberPassword) {
				  that.showAlertTips('请填写密码');
					return
				}
				if (false == utils.checkPwd(that.memberPassword)) {
				  that.showAlertTips('请填写正确的密码');
				  return;
				}
			}else{
				if (!that.phoneNumberValue){
					that.showAlertTips('请填写正确的手机号码');
					return;
				}
        let vcode = /^[0-9]{6}$/.test(that.memberIDcode);
				if (false == vcode){
					that.showAlertTips('请填写6位验证码');
					return;
				}
			}

      that.isLoginBtnClick = true;
      var loginApi = that.oauth+'/account/token';
			let loginBody = '';
      for (var i = 0; i < appbasedata.phoneAreaCode.length; i++) {
        if (appbasedata.phoneAreaCode[i].name === this.memberPhoneAreaCode) {
          that.selectAreaCode = appbasedata.phoneAreaCode[i].code;
        }
      }
			if(that.loginWay == 0){
				loginBody = "username="+that.phoneNumberValue+"&password="+that.memberPassword+'&PhoneArea='+that.selectAreaCode+'&IsMobileMsg=false';
			}else{
				loginBody = `UserName=${that.phoneNumberValue}&Password=${that.memberIDcode}&PhoneArea=${that.selectAreaCode}&IsMobileMsg=true`;
			}
			loginBody = `${loginBody}&ClientID=${LiveClientID}`
      http.postForm(loginApi, loginBody, function(response) {
        if (response.ok && response.data) {
          if (response.data.isOK) {
            var data = {
              userId:response.data.results.sub,
              userName:response.data.results.name,
              userPwd:response.data.results.enPwd,
              token:response.data.results.accessToken,
              isOpen:false,
            };//登录得到的用户信息可以保存下来
            storage.setItem('user-logintoken-id', JSON.stringify(data));
            var userToken = response.data.results.accessToken;

            //登陆成功后获取直播间用户信息
            let liveUrl = that.bibApi + '/UserAccounts/UserInfo'
            http.getByHeader(userToken,encodeURI(liveUrl),function (responseLive) {
              var liveDic = {}// 直播间获取到的用户信息
              if (responseLive.data && responseLive.data.IsOK && responseLive.data.Results.length > 0) {
                liveDic = responseLive.data.Results[0]// 直播间获取到的用户信息
              }
              //登陆成功后获取用户交易密码信息
              var tradeApi = that.bibApi+'/MT4Account?format=json&UserId='+data.userId;
              http.getByHeader(userToken,encodeURI(tradeApi),function (responseTrade) {
                var tradeDic = {BC_ACCOUNT_STATUS:''}// 直播间获取到的用户信息
                if (responseTrade.data && responseTrade.data.IsOK && responseTrade.data.Results.length > 0) {
                  for (var i = 0; i < responseTrade.data.Results.length; i++) {
                    if (responseTrade.data.Results[i].Platform == 'MT5') {
                      tradeDic = responseTrade.data.Results[i]// 直播间获取到的用户信息
                    }
                  }
                }
                //登陆成功后获取用户信息接口
                var userStatusApi = that.bibApi+'/IFXAccountDetails/IFXMC?format=json&NeedAttachmentIamges=false';
                http.getByHeader(userToken,encodeURI(userStatusApi), function(responseStatus) {
                  // console.log('输出用户信息结果：'+JSON.stringify(responseStatus));
                  that.isLoginBtnClick = false;
                  if (responseStatus.ok && responseStatus.data) {
                    if (responseStatus.data.Results.length>0) {
                      var dataResult = responseStatus.data.Results[0];
    				          let ReceiptStatus = dataResult.ReceiptStatus;
                      var BindBankNo = dataResult.Member.BindBankNo;//银行卡号
                      var CertNo = dataResult.Member.CertNo;//身份证号
    				          let IsEmailValid = dataResult.Member.IsEmailValid;//
    				          let MainPassword = dataResult.Member.MainPassword;//
    				          let AddressDetail = dataResult.Member.AddressDetail;//
                      // var memberAccount = dataResult.Member.MemberAccount;//交易账号（判断账号是否激活）
                      var memberAccount = tradeDic.BC_ACCOUNT_STATUS=='Normal'?'Normal':'';//交易账号（判断账号是否激活）
                      let SafeQuestion = dataResult.Member.SafeQuestion;
                      let SafeQuestionAnswer = dataResult.Member.SafeQuestionAnswer;

                      //0:默认(Default) 1:无(None)  2:已上传未处理(Unprocessing)  3:审核中(Approving)  4:审核通过(ApprovedPass)
                      //5:审核退回(ApprovedFail) 6等待账户审核通过:(WaitingAccountApproved)
                      var AttachmentStatus = dataResult.Member.AttachmentStatus;//附件审核状态
                      //0:Default(默认) 1:NULL(无 None)   2:(Unprocessing)未处理  3:(Approving)审核中  4:(ApprovedPass)审核完成
                      //  4:(ApprovedFail)审核退回
    				          var	Trade_ID= dataResult.Member.Trade_ID;
                      var KycStatus = dataResult.Member.KycStatus;//调查问卷审核状态
    				          var user = {
    									  nickName:dataResult.Member.NickName,
    									  userId:response.data.results.sub,
    									  userName:response.data.results.name,
                        realName:dataResult.Member.Name,
    									  userPassWord:response.data.results.enPwd,
    									  token:response.data.results.accessToken,
    									  phone:dataResult.Member.Phone,
    									  phoneArea:dataResult.Member.PhoneArea,
    									  sex:dataResult.Member.Sex,
    									  birthday:dataResult.Member.Birthday,
    									  chatLoginParams:dataResult.ChatLoginParams,
    									  accountStatus:dataResult.Member.AccountStatus,
    					 					mainPassword:MainPassword,//mt4交易密码
                        server:tradeDic.SERVER,//交易服务器
                        tradeId:tradeDic.TRADE_ID,
    										addressLv1:dataResult.Member.AddressLv1,
    										addressLv2:dataResult.Member.AddressLv2,
    										addressLv3:dataResult.Member.AddressLv3,
    					 					addressDetail:AddressDetail,//详细地址
    										email:dataResult.Member.Email,//邮箱
    										safeQuestion:dataResult.Member.SafeQuestion,//密保问题
    										safeQuestionAnswer:dataResult.Member.SafeQuestionAnswer,//密保答案
                        SafeQuestionOther:dataResult.Member.SafeQuestionOther,//其他密保问题
    										iB_NO : dataResult.Member.IB_NO,
    										certType : dataResult.Member.NationalArea,
    										certNo : dataResult.Member.CertNo,
    										bindBankNo : dataResult.Member.BindBankNo, // 银行卡号
    										bindSubBankName : dataResult.Member.BindSubBankName, // 支行名称
    										bindBank : dataResult.Member.BindBank,	//银行简称
    										bindSubBankOther : dataResult.Member.BindSubBankOther,	//支行其他
    										bindSubBankArea : dataResult.Member.BindSubBankArea,	// 省
    										bindSubBankAreaCounty : dataResult.Member.BindSubBankAreaCounty,	// 区
    										bindSubBankAreaCity : dataResult.Member.BindSubBankAreaCity,	//  市
    									};//登录得到的用户信息可以保存下来
                      if (liveDic && liveDic.UserProductResult && liveDic.UserAccount) {
                        user.headUrl = liveDic.UserProductResult.HeadUrl
                        user.liveType = liveDic.UserAccount.Type
                        user.liveLevel = liveDic.UserAccount.Level
                        user.liveIsShield = liveDic.UserAccount.IsShield
                        user.liveNickName = liveDic.UserProductResult.NickName
                        user.liveSex = liveDic.UserProductResult.Sexy
                        user.liveUserType = liveDic.UserProductResult.UserType
                      }

    									let url = that.bibApi + '/ReceiptList/Bibfx'
    									http.getByHeader(userToken, encodeURI(url),function(res){
    										if (res.ok ) {
    											if (res.data && res.data.IsOK && res.data.Results) {
    												// ReceiptStatus = res.data.Results.ReceiptStatus;
                            if (ReceiptStatus == null && res.data.Results.ReceiptStatus) {
                              ReceiptStatus = res.data.Results.ReceiptStatus=='ApprovedPass'?'PassAndNo':res.data.Results.ReceiptStatus;//审核通过且未到账
                            }
    											}
    											ReceiptStatus = ReceiptStatus == null ? '' : ReceiptStatus;
    												storage.setItem('userInfo', JSON.stringify(user));
    												storage.setItem('user_openaccount_from', 'index');
    												storage.getItem('user-original-fromLogin', function(value) {
    												  that.fromLogin = value;//从哪里进入个人中心页面
    														if (that.fromLogin == 'index' || that.fromLogin == 'live' || that.fromLogin == 'setting' || that.fromLogin == 'market' || that.fromLogin == 'messagepush') {
    															that.goBack();
    															return;
    														}
    														if(that.comeform== 'open_demo'){
    														    that.startVirtual();
    														    return;
    														}
    														else if (that.fromLogin == 'livebyopen'){
    															navigator.push({//跳转直播间
    															  url: bundleUrl + 'live.js',
    															  animated: "true",
    															  swipePop: "true",
    															  currentPop:'true',
    															disableBackPan: 'true',
    															}, event => {})
    														}

    														// TO DO 填写资料
    														if (!BindBankNo || !CertNo) {
    															navigator.push({ //跳转填写资料
    															  url: bundleUrl + 'openAccount2.js',
    															  animated: "true",
    															  swipePop: "true",
    																currentPop:'true',
    																disableBackPan: 'true',
    															}, event => {})
    														}

    														// TO DO 上传附件
    														else if (BindBankNo && CertNo && AttachmentStatus != 4) {
    															navigator.push({ //跳转上传附件
    															  url: bundleUrl + 'authentication.js',
    															  animated: "true",
    															  swipePop: "true",
    																currentPop:'true',
    																disableBackPan: 'true',
    															}, event => {})
    														}

    														// TO DO 问卷调查
    														else if (memberAccount) {
    															if (MainPassword && IsEmailValid && SafeQuestion && SafeQuestionAnswer){
    																//  TO DO 个人中心
    																var data = {
    																  title: '用户中心',
    																  url: that.memberCenterUrl + that.utm,
    																  source: 'mc',
    																  from: that.fromLogin,
    																  anchor: 'User_center',
    																}
    																storage.setItem('app-url', JSON.stringify(data));
    																navigator.push({
    																  url: bundleUrl + 'memberCenter.js',
    																  animated: "true",
    																  swipePop: "true",
    																  currentPop:'true',
    																  edgePop: "true",
    																  disableBackPan: 'true',
    																}, event => {})
    															}
    															else{
    																// TO DO  交易密码
    																navigator.push({
    																  url: bundleUrl + 'tradePassword.js',
    																  animated: "true",
    																  swipePop: "true",
    																	currentPop:'true',
    																	disableBackPan: 'true',
    																}, event => {})
    															}
    														} else {
    															if (BindBankNo && CertNo && AttachmentStatus == 4 && KycStatus != 'ApprovedPass') {
    																navigator.push({
    																  url: bundleUrl + 'survey.js',
    																  animated: "true",
    																  swipePop: "true",
    																	currentPop:'true',
    																	disableBackPan: 'true',
    																}, event => {})
    															}
    															if (BindBankNo && CertNo && AttachmentStatus == 4 && KycStatus == 'ApprovedPass') {
    																// TO DO 非审核中 非审核通过
    																if (ReceiptStatus == 'Default' || ReceiptStatus == 'ApprovedFail' || ReceiptStatus == ''){
    																	// tianxie 金额
    																	navigator.push({
    																	  url: bundleUrl + 'activateAccount.js?active=0',
    																	  animated: "true",
    																	  swipePop: "true",
    																		currentPop:'true',
    																		disableBackPan: 'true',
    																	}, event => {})
    																}else if (ReceiptStatus == 'Unprocessing' || ReceiptStatus == 'Approving' || ReceiptStatus == 'PassAndNo'){
    																	navigator.push({
    																	  url: bundleUrl + 'activateAccount.js?active=1',
    																	  animated: "true",
    																	  swipePop: "true",
    																		currentPop:'true',
    																		disableBackPan: 'true',
    																	}, event => {})
    																}

    															}
    														}
    												});
    										}else{
    											that.showAlertTips('网络异常，请稍后再试');
    										}
    									})

                    }else {
                      that.showAlertTips('登录异常，请稍后再试');
                    }
                  }else {
                    that.showAlertTips('网络异常，请稍后再试');
                  }
                })
              });
            });
          }else {
            if (that.loginWay==1) {
            	if (response.data.responseStatus && response.data.responseStatus.errorCode && response.data.responseStatus.errorCode ==="WrongAccountOrPassword") {
					that.showAlertTips('手机号未注册');
					that.isLoginBtnClick = false;
					return;
				}
               that.getPhoneCodeMsg();
             }else{
               that.showAlertTips('账号或密码错误');
             }
            that.isLoginBtnClick = false;
          }
        }else {
          that.isLoginBtnClick = false;
          that.showAlertTips('登录异常，请稍后再试');
        }
      })
    },
    getPhoneCodeMsg:function(){
    var that = this;
		var url = this.bibApi+"/ValidateAPI/PhoneCodeCheck?format=json&Phone="+ this.memberPhoneNumber  +"&Code="+this.memberIDcode+"&PhoneArea="+this.selectAreaCode;
    http.get(url,function (rep) {
        if (rep.ok && rep.data) {
          if (!rep.data.IsOK) {
            that.showAlertTips('请填写正确的验证码');
          }else {
            that.showAlertTips('登录异常，请稍后再试');
          }
        }else {
          that.showAlertTips('登录异常，请稍后再试');
        }
    })
	},
	register:function(){
      this.logEvent('User_sign');
      var data = {
        from: 'userLogin',
        openName: 'User_sign',
      }
      storage.setItem('user-original-openAccount', JSON.stringify(data));
      storage.setItem('user_openaccount_from', 'index');
			if (this.comeform){
				let path = `openAccount.js?comeform=${this.comeform}`
				navigator.push({
				  url: bundleUrl + path,
				  animated: "true",
				  currentPop:'true',
				  swipePop: "true",
				}, event => {})
			}else{
				navigator.push({
				  url: bundleUrl + 'openAccount.js',
				  animated: "true",
				  swipePop: "true",
				  currentPop:'true',
				}, event => {})
			}

    },
    findPassword:function(){
      this.loadWebView(this.forgetPwd, '找回密码');
      // this.showAlertTips('点击了找回密码按钮,跳转找回密码html');
    },
	startVirtual:function(){
       navigator.push({
				url: bundleUrl + 'virtual.js',
				animated: "true",
				currentPop:'true',
				swipePop: "true",
		}, event => {})

	},
    loadWebView: function(url, title = '') {
      if (url && url.length > 0) {
        var data = {
          title: title,
          url: url,
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "false"
        }, event => {})
      }
    },
		tapLoginWay:function(e){
			this.loginWay = e;
			if (e==1 && utils.isAndroid()){
			    this.$refs.password.clearText();
			}
		},
		onclickphoneareacode:function(){
		  var that =this;
		  picker.pick({
		      items: that.areaCodes,
		      index:that.memberPhoneAreaCodeIndex,
		    }, event => {
		      if (utils.isAndroid()) {
                  that.$refs.phoneNum.clearText();
                  that.$refs.phoneNum.blur();
              }
		      if (event.result === 'success') {
		        that.phoneNumberPlaceholder='';
		        that.memberPhoneAreaCodeIndex = event.data;
		        that.memberPhoneAreaCode = that.areaCodes[that.memberPhoneAreaCodeIndex];
		        if (that.memberPhoneAreaCode === '中国大陆(+86)') {
		          that.phoneNumberLength = 11;
		          that.phoneNumberPlaceholder = '填写您的手机号码';
		        }else if (that.memberPhoneAreaCode === '其他') {
		          that.phoneNumberLength = 20;
		          that.phoneNumberPlaceholder = '请填写国家代码+手机号码';
		        }else if (that.memberPhoneAreaCode === '中国香港(+852)') {
		          that.phoneNumberLength = 8;
		          that.phoneNumberPlaceholder = '填写您的手机号码';
		        }else if (that.memberPhoneAreaCode === '中国澳门(+853)') {
		          that.phoneNumberLength = 8;
		          that.phoneNumberPlaceholder = '填写您的手机号码';
		        }else if (that.memberPhoneAreaCode === '台湾(+886)') {
		          that.phoneNumberLength = 10;
		          that.phoneNumberPlaceholder = '填写您的手机号码';
		        }else {
		          that.phoneNumberLength = 20;
		          that.phoneNumberPlaceholder = '请填写手机号码';
		        }

				that.memberPhoneNumber = '';
		      }

		    })
		},
		//输入手机号码
		inputphonenumber:function(event){
		  // this.logEvent('input_phone');
		  this.memberPhoneNumber = event.value;
		  if (this.phoneNumberValue != event.value) {
		    this.phoneNumberValue = event.value;
		  }
		},
		onchangememberphonenumber:function(event){
		  this.memberPhoneNumber = event.value;
		  this.getThePhoneNumberCode(this.memberPhoneNumber,this.memberPhoneAreaCode);
		},
		getThePhoneNumberCode:function(number,numberArea){
		  if (numberArea === '中国大陆(+86)') {//匹配大陆手机号码的正则  ^[1][3-8]\d{9}$
		    if (!/^(122|1[3-9][0-9])\d{8}$/.test(number)) {
		      this.showAlertTips('请填写正确的手机号码');
		      return false;
		    }
		  }else if (numberArea === '中国香港(+852)') {//   ^(5|6|8|9)\d{7}$
		    if (!/^\d{8}$/.test(number)) {
		      this.showAlertTips('请填写正确的手机号码');
		      return false;
		    }
		  }else if (numberArea === '中国澳门(+853)') {//   ^[6]([8|6])\d{5}$
		    if (!/^\d{8}$/.test(number)) {
		      this.showAlertTips('请填写正确的手机号码');
		      return false;
		    }
		  }else if (numberArea === '台湾(+886)') {//   ^[0][9]\d{8}$
		    if (!/^\d{10}$/.test(number)) {
		      this.showAlertTips('请填写正确的手机号码');
		      return false;
		    }
		  }else if (numberArea === '其他') {  //     /^[0-9]*$/
		    if (!/^[0-9]*$/.test(number)) {
		      this.showAlertTips('请填写正确的手机号码和对应的区号');
		      return false;
		    }
		  }
		  return true;
		},

		//获取手机验证码按钮
		onclickphoneIDcode:function(){
		  // this.logEvent('btn_send_verification_code');
		  var that = this;
		  if (that.idCodeTimeTick>0 || that.isTimeDownTick) {
		    return;
		  }
		  if (!that.memberPhoneNumber || !that.getThePhoneNumberCode(that.memberPhoneNumber,that.memberPhoneAreaCode)) {
		    return;
		  }
		  var selectAreaCode = '';
		  for (var i = 0; i < appbasedata.phoneAreaCode.length; i++) {
		    if (appbasedata.phoneAreaCode[i].name === that.memberPhoneAreaCode) {
		      selectAreaCode = appbasedata.phoneAreaCode[i].code;
		    }
		  }
		  if (selectAreaCode === '') {
		    this.showAlertTips('请选择手机区号');
		    return ;
		  }
		  if (that.isTimeDownTick) {
		    return ;
		  }
		  that.phoneCodeKey = 'lHU0M5ORcC52nzAdtxeiEbjb';
		  var token = jwt.sign({ },that.phoneCodeKey,{
		    expiresIn:  300 //秒 到期时间
		  });
		  that.isTimeDownTick = true;
		  var getcodeurl = that.bibApi+'/PhoneCode/ValidateAPI?format=json&Phone='+that.memberPhoneNumber+'&PhoneArea='+selectAreaCode;
		  // http://192.168.0.184:10610
		  //发送验证码
		  http.getByHeader(token,encodeURI(getcodeurl), function(response) {
		    that.isTimeDownTick = false;
		    if (response.ok) {
		      that.idCodeTimeTick = 90;
		      that.timecountdown();
		    }
		  })
		},


		//获取验证码倒计时
		timecountdown: function() {
		  if (this.idCodeTimeTick <= 0) {
		    this.idCodeTimeTick = 0
		    this.getIDcode = '发送验证码';
		  } else if (this.idCodeTimeTick > 0) {
		    setTimeout(this.timecountdown.bind(this), 1000);
		    this.idCodeTimeTick--;
		    this.getIDcode = '已发送('+this.idCodeTimeTick+'s)';
		  }
		},
		//输入手机验证码
		inputIDcode:function(event){
			  if (this.memberIDcode != event.value) {
				this.memberIDcode = event.value;
			  }
		},
		onchangememberIDcode:function(event){
		  var that = this;
		  if (!/^\d{6}$/.test(that.memberIDcode)) {
				that.showAlertTips('请填写正确的6位数字手机验证码');
				return
		  }
		},


  }
}
</script>

<style  src="../style/common.css" scoped></style>
<style scoped>
	.navbar-bg{
		width: 750px;
		height: 88px;
		background-color: white;
		align-items: center;
		justify-content: center;
	}
	.navbar-titleText{
		font-size: 32px;
		line-height: 54px;
		lines:1;
		text-align: center;
		text-overflow:ellipsis;
		color: #454950;
		margin-left: 80px;
		margin-right: 80px;
	}
	.account-bg{
		margin-top:100px;
		height: 88px;
		margin-left: 24px;
		margin-right: 24px;
		border-color: #c7cfdb;
		border-width: 1px;
		/* border-top-left-radius: 8px;
		border-top-right-radius: 8px; */
		align-items: center;
	}
	.pwd-bg{
		height: 88px;
		margin-left: 24px;
		margin-right: 24px;
		margin-top: 40px;
		border-color: #c7cfdb;
		border-width: 1px;
		border-bottom-left-radius: 8px;
		border-bottom-right-radius: 8px;
	}
	.input-view{
		flex: 1;
		margin-left: 14px;
		border-width: 1px;
		border-color: #c7cfdb;
		height: 88px;
	}
	.input-size {

		flex:1;
		height: 88px;
		font-size: 24px;
		margin-left: 20px;
		margin-right: 100px;

	}
	.button-login{
		margin-top:58px;
		height: 90px;
		background-color: #2e74e9;
		border-radius: 8px;
		justify-content: center;
		align-items: center;
		margin-left: 30px;
		margin-right: 30px;
	}
	.button-login-gray{
		margin-top:58px;
		height: 90px;
		background-color: gray;
		border-radius: 8px;
		justify-content: center;
		align-items: center;
		margin-left: 30px;
		margin-right: 30px;
	}
	.button-register{
		margin-right: 38px;
		height: 44px;
		width: 120px;
		justify-content: center;
		align-items: center;
	}
	.button-find{
		margin-left: 38px;
		height: 44px;
		width: 120px;
		justify-content: center;
		align-items: center;
	}
	.text{
		color: white;
	}
	.text-red{
		font-size: 28px;
		color: #2e74e9;
	}
	.text-gray{
		font-size: 28px;
		color: #242424;
	}
	.alert-show{
		position:absolute;
		left:0px;
		top:300px;
		right:0px;
		bottom:0px;
		align-items:center;
	}
	.alert-modul {
		height: 74px;
		border-radius: 37px;
		align-items: center;
		justify-content: center;
		padding-left: 60px;
		padding-right: 60px;
		/* background-color: rgba(0, 0, 0, 0.7); */
		background-color: #4c4c4c;
		opacity:0.68;
	}


</style>
<style scoped>
	.loginway-view{
		height: 82px;
		margin-left: 24px;
		margin-right: 24px;
		margin-top: 114px;

		border-bottom-color: #CCCCCC;
		border-bottom-width: 1px;
		font-size: 38px;

		flex-direction: row;
		justify-content: center;
		align-items: center;
	}
	.loginway-account{
		height: 82px;
    padding-top: 20px;
		margin-right: 74px;
		border-bottom-width: 0px;
		border-bottom-color: #2e74e9;
	}
	.loginway-phone
	{
    height: 82px;
    padding-top: 20px;
		margin-left: 74px;
		border-bottom-width: 0px;
		border-bottom-color: #2e74e9;
	}
	.select{
		border-bottom-width: 2px;
		border-bottom-color: #2e74e9;
	}


	.input-down-select{
	  width: auto;
	  height: 88px;
	  /* backgroundColor:red; */
	  margin-right: 16px;
	  align-items: center;
	  justify-content: center;
	}
	.infoItem {
  flex: 1;
  height: 70px;
  justify-content: space-between;
  align-items: center;
  margin-top: 40px;
}
.infoItem-branch {
  flex: 1;
  height: 70px;
  justify-content: space-between;
  align-items: center;
  margin-top: 16px;
}
.select-id-areacode{
  width:302px;
  height:88px;
  justify-content: space-between;
  align-items: center;
	border-width: 1px;
  border-color: #c7cfdb;
}
.input {
  height: 70px;
  width: 550px;
  border-color: gray;
  border-width: 1px;
}
.account1-bg{
		margin-top:100px;
		height: 88px;
		margin-left: 24px;
		margin-right: 24px;
		align-items: center;
		border-width: 0px;
		border-color: #c7cfdb;
		/* border-color: green; */
	}

	.send-code-text-gray{
	  color: #9BA1AB;
		font-size: 24px;
	}
	.send-code-text-red{
		color: #2e74e9;
		font-size: 24px;
	}
</style>
