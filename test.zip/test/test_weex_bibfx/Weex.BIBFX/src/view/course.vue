<template>
<div :style="{backgroundColor:'#ffffff','padding-bottom': iphonex?'34px':'0px'}">
  <status backgroundColor="#FFFFFF"></status>
  <navigation :title="title" textColor="#242424" :leftImg="leftItemSrc" @leftClick="back"></navigation>
  <!-- <div class="navbar">
    <text class="navbar-title"> {{title}} </text>
    <div @click="back" class="navbar-button">
      <image style="width: 20px; height: 36px" resize="contain" :src="leftItemSrc"></image>
    </div>
  </div> -->
  <div style="flex: 1;width: 750px">
    <div class="week-time">
      <div v-for="(day,index) in weeks" :class="[(index == selected)?'week-selected-item':'week-item']" @click="courseclick(index)">
        <text :class="[(index == selected)?'week-selected-day':'week-day']">{{day}}</text>
      </div>
    </div>
    <cycleslider class="content" auto-play="false" infinite="false" bounces="false" scroll-direction="horizontal" @change="changePage" :index="selected">
      <div style="width:750px" v-for="(lesson,index) in lessons">
        <list class="scroller" show-scrollbar=false alwaysScrollableVertical="true">
          <cell style="background-color: white;" v-for="item in lesson" @click="onLecturer(item)">
            <div class="scroller-item border">
              <div style="justify-content:center;">
                <image v-if="item.icon" class="iconbg" :src="item.iconbg"></image>
                <image v-if="item.icon" class="icon" :src="item.icon"></image>
              </div>
              <div class="scroller-item-info">
                <div style="flex:1;">
                  <text class="subject">{{item.subject}} {{item.time}} </text>
                </div>
                <div style="flex:1;">
                  <text class="name">{{item.name}}{{item.name && item.title?'-':''}}{{item.title}} </text>
                </div>
                <div style="flex:1;justify-content:flex-end">
                  <text class="item-content">{{item.content}} </text>
                </div>
              </div>
              <div v-if="item.image" style="position:absolute;top:0px;bottom:0px;left:0px;right:0px;justify-content:center;backgroundColor:#ffffff;">
                <image style="width:700px;height:200px;border-radius: 10px;" :src="item.image"></image>
              </div>
            </div>
          </cell>
        </list>
        <div v-if="lesson && lesson.length <=0 && !isShow" style="position:absolute;left:0px;right:0px;top:0px;bottom:0px;align-items:center;justify-content:center;background-color: white;">
          <image style="width:130px;height:124px;margin-bottom:40px" :src="no_result"></image>
          <text class="nocourse"> 本日无课程 </text>
          <text class="nocourse" lines='0'> {{showContent(weeks[index])}} </text>
          <div class="alerts" @click="showInfo">
            <text style="font-size:28px;color:#2e74e9"> 市场数据 </text>
          </div>
        </div>
      </div>
    </cycleslider>
    <div v-if="isLoadError" style="position:absolute;left:0px; top:0px;right:0px; bottom:0px;background-color: white;justify-content: center;align-items: center">
      <loadError @refreshNetWorkError="refreshNetWorkError"></loadError>
    </div>
  </div>
  <wxc-loading :show="isShow && (false == isLoadError)" loading-text="加载中..." needMask="true"></wxc-loading>
  <message></message>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var utils = require('../include/utils.js');
var http = require('../include/http.js');
var storage = require('../include/storage.js');
var firebase = weex.requireModule('firebase');
import { TYPE_TEACHER, TYPE_ANCHOR, TYPE_LESSION_NORMAL, TYPE_LESSION_TEACHERS,TYPE_LESSION_ANCHOR } from '../include/type.js'

module.exports = {
  components: {
    status: require('../components/statusbar.vue'),
    navigation: require('../components/navigationBar.vue'),
    "wxc-loading": require('../components/wxc-loading.vue'),
    'loadError': require('../components/loadError.vue'),
    message: require('../components/message.vue'),
  },
  data: function() {
    return {
      assets: assetsUrl,
      cmsApiHost: '', //接口基址
      imageBase: '', //图片基址
      nodeIdTecher: '',
      isShow: false,
      height: 88,
      title: '课程表',
      titleColor: 'white',
      leftItemSrc: assetsUrl + 'back1.png',
      dateStr: '',
      days: 5, //接口参数，需要请求的天数
      selected: 0,
      weeks: [], //星期
      lessons: [], //课程数据
      contents: [], //无课程提示内容
      isLoadError: false, //网络加载出错
      noLessId: 0,
      no_result: assetsUrl + 'no_result.png',
    }
  },
  computed: {
    // lessons: function() {
    //   if (this.selected < this.data.length) {
    //     return this.data[this.selected];
    //   }
    //   return [];
    // },
    iphonex: function() {
      return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' || weex.config.env.deviceModel === 'iPhone11,2' || weex.config.env.deviceModel === 'iPhone11,4' || weex.config.env.deviceModel === 'iPhone11,6' || weex.config.env.deviceModel === 'iPhone11,8');
    }
  },
  created: function() {
    //设置状态栏字体颜色为黑色
    if (weex.supports('@module/app')) {
      weex.requireModule('app').setStatusBarStyle(0);
    }
    if (utils.isAndroid()) {
      this.assets = 'local:///';
    }
    var ms = new Date().getTime();
    this.dateStr = utils.dateFormat(ms, 'yyyy-MM-dd');
    this.loadConfigs();
    this.logEvent('Schedule_page');
    // var that = this;
    // // 接收网络错误的广播
    // const Network = new BroadcastChannel('GloballyRefreshNetwork');
    // Network.onmessage = function(event) {
    //     that.loadConfigs();
    // };
  },
  methods: {
    // 接收网络错误的点击事件的回调
    refreshNetWorkError: function() {
      this.loadConfigs();
    },
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    back: function() {
      this.logEvent('Schedule_page_back');
      navigator.pop({
        animated: "true"
      }, res => {});
    },
    showInfo: function() {
      this.logEvent('Schedule_page_livenews');
      storage.setItem('informationindex', '市场数据');
      let Stack = new BroadcastChannel('showView')
      Stack.postMessage('information');
      setTimeout(() => {
        navigator.pop({
          animated: false
        }, res => {});
      }, 300);
    },
    onLecturer: function(item) {
      let ms = new Date().getTime();
      //直播中的课程，跳到直播业页
      if (ms >= item.startTime && ms <= item.endTime) {
        navigator.pop({
          animated: "false"
        }, res => {});
        let Stack = new BroadcastChannel('showView')
        Stack.postMessage('live');
        return;
      }

      // if (utils.isBlankString(item.name) || item.name.includes("/")) {
      //   //双人模式，暂不处理点击事件
      //   return;
      // }

      if (utils.isBlankString(item.teacher)) {

        return;
      }

      //非直播中的课程，跳到老师专业
      if (TYPE_LESSION_TEACHERS == item.type) {
        navigator.push({
          url: bundleUrl + 'ranklist.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }else {
        storage.setItem('lecturer', JSON.stringify({
          name: item.teacher,
          channelId: this.nodeIdTecher
        }));
        navigator.push({
          url: bundleUrl + 'lecturer.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }

    },
    courseclick: function(index) {
      this.selected = index;
    },
    loadConfigs: function() {
      var that = this;
      storage.getItem('nodeIdList', function(value) {
        var nodeIdList = JSON.parse(value);
        that.nodeIdTecher = nodeIdList.homeTeacherInfo;
        that.noLessId = nodeIdList.noLessons;
      });
      storage.getItem('commonUrl',function(value) {
        if ('' == value || value == undefined || value.length <= 0) {
          return
        }
        var commonUrl = JSON.parse(value);
        if (commonUrl) {
          that.cmsApiHost = commonUrl.cmsApi; //接口基址
          that.imageBaseUrl = commonUrl.imageBaseUrl; //图片基址
          that.getWeekCourse();
          that.loadLessons();
        }
      });

    },
    getIconBg: function(time) {
      var date = new Date(time);
      var path = this.assets + 'cbg1';
      if (date) {
        let hour = date.getHours(); //小时
        let minute = date.getMinutes(); //分
        if (hour >= 18 && hour <= 24) {
          path = this.assets + 'cbg3';
        } else if (hour >= 12) {
          path = this.assets + 'cbg2';
        } else if (hour >= 9) {
          path = this.assets + 'cbg1';
        }
      }
      if (utils.isAndroid()) {
        return path;
      } else {
        return path + '.png';
      }
    },
    loadLessons: function() {
      var that = this;
      this.isShow = true;
      var url = this.cmsApiHost + '/Live/LessonsGroup?format=json&channel=bibfx&DateTime=' + this.dateStr + '&days=' + this.days;
      http.get(url, function(response) {
        that.isShow = false;
        that.isLoadError = false;
        if (response.status < 200) {
          that.isLoadError = true;
        }
        if (response.ok && response.data) {
          var data = response.data;

          if (data && data.length >= that.days) {
            that.lessons.splice(0, that.lessons.length);
            // that.contents.splice(0, that.weeks.length);
            for (let index = 0; index < data.length; index++) {
              var temp = data[index].lessons;
              var array = [];
              for (let i = 0; i < temp.length; i++) {
                var lesson = {};
                lesson.name = temp[i].Name; //课程老师
                lesson.title = temp[i].UserAccountExTitle; //老师头衔
                lesson.subject = temp[i].Title; //课程名称
                lesson.content = temp[i].Descript; //老师描述
                lesson.image = '';
                lesson.icon = '';
                if (temp[i].HeadUrls) {
                  var headUrls = temp[i].HeadUrls;
                  for (var j = 0; j < headUrls.length; j++) {
                    if ("appLessons" == headUrls[j].Key) {
                      lesson.icon = headUrls[j].Url; //老师头像
                      break;
                    }
                  }
                }
                if (temp[i].ImageUrls) {
                  let ImageUrls = temp[i].ImageUrls;
                  for (var j = 0; j < ImageUrls.length; j++) {
                    if ("appLessons" == ImageUrls[j].Key) {
                      lesson.image = ImageUrls[j].Url; //特殊课程图片
                      break;
                    }
                  }
                }
                lesson.startTime = parseInt(temp[i].StartTime.slice(6, -7));
                lesson.endTime = lesson.startTime + temp[i].TimeSpan;
                lesson.time = utils.dateFormat(lesson.startTime, 'hh:mm') + ' - ' + utils.dateFormat(lesson.endTime, 'hh:mm');
                lesson.iconbg = that.getIconBg(lesson.startTime);

                lesson.type = TYPE_LESSION_NORMAL;
                //双人课程代码，暂时屏蔽
                // if (temp[i].Teachers && temp[i].Teachers.length>=2) {
                //   if (TYPE_TEACHER == temp[i].Teachers[1].Type) {
                //     lesson.type = TYPE_LESSION_TEACHERS;
                //   }else {
                //     lesson.type = TYPE_LESSION_ANCHOR;
                //   }
                // }

                if (temp[i].Name) {
                  lesson.teacher = temp[i].Name.split("/", 1)[0];
                }else {
                  lesson.teacher = '';
                }

                array.push(lesson);
              }

              if (data[index].week) {
                that.weeks.push(data[index].week);
                that.lessons.push(array);
                // if (data[index].content) {
                //   that.contents.push(data[index].content);
                // } else {
                //   that.contents.push('');
                // }
              }
              // console.log("weeks:"+lessons[index].weex);
            }
          }
        }
      });
    },
    getWeekCourse: function() {
      var that = this;
      var url = that.cmsApiHost + '/ContentUnion/Site?format=json&channelId=' + that.noLessId;
      http.get(url, function(response) {
        if (response.ok && response.data) {
          for (var i = 0; i < response.data.Results.length; i++) {
            var mTitle = response.data.Results[i].Title;
            var mSummary = response.data.Results[i].Summary;
            that.contents.push({
              "title": mTitle,
              "summary": mSummary
            })
          }

        }
      }, 20000)
    },
    showContent: function(title) {
      for (var i = 0; i < this.contents.length; i++) {
        if (this.contents[i].title && -1 != this.contents[i].title.indexOf(title)) {
          return this.contents[i].summary;
        }
      }
      return '';
    },
    changePage: function(e) {
      if (e.index != this.selected) {
        this.selected = e.index;
      }
    },
  }
}
</script>

<style scoped>
.wrap {
  overflow: hidden;
}

.navbar {
  width: 750px;
  height: 88px;
  background-color: #FFFFFF;
  align-items: center;
  justify-content: center;
}

.navbar-title {
  font-size: 36px;
  color: #242424;
  line-height: 54px;
  text-align: center;
}

.navbar-button {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 120px;
  padding-left: 30px;
  justify-content: center;
}

.content {
  flex: 1;
  flex-direction: row;
}

.week-time {
  width: 750px;
  padding-left: 40px;
  padding-right: 40px;
  justify-content: space-between;
  flex-direction: row;
  border-bottom-color: #e8e8e8;
  border-bottom-width: 20px;
  border-bottom-style: solid;
}

.week-item {
  width: 100px;
  height: 88px;
  justify-content: center;
  align-items: center;
  border-bottom-color: #FFFFFF;
  border-bottom-width: 4px;
  border-bottom-style: solid;
}

.week-selected-item {
  width: 100px;
  height: 88px;
  justify-content: center;
  align-items: center;
  border-bottom-color: #2e74e9;
  border-bottom-width: 4px;
  border-bottom-style: solid;
}

.week-day {
  font-size: 28px;
  color: #6c6e70;
}

.week-selected-day {
  font-size: 28px;
  color: #2e74e9;
}

.scroller {
  width: 750px;
  align-items: center;
  /* background-color: white; */
  background-color: #e8e8e8;
}

.scroller-item {
  width: 700px;
  height: 260px;
  margin-left: 25px;
  /* margin-right: 25px; */
  flex-direction: row;
  align-items: stretch;
  overflow: hidden;
}

.scroller-item-info {
  flex: 1;
  flex-direction: column;
  justify-content: space-between;
  padding-top: 40px;
  padding-bottom: 40px;
  padding-left: 20px;
}

.iconbg {
  width: 164px;
  height: 200px;
  border-radius: 10px;
}

.icon {
  position: absolute;
  left: 0px;
  top: 30px;
  width: 164px;
  height: 200px;
  border-radius: 10px;
}

.subject {
  color: #454950;
  font-size: 32px;
}

.name {
  color: #454950;
  font-size: 28px;
  padding-bottom: 30px;
}

.item-content {
  color: #9ba1ab;
  font-size: 24px;
  lines: 2;
  text-overflow: ellipsis;
}

.border {
  border-bottom-width: 1px;
  border-bottom-color: #e1e1e1;
  border-bottom-style: solid;
}

.nocourse {
  font-size: 32px;
  color: #6c6e70;
  text-align: center;
  margin-left: 60px;
  margin-right: 60px;
  line-height: 60px;
}

.alerts {
  margin-top: 60px;
  width: 366px;
  height: 80px;
  align-items: center;
  justify-content: center;
  /* background-color: #FF9AFF; */
  border-radius: 5px;
  border-color: #2e74e9;
  border-width: 1px;
}
</style>
