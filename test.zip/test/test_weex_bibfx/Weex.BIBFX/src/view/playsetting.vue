<template>
<div @viewdisappear="viewdisappear" style="background-color: #e4e4e4">
  <status backgroundColor="#FFFFFF"></status>
  <navigation :title="title" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="onBack()"></navigation>
  <!-- <div class="navbar">
    <text class="navbar-title"> {{title}} </text>
    <div v-on:click="onBack()" class="goback">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div>
  </div> -->
  <div class="item item-border-bottom" @click="enable = !enable">
    <text class="item-text">开启小窗口</text>
    <image style="width:80px;height:40px" :src="enable?switchOn:switchOff"></image>
  </div>
  <div v-if="enable" style="flex:1;background-color: white">
    <div class="item">
      <text class="item-text">拖动下方滑块调整小窗大小</text>
    </div>
    <div style="width:750px; height:50px; flex-direction: row; justify-content: space-between; align-items: center; padding-left: 26px; padding-right: 26px; background-color: white">
      <text class="item-text">较小</text>
      <text class="item-text">默认</text>
      <text class="item-text">较大</text>
    </div>
    <div style="flex-direction:row;height:48px;width:750px;justify-content: space-between; align-items: center;background-color: white">
      <div class="item-row"></div>
      <div style="width:100px;height:48px;justify-content:center;align-items:center;" @click="change(0)">
        <image style="width:10px;height:10px;" :src="assets+'icon1.png'"></image>
      </div>
      <div style="width:100px;height:48px;justify-content:center;align-items:center;" @click="change(1)">
        <image style="width:14px;height:14px;" :src="assets+'icon2.png'"></image>
      </div>
      <div style="width:100px;height:48px;justify-content:center;align-items:center;" @click="change(2)">
        <image style="width:18px;height:18px;" :src="assets+'icon3.png'"></image>
      </div>
      <image  style="position:absolute;top:0px; width:48px;height:48px;" v-bind:style="{left:left}" :src="assets+'icon.png'" @touchstart="touchstart" @touchmove="move" @touchend="touchend" @touchcancel="cancel"></image>
    </div>
    <div style="width: 750px;height: 40px;background-color: white"/>

    <div class="item item-border-top" >
      <text class="item-text">预览</text>
    </div>
    <div style="flex:1;backgroundColor:#f1f1f1;">
      <image class="backg" :src="assets+'style.png'"></image>
      <image class="backg" :src="assets+'style.png'"></image>
      <image class="backg" :src="assets+'style.png'"></image>
      <image class="backg" :src="assets+'style.png'"></image>
    </div>
    <div style="position: absolute;left: 0px;right: 24px;bottom: 110px;align-items: flex-end">
      <div style="box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.65);">
        <image :class="['size-'+sizeIndex]" :src="assets+'mini.png'"></image>
      </div>
    </div>
  </div>
  <message></message>
</div>
</template>

<script>
var storage = require('../include/storage.js');
var assetsUrl = require('../include/base-url.js').assetsUrl();
var bundleUrl = require('../include/base-url.js').bundleUrl();
var animation = weex.requireModule('animation');
var modal = weex.requireModule('modal');
var navi = weex.requireModule('navigator');
var dom = weex.requireModule('dom');
const app = weex.requireModule('app');
var utils = require('../include/utils.js');
var navigator = weex.requireModule('navigator');
const jpush = weex.requireModule('jpush');
var firebase = weex.requireModule('firebase');

module.exports = {
  components: {
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'message': require('../components/message.vue'),
  },
  data: function() {
    return {
      title: '播放设置',
      assets: assetsUrl,
      switchOn: assetsUrl + 'on.png',
      switchOff: assetsUrl + 'off.png',
      enable: true,
      isIOS: utils.iOS(),
      setting: false,
      preview:assetsUrl + 'on.png',
      sizeIndex:1,
      left:350,
    }
  },
  beforeCreate: function() {
    var self = this;
    storage.getItem('playsetting', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        self.enable = true;
        self.sizeIndex = 1;
        return
      }
      var seting = JSON.parse(value);
      self.enable = seting.enable;
      self.change(seting.sizeIndex);
    });
  },
  created: function() {

  },
  methods: {
    onBack: function() {
      navi.pop({
        animated: "true"
      }, res => {});
    },
    viewdisappear: function() {
      var that = this;
      var seting = {
        enable:this.enable,
        sizeIndex:this.sizeIndex
      }
      storage.setItem('playsetting',JSON.stringify(seting) ,function(value) {});
    },
    change:function(idx){
      if (idx>=0 && idx<=2) {
        this.left =25+idx*325;
        this.sizeIndex=idx;
      }
    },
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    touchstart:function(e){
      this.pointX = e.changedTouches[0].screenX;
    },
    move: function(e) {
      this.offsetX = parseInt(e.changedTouches[0].screenX - this.pointX);
      if (this.left<25) {
        this.left = 25;
      }else if (this.left >675){
        this.left = 675;
      }else {
        this.left = this.left + this.offsetX;
      }
      this.pointX = e.changedTouches[0].screenX;
    },
    touchend: function(e) {
      if (this.left <(25+162)) {
        this.left = 25;
        this.sizeIndex = 0;
      }else if(this.left >(675-162)){
        this.left = 675;
        this.sizeIndex = 2;
      }else {
        this.left = 350;
        this.sizeIndex = 1;
      }
    },
    cancel:function(e){
      if (this.left <(25+162)) {
        this.left = 25;
        this.sizeIndex = 0;
      }else if(this.left >(675-162)){
        this.left = 675;
        this.sizeIndex = 2;
      }else {
        this.left = 350;
        this.sizeIndex = 1;
      }
    }
  }
}
</script>

<style scoped>
.goback {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 120px;
  padding-left: 30px;
  justify-content: center;
}

.navbar-title {
  font-size: 36px;
  color: white;
  line-height: 54px;
  text-align: center;
}

.navbar {
  width: 750px;
  height: 88px;
  background-color: #2e74e9;
  align-items: center;
  justify-content: center;
}

.item {
  height: 100px;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding-left: 26px;
  padding-right: 26px;
  background-color: white;
}

.item-border-top{
  border-top-width: 1px;
  border-top-color: #c7c7c7;
}

.item-border-bottom{
  border-bottom-width: 1px;
  border-bottom-color: #c7c7c7;
}

.item-text {
  font-size: 28px;
  line-height: 42px;
  color: #454950;
}

.item-row{
  position: absolute;
  left: 50px;
  right: 50px;
  top: 22px;
  height: 4px;
  background-color: #c7c7c7;
}

.backg{
  width: 750px;
  height: 240px;
}
.preview{
  position: absolute;
  bottom: 40px;
  right: 34px;
  /* width: 578px;
  height: 324px; */
  border-radius: 6px;
  transition-property: top, left;
  transition-duration: 1s;
  transition-timing-function: linear;
}
.size-0{
  width: 408px;
  height: 228px;
}
.size-1{
  width: 578px;
  height: 324px;
}
.size-2{
  width: 680px;
  height: 381px;
}
</style>
