<template>
<div class="black">
  <status backgroundColor="#FFFFFF"></status>
  <navigation :title="title" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="goBack"></navigation>
  <!-- <div class="navbar">
    <text class="navbar-title"> {{title}} </text>
    <div @click="goBack" class="goback">
      <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
    </div>
  </div> -->
  <div style="flex:1;align-items:center;justify-content:center;">
      <div style="justify-content:center;align-items:center;width:750px;" :style="{height: ipad?'500px':'648px'}">
          <camera ref="camera" orientation="horizontal" :class="[ipad?'camera-horizontal-ipad':'camera-horizontal']"></camera>
          <image v-if="isIOS" :class="[transforms]" resize="cover" :src="border"></image>
          <image v-if="!isIOS&& !isShooted" class="transform" resize="cover" :src="borderdefault"></image>
      </div>
      <text class="tips-text">{{tips}}</text>
  </div>
  <div v-if="!isShooted">
    <div class="button" @click="shooting">
      <text class="font28 text">拍摄</text>
    </div>
    <div class="button2" @click="cancel">
      <text class="font28 text">取消</text>
    </div>
  </div>
  <div v-else>
    <div class="button" @click="confirm">
      <text class="font28 text2">确定</text>
    </div>
    <div class="button2" @click="retakePicture">
      <text class="font28 text2">重拍</text>
    </div>
  </div>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var storage = require('../include/storage.js');
const app = weex.requireModule('app');
var utils = require('../include/utils.js');
module.exports = {
  components: {
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
  },
  computed:{
    transforms:function(){
      if (this.ipad) {
        return this.isTransform == true ? 'transform-s-ipad':'transform-ipad'
      }else {
        return this.isTransform == true ? 'transform-s':'transform'
      }
    }
  },
  data: function() {
    return {
      isShooted:false,//是否已拍摄过
      title: "扫描证件",
      tips:"请将证件放到框内，并调整好光线",
      index:0,
      assets: assetsUrl,
      borderdefault:assetsUrl +'scanner/border.png',//扫描框默认图
      border:'',
      pictureFile:'',
      isTransform:false,
      isIOS:utils.iOS(),
      ipad:utils.ipad()
    }
  },
  created: function() {
    var that = this;
    storage.getItem('app-scanner', function(value) {
      if (value && value.length>0) {
        let data = JSON.parse(value);
        that.title = data.title;
        that.tips = data.tips;
        that.index = data.index;
        that.borderdefault = data.border;
        that.border = that.borderdefault;
      }
    });
  },
  methods: {
    goBack: function() {
      navigator.pop({
        animated: "true"
      }, event => {

      });
    },
    //拍摄
    shooting:function(){
      var that = this;
      this.$refs.camera.shutterCamera(function(data){
          that.border = data.path;
          // that.border = 'data:image/png;base64,'+ data.file;
          that.pictureFile = data.file;
          that.isShooted = true;
          that.isTransform = true;
      });
    },
    //取消
    cancel: function() {
      this.isTransform = false;
      navigator.pop({
        animated: "true"
      }, event => {

      });
    },
    //重拍
    retakePicture:function(){
      this.isTransform = false;
      this.isShooted = false;
      this.border = this.borderdefault;
      this.pictureFile = '';
      if (!this.isIOS)
           this.$refs.camera.rePreview();
    },
    //确定
    confirm: function() {
      let data={
        url:this.border,
        file:this.pictureFile,
        index:this.index,
      }
      storage.setItem('user-scanner-picture', JSON.stringify(data));
      this.cancel();
    },
  }
}
</script>

<style  src="../style/common.css" scoped>
</style>
<style scoped>
.black{
  background-color: black;
}
.border{
  border-color: red;
  border-width: 1px;
}
.camera-horizontal{
  position:absolute;
  top:0px;
  left:174px;
  width:402px;
  height:648px;
}
/* 相机拍摄框横向iOS需要逆向旋转90度  竖向则不需要 */
.transform-s{
  transform:  'rotate(90deg)';
  transform-origin: center center;
  overflow: hidden;
  width:648px;
  height:404px;
}
.transform{
  transform:  'rotate(0deg)';
  transform-origin: center center;
  width:402px;
  height:648px;
  overflow: hidden;
}

.camera-horizontal-ipad{
  position:absolute;
  top:0px;
  left:220px;
  width:310px;
  height:500px;
}
.transform-s-ipad{
  transform:  'rotate(90deg)';
  transform-origin: center center;
  overflow: hidden;
  width:500px;
  height:310px;
}
.transform-ipad{
  transform:  'rotate(0deg)';
  transform-origin: center center;
  width:310px;
  height:500px;
  overflow: hidden;
}


.align {
  margin-left: 25px;
  margin-right: 25px;
}

.bottom{
  position: absolute;
  bottom: 0px;
  left: 0px;
  right: 0px;
}

.button {
  height: 90px;
  justify-content: center;
  align-items: center;
  margin-left: 30px;
  margin-right: 30px;
  margin-bottom: 2px;
  border-radius: 5px;
  background-color: #ffffff;
}
.button2 {
  height: 90px;
  justify-content: center;
  align-items: center;
  margin-left: 30px;
  margin-right: 30px;
  margin-bottom: 30px;
  border-radius: 5px;
  background-color: #ffffff;
}
.tips-text{
  color:white;
  margin-top:50px;
  text-align: center;
  width:622px;
}
.text{
  color: #333333;
}
.text2{
  color: #2e74e9;
}
</style>
