<template>
<!-- <div v-if="show" class="container" @click="maskClick">
  <div class="view-alert">
    <div class="view-title">
      <text class="text-title">上传图片</text>
    </div>
    <div class="cut-line"></div>
    <image class="fullScreen-btn"  resize="contain" :src="path"></image>
    <div class="view-bottom">
      <div class="input-bg">
        <input class="input-size" placeholder="图片描述" @change="changePhoto" @input="inputPhoto"></input>
      </div>
      <div  class="footer">
        <div class="footer-cancel" @click="cancelClick">
          <text class="font32 cancel"> {{cancel}} </text>
        </div>
        <div class="footer-confirm" @click="confirmClick">
          <text class="font32 confirm"> {{confirm}} </text>
        </div>
      </div>
    </div>
  </div>
</div> -->
<div v-if="show" class="container" @click="maskClick">
  <div class="view-alert">
    <image style="position: absolute;left: 0;top: 0;width: 122px;height: 94px" :src="alert_top_left" resize="cover"></image>
    <image style="position: absolute;right: 0;top: 0;width: 92px;height: 74px" :src="alert_top_right" resize="cover"></image>
    <!-- <image style="position: absolute;top: 0;left: 0;right: 0;bottom: 0;" :src="alert_bg" resize="cover"></image> -->
    <image style="position: absolute;right: 0;bottom: 0;width: 370px;height: 172px" :src="alert_bottom_right" resize="cover"></image>
    <div class="close" @click="close()">
      <image style="width: 26px;height: 26px;margin-right: 20px;margin-top: 20px" :src="alert_close" resize="cover"></image>
    </div>

    <div class="view-title">
      <text class="text-title">上传文件</text>
    </div>
    <div class="cut-line"></div>
    <image class="fullScreen-btn"  resize="contain" :src="path"></image>
    <div class="view-bottom">
      <div class="input-bg">
        <input class="input-size" placeholder="图片描述" @change="changePhoto" @input="inputPhoto"></input>
      </div>
    </div>
    <div class="bottom">
      <text class="font28" style="color: #ffffff;margin-right: 20px" @click="cancelClick">{{cancel}}</text>
      <text class="font28" style="color: #ffffff;margin-right: 20px">|</text>
      <text class="font28" style="color: #ffffff;" @click="confirmClick">{{confirm}}</text>
    </div>
  </div>

</div>
</template>

<script>
var assetsUrl = require('../include/base-url.js').assetsUrl();

export default {
  props: {
    show: { default: false },
    path:{type: String,default: ''},
    confirm: {
      default: '发送'
    },
    cancel: {
      default: '取消'
    },
  },
  data: function() {
    return {
      content:'',
      assets: assetsUrl,
      deviceHeight:WXEnvironment.deviceHeight,
      deviceWidth:WXEnvironment.deviceWidth,
      alert_top_right: assetsUrl + 'alert_top_right.png',
      alert_top_left: assetsUrl + 'alert_top_left.png',
      alert_bg: assetsUrl + 'alert_bg.png',
      alert_close: assetsUrl + 'alert_close.png',
      alert_bottom_right: assetsUrl + 'alert_bottom_right.png',
    }
  },
  methods: {
  close: function() {
    this.show = false;
    this.$emit('cancel');
    this.$emit('close');
  },
  cancelClick: function() {
    this.show = false;
    this.$emit('cancel');
    this.$emit('close');
  },
  confirmClick: function() {
    this.show = false;
    this.$emit('confirm',this.content);
    this.$emit('close');
    this.content=''
  },
  maskClick:function(){
    // this.$emit('close');
  },
  changePhoto:function(event){
    this.content = event.value
  },
  inputPhoto:function(event){
    this.content = event.value
  },
}
}
</script>
<style src="../style/common.css" scoped></style>
<style scoped>
.container {
  position: fixed;
  left: 0px;
  top: 0px;
  right: 0px;
  bottom: 0px;
  /*兼容H5异常*/
  z-index: 99999;
  justify-content: center;
  align-items: center;
  background-color: rgba(0,0,0,0.8);
}
.view-alert{
   width: 686px;
   height: 876px;
   /* border-radius: 8px; */
   background-color:white;

   padding-top: 110px;
   padding-bottom: 172px;
   /* justify-content: center; */
   /* align-items: center; */
}
.view-title {
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  height: 71px;
}
.image-icon{
  margin-right: 14px;
  width: 50px;
  height: 50px;
  /* border-width: 3px;
  border-color: gray;
  border-radius: 25px; */
}
.text-title{
  margin-left: 46px;
  font-size: 36px;
  line-height: 54px;
  text-align: center;
  color: #333333;
  font-weight: bold;
}
.cut-line{
  margin-bottom: 24px;
  background-color: #e5e7ec;
  height: 1px;
}
.fullScreen{
  position: absolute;
  left: 0px;
  top: 0px;
  right: 0px;
  bottom: 0px;
}
.fullScreen-btn{
  width: 690px;
  height: 384px;
}
.view-bottom{
  width:686px;
  height:120px;
  margin-top: 4px;
}
.input-bg{
  margin-left: 46px;
  margin-right: 46px;
  margin-top: 20px;
  border-width: 1px;
  border-color: #c3c4c8;
  border-radius: 10px;
  /* background-color: #f7faff; */
}
.input-size{
  margin-left: 24px;
  color: #999999;
  font-size: 28px;
  flex: 1;
  height:78px;
}
.footer {
  margin-left: 46px;
  margin-right: 46px;
  margin-top: 32px;
  height: 80px;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
}
.footer-cancel {
  width: 280px;
  height: 80px;
  align-items: center;
  justify-content: center;
  border-radius: 40px;
  border-color: #518deb;
  border-width: 2px;
}
.footer-confirm {
  width: 280px;
  height: 80px;
  align-items: center;
  justify-content: center;
  border-radius: 40px;
  background-color: #518deb;
}

.font32{
  font-size: 32px;
  line-height: 48px;
  font-weight: bold;
}
.cancel {
  color: #518deb;
}
.confirm {
  color: #ffffff;
}




.close{
  position: absolute;
  right: 0;
  top: 0;
  width: 92px;
  height: 74px;
  justify-content: flex-start;
  align-items: flex-end;
}
.bottom{
  /*background-color: red;*/
  /*height: 88px;*/

  position: absolute;
  right: 30px;
  bottom: 20px;
  width: 200px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
}
</style>
