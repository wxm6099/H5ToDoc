<template>
<div style="backgroundColor:white" @viewappear="viewAppear" @viewdisappear="viewdisappear" @foreground="foreground">
  <status backgroundColor="#FFFFFF"></status>
  <navigation title="我的" textColor="#242424"></navigation>
  <scroller class="my-scroller" alwaysScrollableVertical="true" scrollable="true">
    <div class="screenWidth">
      <image style="position:absolute;top:0px;left:0px;width:750px;height:374px;" :src="assets+'topbg.png'"></image>
      <div class="user">
        <div class="name" @click="loginClick">
          <text :class="['title',logined?'bold':'normal']">{{name}}</text>
        </div>
        <div v-if="logined" class="amount" @click="eyeopen=!eyeopen">
          <text style="width:350px;text-align:right;fontSize:28px;color:#333333;">资产（美元）：</text>
          <text style="fontSize:30px;color:#6098F2;font-weight: bold;">{{eyeopen?'$'+amount:'******'}}</text>
          <image style="margin-left:20px;width:40px;height:40px;" :src="assets+(eyeopen?'eye_open.png':'eye_closed.png')"></image>
        </div>
        <div class="buttons-div">
          <div class="buttons" @click="buttonClick(0)">
            <text class="buttonsText buttonsTextB">{{logined?'取款':'注册'}}</text>
          </div>
          <div class="buttons buttonsH" @click="buttonClick(1)">
            <text class="buttonsText buttonsTextW">{{logined?'注资':'登录'}}</text>
          </div>
        </div>
      </div>
      <image :src="avatar" class="avatarIcon" @click="changeAvatar"></image>
      <image v-if="logined" :src="assets+'avatarIcon.png'" class="avatarIconB"></image>
    </div>
    <div class="group">
      <div class="container border" v-on:click="userCenter()">
        <image v-if="rightItemSrc" :src="rightItemSrc" class="right-image"></image>
        <image v-if="assets" :src="assets+'user_center.png'" resize="contain" class="left-image"></image>
        <div class="center">
          <text class="title">用户中心 </text>
        </div>
      </div>
      <div class="container border" v-on:click="news();logEvent('User_notice')">
        <image v-if="rightItemSrc" :src="rightItemSrc" class="right-image"></image>
        <image v-if="assets" :src="assets+'notice.png'" class="left-image"></image>
        <div class="center">
          <text class="title">最新公告 </text>
        </div>
      </div>
      <div class="container" v-on:click="openDemoAccount();logEvent('User_demo')">
        <image v-if="rightItemSrc" :src="rightItemSrc" class="right-image"></image>
        <image v-if="assets" :src="assets+'simulate.png'" class="left-image"></image>
        <div class="center">
          <text class="title">模拟试玩 </text>
        </div>
      </div>
    </div>
    <!-- MT5交易-->
    <div class="group">
      <div class="container border" v-on:click="mt4()">
        <image v-if="rightItemSrc" :src="rightItemSrc" class="right-image"></image>
        <image v-if="assets" :src="assets+'mt5.png'" class="left-image"></image>
        <div class="center">
          <text class="title">MT5交易 </text>
        </div>
      </div>
      <div class="container" v-on:click="promotion();logEvent('User_promotions')">
        <image v-if="rightItemSrc" :src="rightItemSrc" class="right-image"></image>
        <image v-if="assets" :src="assets+'promotion.png'" class="left-image"></image>
        <div class="center">
          <text class="title">推广优惠 </text>
          <div v-if="addDateTime  > lastTime" style="width:10px;height:10px;backgroundColor:red;border-radius:5px;margin-bottom:20px;"></div>
          <text class="detail">{{tips}}</text>
        </div>
      </div>
    </div>
    <div class="group">
      <div class="container border" v-on:click="contactUs();logEvent('User_contactus')">
        <image v-if="rightItemSrc" :src="rightItemSrc" class="right-image"></image>
        <image v-if="assets" :src="assets+'contact.png'" class="left-image"></image>
        <div class="center">
          <text class="title">联系我们 </text>
        </div>
      </div>
      <!-- 关于我们-->
      <div class="container border" v-on:click="about();logEvent('User_aboutus')">
        <image v-if="rightItemSrc" :src="rightItemSrc" class="right-image"></image>
        <image v-if="assets" :src="assets+'about.png'" class="left-image"></image>
        <div class="center">
          <text class="title">关于我们 </text>
        </div>
      </div>
      <div class="container" v-on:click="setting();logEvent('User_setting')">
        <image v-if="rightItemSrc" :src="rightItemSrc" class="right-image"></image>
        <image v-if="assets" :src="assets+'setting.png'" class="left-image"></image>
        <div class="center">
          <text class="title">设置 </text>
        </div>
      </div>
    </div>
  </scroller>
  <chooseAvatar v-if="showChooseAvatar" @cancel="updateAvatar"></chooseAvatar>
  <dialog :show="showDialog" title="" content="您好，登录账号即可使用用户中心" confirm="登录" cancel="注册" @confirm="memberCenter(0)" @cancel="openAccount" @close="showDialog=false"></dialog>
  <div v-if="isShowAlert" class="alert-show">
    <div class="alert-modul">
      <text style="color:#FFFFFF;font-size:28px;"> {{alertTips}} </text>
    </div>
  </div>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var dom = weex.requireModule('dom')
var navigator = weex.requireModule('navigator')
var app = weex.requireModule('app')
var storage = require('../include/storage.js');
var http = require('../include/http.js');
var url = require('../include/url.js');
var modal = weex.requireModule('modal');
var utils = require('../include/utils.js');
var firebase = weex.requireModule('firebase');
var scanner = weex.requireModule('QRCodeModule');
const jwt = require('jsonwebtoken');

module.exports = {
  components: {
    navigation: require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'home-header': require('../components/Header.vue'),
    "wxc-loading": require('../components/wxc-loading.vue'),
    "dialog": require('../components/dialog.vue'),
    chooseAvatar: require('../components/chooseAvatar.vue')
  },
  computed: {
    name: function() {
      var name = '登录后查看更多';
      if (this.logined) {
        if (this.user.realName) {
          name = this.user.realName;
        } else {
          name = '';
        }
      }
      return name;
    }
  },
  data: function() {
    return {
      codeKey: 'lHU0M5ORcC52nzAdtxeiEbjb',
      string: require('../include/string.js'),
      assets: assetsUrl,
      leftItemSrc: assetsUrl + 'arrow.png',
      rightItemSrc: assetsUrl + 'arrow.png',
      cmsApiHost: '', //接口地址
      imageBaseUrl: '', //图片基地址
      memberCenterUrl: '', //用户中心地址
      trueAccountUrl: '', //开户链接
      demoAccountUrl: '', //模拟开户链接
      deposit: '', //帐户注资链接
      withdraw: '', //账号取款链接
      contactUrl: '', //联系我们（客服）
      aboutUrl: '', //关于我们
      logined: false, //登录标记
      logining: false, //登录获取信息中
      showDialog: false, //温馨提醒
      token: '', //
      avatar: '', //
      eyeopen: true,
      defaultPic: {}, //默认头像
      amount: '0.00',
      user: {},
      showChooseAvatar: false,
      settings: {},
      utm: '',
      tips: '', // 登录提示语
      contentId: 0,
      lastTime: 0,
      addDateTime: 0,
      isShowAlert: false,
      alertTips: '', //弹窗提示语
      islogining: false //登录中
    }
  },
  beforeCreate: function() {
    var that = this;
    let headImageInfo = storage.getItemSync('headImageInfo');
    if (headImageInfo && headImageInfo.length >= 2) {
      let json = JSON.parse(headImageInfo);
      that.defaultPic = json.defaultPic;
    }

    storage.getItem('app-addDateTime', function(value) {
      if (value && value.length > 0) {
        that.lastTime = parseInt(value);
      } else {
        that.lastTime = 0;
      }
    });
    storage.getItem('commonUrl', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.cmsApiHost = commonUrl.cmsApi; //接口基址
        that.imageBaseUrl = commonUrl.imageBaseUrl; //图片基址
        that.deposit = commonUrl.deposit;
        that.withdraw = commonUrl.withdraw;
        that.aboutUrl = commonUrl.aboutus;
      }
      storage.getItem('contentIdList', function(value) {
        if (value && value.length > 0) {
          var contentIdList = JSON.parse(value);
          that.contentId = contentIdList.promotions; //id未配置正确
          that.getPromTips();
        }
      });
      storage.getItem("setting", function(data) {
        if (data) {
          that.settings = JSON.parse(data);
          that.getLastTime(that.settings['推广优惠'].title);
        }
      });
    });
  },
  created: function() {
    var that = this;
    this.channelName = app.channelName();
    if (this.channelName) {
      this.utm = "?ComeFrom=GlobalApps&utm_source=APP&utm_campaign=&utm_content=&utm_term=&utm_medium=" + this.channelName;
    }
    storage.getItem('memberCenter', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var memberCenter = JSON.parse(value);
      if (memberCenter) {
        that.memberCenterUrl = memberCenter.memberCenterUrl;
        that.oauth = memberCenter.oauth;
      }
    });
  },
  methods: {
    viewAppear: function(event) {
      var that = this;
      //设置状态栏字体颜色为黑色
      if (app) {
        app.setStatusBarStyle(0);
      }
      this.updateUser();
    },
    viewdisappear: function() {
      this.islogining = false;
    },
    foreground: function() {
      this.updateUser();
    },
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    updateUser: function() {
      let that = this;
      storage.getItem('userInfo', function(data) {
        if (data) {
          that.user = JSON.parse(data);
        }
        if (that.user.userName && that.user.userPassWord) {
          that.logined = true;
          that.memberCenter(-1);
        } else {
          that.logined = false;
          that.token = '';
        }
        that.showAvatar();
        that.getUserBalance();
      });
    },
    showAvatar() {
      if (!utils.isBlankString(this.user.headUrl)) {
        this.avatar = this.user.headUrl;
      } else if (this.user.liveSex > 1) {
        this.avatar = this.defaultPic.femaleMemAvatar;
      } else if (this.user.liveSex >= 0) {
        this.avatar = this.defaultPic.maleMemAvatar;
      } else if (utils.isBlankString(this.user.userName)) {
        this.avatar = this.assets + 'logout.png';
      } else {
        this.avatar = '';
      }
    },
    //弹窗事件
    showAlertTips: function(tips, time = 2000) {
      if (false == this.isShowAlert) {
        this.isShowAlert = true;
        this.alertTips = tips;
        setTimeout(() => {
          this.isShowAlert = false;
          // this.tips = '';
        }, time)
      }
    },
    loadWebView: function(url, title = '') {
      if (url && url.length > 0) {
        var data = {
          title: title,
          url: url,
          logined: this.logined
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'webview.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    userCenter: function() {
      let that = this;
      if (this.islogining)
        return
      this.islogining = true;
      this.memberCenter(0);
    },
    loginClick: function() {
      if (!this.logined) {
        storage.setItem('user-original-fromLogin', 'index');
        navigator.push({
          url: bundleUrl + 'userLogin.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    changeAvatar: function() {
      if (this.logined) {
        this.showChooseAvatar = true;
      } else {
        this.showChooseAvatar = false;
      }

    },
    updateAvatar: function() {
      let that = this;
      this.showChooseAvatar = false;
      storage.getItem('userInfo', function(data) {
        if (data) {
          let userData = JSON.parse(data);
          that.user.headUrl = userData.headUrl;
        }
        that.showAvatar();
      });
    },
    buttonClick: function(index) {
      switch (index) {
        case 0:
          if (this.logined) {
            this.showWithdraw();
          } else {
            this.openAccount();
          }
          break;
        case 1:
          if (this.logined) {
            this.fastdeposit();
          } else {
            this.memberCenter(0);
          }
          break;
        default:
          break;
      }
    },
    memberClick: function() {
      if (this.logined) {
        this.memberCenter(1);
      } else {
        this.showDialog = true;
      }
    },
    memberCenter: function(type) {
      var that = this;
      if (that.logined) {
        storage.getItem('user-logintoken-id', function(value) {
          if (value) {
            var dataToken = JSON.parse(value);
            //登陆成功后获取用户状态
            let liveUrl = that.cmsApiHost + '/UserAccounts/UserInfo?format=json&channel=bibfx'
            http.getByHeader(dataToken.token, encodeURI(liveUrl), function(responseLive) {
              var liveDic = {} // 直播间获取到的用户信息
              if (responseLive.data && responseLive.data.IsOK && responseLive.data.Results.length > 0) {
                liveDic = responseLive.data.Results[0] // 直播间获取到的用户信息
              }
              //登陆成功后获取用户交易密码信息
              var tradeApi = that.cmsApiHost + '/MT4Account?format=json&UserId=' + that.user.userId;
              http.getByHeader(dataToken.token, encodeURI(tradeApi), function(responseTrade) {
                var tradeDic = {
                  BC_ACCOUNT_STATUS: ''
                } // 直播间获取到的用户信息
                if (responseTrade.data && responseTrade.data.IsOK && responseTrade.data.Results.length > 0) {
                  for (var i = 0; i < responseTrade.data.Results.length; i++) {
                    if (responseTrade.data.Results[i].Platform == 'MT5') {
                      tradeDic = responseTrade.data.Results[i] // 直播间获取到的用户信息
                    }
                  }
                }
                let MainPassword = tradeDic.TRADE_PASSWORD; //MT5交易密码
                var StatusApi = that.cmsApiHost + '/IFXAccountDetails/IFXMC?format=json&NeedAttachmentIamges=false';
                http.getByHeader(dataToken.token, encodeURI(StatusApi), function(responseStatus) {
                  if (responseStatus.ok && responseStatus.data) {
                    if (responseStatus.data.Results.length > 0) {
                      var dataResult = responseStatus.data.Results[0];

                      let ReceiptStatus = dataResult.ReceiptStatus;

                      var BindBankNo = dataResult.Member.BindBankNo; //银行卡号
                      var CertNo = dataResult.Member.CertNo; //身份证号

                      let IsEmailValid = dataResult.Member.IsEmailValid; //
                      // let MainPassword = dataResult.Member.MainPassword;//
                      let AddressDetail = dataResult.Member.AddressDetail; //

                      // var memberAccount = dataResult.Member.MemberAccount; //交易账号（判断账号是否激活）
                      var memberAccount = tradeDic.BC_ACCOUNT_STATUS == 'Normal' ? 'Normal' : ''; //交易账号（判断账号是否激活）

                      let SafeQuestion = dataResult.Member.SafeQuestion;
                      let SafeQuestionAnswer = dataResult.Member.SafeQuestionAnswer;

                      //0:默认(Default) 1:无(None)  2:已上传未处理(Unprocessing)  3:审核中(Approving)  4:审核通过(ApprovedPass)
                      //5:审核退回(ApprovedFail) 6等待账户审核通过:(WaitingAccountApproved)
                      var AttachmentStatus = dataResult.Member.AttachmentStatus;
                      //0:Default(默认) 1:NULL(无 None)   2:(Unprocessing)未处理  3:(Approving)审核中  4:(ApprovedPass)审核完成
                      //  4:(ApprovedFail)审核退回
                      var KycStatus = dataResult.Member.KycStatus;

                      var user = {
                        userId: dataToken.userId,
                        userName: dataToken.userName,
                        userPassWord: dataToken.userPwd,
                        token: dataToken.token,
                        nickName: dataResult.Member.NickName,
                        realName: dataResult.Member.Name,
                        phone: dataResult.Member.Phone,
                        phoneArea: dataResult.Member.PhoneArea,
                        sex: dataResult.Member.Sex,
                        birthday: dataResult.Member.Birthday,
                        chatLoginParams: dataResult.ChatLoginParams,
                        accountStatus: dataResult.Member.AccountStatus,
                        server: tradeDic.SERVER, //交易服务器
                        tradeId: tradeDic.TRADE_ID,
                        mainPassword: MainPassword, //mt4交易密码
                        addressDetail: AddressDetail, //详细地址
                        email: dataResult.Member.Email, //邮箱
                        safeQuestion: dataResult.Member.SafeQuestion, //密保问题
                        safeQuestionAnswer: dataResult.Member.SafeQuestionAnswer, //密保答案
                        SafeQuestionOther: dataResult.Member.SafeQuestionOther, //其他密保问题
                        iB_NO: dataResult.Member.IB_NO,
                        certType: dataResult.Member.NationalArea,
                        certNo: dataResult.Member.CertNo,
                        bindBankNo: dataResult.Member.BindBankNo, // 银行卡号
                        bindSubBankName: dataResult.Member.BindSubBankName, // 支行名称
                        bindBank: dataResult.Member.BindBank, //银行简称
                        bindSubBankOther: dataResult.Member.BindSubBankOther, //支行其他
                        addressLv1: dataResult.Member.AddressLv1,
                        addressLv2: dataResult.Member.AddressLv2,
                        addressLv3: dataResult.Member.AddressLv3,
                        bindSubBankArea: dataResult.Member.BindSubBankArea, // 省
                        bindSubBankAreaCounty: dataResult.Member.BindSubBankAreaCounty, // 区
                        bindSubBankAreaCity: dataResult.Member.BindSubBankAreaCity, //  市
                      };
                      //登录得到的用户信息可以保存下来
                      if (liveDic && liveDic.UserProductResult && liveDic.UserAccount) {
                        user.headUrl = liveDic.UserProductResult.HeadUrl
                        user.liveType = liveDic.UserAccount.Type
                        user.liveLevel = liveDic.UserAccount.Level
                        user.liveIsShield = liveDic.UserAccount.IsShield
                        user.liveNickName = liveDic.UserProductResult.NickName
                        user.liveSex = liveDic.UserProductResult.Sexy
                        user.liveUserType = liveDic.UserProductResult.UserType
                      }
                      if (!utils.isBlankString(user.headUrl)) {
                        that.user.headUrl = user.headUrl;
                        that.showAvatar();
                      }
                      that.user.token = user.token;
                      that.getUserBalance();
                      let url = that.cmsApiHost + '/ReceiptList/Bibfx'
                      http.getByHeader(dataToken.token, encodeURI(url), function(res) {
                        if (res.ok) {
                          if (res.data && res.data.IsOK && res.data.Results) {
                            // ReceiptStatus = res.data.Results.ReceiptStatus;
                            if (ReceiptStatus == null && res.data.Results.ReceiptStatus) {
                              ReceiptStatus = res.data.Results.ReceiptStatus == 'ApprovedPass' ? 'PassAndNo' : res.data.Results.ReceiptStatus; //审核通过且未到账
                            }
                            if (!utils.isBlankString(res.data.Results.TradeAmount)) {
                              user.TradeAmount = res.data.Results.TradeAmount;
                              user.TradeCurrency = res.data.Results.TradeCurrency;
                            }
                          }
                          ReceiptStatus = ReceiptStatus == null ? '' : ReceiptStatus;
                          storage.setItem('userInfo', JSON.stringify(user));
                          if (type == -1) { // -1表示只做更新数据，不做跳转
                            return
                          }
                          storage.setItem('user_openaccount_from', 'index');

                          // TO DO 填写资料
                          if (!BindBankNo || !CertNo) {
                            navigator.push({ //跳转填写资料
                              url: bundleUrl + 'openAccount2.js',
                              animated: "true",
                              swipePop: "true",
                              disableBackPan: 'true',
                            }, event => {})
                          }
                          // TO DO 上传附件
                          else if (BindBankNo && CertNo && AttachmentStatus != 4) {
                            navigator.push({ //跳转上传附件
                              url: bundleUrl + 'authentication.js',
                              animated: "true",
                              swipePop: "true",
                              disableBackPan: 'true',
                            }, event => {})
                          } else if (memberAccount) {
                            if (MainPassword && IsEmailValid && SafeQuestion && SafeQuestionAnswer) {
                              //  TO DO 个人中心
                              var data = {
                                title: '用户中心',
                                url: that.memberCenterUrl + that.utm,
                                source: 'mc',
                                from: 'User_center',
                                anchor: 'User_center',
                              }
                              storage.setItem('app-url', JSON.stringify(data));
                              navigator.push({
                                url: bundleUrl + 'memberCenter.js',
                                animated: "true",
                                swipePop: "true",
                                edgePop: "true",
                                disableBackPan: 'true',
                              }, event => {})
                            } else {
                              // TO DO  交易密码
                              navigator.push({
                                url: bundleUrl + 'tradePassword.js',
                                animated: "true",
                                swipePop: "true",
                                disableBackPan: 'true',
                              }, event => {})
                            }
                          } else {
                            if (BindBankNo && CertNo && AttachmentStatus == 4 && KycStatus != 'ApprovedPass') {
                              navigator.push({
                                url: bundleUrl + 'survey.js',
                                animated: "true",
                                swipePop: "true",
                                disableBackPan: 'true',
                              }, event => {})
                            }
                            if (BindBankNo && CertNo && AttachmentStatus == 4 && KycStatus == 'ApprovedPass') {
                              // TO DO 非审核中 非审核通过
                              if (ReceiptStatus == 'Default' || ReceiptStatus == 'ApprovedFail' || ReceiptStatus == '') {
                                // tianxie 金额
                                navigator.push({
                                  url: bundleUrl + 'activateAccount.js?active=0',
                                  animated: "true",
                                  swipePop: "true",
                                  disableBackPan: 'true',
                                }, event => {})
                              } else if (ReceiptStatus == 'Unprocessing' || ReceiptStatus == 'Approving' || ReceiptStatus == 'PassAndNo') {
                                navigator.push({
                                  url: bundleUrl + 'activateAccount.js?active=1',
                                  animated: "true",
                                  swipePop: "true",
                                  disableBackPan: 'true',
                                }, event => {})
                              }
                            }
                          }
                        }
                      })

                    } else {
                      that.showAlertTips('登录异常，请稍后再试');
                    }
                  } else {
                    that.showAlertTips('登录异常，请稍后再试');
                  }
                });
              });
            })
          }
        });
      } else {
        storage.setItem('user-original-fromLogin', 'index');
        navigator.push({
          url: bundleUrl + 'userLogin.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    news: function() {
      let newItem = this.settings['最新公告'];
      if (newItem) {
        storage.setItem('tags', JSON.stringify(newItem));
        navigator.push({
          url: bundleUrl + 'topic.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    openAccount: function() {
      this.logEvent('My_sign');
      var data = {
        from: 'my',
        openName: 'My_sign',
      }
      storage.setItem('user-original-openAccount', JSON.stringify(data));
      storage.setItem('user_openaccount_from', 'index');
      navigator.push({
        url: bundleUrl + 'openAccount.js', //survey  openAccount userLogin  authentication
        animated: "true",
        swipePop: "true",
      }, event => {})
    },
    showWithdraw: function() {
      if (this.withdraw && this.withdraw.length > 0) {
        var data = {
          title: '账户取款',
          url: this.withdraw + this.utm,
          source: 'fastdeposit',
          from: 'fastdeposit'
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'memberCenter.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    fastdeposit: function() {
      if (this.deposit && this.deposit.length > 0) {
        var data = {
          title: '账户注资',
          url: this.deposit + this.utm,
          source: 'fastdeposit',
          from: 'fastdeposit'
        }
        storage.setItem('app-url', JSON.stringify(data));
        navigator.push({
          url: bundleUrl + 'memberCenter.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    // 获取用户余额
    getUserBalance: function() {
      if (this.user && this.user.token) {
        let that = this
        let getMoneyUrl = `${this.cmsApiHost}/FreeAmount/bibfxMC?UserId=${this.user.userId}&Server=${this.user.server}&TradeID=${this.user.tradeId}`
        http.getByHeader(this.user.token, getMoneyUrl, function(response) {
          if (response.ok && response.data) {
            that.amount = parseFloat(response.data).toFixed(2);
          } else {
            that.amount = '0.00';
          }
        })
      }
    },
    openDemoAccount: function() {
      let that = this;
      if (that.logined) {
        navigator.push({
          url: bundleUrl + 'virtual.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      } else {
        // TO DO  弹窗
        that.showAlertTips('请先登录');
        navigator.push({
          url: bundleUrl + 'userLogin.js?comeform=open_demo',
          animated: "true",
          swipePop: "true",
          disableBackPan: 'true',
        }, event => {})
      }

    },
    mt4: function() {
      if (utils.isAndroid()) {
        weex.requireModule('app').openMt4();
      } else {
        if (app.canOpenURL("metatrader5://")) {
          app.openURL("metatrader5://com.bibfx.app");
        } else {
          app.openURL(url.MT4);
        }
      }
    },
    promotion: function() {
      let promotion = this.settings['推广优惠'];
      if (promotion) {
        this.lastTime = Date.now();
        storage.setItem('app-addDateTime', this.lastTime.toString());
        storage.setItem('tags', JSON.stringify(promotion));
        navigator.push({
          url: bundleUrl + 'topic.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    setting: function() {
      navigator.push({
        url: bundleUrl + 'setting.js',
        animated: "true",
        swipePop: "true",
      }, event => {})
    },
    contactUs: function() {
      navigator.push({
        url: bundleUrl + 'contact.js',
        animated: "true",
        swipePop: "true",
      }, event => {})
    },
    about: function() {
      // app.openURL(this.aboutUrl);
      this.loadWebView(this.aboutUrl, '关于我们');
    },
    getPromTips: function() {
      var that = this;
      if (undefined == this.cmsApiHost || '' == this.contentId) {
        return;
      }
      var url = this.cmsApiHost + '/ContentUnion/Site?format=json&id=' + that.contentId;
      http.get(url, function(response) {
        if (response.ok && response.data && response.data.Results && response.data.Results.length > 0) {
          var result = response.data.Results[0];
          if (result) {
            that.tips = result.Summary;
          }
        }
      });
    },
    getLastTime: function(title) {
      var that = this;
      if (undefined == this.cmsApiHost || '' == title) {
        return;
      }
      var url = this.cmsApiHost + '/ContentUnion/Site?format=json&OrderByDesc=AddDate&Take=1&Skip=0&Tags=' + encodeURIComponent(title);
      http.get(url, function(response) {
        if (response.ok && response.data) {
          var results = response.data.Results;
          if (results && results.length > 0) {
            that.addDateTime = parseInt(results[0].AddDate.replace('/Date(', '').replace(')/', '').substring(0, 13));
          }
        }
      }, 2000);
    },
    startScanner: function() {
      var self = this;
      if (utils.isAndroid() && app) {
        app.isCheckCameraPermission(function(value) {
          if (value) {
            self.startToScanner();
          }
        });
      }
      if (!utils.isAndroid()) {
        self.startToScanner();
      }
    },
    startToScanner: function() {
      var self = this;
      scanner.start(callback => {
        if (self.user && self.user.userName && self.user.userId) {
          let qrToken = utils.getQueryString(callback.data, "token");
          let clientId = utils.getQueryString(callback.data, "clientId");
          if (qrToken && qrToken.length > 5) {
            var token = jwt.sign({
              codeId: qrToken,
              action: "scan"
            }, self.codeKey, {
              expiresIn: 300 //秒 到期时间
            });
            let url = self.oauth + '/account/CodeScan?token=' + token;
            http.get(url, function(response) {
              if (response && response.data && response.data.isOK) {
                self.qrcodeLogin(qrToken, clientId);
              }
            });
          }
        } else {
          storage.setItem('user-original-fromLogin', 'setting');
          navigator.push({
            url: bundleUrl + 'userLogin.js',
            animated: "true",
            swipePop: "true",
          }, event => {})
        }
      });
    },
    qrcodeLogin: function(token = '', clientId = '') {
      if (token && token.length > 0) {
        var jwtToken = jwt.sign({
          codeId: token,
          action: "Login",
          userId: this.user.userId,
          userName: this.user.userName
        }, this.codeKey, {
          expiresIn: 300 //秒 到期时间
        });
        storage.setItem('qrcode', JSON.stringify({
          jwtToken,
          clientId
        }));
        navigator.push({
          url: bundleUrl + 'qrcodeLogin.js',
          animated: "true",
          swipePop: "true",
        })
      }
    }
  }
}
</script>


<style scoped>
.screenWidth {
  width: 750px;
}

.navibar {
  height: 88px;
  background-color: #2e74e9;
  align-items: center;
  justify-content: center;
  flex-direction: row;
}

.navbar-title {
  font-size: 36px;
  color: white;
  line-height: 54px;
  text-align: center;
}

.user {
  width: 700px;
  margin-left: 25px;
  margin-top: 120px;
  padding-bottom: 40px;
  background-color: white;
  border-radius: 10px;
}

.user-center {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 150;
  right: 80;
  flex-direction: row;
  align-items: center;
}

.name {
  margin-top: 50px;
  height: 80px;
  justify-content: center;
  align-items: center
}

.amount {
  height: 46px;
  flex-direction: row;
  align-items: center;
}

.buttons-div {
  width: 700px;
  height: 80px;
  flex-direction: row;
  justify-content: center;
  margin-top: 20px;
}

.buttons {
  width: 300px;
  height: 80px;
  border-color: #518DEB;
  border-width: 1px;
  margin-left: 10px;
  margin-right: 10px;
  justify-content: center;
  align-items: center;
  border-radius: 40px;
}

.buttonsH {
  background-color: #4985E6;
  background-image: linear-gradient(to top, #4985E6, #87B8FF);
}

.buttonsText {
  font-size: 32px;
  line-height: 48px;
}

.buttonsTextB {
  color: #518DEB;
}

.buttonsTextW {
  color: #FFFFFF;
}

.avatarIcon {
  position: absolute;
  top: 70px;
  left: 325px;
  width: 100px;
  height: 100px;
  border-radius: 50px;
}

.avatarIconB {
  position: absolute;
  top: 134px;
  left: 389px;
  width: 36px;
  height: 36px;
  border-radius: 18px;
}

.right-icon {
  position: absolute;
  bottom: 61;
  right: 0;
  width: 18;
  height: 30;
}

.my-scroller {
  margin-top: 0px;
  margin-bottom: 0px;
  padding-bottom: 20px;
  background-color: #F1F1F1;
  width: 750px;
}

.group {
  width: 700px;
  margin-left: 25px;
  margin-top: 25px;
  background-color: white;
  border-radius: 10px;
}

.border {
  border-bottom-width: 1px;
  border-bottom-style: solid;
  border-bottom-color: #E1E1E1;
}

.container {
  flex-direction: row;
  top: 0;
  height: 98;
  margin-left: 24px;
  margin-right: 24px;
}

.center {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 80;
  right: 40;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  overflow: hidden;
}

.title {
  text-align: left;
  font-size: 32px;
  line-height: 48px;
  /* font-weight: bold; */
  color: #333333;
}

.detail {
  flex: 1;
  lines: 1;
  text-align: right;
  text-overflow: ellipsis;
  font-size: 28px;
  line-height: 34px;
  color: #F96564;
}

.left-image {
  position: absolute;
  bottom: 32;
  left: 0;
  width: 36;
  height: 36;
}

.right-image {
  position: absolute;
  bottom: 35;
  right: 0;
  width: 18;
  height: 30;
}

.alert-show {
  position: absolute;
  left: 0px;
  top: 300px;
  right: 0px;
  bottom: 0px;
  align-items: center;
}

.alert-modul {
  height: 74px;
  border-radius: 37px;
  align-items: center;
  justify-content: center;
  padding-left: 60px;
  padding-right: 60px;
  background-color: #4c4c4c;
  opacity: 0.68;
}

.bold {
  font-weight: bold;
}

.normal {
  font-weight: normal;
}
</style>
