<template>
<div @viewappear="viewAppear">
  <status backgroundColor="#FFFFFF"></status>
  <navigation title="模拟开户" textColor="#242424" :leftImg="assets+'back1.png'" @leftClick="goBack"></navigation>
	<!-- <div class="navbar">
	  <text class="navbar-title"> 模拟开户 </text>
	  <div @click="goBack" class="goback">
	    <image style="width: 20px; height: 36px" resize="contain" :src="assets+'back1.png'"></image>
	  </div>
	</div> -->

  <scroller class="my-scroller" alwaysScrollableVertical="true" scrollable="true">
    <div class="group-head">
			<image class="group-head-img" :src="assets + 'happy.png'"></image>
			<text class="group-head-text">您已成功领取模拟账户！</text>
		</div>
		<div class="group">
			<text class="font28" style="color: #454950;">您将享有：30天免费MT5模拟账户，交易额度为20万美金！如有任何问题，请联系24小时在线客服。祝您交易愉快！</text>
		</div>
		<div class="group flexV">
			<div class="flexH">
				<text class="font28" style="color: #454950;">账号：</text>
				<text class="font28" style="color: #2e74e9;">{{account}}</text>
			</div>
			<div class="flexH">
				<text class="font28" style="color: #454950;">密码：</text>
				<text class="font28" style="color: #2e74e9;">{{password}}</text>
			</div>
		</div>

    <div class="group">
			<text class="font28" style="color: #9BA1AB;">请妥善保管您的模拟账号信息，切勿向第三方透漏以上资料。</text>
		</div>
		<div class="group flexH" style="justify-content: space-between;">
			<div class="group-button flexH" @click="tapLive">
				<image style="width: 28px;height: 44px;margin-right: 20px;" :src="assets + 'microphone.png'"></image>
				<text class="font26" style="color: #454950;">马上进入直播间</text>
			</div>
			<div class="group-button flexH" style="background-color: #2e74e9;" @click="tapDownload">
				<image style="width: 28px;height: 44px;margin-right: 20px;" :src="assets + 'mt5_download.png'"></image>
				<text class="font26" style="color: #FFFFFF;">立即下载MT5</text>
			</div>
		</div>

  </scroller>

	<div v-if="isShowAlert" class="alert-show">
	  <div class="alert-modul">
	    <text style="color:#FFFFFF;font-size:28px;"> {{alertTips}} </text>
	  </div>
	</div>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var dom = weex.requireModule('dom')
var navigator = weex.requireModule('navigator')
var app = weex.requireModule('app')
var storage = require('../include/storage.js');
var http = require('../include/http.js');
var url = require('../include/url.js');
var modal = weex.requireModule('modal');
var utils = require('../include/utils.js');
var firebase = weex.requireModule('firebase');
var scanner = weex.requireModule('QRCodeModule');
const jwt = require('jsonwebtoken');
import {
  MT4
} from '../include/url.js';

module.exports = {
  components: {
    'navigation': require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'home-header': require('../components/Header.vue'),
    "wxc-loading": require('../components/wxc-loading.vue'),
    "dialog": require('../components/dialog.vue'),
  },
  computed: {

  },
  data: function() {
    return {
      codeKey : 'lHU0M5ORcC52nzAdtxeiEbjb',
      string: require('../include/string.js'),
      assets: assetsUrl,
      leftItemSrc: assetsUrl + 'arrow.png',
      rightItemSrc: assetsUrl + 'arrow.png',
      cmsApiHost: '', //接口地址
      imageBaseUrl: '', //图片基地址
      memberCenterUrl: '', //用户中心地址
      contactUrl: '', //联系我们（客服）
      aboutUrl: '', //关于我们
      logined: false, //登录标记
      logining: false, //登录获取信息中

			account: '',
			password: '',

			isShowAlert: false,
			alertTips: '',//弹窗提示语

    }
  },
  created: function() {
    var that = this;
    this.channelName = app.channelName();
    if (this.channelName) {
      this.utm = "?ComeFrom=GlobalApps&utm_source=APP&utm_campaign=&utm_content=&utm_term=&utm_medium=" + this.channelName;
    }
    storage.getItem('memberCenter', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var memberCenter = JSON.parse(value);
      if (memberCenter) {
        that.memberCenterUrl = memberCenter.memberCenterUrl;
        that.oauth = memberCenter.oauth;
      }
    });
		storage.getItem('user-logintoken-id', function(value) {
		  if (value ) {
		    var data = JSON.parse(value);
		    that.userToken = data.token;
		  }
		});
		storage.getItem('commonUrl',function(value) {
		  if ('' == value || value == undefined || value.length <= 0) {
		    return;
		  }
		  var commonUrl = JSON.parse(value);
		  if (commonUrl) {
		    that.cmsApiHost = commonUrl.cmsApi;
				console.log('that.cmsApiHosttttttttttttt:' + that.cmsApiHost);
				that.getVirtualAccount();
				// that.createVirtualAccount();
		  }
		});


  },
  methods: {
    viewAppear: function(event) {
      var that = this;
      //设置状态栏字体颜色为黑色
      if (app) {
        app.setStatusBarStyle(0);
      }

    },
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
		goBack:function(){
// 		  navigator.pop({
// 		    animated: "true"
// 		  }, event => {});
			navigator.pop({
			  url: bundleUrl + 'index.js',
			  animated: "false"
			}, event => {});
		},
		//弹窗事件
		showAlertTips: function(tips, time = 2000) {
			console.log('wwwwww');
			console.log('this.isShowAlertttttttttt', this.isShowAlert);
		  if (false == this.isShowAlert) {
		    this.isShowAlert = true;
		    this.alertTips = tips;
		    setTimeout(() => {
		      this.isShowAlert = false;
		      // this.tips = '';
		    }, time)
		  }
		},

		getVirtualAccount:function(){
			let that = this;
			let url = that.cmsApiHost+'/DemoAccounts/Bibfx';
			console.log('TTTTTTTTTTTTT：'+ that.userToken);
			// 获取模拟账户
			http.getByHeader(that.userToken,encodeURI(url), function(response) {
			  console.log('FFFFFFFFFFFFF：'+JSON.stringify(response));
				if (response.ok){
					if (response.data && response.data.IsOK && response.data.Results) {
							let Results = response.data.Results;
							that.account = Results.TradeId;
							that.password = Results.AccountPwd;
					  }else{
							// 没有模拟账户，则创建一个
							let url2 = that.cmsApiHost+'/OpenDemoAccount/Bibfx';
							console.log('UUUUUUUUUUU：'+ url2);
							var body = 'format=json';
							http.postFormToken(that.userToken,encodeURI(url2), body ,function(response) {
							  console.log('CCCCCCCCCCCCCCC：'+JSON.stringify(response));
								if (response.ok){
									if (response.data && response.data.IsOK && response.data.Results) {
										let Results = response.data.Results;
										if (Results.TradeId && Results.AccountPwd){
											that.account = Results.TradeId;
											that.password = Results.AccountPwd;
										}else{
											that.showAlertTips('领取模拟账户失败，请联系客服')
										}
									}else{
										that.showAlertTips('领取模拟账户失败，请联系客服')
									}
								}else{
									that.showAlertTips('网络失败')
								}
							})
						}
				}else{
					that.showAlertTips('网络失败')
				}
			})
		},

// 		createVirtualAccount:function(){
// 			let that = this;
// 			console.log('TTTTTTTTTTTTT：'+ that.userToken);
// 			let url = that.cmsApiHost+'/OpenDemoAccount/Bib';
// 			console.log('LLLLLLLLLLLLLL：'+ url);
// 			http.postFormToken(that.userToken,encodeURI(url), null ,function(response) {
// 			  console.log('CCCCCCCCCCCCCCC：'+JSON.stringify(response));
// 			  if (response.IsOK && response.Results) {
// 					let Results = response.Results;
// 					that.account = Results.AccountDemoId;
// 					that.password = Results.AccountPwd;
// 			  }
// 			})
// 		},

    tapLive:function(){
			navigator.push({
			  url: bundleUrl + 'live.js',
			  animated: "true",
			  swipePop: "true",
			}, event => {})
		},
		tapDownload:function(){
// 			if (weex.supports('@module/app.openRatingReview')) {
// 			  app.openRatingReview();
// 			}
			if (utils.isAndroid()) {
			  weex.requireModule('app').openMt4();
			} else {
			  if (app.canOpenURL("metatrader5://")) {
			    app.openURL("metatrader5://com.app.test");
			  } else {
			    app.openURL(MT4);
			  }
			}
		}

  }
}
</script>

<style  src="../style/common.css" scoped></style>
<style scoped>
	.my-scroller {
	  margin-top: 0px;
	  margin-bottom: 0px;
	  background-color: white;
	  width: 750px;
	}
	.group-head{
		width: 750px;
		margin-left: 10px;
		margin-right: 10px;
		margin-top: 70px;
		margin-bottom: 20px;
		flex-direction: column;
		align-items: center;
	}
	.group-head-img{
		width: 177px;
		height: 128px;
	}
	.group-head-text{
		font-size: 38px;
		color: #454950;
		margin-top: 38px;
	}
	.group{
		margin-left: 25px;
		margin-right: 25px;
		margin-top: 40px;
	}
	.group-button{
		width: 300px;
		height: 80px;
		border-radius: 5px;
		border-color: #7C7F84;
		border-width: 1px;
		justify-content: center;
		align-items: center;
	}

.alert-show{
		position:absolute;
		left:0px;
		top:300px;
		right:0px;
		bottom:0px;
		align-items:center;
	}
	.alert-modul {
		height: 74px;
		border-radius: 37px;
		align-items: center;
		justify-content: center;
		padding-left: 60px;
		padding-right: 60px;
		/* background-color: rgba(0, 0, 0, 0.7); */
		background-color: #4c4c4c;
		opacity:0.68;
	}
</style>
