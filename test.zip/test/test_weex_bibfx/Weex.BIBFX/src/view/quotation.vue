<template>
<div @viewappear="viewappear" @viewdisappear="viewdisappear" @foreground="foreground" @background="background">
  <status backgroundColor="#FFFFFF"></status>
  <div class="navbar">
    <text class="navbar-title"> {{title}} </text>
    <div style="position:absolute;top:0px;right:0px;bottom:0px;width:170px;justify-content: center;align-items: center;" @click="onloadWebView('交易细则',rules)">
      <text class="navbar-title-r"> 交易细则 </text>
    </div>
  </div>
  <div style="flex:1;width: 750px;backgroundColor: #e8e8e8;">
    <list>
      <header class="title-item">
        <div class="title-item" style="width:750px;">
          <text class="title-left"> 交易品种</text>
          <text class="title-center"> 卖出价</text>
          <text class="title-right"> 买入价</text>
        </div>
      </header>
      <cell class="cell-item" v-for="itemdata in quoteData" @click="showQuote(itemdata)">
        <div class="quoteName">
          <text class="item-name">{{itemdata.symbolName}}</text>
          <text class="item-symbol">{{itemdata.symbol}}</text>
        </div>
        <div :class="['quoteItem',(itemdata.Bid >= itemdata.Open)?'quoteItemUp':'quoteItemDn']">
          <text class="quoteItemText">{{itemdata.Bid}}</text>
          <image v-if="itemdata.Bid" class="quoteItemArrow" :src="assets+(itemdata.Bid<itemdata.Open?'dropw.png':'risew.png')"></image>
        </div>
        <div :class="['quoteItem',(itemdata.Ask >= itemdata.Open)?'quoteItemUp':'quoteItemDn']">
          <text class="quoteItemText">{{itemdata.Ask}}</text>
          <image v-if="itemdata.Ask" class="quoteItemArrow" :src="assets+(itemdata.Bid<itemdata.Open?'dropw.png':'risew.png')"></image>
        </div>
        <div class="quoteItemSp">
          <text class="item-spread">{{itemdata.spread}}</text>
        </div>
      </cell>
    </list>
    <div v-if="!logined && (loginTips.length > 0)" class="loginTips" @click="login">
      <text class="login-tips-text">{{loginTips}}</text>
      <div class="login-tips-btn">
        <text style="font-size: 28px;line-height:48px;color:#ffffff">登录</text>
      </div>
    </div>
    <div v-if="isLoadError" style="position:absolute;left:0px; top:0px;right:0px; bottom:0px;background-color: white;justify-content: center;align-items: center">
      <loadError @refreshNetWorkError="refreshNetWorkError"></loadError>
    </div>
  </div>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
const quote = require('../quote.json')
var dom = weex.requireModule('dom')
var navigator = weex.requireModule('navigator')
var app = weex.requireModule('app')
var http = require('../include/http.js');
var url = require('../include/url.js');
var modal = weex.requireModule('modal');
var navi = weex.requireModule('navigator')
var websocket = weex.requireModule('webSocket')
var storage = require('../include/storage.js');
var utils = require('../include/utils.js');
var firebase = weex.requireModule('firebase');
module.exports = {
  components: {
    navigation: require('../components/navigationBar.vue'),
    'status': require('../components/statusbar.vue'),
    'loadError': require('../components/loadError.vue'),
  },
  data: function() {
    return {
      assets: assetsUrl,
      title: '行情',
      width: 0,
      position: 20,
      channelIndex: -1,
      lastIndex: 0,
      loadingData: false, //加载中
      pageSize: 5,
      pageIndex: 0,
      total: 0,
      contentOffset: 0,
      addquote: assetsUrl + 'add_product.png',
      wsUlr: '',
      rules:'',
      quoteData: [],
      symbolIdStr: '',
      TempItemList: [],
      isRefresh: true,
      loadend: false,
      quoteChannel: {},
      isLoadError: false, //网络加载出错
      outofview: false,
      timerId: 0,
      connecting: 0,
      needUpdate: true, //是否需要更新数据
      utm: '',
      logined: false,
      loginTips: '', // 登录提示语
      loginTipsId: 0,
      loginClicked: false // 防止多次点击事件
    }
  },
  created: function() {
    var that = this;
    var domModule = weex.requireModule('dom');
    this.quoteChannel = new BroadcastChannel('bibfx');
    if (!utils.isAndroid()) {
      this.setupWebsocket();
    }
    domModule.addRule('fontFace', {
      'fontFamily': "GEO415M",
      'src': "url('" + assetsUrl + "geo415m_0.ttf')",
    });
    const wsData = new BroadcastChannel('refreshData');
    wsData.onmessage = function(event) {
      that.isRefresh = true;
      that.loading = true;
    }

    let quoteJson = storage.getItemSync('quote');
    if (!utils.isBlankString(quoteJson) && quoteJson.length > 4) {
      this.quoteData = JSON.parse(quoteJson);
    } else {
      this.quoteData = quote;
    }
    for (let i = 0; i < that.quoteData.length; i++) {
      this.symbolIdStr = that.symbolIdStr + ',' + that.quoteData[i].symbol
    }

    storage.getItem('commonUrl', function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        that.cmsApiHost = commonUrl.cmsApi; //接口基址
        that.imageBaseUrl = commonUrl.imageBaseUrl; //图片基址
        that.contentBaseUrl = commonUrl.contentBaseUrl; //文章基址
        that.wsUlr = commonUrl.quoteSocketUrl;
        that.rules = commonUrl.rules;//交易细则
      }
      storage.getItem('contentIdList', function(value) {
        if (value && value.length > 0) {
          var contentIdList = JSON.parse(value);
          that.loginTipsId = contentIdList.loginTips; //id未配置正确
          that.getLoginTips();
        }
      });
      that.getWSConFig();
    });
  },
  methods: {
    // 接收网络错误的点击事件的回调
    refreshNetWorkError: function() {
      this.getServerData();
    },
    viewappear: function() {
      var that = this;
      this.needUpdate = true;
      this.loginClicked = false;
      if (weex.supports('@module/app')) {
        weex.requireModule('app').setStatusBarStyle(0);
      }
      storage.getItem('userInfo', function(data) {
        if (data) {
          let user = JSON.parse(data);
          if (user.userName) {
            that.logined = true;
          } else {
            that.logined = false;
          }
        }
      });
    },
    viewdisappear: function() {
      this.needUpdate = false;
    },
    foreground: function() {
      this.outofview = false;
      this.timerId++;
      this.connectWebSocket(this.timerId);
      this.setupWebsocket();
    },
    background: function() {
      this.outofview = true;
      this.timerId++;
      websocket.close();
    },
    logEvent: function(name) {
      if (firebase) {
        firebase.logEventWithName(name);
      }
    },
    getWSConFig: function() {
      let that = this;
      that.getServerData();
      that.connectWebSocket();
      if (utils.isAndroid()) {
        that.setupWebsocket();
      }
    },
    onloadWebView: function(title, url) {
      var json = {
        'title': title,
        'url': url
      }
      storage.setItem('app-url', JSON.stringify(json))
      navigator.push({
        url: bundleUrl + 'webview.js',
        animated: "true",
        swipePop: "true",
      }, event => {})
    },
    showQuote(item) {
      if (!utils.isBlankString(item.symbol)) {
        let pro = 'Quotes_quote_' + item.symbol;
        this.logEvent(pro);
      }
      storage.setItem('topproductdata', JSON.stringify(item));
      navi.push({
        url: bundleUrl + 'quote.js',
        animated: "false",
      }, event => {

      })
    },
    pushClick: function() {
      this.logEvent('Quotes_page_more');
      navi.push({
        disableBackPan: 'true',
        url: bundleUrl + 'myquote.js',
        animated: "true",

      }, event => {})
    },
    getServerData: function() {
      var that = this;
      if (utils.isBlankString(that.cmsApiHost)) {
        return;
      }
      let url = that.cmsApiHost + "/Quotes/Last?SymbolNames=" + that.symbolIdStr;
      http.get(encodeURI(url), function(response) {
        that.isLoadError = false;
        if (response.status < 200) {
          that.isLoadError = true;
        } else {
          that.loadend = true;
        }
        for (let i = 0; response.data && i < response.data.length; i++) {
          that.parseSocketData(JSON.stringify(response.data[i]));
        }
        if (response.status < 200) {
          setTimeout(() => {
            that.getServerData()
          }, 5000);
        }
      });
    },
    connectWebSocket: function(id = 0) {
      if (true == this.outofview || id != this.timerId) {
        return;
      }
      websocket.WebSocket(this.wsUlr, '');
    },
    onopen: function() {
      if (true == this.outofview) {
        return;
      }
      this.sendWebSocketStr();
    },
    setupWebsocket: function() {
      var that = this;
      websocket.onopen(this.onopen.bind(this));
      websocket.onmessage(function(e) { //服务器返回消息
        if (true == that.outofview) {
          return;
        }
        if (true == that.needUpdate) {
          that.parseSocketData(e.data);
        }
        that.quoteChannel.postMessage(e.data);
      });
      websocket.onerror(function(e) { //错误事件的监听器
        if (true == that.outofview || e.data == "closed" || e.data == "close") {
          return;
        }
        let id = that.timerId;
        if (0 == that.connecting) {
          that.connecting = 1;
          setTimeout(() => {
            that.connecting = 0;
            that.connectWebSocket(id)
          }, 10000);
        }

      });
      websocket.onclose(function(e) { //关闭事件的监听器
        console.log("websocket-onclose" + JSON.stringify(e));
      });
    },
    sendWebSocketStr: function() {
      if (true == this.outofview) {
        return;
      }
      websocket.send("Symbols " + this.symbolIdStr.replace(/,/g, " "));
    },
    parseSocketData: function(resp) {
      let data = JSON.parse(resp)
      for (let i = 0; i < this.quoteData.length; i++) {
        if (this.quoteData[i].symbol == data.Symbol || this.quoteData[i].symbol == data.SymbolName) {
          this.$set(this.quoteData[i], 'Ask', parseFloat(data.Ask).toFixed(this.quoteData[i].fixed))
          this.$set(this.quoteData[i], 'Bid', parseFloat(data.Bid).toFixed(this.quoteData[i].fixed))
          this.$set(this.quoteData[i], 'High', data.High)
          this.$set(this.quoteData[i], 'Low', data.Low)
          this.$set(this.quoteData[i], 'Open', data.Open)
          this.$set(this.quoteData[i], 'YClose', data.YClose)
          this.$set(this.quoteData[i], 'spread', utils.calculationSpread(data.Ask, data.Bid, this.quoteData[i].spreadSize, this.quoteData[i].mul))
          break
        }
      }
    },
    login: function() {
      if (this.loginClicked) {
        return;
      }
      this.logEvent('Quotes_login');
      this.loginClicked = true;
      storage.setItem('user-original-fromLogin', 'market');
      navigator.push({
        url: bundleUrl + 'userLogin.js',
        animated: "true",
        swipePop: "true",
      }, event => {})
    },
    getLoginTips: function() {
      var that = this;
      if (undefined == this.cmsApiHost) {
        return;
      }
      var url = this.cmsApiHost + '/ContentUnion/Site?format=json&id=' + that.loginTipsId;
      http.get(url, function(response) {
        if (response.ok && response.data && response.data.Results && response.data.Results.length > 0) {
          var result = response.data.Results[0];
          if (result) {
            that.loginTips = result.Summary;
          }
        }
      });
    }
  },
}
</script>

<style scoped>
.wrap {
  overflow: hidden;
}
.navbar {
  width: 750px;
  height: 88px;
  background-color: #ffffff;
  align-items: center;
  justify-content: center;
}

.navbar-title {
  font-size: 36px;
  color: white;
  line-height: 54px;
  text-align: center;
  color: #333333;
}

.navbar-title-r {
  font-size: 28px;
  line-height: 42px;
  color: #999999;
}

.channel {
  width: 750px;
  padding-left: 30px;
  padding-right: 30px;
  justify-content: space-between;
  flex-direction: row;
  border-bottom-width: 20px;
  border-bottom-color: #e8e8e8;
}

.scroller {
  width: 750px;
  height: 88px;
  flex-direction: row;
  /* padding-left: 20px;
                    padding-right: 20px; */
  justify-content: flex-end;
  /* margin-right: 5px; */
}

.channel-item {
  /* margin-left: 60px;
        margin-right: 40px; */
  /* flex: 1; */
  justify-content: center;
  align-items: center;
  /* flex: 1; */
}

.cell-item {
  width: 750px;
  height: 150px;
  flex-direction: row;
  background-color: white;
  justify-content: center;
  align-items: center;
  /* border-width: 1px; */
  border-bottom-width: 1px;
  border-bottom-color: #e1e1e1;
}

.title-item {
  flex-direction: row;
  background-color: white;
  justify-content: center;
  align-items: center;
  height: 80px;
  background-color: #EAF1FD;
}

.loading-indicator {
  height: 50px;
  width: 50px;
  color: #9ba1ab;
}

.loading-indicator-text {
  color: #9ba1ab;
  font-size: 30px;
  margin-left: 8px;
  text-align: center;
}

.item-name {
  font-size: 30px;
  line-height: 44px;
  color: #333333;
  text-align: left;
}

.item-spread{
  font-size: 30px;
  line-height: 44px;
  color: #333333;
  text-align: center;
}

.item-symbol {
  font-size: 28px;
  line-height: 42px;
  color: #999999;
  text-align: left;
}

.title-left {
  /*margin-left: 30px;*/
  /*width: 175px;*/
  font-size: 28px;
  line-height: 42px;
  flex: 1;
  color: #454950;
  text-align: center;
}

.title-center {
  width: 190px;
  font-size: 28px;
  line-height: 42px;
  color: #454950;
  text-align: center;
  margin-right: 30px;
}

.title-right {
  width: 190px;
  font-size: 28px;
  line-height: 42px;
  color: #454950;
  text-align: center;
  margin-right: 30px;
}

.content {
  flex: 1;
  flex-direction: row;
}

.content-item {
  width: 750px;
  height: 240px;
  flex-direction: row;
  padding-left: 30px;
  padding-right: 30px;
  padding-top: 40px;
  padding-bottom: 40px;
  border-bottom-width: 1px;
  border-bottom-color: #f1f1f1;
}

.content-title {
  font-size: 32px;
  color: #454950;
  lines: 1;
  text-overflow: ellipsis;
}

.content-subtitle {
  font-size: 26px;
  color: #9ba1ab;
  text-overflow: ellipsis;
  lines: 2;
}

.content-date {
  font-size: 26px;
  color: #9ba1ab;
  lines: 1;
}

.content-image {
  width: 284px;
  height: 160px;
}

.div-normal {
  border-bottom-color: #ffffff;
}

.div-highlight {
  /*border-bottom-color: #e9302e;*/
  border-bottom-color: #2e74e9;
}

.normal {
  font-size: 28px;
  color: #454950;
}

.highlight {
  font-size: 28px;
  /*color: #e9302e;*/
  color: #2e74e9;
}

.quote-tips {
  margin-top: 20px;
  margin-bottom: 20px;
  justify-content: center;
  align-items: center;
  flex-direction: row;
}

.quote-tips-text {
  font-size: 24px;
  color: #9ba1ab;
  text-align: center;
}

.login-tips-text {
  flex: 1;
  font-size: 28px;
  lines: 1;
  text-overflow: ellipsis;
  line-height: 40px;
  color: #ffffff;
  margin-left: 32px;
}

.login-tips-btn{
  width: 120px;
  height: 48px;
  border-radius: 4px;
  align-items: center;
  justify-content: center;
  margin-right: 32px;
  background-color: #2E74E9;
}

.quoteName{
  font-size: 28px;
  line-height: 42px;
  margin-left: 32px;
  flex: 1;
  color: #454950;
  text-align: left;
}

.quoteItem {
  margin-left: 10px;
  margin-right: 32px;
  width: 190px;
  height: 60px;
  flex-direction: row;
  border-radius: 8px;
  justify-content: center;
  align-items: center;
}

.quoteItemUp {
  background-color: #24B267;
}

.quoteItemDn {
  background-color: #F14342;
}

.quoteItemText {
  font-size: 30px;
  line-height: 45px;
  color: #ffffff;
}
.quoteItemArrow{
  width: 14px;
  height: 21px;
  margin-left: 5px;
}

.bold {
  font-weight: bold;
}

.quoteItemSp {
  position: absolute;
  right: 200;
  top: 56px;
  width: 80px;
  height: 36px;
  justify-content: center;
  align-items: center;
  background-color: #ffffff;
  border-radius: 4px;
}

.loginTips{
  position: absolute;
  bottom: 0;
  left: 0px;
  right: 0px;
  height: 70px;
  background-color: rgba(3,12,27,0.7);
  align-items:center;
  flex-direction:row;
  justify-content: space-between;
}
</style>
