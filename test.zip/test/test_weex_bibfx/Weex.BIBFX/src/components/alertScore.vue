<template>
  <div v-if="show" class="bg" @click="click">
    <div class="container">

      <image style="position: absolute;right: 0;bottom: 0;width: 370px;height: 172px" :src="alert_bottom_right" resize="cover"></image>

      <div class="close" @click="close">
        <image style="width: 22px;height: 22px;" :src="closeimg" resize="contain"></image>
      </div>

      <div class="content">
        <div class="header">
          <image style="flex:1" :src="teacherData.img"  resize="contain"></image>
        </div>
        <text class="font26 text" style="margin-top: 8px;line-height: 36px;">{{teacherData.name}}</text>
        <text class="font26 text">{{teacherData.time}}</text>
        <text class="font28 text" style="margin-top: 4px">请为本次课程打个分吧！</text>
        <text class="font26" style="margin-top: 14px;color: #5c8eea;text-decoration:underline;" @click="allStar">全五星，再接再厉!</text>
      </div>
      <div class="score">
        <template v-for="(item,index) in scoreData">
          <div class="score-item">
            <text class="font26 text" style="margin-right: 10px">{{item.text}}</text>
            <template v-for="(subItem,subIndex) in item.star" >
              <image v-if="subItem" class="star" :src="star_fill" resize="contain" @click="touchStar(index,subIndex)"></image>
              <image v-if="!subItem" class="star" :src="star_empty" resize="contain" @click="touchStar(index,subIndex)"></image>
            </template>
<!--            <image class="star" :src="star_fill" resize="contain"></image>-->
<!--            <image class="star" :src="star_fill" resize="contain"></image>-->
<!--            <image class="star" :src="star_fill" resize="contain"></image>-->
<!--            <image class="star" :src="star_empty" resize="contain"></image>-->
<!--            <image class="star" :src="star_empty" resize="contain"></image>-->
          </div>
        </template>
      </div>

      <div class="bottom">
        <text class="font32" style="color: #ffffff;margin-right: 24px" @click="close">取消</text>
        <text class="font32" style="color: #ffffff;margin-right: 24px">|</text>
        <text class="font32" style="color: #ffffff;" @click="submit">提交</text>
      </div>

    </div>
  </div>


</template>

<script>
  const assetsUrl = require('../include/base-url.js').assetsUrl();
  export default {
    props: {
      show: { default: false }
    },
    data(){
      return{
        star_fill: assetsUrl + 'calendar_star_solid.png',
        star_empty: assetsUrl + 'calendar_star_white.png',
        closeimg: assetsUrl + 'close_gray.png',
        alert_bottom_right: assetsUrl + 'alert_bottom_right.png',

        teacherData:{
          img: '',
          name: '彭老师',
          time: '16:00 ~ 17:00'
        },
        scoreData:[
          {text: '教学质量', star : [false,false,false,false,false]},
          {text: '讲师实力', star : [false,false,false,false,false]},
          {text: '交易部署', star : [false,false,false,false,false]}
        ]
      }
    },
    methods:{
      click:function(){

      },
      close:function () {
        this.show = false;
        this.$emit('close')
      },
      submit:function () {
        this.show = false;
        this.$emit('submit')
      },
      allStar:function () {
        let arr = this.scoreData;
        for (let i = 0 ; i < arr.length; i++){
           let star = arr[i].star;
           for (let j = 0; j < star.length; j++){
             star[j] = true;
           }
        }
        for (let i = 0; i < arr.length; i ++){
          this.scoreData.splice(i,1,arr[i]);
        }
      },
      touchStar:function (index,subIndex) {
        console.log('TTTTTTTTT')
        let arr = this.scoreData;
        for (let i = 0 ; i < arr.length; i++){
          let star = arr[i].star;
          if (index === i){
            for (let j = 0; j < star.length; j++){
              if (j <= subIndex) {
                star[j] = true;
              } else {
                star[j] = false;
              }
            }
          }
        }
        for (let i = 0; i < arr.length; i ++){
          this.scoreData.splice(i,1,arr[i]);
        }
      }

    }
  }
</script>
<style src="../style/common.css" scoped></style>
<style scoped>
  .bg{
    position: fixed;
    left: 0px;
    top: 0px;
    right: 0px;
    bottom: 0px;
    /*兼容H5异常*/
    z-index: 99999;
    justify-content: center;
    align-items: center;
    background-color: rgba(0, 0, 0, 0.5);
  }
  .container{
    background-color: white;
    /*position: absolute;*/
    width: 600px;
    height: 800px;
    padding-top: 46px;
    padding-left: 50px;
    padding-right: 50px;
    border-radius: 8px;

    flex-direction: column;
  }
  .close{
    position: absolute;
    top: 0;
    right: 0;
    width: 60px;
    height: 60px;
    justify-content: center;
    align-items: center;
    flex-direction: row;
  }
  .content{
    justify-content: center;
    align-items: center;
    flex-direction: column;
  }
  .header{
    border-width: 2px;
    border-color: #b0805d;
    width: 98px;
    height: 98px;
    border-radius: 50%;
  }
  .text{
    color: #333333;
  }
  .score{
    margin-top: 36px;
  }
  .score-item{
    /*width: 300px;*/
    height: 44px;
    margin-bottom: 30px;

    justify-content: center;
    align-items: center;
    flex-direction: row;
    flex-wrap: nowrap;
  }
  .star{
    width: 48px;
    height: 44px;
    margin-left: 20px;
  }
  .bottom{
    position: absolute;
    right: 30px;
    bottom: 20px;
    width: 200px;
    flex-direction: row;
    align-items: center;
    justify-content: center;
  }

</style>
