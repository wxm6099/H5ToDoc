<template>
  <div v-if="show" class="bg" @click="maskClick">
    <div class="container" ref="test2">

      <image style="position: absolute;top: 0;left: 0;right: 0;bottom: 0;" :src="alert_bg" resize="cover"></image>
      <image style="position: absolute;left: 0;top: 0;width: 122px;height: 94px" :src="alert_top_left" resize="cover"></image>
      <image style="position: absolute;right: 0;top: 0;width: 92px;height: 74px" :src="alert_top_right" resize="cover"></image>


      <div class="close" @click="close()">
        <image style="width: 26px;height: 26px;margin-right: 20px;margin-top: 20px" :src="alert_close" resize="cover"></image>
      </div>
      <div class="content">
        <div class="title">
          <text style="color: rgb(51,51,51);line-height: 60px;font-size: 28px;margin-right: 40px;">{{dataSource.title}}</text>
          <text style="color: rgb(51,51,51);line-height: 60px;font-size: 28px;">{{dataSource.subTitle}}</text>
        </div>
        <div class="desc">
          <scroller show-scrollbar="false">
            <richtext style="color: rgb(102,102,102);line-height: 40px;font-size: 24px">{{dataSource.desc}}</richtext>
          </scroller>
        </div>
      </div>
    </div>
  </div>


</template>

<script>
  const assetsUrl = require('../include/base-url.js').assetsUrl();
  const animation = weex.requireModule('animation');
  export default {
    props: {
      show: { default: false },
      data: { default: {} }
    },
    data(){
      return{
        alert_top_right: assetsUrl + 'alert_top_right.png',
        alert_top_left: assetsUrl + 'alert_top_left.png',
        alert_bg: assetsUrl + 'alert_bg.png',
        alert_close: assetsUrl + 'alert_close.png',
        dataSource: {
          title: '',
          subTitle: '',
          desc:''
        }
      }
    },
    watch: {
      data(){
        if (this.data) {
          this.dataSource.title = this.data.user.name;
          this.dataSource.subTitle = this.getBroadMsgTime(this.data);
          this.dataSource.desc = this.getMsgText(this.data);
        }
      },
      show(){
        let that = this;
        if (this.show) {
          setTimeout(function () {
            that.move(150);
          },100)
        }
      }

    },
    methods:{
      maskClick:function(){
        
      },
      close:function () {
        // this.show = false;
        this.$emit('close')
      },
      getBroadMsgTime:function(item){
        var msgTime
        if (item.sendOn) {
          msgTime = parseInt(item.sendOn.replace(/[^\d]/g, '')) / 10000
        } else {
          msgTime = parseInt(item.created / 1000000)
        }
        var time = new Date(msgTime)
        return this.addZero(time.getHours()) + ':' + this.addZero(time.getMinutes())
      },
      getMsgText: function (item) {
        if (!item) {
          return ''
        }
        let text = '';
        text = item.text.replace(/<br>/g, '\n');
        text = text.replace(/}/g, '} ');
        return text;
      },
      addZero: function (obj) {
        return obj < 10 ? '0' + obj : obj
      },

      move:function (bottom) {
        var testEl = this.$refs.test2;
        animation.transition(testEl, {
          styles: {
            transform: `translate(0, ${bottom}px)`,
            transformOrigin: 'center center',
            opacity: 1
          },
          duration: 300, //ms
          timingFunction: 'ease',
          delay: 0, //ms
          needLayout: true,
        })
      },

    }
  }
</script>
<style src="../style/common.css" scoped></style>
<style scoped>
  .bg{
    position: fixed;
    left: 0px;
    top: 0px;
    right: 0px;
    bottom: 0px;
    /*兼容H5异常*/
    z-index: 99999;
    justify-content: center;
    align-items: center;
    background-color: rgba(0, 0, 0, 0.5);
  }
  .container{
    background-color: white;
    /*position: absolute;*/
    width: 688px;
    height: 600px;
    padding-top: 88px;
    padding-bottom: 60px;
    padding-left: 50px;
    padding-right: 50px;

    border-radius: 8px;

    margin-bottom: 300px;
    opacity: 0;

  }
  .close{
    position: absolute;
    right: 0;
    top: 0;

    width: 92px;
    height: 74px;
    justify-content: flex-start;
    align-items: flex-end;
  }
  .content{

  }
  .title{

    height: 60px;
    line-height: 60px;
    margin-bottom: 12px;

    justify-content: flex-start;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
  }
  .desc{
    /*width: 100%;*/
    height: 380px;
    overflow: hidden;
  }

</style>
