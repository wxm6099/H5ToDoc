<template>
<div>
  <!-- <div v-if="isIOS" :style="{width: '750px', height: '40px', backgroundColor: backgroundColor}"> -->
  <div :style="{width: '750px', 'height': getStatusHeight(), backgroundColor: backgroundColor}">
  </div>
</div>
</template>

<script>
import instance from '../include/instance'
var utils = require('../include/utils.js');
var app = weex.requireModule('app');
module.exports = {
  props: {
    backgroundColor: {
      default: '#FFFFFF'  //默认白色状态栏
    }
  },
  computed: {

  },
  data: function() {
    return {
      isIOSX: utils.iphonex()
    }
  },
  methods:{
     getStatusHeight:function () {
       if (app&&utils.isAndroid()){
         return  app.getStatusbarHeight();
       }
       return  this.isIOSX?'88px':'40px'
     }
  }
}
</script>
