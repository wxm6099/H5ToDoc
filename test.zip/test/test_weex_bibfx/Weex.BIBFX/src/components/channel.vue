<template>
    <div class="wrapper">
        <scroller class="scroller" scrollDirection="horizontal"  show-scrollbar="false">
            <div style="position: absolute;  bottom: 0;width:{{width}};height: 4px;left:{{position}}; background-color: red;"></div>
            <text v-for="tabname in tabNameList" :class="['i-c',index == tabname.id?'c-act':'']"
                  :ref="'channel'+tabname.id " @click="channelClick(tabname.id)">{{tabname.symbolTypeName}}
            </text>
        </scroller>
    </div>
</template>

<script>
    var dom = weex.requireModule('dom');
    var animation = weex.requireModule('animation')
    var modal = weex.requireModule('modal')
    var storage = require('../include/storage.js');
    export default {
        data() {
            return {
                string: require('../include/string.js'),
                index: 0,
                selectorindex: 0,
                itemwidth: 187.5,//栏目格子大小
                position: 61.25,
                width: 65,
                tabNameList: [],
            }
        },
        mounted() {
        },

        created() {
            this.getTabName();
        },
        methods: {
            scroll: function (e) {
                var ratio = parseFloat(e.offsetXRatio);
                // console.log("ratio :"+ratio);
                console.log("scroll 2: ");
                if (this.index > 0) {
                    this.position = (this.itemwidth - this.width) / 2 + this.itemwidth * this.index - (this.itemwidth * ratio);
                } else {
                    this.position = (this.itemwidth - this.width) / 2 - (this.itemwidth * ratio);
                }
            },
            channelClick: function (index) {
                console.log("scroll 3: ");
                var params = {
                    index: index,
                    selectorindex: index,
                };
                this.$emit('change', params);
            },
            chooseChannel: function (index) {
                console.log("scroll 4: ");
                this.index = index;
                this.position = (this.itemwidth - this.width) / 2 + this.itemwidth * this.index;
                console.log("scroll 4 position: "+position);
                var el = this.$refs['channel' + this.index][0];
                console.log("scroll 4 el: "+el);
                var offset = -this.itemwidth * Math.min(this.index, 2);
                console.log("scroll 4 offset: "+offset);
                if (el) {
                    // 320
                    dom.scrollToElement(el, {offset: offset});
                }

            },
            getTabName: function () {
                var that = this;
                storage.getItem('quoteList',function (value) {
                    if ('' == value || value == undefined || value.length <= 0) {
                        return
                    }
                    var quote = JSON.parse(value);
                    that.tabNameList.push({symbolTypeName: "自选", id: 0});
                    that.tabNameList.push({symbolTypeName: "全部", id: 1});
                    if (quote) {
                        for (var i = 0; i < quote.length; i++) {
                            that.tabNameList.push({symbolTypeName: quote[i].symbolTypeName, id: i + 2});
                        }
                    }
                });
            }
        }
    }
</script>
<style scoped>
    .wrapper {
        position: relative;
        top: 0px;
        left: 0px;
        right: 0px;
        height: 90px;
        z-index: 10;
        number: 2;
        background-color: #FBFBFB;
        border-bottom-width: 1px;
        border-bottom-color: #F0F0F0;
        border-bottom-style: solid;
        flex-direction: row;
    }

    .scroller {
        position:absolute;
        right: 0px;
        left: 0px;
        top: 0px;
        height: 90px;
        flex-direction: row;
    }

    .i-c {
        padding-top: 25px;
        width: 187.5px;
        font-size: 30px;
        color: black;
        /*border-width: 2px;
        border-color: red;*/
        text-align: center;
    }

    .c-act {
        color: red;
    }

</style>
