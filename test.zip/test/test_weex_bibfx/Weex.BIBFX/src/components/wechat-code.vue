<template>
    <div v-if="showLoading" class="loading-need-mask " :style="maskStyle" @click="maskClicked">
            <div class='loading-box' :aria-hidden="true"  @click="maskClicked" @longpress="onlongpress">
                <image ref="code" v-if="url" :src="url" class="loading-trip-image" resize="contain" quality="original"></image>
                <text v-if="loadingText" class="loading-text">{{loadingText}}</text>
            </div>
    </div>
</template>

<style scoped>
    .loading-need-mask {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: white;
        /*background-color: rgba(0, 0, 0, 0.2);*/
        align-items: center;
        justify-content: center;
    }

    .loading-box {
        width: 455px;
        height: 455px;
        align-items: center;
        justify-content: center;
        /*background-color: rgba(0, 0, 0, 0.8);*/
    }
    .trip-loading {
        /*background-color: rgba(0, 0, 0, .2);*/
    }
    .loading-trip-image {
        height: 420px;
        width: 455px;
        /*border-width: 1px;*/
        /*border-style: solid;*/
    }
    .loading-text {
        color: #000000;
        font-size: 28px;
        height: 35px;
        width: 455px;
        text-align: center;
    }
</style>

<script>
    var Utils = require('../include/utils.js');
    var assets = require('../include/base-url.js').assetsUrl();
    var modal = weex.requireModule('modal');
    export default {
        props: {
            show: {
                type: Boolean,
                default: false
            },
            url: {
                type: String,
                default: ''
            },
            loadingText: {
                type: String,
                default: ''
            },
            interval: {
                type: [Number, String],
                default: 0
            },
            needMask: {
                type: Boolean,
                default: false
            },
            maskStyle: {
                type: Object,
                default: () => ({})
            }
        },
        data: () => ({
            showLoading: false,
            tid: 0,
        }),
        watch: {
            show() {
                this.setShow();
            }
        },
        computed: {},
        created() {
            this.setShow();
        },
        methods: {
            maskClicked() {
                // this.show = false;
                this.needMask && (this.$emit('wxcLoadingMaskClicked', {}));
            },
            onlongpress(event) {
              var that = this;
                const $image = this.$refs.code;
                $image.save(result => {
                    if (result.success) {
                        // this.show = false;
                         modal.toast({
                            message:"保存成功",
                            duration: 0.3
                        })
                        that.$emit('wxcLoadingMaskClicked');
                    } else {
                        // modal.toast({
                        //     message: result.errorDesc,
                        //     duration: 0.3
                        // })
                    }
                })
            },
            setShow() {
                const {interval, show, showLoading} = this;
                const stInterval = parseInt(interval);
                if (this.tid != 0) {
                    clearTimeout(this.tid);
                }
                if (show) {
                    if (showLoading) {
                        return;
                    }
                    if (stInterval === 0) {
                        this.showLoading = true;
                    } else {
                        this.tid = setTimeout(() => {
                            this.showLoading = true;
                        }, stInterval);
                    }
                } else {
                    this.showLoading = false;
                }
                // console.log("-------this.showLoading:"+this.showLoading);
            }
        }
    };
</script>
