<template>
<div class="wrap" @click ="wxcCellClicked">
    <image :src="checkIcon"
           class="checkbox"></image>
    <text :style="{color:textColor}"
          class="title-text">{{title}}</text>
  </div>
</template>

<script scoped>
var assetsUrl = require('../include/base-url.js').assetsUrl();

module.exports = {
  props: {
    title: {
      type: String,
      require: true
    },
    value: {
      type: [String, Number, Object],
      require: true
    },
    disabled: {
      type: Boolean,
      default: false
    },
    checked: {
      type: Boolean,
      default: false
    },
    config: {
      type: Object,
      default: () => ({})
    }
  },
  data:function(){
    return{
      icon: [assetsUrl+'checkbox/checked.png',assetsUrl+'checkbox/unchecked.png', assetsUrl+'checkbox/checked_disabled.png',assetsUrl+'checkbox/unchecked_disabled.png'],
      color: '#3D3D3D',
      innerChecked: false
    }
  },
  computed: {
    checkIcon () {
      const { icon, disabled, innerChecked, config } = this;
      const mergeIcon = [...icon];
      config.checkedIcon && (mergeIcon[0] = config.checkedIcon);
      config.unCheckedIcon && (mergeIcon[1] = config.unCheckedIcon);
      config.checkedDisabledIcon && (mergeIcon[2] = config.checkedDisabledIcon);
      config.unCheckedDisabledIcon && (mergeIcon[3] = config.unCheckedDisabledIcon);
      if (disabled) {
        return mergeIcon[innerChecked ? 2 : 3];
      } else {
        return mergeIcon[innerChecked ? 0 : 1];
      }
    },
    textColor () {
      const { innerChecked, disabled, config } = this;
      const checkedColor = config.checkedColor ? config.checkedColor : '#EE9900';
      return innerChecked && !disabled ? checkedColor : '#3D3D3D';
    }
  },
  watch: {
    checked (newChecked) {
      this.innerChecked = newChecked;
      console.log("rdddd newChecked:"+this.innerChecked);
    }
  },
  created () {
    const { checked } = this;
    this.innerChecked = checked;
  },
  methods: {
    wxcCellClicked () {
      const { disabled, innerChecked, value } = this;
      if (!disabled) {
        this.innerChecked = !innerChecked;
        this.$emit('checkBoxItemChecked', { value, checked: this.innerChecked })
      }
    }
  }
}
</script>

<style scoped>
.wrap {
  flex-direction: row;
  align-items: center;
  border-color: red;
}

.checkbox {
  width: 34px;
  height: 34px;
  margin: 5px;
}

.title-text {
  font-size: 30px;
  margin-left: 20px;
}
</style>
