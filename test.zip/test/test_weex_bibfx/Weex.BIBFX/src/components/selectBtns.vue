<template>
  <div v-if="show" class="container" @click="maskClick">
    <div class="content-bg">
      <div class="content">
        <div v-for="(data,index) in datas" :class="[index==0?'content-cell':'content-cell-line']" @click="btnClick(data)">
          <text class="text-cell">{{data.title}}</text>
          <image class="image-icon" :src="data.img"></image>
        </div>
      </div>
      <div class="cancel-btn" @click="cancelClick">
        <text class="text-cancel">取消</text>
      </div>
    </div>
  </div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var globalEvent = weex.requireModule('globalEvent');
var app = weex.requireModule('app');
var storage = require('../include/storage.js');

module.exports = {
  props: {
    show: { default: false },
    datas: [],
  },
  data: function() {
    return {
      assets: assetsUrl,
    }
  },
  created:function() {

  },
  methods: {
    maskClick:function(){

    },
    btnClick:function(data){
      this.show = false;
      this.$emit('btnClick',data.title);
    },
    cancelClick:function(){
      this.show = false;
      this.$emit('cancel');
    },
  }
}
</script>

<style scoped>
.container {
  position: fixed;
  left: 0px;
  top: 0px;
  right: 0px;
  bottom: 0px;
  /*兼容H5异常*/
  z-index: 99999;
  justify-content: flex-end;
  align-items: center;
  background-color: rgba(0, 0, 0, 0.6);
}
.content-bg {
  flex: 1px;
  width: 686px;
}
.content {
  flex: 1;
  background-color: #FFFFFF;
  border-radius: 20px;
}
.content-cell-line {
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin-left: 46px;
  margin-right: 46px;
  height: 110px;
  border-top-width: 1px;
  border-top-color: #e5e7ec;
}
.content-cell {
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  height: 110px;
  margin-left: 46px;
  margin-right: 46px;
}
.image-icon{
  width: 57px;
  height: 48px;
}
.text-cell{
  font-size: 36px;
  line-height: 54px;
  text-align: center;
  color: #333333;
}
.cancel-btn{
  margin-top:20px;
  margin-bottom: 20px;
  background-color:#FFFFFF;
  border-radius: 20px;
  height:106px;
  justify-content: center;
  align-items: center;
}
.text-cancel{
  font-size: 36px;
  line-height: 54px;
  text-align: center;
  color: #518deb;
  font-weight: bold;
}
</style>
