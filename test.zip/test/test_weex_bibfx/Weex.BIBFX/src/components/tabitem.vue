<template>
  <div
    :style="{ backgroundColor: backgroundColor }"
    class="container"
    @click="onclickitem">
    <image
      :src="icon"
      class="tab-icon"></image>
    <text
      :style="{ color: titleColor }"
      class="tab-text">{{title}}</text>
  </div>
</template>

<style scoped>
  .container {
    flex: 1;
    flex-direction: column;
    align-items:center;
    justify-content:center;
    height: 100;
    /* border-top-color: #F1F1F1;
    border-top-style: solid;
    border-top-width: 1px; */
  }
  .top-line {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 2;
  }
  .tab-icon {
    /* margin-top: 5; */
    width: 50;
    height: 50;
  }
  .tab-text {
    margin-top: 8;
    text-align: center;
    font-size: 22px;
  }

  .tab-icon-top {
  margin-top: -20px;
  width: 110;
  height: 100;
}
</style>

<script>
  module.exports = {
    props: {
      index: { default: 0 },
      title: { default: '' },
      titleColor: { default: '#9ba1ab' },
      icon: { default: '' },
      backgroundColor: { default: '#FFFFFF' },
    },
    methods: {
      onclickitem: function (e) {
        var params = {
          index: this.index
        };
        this.$emit('tabItemOnClick', params);
      }
    }
  }
</script>
