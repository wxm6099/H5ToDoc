<template>
  <div @click="maskClick" class="background">
    <div class="flexH tabbar">
      <div class="tabYellowView" @click="clickTabTitle(true)"></div>
      <text class="tabTitle" @click="clickTabTitle(true)">{{showItem.title}}</text>
      <image class="tabSelectIcon" :src="tabSelectIcon" @click="clickTabTitle(true)"></image>
      <div v-if="login.isLogin" class="tabRightView-bg flexH" @click="clickTabTitle(false)">
        <text v-if="!course.isNo" class="tabName">{{course.teacher}}</text>
        <image v-if="!course.isNo" class="tabLiveIcon" :src="tabLiveIcon"></image>
        <text v-if="!course.isNo" class="tabTime">{{course.time}}</text>
        <text v-if="course.isNo" class="tabTips">周一至周五早上9:00，约你谈金论银</text>
      </div>
      <div v-if="!login.isLogin" class="tabRightView-bg flexH" @click="clickTabTitle(false)">
        <text class="tabTimeDown-title">今日剩余观看时间：</text>
        <text class="tabTimeDown-time">{{login.downTime}}</text>
      </div>
    </div>
    <cycleslider class="content" :index="showItem.index" auto-play="false" infinite="false" bounces="false" scrollable="false" forbidSlideAnimation="true" scroll-direction="horizontal">
      <div style="width:750px;" @click="touchSlider">
        <list show-scrollbar=false style="width:750px;" ref="list1"  @scrollstart="scrollstart"  @scroll="touchScroll" @scrollend="scrollend">
          <cell v-for="(item,i) in messages" :key="updateNum*10+1" :ref="'mainMessage'+i" @click="touchSlider">
            <div style="width: 750px;margin-top:20px;margin-bottom:10px;">
              <div class="message-bg">
                <div v-if="loginUser.uid!=item.user.uid  || !login.isLogin" class="messageTitle">
                  <text :class="[item.user.type>=30?'userNickName-text-g':'userNickName-text-w']">{{item.user.name}}</text>
                  <text v-if="item.user.type==50" class="userIdentity-text">讲师</text>
                  <text v-if="item.user.type==51" class="userIdentity-text">主播</text>
                  <text class="userSendTime-text">{{getMsgTime(item,true)}}</text>
                </div>
                <div v-if="item.type!='file' && item.m_type!='file'">
                  <div v-if="login.isLogin && loginUser.uid==item.user.uid" class="senderRichText-bg">
                    <richtext enableCopy="true" :atColor="atMessage.atMyColor" class="senderRichText" :style="{color:item.user.textColor}">
                      <span>{{getMsgText(item)}}</span>
                    </richtext>
                  </div>
                  <richtext v-if="loginUser.uid!=item.user.uid || !login.isLogin" enableCopy="true" :atColor="atMessage.atColor" class="receiverRichText" :style="{color:item.user.textColor}">
                    <span>{{getMsgText(item)}}</span>
                  </richtext>
                </div>
                <div v-if="item.type=='file' || item.m_type=='file'">
                  <div :class="[login.isLogin && loginUser.uid==item.user.uid?'messageImage-r':'messageImage-l']">
                    <image @click="imageClick(getMsgImg(item))" class="messageImage" resize="cover" :src="getMsgImg(item)"></image>
                  </div>
                  <div v-if="login.isLogin && loginUser.uid==item.user.uid" class="senderRichText-bg">
                    <richtext class="senderRichText" :style="{color:item.user.textColor}">
                      <span>{{getImgMsgText(item)}}</span>
                    </richtext>
                  </div>
                  <richtext v-if="loginUser.uid!=item.user.uid || !login.isLogin" class="receiverRichText" :style="{color:item.user.textColor}">
                    <span>{{getImgMsgText(item)}}</span>
                  </richtext>
                </div>
              </div>
              <image @click="headerClick(item,i)" :class="[login.isLogin && loginUser.uid==item.user.uid?'senderHeader':'otherHeader']" :src="getHeaderImg(item)"></image>
              <image v-if="(item.user.type==15||item.user.type==20)&&item.user.level>=10" @click="headerClick(item,i)" :class="[login.isLogin && loginUser.uid==item.user.uid?'senderHeader-level':'otherHeader-level']" :src="levelIcon"></image>
            </div>
            <div v-if="i == HISTORY_SIZE-1" class="historyMessage">
              <div class="historyLine"></div>
              <text class="historyTitle">以上为历史消息</text>
              <div class="historyLine"></div>
            </div>
          </cell>
        </list>
        <!-- @消息列表的浮窗 -->
        <div v-if="showItem.index == 0" class="atMessage-bg">
          <div v-if="atMessage.isShow" style="width:750px;background-color:#FFFFFF;">
            <list show-scrollbar=false style="width:750px;max-height:300px;background-color:#FFFFFF;" ref="list2">
              <cell v-for="(item,i) in atMessage.showList" :key="item.mid"  @click="touchSlider">
                <div class="atMessage-content" @click="atListClick(item,i)">
                  <div class="atMessage-content-bg">
                    <richtext :class="[atMessage.isFold?'atMessage-text-line':'atMessage-text-lines']">
                      <span style="color:#2e74e9;margin-right:20px;">[有人@我]</span>
                      <span style="color:#FFFFFF;background-color:#FFFFFF">' '</span>
                      <span>{{getAtMsgText(item)}}</span>
                    </richtext>
                  </div>
                </div>
                <div v-if="!atMessage.isFold && atMessage.showList.length>1" class="atMessage-line"></div>
              </cell>
            </list>
            <div style="position:absolute;top:20px;right:25px;" @click="atListCloseClick(item,i)">
              <image style="width:40px;height:40px;" :src="deleteimg"></image>
            </div>
            <div class="atMessage-unfold-bg" @click="foldOrUnfoldClick()">
              <text class="atMessage-fold-text">{{atMessage.fold}}</text>
              <image :class="[atMessage.isFold == true ? 'atMessage-image-fold':'atMessage-image-unfold']" :src="unfoldimg"></image>
            </div>
          </div>
          <!-- 讲师说 按钮 -->
          <div :class="[atMessage.isShow?'atMessage-teacherSay-bottom':'atMessage-teacherSay-top']">
            <div class="teacherSay" @click="clickTeacherSay">
              <text class="teacherSay-text">讲师说</text>
            </div>
            <div v-if="teacherSay.isRed" class="atMessage-teacherSay-redCircle"></div>
          </div>
        </div>
        <!-- 讲师历史留言列表 -->
        <div v-if="teacherSay.isShow" class="teacherSay-list-bg">
          <list v-if="teacherMessages.length>0" show-scrollbar=false class="teacherSay-list" ref="list3">
            <cell v-for="(item,i) in teacherMessages" :key="updateNum*100+1">
              <div class="teacherSay-list-cell">
                <div class="teacherSay-list-title">
                  <div class="teacherSay-list-header-bg">
                    <image class="teacherSay-list-header" :src="getHeaderImg(item)"></image>
                    <text class="teacherSay-list-teacher">{{item.user.name}}</text>
                   <div :class="[item.isOn==true?'teacherSay-onLine':'teacherSay-offLine']"></div>
                  </div>
                  <text class="teacherSay-list-text">{{getMsgTime(item,false)}}</text>
                </div>
                <richtext v-if="item.type!='file' && item.m_type!='file'" enableCopy="true" :atColor="atMessage.atColor" class="teacherSay-list-text">
                  <span>{{getMsgText(item)}}</span>
                </richtext>
                <div v-if="item.type=='file' || item.m_type=='file'" class="messageImage-l">
                  <image @click="imageClick(getMsgImg(item))" class="messageImage" resize="cover" :src="getMsgImg(item)"></image>
                </div>
                <richtext v-if="item.type=='file' || item.m_type=='file'" class="teacherSay-list-text">
                  <span>{{getImgMsgText(item)}}</span>
                </richtext>
              </div>
            </cell>
          </list>
          <div v-if="teacherMessages.length==0" style="" class="teacherSay-list-no" @click="noTeacherSay">
            <text class="teacherSay-list-no-text">暂无讲师留言</text>
          </div>
          <div class="teacherSayIcon-bg-d"></div>
          <div class="teacherSayIcon-bg" @click="clickTeacherSayClose">
            <image class="teacherSayIcon" :src="closeIcon"></image>
          </div>
        </div>
      </div>
      <div style="width:750px;" @click="touchSlider">
        <list v-if="login.isLogin&&newBroads.list.length>0" show-scrollbar=false style="width:750px;" ref="list4">
          <cell v-for="(item,i) in newBroads.list" :key="updateBroadNum*1000+1"  @click="clickBroadList(item,i)">
            <div class="broadCell-bg">
              <div class="broadCell-name">
                <text class="broadCell-gold">{{item.user.name}}</text>
              </div>
              <div class="broadCell-content">
                <richtext enableCopy="true" :atColor="atMessage.atColor" class="broadCell-white" @click="clickBroadList(item,i)">
                  <span>{{getMsgText(item)}}</span>
                </richtext>
              </div>
              <div class="broadCell-time">
                <text class="broadCell-gray">{{getBroadMsgTime(item)}}</text>
              </div>
            </div>
            <div class="broadCell-line"></div>
          </cell>
          <cell ref="bottom" style="height:2px;"></cell>
        </list>
        <div v-if="login.isLogin&&newBroads.list.length<=0" class="noBroad-bg">
          <div v-if="topic.noBroad.title_text" class="flexH noBroad-title-bg">
            <text class="noBroad-tags">HOT</text>
            <text class="noBroad-title">{{topic.noBroad.title_text}}</text>
          </div>
          <text class="noBroad-content">{{topic.noBroad.content_text}}</text>
          <text class="noBroad-time">{{topic.noBroad.time_text}}</text>
        </div>
      </div>
    </cycleslider>
    <div v-if="showItem.isShow" class="tabItem-bg" ref="test2">
      <div class="tabItemText-bg" @click="selectTabItem(0)">
        <text :class="[showItem.index==0?'tabItemText-gold':'tabItemText-black']">实时聊天</text>
      </div>
      <div class="tabItemText-bg tabItemText-bg-top" @click="selectTabItem(1)">
        <text :class="[showItem.index==1?'tabItemText-gold':'tabItemText-black']">最新广播</text>
      </div>
    </div>
  </div>
</template>

<script>
  var bundleUrl = require('../include/base-url.js').bundleUrl();
  var assetsUrl = require('../include/base-url.js').assetsUrl();
  var navigator = weex.requireModule('navigator');
  var globalEvent = weex.requireModule('globalEvent');
  var app = weex.requireModule('app');
  var storage = require('../include/storage.js');
  const http = require('../include/http.js')
  const websocket = weex.requireModule('webSocket')
  const utils = require('../include/utils.js')
  const dom = weex.requireModule('dom')
  const animation = weex.requireModule('animation');

  module.exports = {
    props: {
      login: { default: {isLogin:false,downTime:'00:00:00'} },
      loginUser: { default: {} },
      onData:{ default: [] },
      button: { default: {} },
    },
    data: function() {
      return {
        assets: assetsUrl,
        levelIcon:assetsUrl+'live_level.png',
        tabSelectIcon:assetsUrl+'live_at_unfold.png',
        closeIcon:assetsUrl+'close_gray.png',
        tabLiveIcon:assetsUrl+'live_tab_jump.png',
        unfoldimg: assetsUrl + 'live_at_unfold.png',
        deleteimg: assetsUrl + 'close_gray.png',
        isAndroid: utils.isAndroid(),

        showItem:{isShow:false,index:0,title:'实时聊天'},
        isLock:false,
        updateNum: 1,//实时聊天和讲师说的刷新参数
        updateBroadNum:1,//最新广播的刷新参数
        cmsApiHost:'',
        userApi:'',//获取身份用户列表api
        messages:[],//实时聊天 信息
        HISTORY_SIZE:0,//历史消息分隔线
        newBroads:{all:[],list:[]},//最新广播 信息
        teacherSay:{isShow:false,isRed:false,onLines:[]},
        teacherMessages:[],//讲师说 信息
        atMessage: {isShow: false, isFold: true, fold: '展开', allList: [], showList: [],atColor:'#2e74e9',atMyColor:'#2e74e9'},//at  信息
        course: {isNo:true,courses:[],teacher:'',time:'',courseDownTime:0},
        topic:{id:0,noBroad:{}},//无广播时的内容
        textColor:{helper:'#ff8f17',teacher:'#4e8fd3',client:'#242424'},
      }
    },
    created:function() {
      var that = this;
      // that.startTimer()
      var common = storage.getItemSync('commonUrl')
      if (common && common.length >= 2) {
        var commonUrl = JSON.parse(common)
        that.cmsApiHost = commonUrl.cmsApi // 接口基址
        that.getMessage()
        that.getTeacherMessage()
        that.getNewBroadMessage()
        that.getCourse();
        storage.getItem('nodeIdList', function(value) {
          var nodeIdList = JSON.parse(value);
          that.topic.id = nodeIdList.activityId;
          that.getTopicActivity();
        });
      }
      storage.getItem('chatRoom',function (chatRoom) {
        if (chatRoom && chatRoom.length >= 2) {
          var chat = JSON.parse(chatRoom)
          if (chat&&chat.chatUsersApi) {
            that.userApi = chat.chatUsersApi
          }else {
            var url = chat.socket
            if(url.indexOf("wss") == 0) {
              url = url.replace('wss','https')
            }
            if(url.indexOf("ws") == 0) {
              url = url.replace('ws','http')
            }
            url = url.replace('/stream','')
            that.userApi = url
          }
          that.getOnlineTeachers();
        }
      });
    },
    watch: {
      'login.isLogin' : {//只监听登录状态的改变
        handler(){
          this.updateNum++;
          if (!this.login.isLogin) {//退出登录
            this.loginUser = {};
            this.newBroads.all = [];//清除最新广播内容
            this.newBroads.list = [];//清除最新广播内容
            this.teacherMessages = [];//清除讲师说内容
            if (this.teacherSay.isShow) {
              this.teacherSay.isShow = false
            }
            this.messages = [];//清除聊天内容
            if (this.showItem.index!=0) {//不在实时聊天切换到实时聊天
              this.selectTabItem(0)
            }
            this.atMessage.isShow = false//清除@内容
            this.atMessage.isFold = true
            this.atMessage.fold = '展开'
            this.atMessage.allList = []
            this.atMessage.showList = []
            if (this.cmsApiHost) {
              this.getMessage()
              this.getTeacherMessage()
              this.getNewBroadMessage()
              this.getCourse();
            }
            if (this.userApi && this.userApi != '') {
              this.getOnlineTeachers();
            }
          }
        },
        deep:true,
        immediate:false
      },
      button : {
        handler(data){
          if (data.clear == true) {//清屏
            if (this.showItem.index == 1&&this.newBroads.list.length>0) {//在最新广播栏目时有广播则清除
              // this.newBroads.all = [];
              // this.newBroads.list = [];
            }
            if (this.showItem.index == 0) {//在实时聊天栏目时
              if (this.teacherSay.isShow) {//打开讲师说  清除讲师说内容
                this.teacherMessages = [];
              }else {//清除聊天内容  有@信息也清除
                this.messages = [];
                if (this.atMessage.isShow) {
                  this.atMessage.isShow = false
                  this.atMessage.isFold = true
                  this.atMessage.fold = '展开'
                  this.atMessage.allList = []
                  this.atMessage.showList = []
                }
              }
            }
            this.button.clear = false
          }else if (data.lock == true) {//锁屏
            this.isLock = !this.isLock;
            this.button.lock = false
          }else if (data.at == 'show') {//点击at  关闭弹窗
            if (this.showItem.isShow) {//关闭tab弹窗
              this.showItem.isShow = false;
            }
            if (this.teacherSay.isShow) {//关闭讲师说弹窗
              this.teacherSay.isShow = false;
            }
          }
        },
        deep:true,
        immediate:false
      },
      onData (datas) {//websocket推送过来的数据集
        var that = this;
        if (datas) {
          let needScroll = false
          for (var i = 0; i < datas.length; i++) {
            if (datas[i].isUpdate) {//已经处理过的websocket推过来的消息
              return
            }
            that.$set(datas[i], 'isUpdate', true)
            if (datas[i].type == 'message' || datas[i].type == 'file' || datas[i].type == 'notice') {
              if ((/\{@(.+?)\}/g).test(datas[i].text)) {  //获取@信息
                if (datas[i].type != 'notice') {//公告不包含@信息
                  this.getAtMessage(datas[i])
                }
              }
              let info = JSON.parse(datas[i].from)
              if (info) {
                // 30 管理员  51 主播
                if (info.type==40 || info.Type==40|| info.type==30||info.Type==30) {
                  info.textColor = that.textColor.helper
                }else if (info.type==50 || info.Type==50||info.type == 51|| info.Type == 51) {
                  info.textColor = that.textColor.teacher
                }else {
                  info.textColor = that.textColor.client
                }
                that.$set(datas[i], 'user', info)
              } else {
                var info = {
                  name: '',
                  avator: '',
                  uid: '',
                  isShield: false,
                  sexy: 0,
                  type: 0,
                  textColor:that.textColor.client
                }
                that.$set(datas[i], 'user', info)
              }
              this.messages.push(datas[i])//实时聊天
              if (info.Type == 50 || info.type == 50) {//讲师说
                if (!this.teacherSay.isShow) {
                  this.teacherSay.isRed = true;
                }
                this.teacherMessages.push(JSON.parse(JSON.stringify(datas[i])))
                this.setTeacherOnline();
              }
              if (datas[i].type == 'notice') {//最新广播
                this.newBroads.all.unshift(datas[i]);
                if (this.newBroads.all.length<=5) {
                  this.newBroads.list=this.newBroads.all
                }else {
                  this.newBroads.list = this.newBroads.all.slice(0,5)
                }
                this.updateBroadNum++;//新增最新广播时刷新界面（允许晃动）
              }
              // this.updateNum++;//新增数组数据时  页面会晃动
              needScroll = true
            } else if (datas[i].type == 'delete') {
              for (var index = this.messages.length - 1; index >= 0; index--) {
                if (datas[i].text == this.messages[index].MessageId || datas[i].text == this.messages[index].messageId || datas[i].text == this.messages[index].id) {
                  this.messages.splice(index, 1)
                  break
                }
              }
              for (var index = this.newBroads.all.length - 1; index >= 0; index--) {
                if (datas[i].text == this.newBroads.all[index].MessageId || datas[i].text == this.newBroads.all[index].messageId || datas[i].text == this.newBroads.all[index].id) {
                  this.newBroads.all.splice(index, 1)
                  if (this.newBroads.all.length<=5) {
                    this.newBroads.list=this.newBroads.all
                  }else {
                    this.newBroads.list = this.newBroads.all.slice(0,5)
                  }
                  this.updateBroadNum++;//新增最新广播时刷新界面（允许晃动）
                  break
                }
              }
              for (var index = this.teacherMessages.length - 1; index >= 0; index--) {
                if (datas[i].text == this.teacherMessages[index].MessageId || datas[i].text == this.teacherMessages[index].messageId || datas[i].text == this.teacherMessages[index].id) {
                  this.teacherMessages.splice(index, 1)
                  break
                }
              }
              this.updateNum++
              needScroll = true
            } else if (datas[i].type == 'forbidAll') {

            } else if (datas[i].type == 'duringClass') {

            } else if (datas[i].type == 'update') {

            } else if (datas[i].type == 'online' || datas[i].type == 'offline') {
              this.getOnlineTeachers();
            } else if (datas[i].type == 'userlist') {
              // var str_text = JSON.parse(datas[i].text);
              // var text = `[${str_text}]`;
              // this.teacherSay.onLines = JSON.parse(text);
              // this.setTeacherOnline();
            }else {
              // console.log('输出message的类型：'+datas[i].type);
            }
          }
          if (needScroll) {
            setTimeout(this.scrollToBottom, 500)
          }
        }
      }
    },
    methods: {
      noTeacherSay:function(){

      },
      getOnlineTeachers:function(){
        var url = this.userApi + '/users?channel=bibfx&count=100&type=50'
        var that = this
        http.get(url, function (response) {
          if (response.ok && response.data) {
            that.teacherSay.onLines = response.data
            that.setTeacherOnline();
          }
        })
      },
      setTeacherOnline:function(){
        if (this.teacherMessages.length>0) {
          for (var j = 0; j < this.teacherMessages.length; j++) {
            var teacherName = this.teacherMessages[j].user.name
            var isOnLine = false
            if (this.teacherSay.onLines.length>0) {
              for (var i = 0; i < this.teacherSay.onLines.length; i++) {
                var teacherData = JSON.parse(this.teacherSay.onLines[i])
                if (teacherName == teacherData.name) {
                  isOnLine = true
                }
              }
            }
            if (isOnLine) {
              this.$set(this.teacherMessages[j], 'isOn', true)
            }else {
              this.$set(this.teacherMessages[j], 'isOn', false)
            }
          }
        }
      },
      getAtMessage: function (atMsg) {
        if (this.login.isLogin == false) {//未登录 不接收@消息
          return
        }
        var atNameList = []// 不带符号的at姓名数组
        let array
        var reg = /\{\@(.+?)\}/g
        while (array = reg.exec(atMsg.text)) {
          if (array[1] != '' && undefined != array[1]) {
            atNameList.push(array[1])
          }
        }
        var result = false
        for (var i = 0; i < atNameList.length; i++) {
          // at的人有自己  或者自己是讲师，客服  助理等
          if (atNameList[i] == this.loginUser.name || atNameList[i] == 'all') {
            result = true
          } else if (atNameList[i] == '讲师' && this.loginUser.type == 50) {
            result = true
          } else if (atNameList[i] == '助理' && this.loginUser.type == 40) {
            result = true
          }
        }
        if (!result || this.loginUser.uid == JSON.parse(atMsg.from).uid) {
          return// 自己at别人或者别人的at信息没有自己，则不显示
        }
        var name = JSON.parse(atMsg.from).name + ':'
        var text = ''
        if (atMsg.type == 'file' || atMsg.m_type == 'file') {
          if (this.loginUser.uid != JSON.parse(atMsg.from).uid) {
            text = '\n'
          }
        } else {
          text = atMsg.text.replace(/<br>/g, '\n')
          text = text.replace(/{/g, '')
          text = text.replace(/}/g, ' ')
        }
        atMsg.content = name + text
        atMsg.names = atNameList
        atMsg.mid = atMsg.id// 消息的id
        this.atMessage.allList.splice(0, 0, atMsg)
        if (atMsg.content) {
          this.atMessage.isShow = true
          if (this.atMessage.isFold) {
            this.atMessage.showList.splice(0, 1, atMsg)
          } else {
            this.atMessage.showList = []
            this.atMessage.showList = this.atMessage.allList
          }
        }
      },
      maskClick: function() {

      },
      touchSlider: function () {
        if (this.showItem.isShow) {//关闭tab弹窗
          this.showItem.isShow = false;
        }
        if (this.teacherSay.isShow) {//关闭讲师说弹窗
          this.teacherSay.isShow = false;
        }
        this.$emit('touchSlider');
      },
      scrollstart: function () {

      },
      scrollend:function(){

      },
      touchScroll: function (event) {
        let height = event.contentSize.height;
        let y = event.contentOffset.y;
      },
      getAtMsgText: function (item) {
        return item.content;
      },
      getMsgText: function (item) {
        if (!item) {
          return ''
        }
        var text = ''
        if (item.type == 'file' || item.m_type == 'file') {
          if (this.loginUser.uid != item.user.userId) {
            text = '\n'
          }
        } else {
          text = item.text.replace(/<br>/g, '\n')
          text = text.replace(/}/g, '} ')
        }
        return text;
      },
      getImgMsgText: function (item) {
        if (item.type == 'file' || item.m_type == 'file') {
          let matches = item.text.split(' ')
          if (matches && matches.length >= 2) {
            var msg = ''
            for (var i = 1; i < matches.length; i++) {
              msg += matches[i]
            }
            return msg;
          } else {
            return ''
          }
        }
        var text = item.text.replace(/<br>/g, '\n')
        text = text.replace(/}/g, '} ')
        return text;
      },
      getMsgImg: function (item) {
        if (item.type == 'file' || item.m_type == 'file') {
          let matches = item.text.split(' ')
          if (matches && matches.length >= 1) {
            return matches[0]
          }
        }
        return item.text
      },
      getHeaderImg:function(item){
        return encodeURI(item.user.avator)
      },
      imageClick: function (url = '') {
        // 查看大图
        this.$emit('alertView', {type:'bigImg',data:{imgUrl:url}})
      },
      // 聊天头像点击事件
      headerClick: function (item, index) {
        this.$emit('alertView', {type:'headerImg',data:item})
      },
      getBroadMsgTime:function(item){
        //1小时内的，显示XX秒前、XX分钟前；1小时~24点前的，显示		“今天XX：XX”；只取当天广播内容
        var msgTime
        if (item.sendOn) {
          msgTime = parseInt(item.sendOn.replace(/[^\d]/g, '')) / 10000
        } else {
          msgTime = parseInt(item.created / 1000000)
        }
        var time = new Date(msgTime)
        var timeStamp = new Date().getTime()//当前时间的时间戳（毫秒）
        return '今天' + this.addZero(time.getHours()) + ':' + this.addZero(time.getMinutes())
      },
      getMsgTime: function (item,isSecond) {
        //当天时间显示时分秒 09:23:05  跨天显示月日时分 08-16 09:23
        var msgTime
        if (item.sendOn) {
          msgTime = parseInt(item.sendOn.replace(/[^\d]/g, '')) / 10000
        } else {
          msgTime = parseInt(item.created / 1000000)
        }
        var time = new Date(msgTime)
        var timeStamp = new Date().setHours(0, 0, 0, 0)//当前时间的0点
        if (msgTime < timeStamp) { // 消息超过当天
          return time.getMonth() + 1 + '-' + time.getDate() + ' ' + this.addZero(time.getHours()) + ':' + this.addZero(time.getMinutes())
        } else {// 消息未跨天
          if (isSecond) {
            return this.addZero(time.getHours()) + ':' + this.addZero(time.getMinutes()) + ':' + this.addZero(time.getSeconds())
          }else {
            return this.addZero(time.getHours()) + ':' + this.addZero(time.getMinutes())
          }
        }
      },
      addZero: function (obj) {
        return obj < 10 ? '0' + obj : obj
      },
      getMessage: function () {
        var url = this.cmsApiHost + '/Live/Message?m_typeIn=message,file,notice&channel=bibfx&orderByDesc=sendOn&Skip=0&Take=50'//无时间限制
        var that = this
        that.messages.splice(0, that.messages.length)
        http.get(url, function (response) {
          if (response.data && response.data.Results && response.data.Results.length > 0) {
            for (var i = 0; i < response.data.Results.length; i++) {
              if (response.data.Results[i].m_from && JSON.parse(response.data.Results[i].m_from)) {
                let info = JSON.parse(response.data.Results[i].m_from)
                if (info.type==40 || info.Type==40|| info.type==30||info.Type==30) {
                  info.textColor = that.textColor.helper
                }else if (info.type==50 || info.Type==50||info.type == 51|| info.Type == 51) {
                  info.textColor = that.textColor.teacher
                }else {
                  info.textColor = that.textColor.client
                }
                that.$set(response.data.Results[i], 'user', info)
                that.messages.splice(0, 0, response.data.Results[i])//实时聊天 信息
                that.HISTORY_SIZE = that.messages.length
              } else {
                // var info = {
                //   name: '',
                //   avator: '',
                //   uid: '',
                //   isShield: false,
                //   sexy: 0,
                //   type: 0,
                //   textColor:that.textColor.client
                // }
                // that.$set(response.data.Results[i], 'user', info)
              }
              // that.messages.splice(0, 0, response.data.Results[i])//实时聊天 信息
              // that.HISTORY_SIZE = that.messages.length
            }
            setTimeout(that.scrollToBottom, 500)
          }
        })
      },
      getTeacherMessage: function () {//获取今天的历史的 讲师留言
        // let dateStr = utils.dateFormat((new Date()).getTime(), 'yyyy-MM-dd 09:00:00') + ',' + utils.dateFormat((new Date()).getTime(), 'yyyy-MM-dd hh:mm:ss')
        let dateStr = utils.dateFormat((new Date()).getTime()-24*60*60*1000, 'yyyy-MM-dd hh:mm:ss') + ',' + utils.dateFormat((new Date()).getTime(), 'yyyy-MM-dd hh:mm:ss')
        var url = this.cmsApiHost + '/Live/Message?m_typeIn=message,file,notice&channel=bibfx&orderByDesc=sendOn&Skip=0&Type=50&sendOnBetween=' + dateStr
        var that = this
        that.teacherMessages.splice(0, that.teacherMessages.length)
        http.get(url, function (response) {
          if (response.data && response.data.Results && response.data.Results.length > 0) {
            for (var i = 0; i < response.data.Results.length; i++) {
              if (response.data.Results[i].m_from && JSON.parse(response.data.Results[i].m_from)){
                let info = JSON.parse(response.data.Results[i].m_from)
                if (info) {
                  if (info.type==40 || info.Type==40) {
                    info.textColor = that.textColor.helper
                  }else if (info.type==50 || info.Type==50) {
                    info.textColor = that.textColor.teacher
                  }else {
                    info.textColor = that.textColor.client
                  }
                  that.$set(response.data.Results[i], 'user', info)
                  if (info.Type == 50 || info.type == 50) {
                    that.teacherMessages.splice(0, 0, response.data.Results[i])//讲师说 信息
                  }
                } else {
                  // var info = {
                  //   name: '',
                  //   avator: '',
                  //   uid: '',
                  //   isShield: false,
                  //   sexy: 0,
                  //   type: 0,
                  //   textColor:that.textColor.client
                  // }
                  // that.$set(response.data.Results[i], 'user', info)
                }
                // if (info.Type == 50 || info.type == 50) {
                //   that.teacherMessages.splice(0, 0, response.data.Results[i])//讲师说 信息
                // }
              }

            }
            that.setTeacherOnline();
            setTimeout(that.scrollToBottom, 500)
          }
        })
      },
      getNewBroadMessage:function(){//获取今天的历史的 最新广播 且不超过5条
        var that = this
        let dateStr = utils.dateFormat((new Date()).getTime(), 'yyyy-MM-dd 09:00:00') + ',' + utils.dateFormat((new Date()).getTime(), 'yyyy-MM-dd hh:mm:ss')
        var url = this.cmsApiHost + '/Live/Message?m_typeIn=notice&channel=bibfx&orderByDesc=sendOn&Skip=0&sendOnBetween=' + dateStr
        http.get(utils.encodeURLParams(url), function (response){
          that.newBroads.all.splice(0, that.newBroads.all.length)
          if (response.data && response.data.Results && response.data.Results.length > 0) {
            for (var i = 0; i < response.data.Results.length; i++) {
              let info = JSON.parse(response.data.Results[i].m_from)
              if (info) {
                if (info.type==40 || info.Type==40) {
                  info.textColor = that.textColor.helper
                }else if (info.type==50 || info.Type==50) {
                  info.textColor = that.textColor.teacher
                }else {
                  info.textColor = that.textColor.client
                }
                that.$set(response.data.Results[i], 'user', info)
              } else {
                var info = {
                  name: '',
                  avator: '',
                  uid: '',
                  isShield: false,
                  sexy: 0,
                  type: 0,
                  textColor:that.textColor.client
                }
                that.$set(response.data.Results[i], 'user', info)
              }
              that.newBroads.all.push(response.data.Results[i])
              if (that.newBroads.all.length>5) {
                that.newBroads.list = that.newBroads.all.slice(0,5);
              }else {
                that.newBroads.list = that.newBroads.all
              }
            }
          }
        })
      },
      //获取课程信息
      getCourse: function() {
        var that = this;
        var ms = (new Date()).getTime();
        if (that.cmsApiHost) {
          let dateStr = utils.dateFormat(ms, 'yyyy-MM-dd')
          var url = that.cmsApiHost + '/Live/LessonsGroup?format=json&channel=bibfx&DateTime=' + dateStr;
          http.get(url, function(response) {
            if (response.ok && response.data) {
              var results = response.data;
              if (results && results.length > 0) {
                that.$emit('alertView', {type:'course',data:results[0]});
                if (results[0].lessons.length<=0) {
                  that.course.isNo = true;
                  that.getLivingCourse()
                  return
                }
                var isNoCourse = true
                for (var i = 0; i < results[0].lessons.length; i++) {
                  var lesson = results[0].lessons[i];
                  var course = {};//需要用到的课程信息
                  if (lesson.Name) {
                    course.teacher = lesson.Name
                  }
                  if (lesson.TimeSpan) {
                    course.duration = lesson.TimeSpan//duration 单位：毫秒
                  }
                  if (lesson.StartTime) { //"StartTimestamp": 1532307600000,
                    course.startTime = parseInt(lesson.StartTime.slice(6, -7));
                    course.endTime = course.startTime + course.duration;
                  }
                  if (course.startTime > 0 && course.endTime > course.startTime) {
                    course.time = utils.dateFormat(course.startTime, 'hh:mm') + '-' + utils.dateFormat(course.endTime, 'hh:mm')
                  }
                  if (ms >= course.startTime && ms <= course.endTime) {
                    isNoCourse = false
                    that.course.isNo = false;
                    that.course.teacher = course.teacher;
                    that.course.time = course.time;
                  } else {

                  }
                  that.course.courses.push(course);
                }
                if (isNoCourse) {
                  that.course.isNo = true;
                }
                that.getLivingCourse()
              }else {
                that.course.isNo = true;
                that.getLivingCourse()
              }
            } else {
              that.course.isNo = true;
              that.getLivingCourse()
            }
          });
        }
      },
      //课程开始以及课程结束的倒计时时长计算
      getLivingCourse:function(){
        var ms = (new Date()).getTime();//当前时间的时间戳（毫秒）
        var lessTime = 7*24*60*60*1000
        if (this.course.courses.length>0) {
          if (this.course.isNo) {//无课程
            for (var i = 0; i < this.course.courses.length; i++) {
              var less = this.course.courses[i];
              var lowTime = less.startTime - ms;
              if (lowTime>0 && lowTime<lessTime) {
                lessTime = lowTime
              }
            }
          }else {//有课程
            for (var i = 0; i < this.course.courses.length; i++) {
              var less = this.course.courses[i];
              if (ms >= less.startTime && ms < less.endTime) {
                lessTime = less.endTime - ms;
                this.course.isNo = false;
                this.course.teacher = less.teacher;
                this.course.time = less.time;
              }
            }
          }
          if (lessTime>0) {
            this.course.courseDownTime = lessTime;
            this.onCountdown();//开启倒计时
          }
        }
      },
      //课程倒计时
      onCountdown: function() {
        if (this.login.isLogin == false) {
          return;
        }
        if (this.course.courseDownTime <= 0) {
          this.updateLivingCourse();
        } else {
          this.course.courseDownTime -= 1000;
          setTimeout(this.onCountdown.bind(this), 1000);
        }
      },
      //课程倒计时结束后更新课程信息
      updateLivingCourse:function(){
        var ms = (new Date()).getTime();
        var isNoCourse = true
        if (this.course.courses.length>0) {
          for (var i = 0; i < this.course.courses.length; i++) {
            var less = this.course.courses[i];
            if (ms >= less.startTime && ms < less.endTime) {
              isNoCourse = false;
              this.course.isNo = false;
              this.course.teacher = less.teacher;
              this.course.time = less.time;
              this.getLivingCourse()
            }
          }
          if (isNoCourse) {
            this.course.isNo = true;
            this.course.teacher = '';
            this.course.time = '';
            this.getLivingCourse()
          }
        }
      },
      getTopicActivity: function() {
        var that = this;
        var url = that.cmsApiHost + '/ContentUnion/Site?format=json&OrderByDesc=Taxis&ChannelIds=' + this.topic.id + "&Take=2&Skip=0";
        http.get(url, function(response) {
          if (response.ok && response.data && response.data.Results && response.data.Results.length > 0) {
            var result = response.data.Results[0];
            that.topic.noBroad = result;
            that.topic.noBroad.title_text = that.topic.noBroad.Title
            if (that.topic.noBroad.ContentNoHtmlTag) {
              that.topic.noBroad.content_text = that.topic.noBroad.ContentNoHtmlTag
            }
            if (that.topic.noBroad.Summary) {
              that.topic.noBroad.content_text = that.topic.noBroad.Summary
            }
            if (that.topic.noBroad.EndTime) {
              var stamp = parseInt(that.topic.noBroad.EndTime.slice(6, -7));
               var date = utils.dateFormat(stamp, 'yyyy年MM月dd日')
               that.topic.noBroad.time_text = '活动时间：即日起至'+date
            }
          }
        },20000);
      },
      scrollToBottom: function (animated = false) {
        if (this.isLock) {
          return
        }
        if (this.$refs.list1) {
          this.$refs.list1.scrollToBottom(animated)
        }
        if (this.$refs.list3) {
          this.$refs.list3.scrollToBottom(animated)
        }
        // if (this.$refs.list4) {
        //   this.$refs.list4.scrollToBottom(animated)
        // }
      },
      clickTabTitle:function(isClick){
        this.$emit('touchSlider');
        if (this.teacherSay.isShow) {//关闭讲师说弹窗
          this.teacherSay.isShow = false;
        }
        if (isClick) {
          this.showItem.isShow = true;
        }else {
          this.showItem.isShow = false;
        }

        let that = this;
        if (this.showItem.isShow){
          setTimeout(function () {
            that.move(-100);
          },100)
        }

      },
      selectTabItem:function(idx){
        this.showItem.isShow = false;
        if (this.showItem.index==idx) {
          return
        }
        switch (idx) {
          case 0:
            this.showItem.title = '实时聊天';
            break;
          case 1:
            if (!this.login.isLogin) {
              this.$emit('alertView', {type:'newBroad',data:{type:'newBroad',done:'login'}})
              return
            }else {
              this.showItem.title = '最新广播';
            }
            break;
          default:
        }
        this.showItem.index = idx;
      },
      clickTeacherSay:function(){
        this.$emit('touchSlider');
        if (this.showItem.isShow) {//关闭tab弹窗
          this.showItem.isShow = false;
        }
        if (this.login.isLogin) {
          this.teacherSay.isShow = true;
          this.teacherSay.isRed = false;
          // setTimeout(this.scrollToBottom, 100)
        }else {
          this.$emit('alertView', {type:'teacherSay',data:{type:'teacherSay',done:'login'}})
        }
      },
      clickTeacherSayClose:function(){
        this.teacherSay.isShow = false;
      },
      clickBroadList:function(item,i){
        // this.touchSlider();
        if (this.showItem.isShow) {//关闭tab弹窗
          this.showItem.isShow = false;
        }
        if (this.teacherSay.isShow) {//关闭讲师说弹窗
          this.teacherSay.isShow = false;
        }
        this.$emit('alertView', {type:'broadCell',data:item})
      },
      atListClick: function (item, index) {
        let offset = -100
        for (var i = 0; i < this.messages.length; i++) {
          if (this.messages[i].id == item.id) {
            // 此条信息滚动到底部
            var refid = 'mainMessage' + i
            const ref = this.$refs[refid]
            const el = ref ? ref[0] : null
            if (this.messages.length - i > 3 || !this.isAndroid) {
              offset = -100
            } else if (this.messages.length - i > 0 || !this.isAndroid) {
              offset = 0
            }
            if (el) {
              dom.scrollToElement(el, {offset: offset})
            }
          }
        }
        if (!this.atList.isFold) {
          this.foldOrUnfoldClick()
        }
        // if (item.from && JSON.parse(item.from).name) {
        //   this.messageStr = '{@'+JSON.parse(item.from).name+'}'
        // }
      },
      // 删除单独一条at信息的列表
      deleteAtListItem: function (item) {
        for (var i = this.atMessage.allList.length - 1; i >= 0; i--) {
          if (this.atMessage.allList[i].id == item.id) {
            this.atMessage.allList.splice(i, 1)
          }
        }
        this.atMessage.showList = []
        if (this.atMessage.isFold && this.atMessage.allList.length > 0) {
          this.atMessage.showList.splice(0, 0, this.atMessage.allList[0])
        } else if (!this.atMessage.isFold && this.atMessage.allList.length > 0) {
          this.atMessage.showList = this.atMessage.allList
        } else {
          this.atMessage.isShow = false
          this.atMessage.isFold = true
          this.atMessage.fold = '展开'
        }
      },
      // 清除所有at列表
      atListCloseClick: function (item, index) {
        this.atMessage.allList = []
        this.atMessage.showList = []
        this.atMessage.isShow = false
        this.atMessage.isFold = true
        this.atMessage.fold = '展开'
      },
      // 展开  收起at信息列表
      foldOrUnfoldClick: function () {
        // this.isShowAt = false
        if (this.atMessage.isFold) {
          this.atMessage.fold = '收起'
          this.atMessage.isFold = false
          this.atMessage.showList = []
          this.atMessage.showList = this.atMessage.allList
        } else {
          this.atMessage.fold = '展开'
          this.atMessage.isFold = true
          this.atMessage.showList = []
          this.atMessage.showList.splice(0, 0, this.atMessage.allList[0])
        }
      },
      move:function (bottom) {
        var testEl = this.$refs.test2;
        animation.transition(testEl, {
          styles: {
            transform: `translate(${bottom}px,0)`,
            transformOrigin: 'center center',
            opacity: 1
          },
          duration: 300, //ms
          timingFunction: 'ease',
          delay: 0, //ms
          needLayout: true,
        })
      },
    }
  }
</script>

<style src="../style/font.css"></style>
<style src="../style/common.css"></style>
<!--<style src="../styles/color.css">-->
<!--</style>-->
<style scoped>
  .background{
    flex: 1;
    width:750px;
    /* height:500px; */
    background-color: rgb(255, 255, 255);
  }
  .tabbar{
    /* width: 750px; */
    height: 80px;
    background-color: rgb(235, 239, 242);
    /* border-bottom-color: rgba(255, 255, 255, 0.1); */
    /* border-bottom-width: 1px; */
    align-items: center;
  }
  .tabYellowView{
    margin-left: 0px;
    width: 6px;
    height: 28px;
    background-color: #2e74e9;
  }
  .tabTitle{
    margin-left: 20px;
    padding-right: 10px;
    color: #242424;
    font-size: 30px;
    line-height: 45px;
    text-align: center;
  }
  .tabSelectIcon{
    /* margin-left: 20px; */
    width: 25px;
    height: 20px;
  }
  .tabRightView-bg{
    margin-right: 30px;
    flex: 1;
    height: 80px;
    justify-content: flex-end;
    align-items: center;
  }
  .tabName{
    margin-right: 20px;
    color: #6c6e70;
    font-size: 30px;
    line-height: 45px;
    text-align: center;
  }
  .tabLiveIcon{
    margin-right: 20px;
    width: 40px;
    height: 40px;
  }
  .tabTime{
    margin-right: 0px;
    color: #abafbc;
    font-size: 30px;
    line-height: 45px;
    text-align: center;
  }
  .tabTips{
    margin-right: 0px;
    color: #6c6e70;
    font-size: 28px;
    line-height: 42px;
    text-align: center;
  }
  .tabTimeDown-title{
    color: #c4c7d0;
    font-size: 28px;
    line-height: 42px;
    text-align: center;
  }
  .tabTimeDown-time{
    color: #2e74e9;
    font-size: 28px;
    line-height: 42px;
    text-align: center;
  }
  .content {
    flex: 1;
    flex-direction: row;
    overflow: hidden;
  }
  .message-bg{
    margin-left:86px;
    margin-right:86px;
    justify-content:center;
  }
  .messageTitle{
    flex-direction: row;
    margin-left:20px;
    margin-right:20px;
  }
  .userNickName-text-g{
    margin-right: 20px;
    color: #ff8f17;
    font-size: 24px;
    line-height: 36px;
    text-align: center;
  }
  .userNickName-text-w{
    margin-right: 20px;
    color: #abafbc;
    font-size: 24px;
    line-height: 36px;
    text-align: center;
  }
  .userIdentity-text{
    margin-right: 20px;
    padding-left: 3px;
    padding-right: 3px;
    color: rgb(255, 255, 255);
    font-size: 24px;
    line-height: 36px;
    text-align: center;
    border-radius: 4px;
    background-color: #2e74e9;
  }
  .userSendTime-text{
    color: #c4c7d0;
    font-size: 24px;
    line-height: 36px;
    text-align: center;
  }
  .senderRichText-bg{
    margin-top: 10px;
    justify-content: center;
    align-items: flex-end;
  }
  .senderRichText{
    margin-left:10px;
    margin-right:20px;
    /* color: rgb(224, 158, 109); */
    font-size:30px;
    line-height:45px;
    /* text-align: right; */
    background-color:transparent;
  }
  .receiverRichText{
    margin-top: 10px;
    margin-left:20px;
    margin-right:20px;
    /* color: rgb(128, 141, 165); */
    font-size:30px;
    line-height:50px;
    background-color: transparent;
  }
  .messageImage-l{
    margin-top: 10px;
    margin-left:20px;
    justify-content: center;
  }
  .messageImage-r{
    margin-top: 10px;
    margin-right:20px;
    align-items: flex-end;
    justify-content: center;
  }
  .messageImage{
    width:200px;
    height:150px;
  }
  .otherHeader{
    left:30px;
    position:absolute;
    width:56px;
    height:56px;
    border-radius:28px;
    overflow:hidden;
    background-color:#999999;
  }
  .otherHeader-level{
    left:62px;
    top:32px;
    position:absolute;
    width:24px;
    height:24px;
    border-radius:12px;
    overflow:hidden;
  }
  .senderHeader{
    right: 30px;
    position:absolute;
    width:56px;
    height:56px;
    border-radius:28px;
    overflow:hidden;
    background-color:#999999;
  }
  .senderHeader-level{
    position:absolute;
    right: 30px;
    top:32px;
    width:24px;
    height:24px;
    border-radius:12px;
    overflow:hidden;
  }
  .historyMessage{
    width: 750px;
    margin-top: 20px;
    height: 36px;
    margin-bottom: 14px;
    flex-direction: row;
    justify-content: center;
    align-items: center;
  }
  .historyLine{
    width: 120px;
    height:1px;
    background-color:rgba(128, 141, 165, 0.1);
  }
  .historyTitle{
    color: #abafbc;
    font-size: 24px;
    line-height: 36px;
    text-align: center;
    margin-left: 30px;
    margin-right: 30px;
  }
  .atMessage-bg{
    position:absolute;
    top:0px;
    left:0px;
    width: 750px;
    flex: 1;
    /* background-color:#373E53; */
    /* border-bottom-color: red; */
    /* border-bottom-width: 2px; */
  }
  .atMessage-content{
    flex-direction: row;
    align-items:center;
    justify-content:space-between;
    margin-top:20px;
    /* margin-bottom:20px; */
  }
  .atMessage-content-bg{
    flex-direction: row;
    align-items:center;
    margin-left:32px;
    margin-right:10px;
  }
  .atMessage-text-lines{
    font-size:28px;
    line-height:42px;
    color:#69748A;
    lines:2;
    max-height: 84px;
    width:620px;
    overflow: hidden;
    text-overflow: ellipsis;
    text-breakMode: tail;
    background-color: transparent;
  }
  .atMessage-text-line{
    font-size:28px;
    line-height:42px;
    color:#69748A;
    lines:1;
    max-height: 42px;
    width:620px;
    overflow: hidden;
    text-overflow: ellipsis;
    text-breakMode: tail;
    background-color: transparent;
  }
  .atMessage-unfold-bg{
    flex-direction: row;
    align-items:center;
    justify-content:center;
    padding-top: 10px;
    padding-bottom:10px;
    background-color:#FFFFFF;
    border-bottom-color: #e0e4eb;
    border-bottom-width: 1px;
  }
  .atMessage-fold-text{
    font-size:24px;
    line-height:36px;
    color:#242424;
  }
  .atMessage-line{
    margin-left: 32px;
    margin-right: 32px;
    margin-top:20px;
    height:1px;
    background-color:#e0e4eb;
  }
  .atMessage-image-fold{
    margin-left:10px;
    width:30px;
    height:30px;
    transform:  'rotate(0deg)';
    transform-origin: center center;
  }
  .atMessage-image-unfold{
    margin-left:10px;
    width:30px;
    height:30px;
    transform:  'rotate(180deg)';
    transform-origin: center center;
  }
  .atMessage-teacherSay-top{
    margin-top: 30px;
    flex-direction: row;
    align-items:center;
    justify-content:flex-end;
    padding-left: 30px;
    padding-right: 30px;
  }
  .atMessage-teacherSay-bottom{
    flex-direction: row;
    align-items:center;
    justify-content:flex-end;
    padding-left: 30px;
    padding-right: 30px;
  }
  .atMessage-teacherSay-redCircle{
    position:absolute;
    right:23px;
    top: 0px;
    width: 14px;
    height: 14px;
    border-radius: 7px;
    background-color: #f04341;
  }
  .broadCell-line{
    /* width: 686px; */
    margin-left: 32px;
    margin-right: 32px;
    height: 1px;
    border-style: dashed;
    border-color: rgba(229, 229, 229, 0.5);
    border-width: 1px;
  }
  .broadCell-bg{
    flex-direction: row;
    margin-top: 25px;
    margin-bottom: 25px;
  }
  .broadCell-name{
    margin-left: 30px;
    width: 120px;
    /* height: 40px; */
    justify-content: flex-start;
    align-items: center;
    /* background-color: yellow; */
  }
  .broadCell-gold{
    width: 120px;
    lines:3;
    max-height: 120px;
    font-size: 28px;
    line-height: 40px;
    /* color: rgb(196, 139, 98); */
    color: #ff8f17;
  }
  .broadCell-content{
    flex: 1;
    width: 360px;
    margin-left: 30px;
    margin-right: 30px;
    justify-content: center;
  }
  .broadCell-white{
    width: 360px;
    lines:3;
    overflow: hidden;
    text-overflow: ellipsis;
    max-height: 120px;
    text-breakMode: tail;
    word-wrap:break-word;
    color: black;
    font-size:28px;
    line-height:40px;
    background-color: transparent;
  }
  .broadCell-time{
    margin-right: 30px;
    width: 140px;
    /* height: 40px; */
    justify-content: flex-start;
    align-items: center;
    /* background-color: red; */
  }
  .broadCell-gray{
    font-size: 28px;
    line-height: 40px;
    color: rgb(129, 132, 142);
  }
  .noBroad-bg{
    flex: 1;
    width: 750px;
    margin-left: 30px;
    margin-right: 30px;
  }
  .noBroad-title-bg{
    margin-top: 40px;
    align-items: center;
  }
  .noBroad-tags{
    color: white;
    font-size: 18px;
    line-height: 28px;
    width: 54px;
    height: 28px;
    border-top-left-radius: 14px;
    border-bottom-right-radius: 14px;
    margin-right: 20px;
    background-color: red;
    text-align: center;
  }
  .noBroad-title{
    color: #e09e6d;
    font-size: 28px;
    line-height: 42px;
    font-weight: bold;
  }
  .noBroad-content{
    width: 690px;
    margin-top: 30px;
    color: #999999;
    font-size: 28px;
    line-height: 42px;
  }
  .noBroad-time{
    width: 690px;
    margin-top: 52px;
    color: #ffffff;
    font-size: 28px;
    line-height: 42px;
  }
  .teacherSay{
    margin-top: 5px;
    margin-left: 0px;
    width:140px;
    height:60px;
    border-radius: 10px;
    background-color: #2e74e9;
    justify-content: center;
    align-items: center;
  }
  .teacherSay-text{
    color: rgb(255, 255, 255);
    font-size:30px;
    line-height:50px;
  }
  .teacherSay-list-bg{
    position:absolute;
    right:0px;
    top: 0px;
    width: 423px;
    bottom: 5px;
  }
  .teacherSay-list{
    flex:1;
    width:400px;
    margin-top:13px;
    margin-left:25px;
    /* background-color: rgb(50, 58, 79); */
    background-color: #f5f8fe;
  }
  .teacherSay-list-cell{
    margin-top: 30px;
    padding-left: 18px;
    padding-right: 18px;
    padding-bottom: 10px;
    border-bottom-color: #e0e4eb;
    border-bottom-width: 1px;
  }
  .teacherSay-list-title{
    flex-direction: row;
    justify-content: space-between;
    margin-bottom: 10px;
    align-items: center;
  }
  .teacherSay-list-header-bg{
    flex-direction: row;
    align-items: center;
  }
  .teacherSay-onLine{
    position: absolute;
    left:40px;
    top:40px;
    width: 16px;
    height: 16px;
    border-radius: 8px;
    background-color: rgb(0, 255, 47);
  }
  .teacherSay-offLine{
    position: absolute;
    left:40px;
    top:40px;
    width: 16px;
    height: 16px;
    border-radius: 8px;
    background-color: gray;
  }
  .teacherSay-list-header{
    margin-right: 20px;
    width:56px;
    height:56px;
    border-radius:28px;
    overflow:hidden;
    background-color:#999999;
  }
  .teacherSay-list-teacher{
    font-size: 24px;
    line-height: 36px;
    /* color: rgb(255, 255, 255); */
    color: #333333;
  }
  .teacherSay-list-text{
    font-size: 24px;
    line-height: 36px;
    /* color: rgb(128, 141, 165); */
    color: #808da5;
    background-color: transparent;
  }
  .teacherSay-list-no{
    flex:1;
    width:400px;
    margin-top:13px;
    margin-left:18px;
    /* background-color: rgb(50, 58, 79); */
    background-color: #f5f8fe;
    justify-content: flex-start;
    align-items: center;
  }
  .teacherSay-list-no-text{
    font-size: 28px;
    line-height: 42px;
    color: rgb(116, 129, 151);
  }
  .teacherSayIcon-bg-d{
    position:absolute;
    left:25px;
    top: 0px;
    height: 13px;
    width: 400px;
    justify-content: center;
    align-items: center;
    /* background-color: rgb(50, 58, 79); */
    background-color: #f5f8fe;
  }
  .teacherSayIcon-bg{
    position:absolute;
    left:0px;
    top: 0px;
    width: 46px;
    height: 46px;
    border-radius: 23px;
    justify-content: center;
    align-items: center;
    background-color: rgb(12, 17, 35);
  }
  .teacherSayIcon{
    width: 24px;
    height: 22px;
  }
  .tabItem-bg{
    position:absolute;
    /*left:28px;*/
    top: 25px;
    border-radius: 5px;
    background-color: #ffffff;

    opacity: 0;
    left:128px;
  }
  .tabItemText-bg{
    flex: 1;
    padding-top: 20px;
    padding-bottom: 20px;
    padding-left: 30px;
    padding-right: 30px;
    align-items:center;
    justify-content:center;
  }
  .tabItemText-bg-top{
    border-top-color: #dddddd;
    border-top-width: 1px;
  }
  .tabItemText-gold{
    font-size: 28px;
    line-height: 42px;
    color: #2e74e9;
  }
  .tabItemText-black{
    font-size: 28px;
    line-height: 42px;
    color: #242424;
  }
</style>
