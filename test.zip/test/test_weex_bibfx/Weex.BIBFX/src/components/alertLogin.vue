<template>
  <div v-if="show" class="bg" @click="click">
    <div class="container">

      <image style="position: absolute;left: 0;top: 0;width: 122px;height: 94px" :src="alert_top_left" resize="cover"></image>
      <image style="position: absolute;right: 0;top: 0;width: 92px;height: 74px" :src="alert_top_right" resize="cover"></image>
      <image style="position: absolute;top: 0;left: 0;right: 0;bottom: 0;" :src="alert_bg" resize="cover"></image>
      <image style="position: absolute;right: 0;bottom: 0;width: 370px;height: 172px" :src="alert_bottom_right" resize="cover"></image>

      <div class="close" @click="close()">
        <image style="width: 26px;height: 26px;margin-right: 20px;margin-top: 20px" :src="alert_close" resize="cover"></image>
      </div>

      <div class="content">
        <text class="font32" style="color: rgb(51,51,51);text-align: center;letter-spacing: 1px">{{text}}</text>
      </div>
      <div class="bottom">
        <text class="font28" style="color: #ffffff;margin-right: 20px" @click="login">登录</text>
        <text class="font28" style="color: #ffffff;margin-right: 20px">|</text>
        <text class="font28" style="color: #ffffff;" @click="register">注册</text>
      </div>
    </div>

  </div>


</template>

<script>
  const loginTextType = {
    0: '游客观看时间已结束，请登录会员账号，即可继续观看直播。',
    1: '游客注册为直播室会员后，即可查看所有讲师的精彩策略分析！',
    2: '亲爱的游客，查看讲师即时交易策略，请立即注册/登录皇御直播间！',

  };
  const assetsUrl = require('../include/base-url.js').assetsUrl();
  export default {
    props: {
      show: { default: false },
      type: { default: 0},
    },
    data(){
      return{
        alert_top_right: assetsUrl + 'alert_top_right.png',
        alert_top_left: assetsUrl + 'alert_top_left.png',
        alert_bg: assetsUrl + 'alert_bg.png',
        alert_close: assetsUrl + 'alert_close.png',
        alert_bottom_right: assetsUrl + 'alert_bottom_right.png',

        text: loginTextType[0],
      }
    },
    watch: {
      type() {
        this.text = loginTextType[this.type];
      }
    },
    methods:{
      close:function () {
        this.show = false;
        this.$emit('close', this.type);
      },
      login:function () {
        this.$emit('login')
      },
      register:function () {
        this.$emit('register')
      },
      click:function(){

      }
    }

  }
</script>
<style src="../style/common.css" scoped></style>
<style scoped>
  .bg{
    position: fixed;
    left: 0px;
    top: 0px;
    right: 0px;
    bottom: 0px;
    /*兼容H5异常*/
    z-index: 99999;
    justify-content: center;
    align-items: center;
    background-color: rgba(0, 0, 0, 0.5);
  }
  .container{
    background-color: white;
    /*position: absolute;*/
    width: 688px;
    height: 410px;
    padding-top: 110px;
    padding-bottom: 172px;
    padding-left: 56px;
    padding-right: 56px;

    border-radius: 5px;

    justify-content: center;
    align-items: center;

  }
  .close{
    position: absolute;
    right: 0;
    top: 0;
    width: 92px;
    height: 74px;
    justify-content: flex-start;
    align-items: flex-end;
  }
  .content{
    text-align: center;
    justify-content: center;
    align-items: center;

  }
  .bottom{
    /*background-color: red;*/
    /*height: 88px;*/

    position: absolute;
    right: 30px;
    bottom: 20px;
    width: 200px;
    flex-direction: row;
    align-items: center;
    justify-content: center;
  }



</style>
