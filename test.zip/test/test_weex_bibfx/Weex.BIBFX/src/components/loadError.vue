<template>
<div>
  <div class="content">
    <image style="margin-bottom: 10px;height: 80px;width: 102px;overflow: hidden;" :src="netError"></image>
    <text style="margin-top: 30px;text-align: center;font-size: 28px;color: #454950;">数据加载失败</text>
    <text style="margin-top: 16px;text-align: center;font-size: 28px;color: #454950;">请检查您的手机是否联网</text>
    <div style="margin-top: 30px;width: 190px;height: 60px;border-width: 2px;border-color: #2e74e9;border-radius: 30px;justify-content: center;align-items: center;" @click="refreshNetWorkBtnClick()">
      <text style="text-align: center;font-size: 28px;  line-height:42px;color: #2e74e9;">刷新重试</text>
    </div>
  </div>
</div>
</template>

<script>
export default {
  name: "loadError"
}
var assetsUrl = require('../include/base-url.js').assetsUrl();
var firebase = weex.requireModule('firebase');

module.exports = {
  data: function() {
    return {
      netError: assetsUrl + 'net_error.png',
      cmsApiHost: '',
    }
  },
  created:function() {
    var that = this;
    // globalEvent.addEventListener("notification", function(e) {
    // });
  },
  methods: {
    refreshNetWorkBtnClick() {
        this.$emit('refreshNetWorkError');
      if (firebase) {
        firebase.logEventWithName('Error_retry');
      }
    },

  },
}
</script>

<style scoped>
.content {
  flex: 1;
  align-items: center;
  justify-content: center;
  background-Color: #FFFFFF;
}
</style>
