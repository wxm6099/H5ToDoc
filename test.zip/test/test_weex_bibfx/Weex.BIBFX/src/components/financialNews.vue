<template>
<div style="width: 750px">
  <div style="flex-direction: row;height: 80px;width: 750px;align-items: center;backgroundColor:#ffffff">
    <div class="content-item-date-vertical"></div>
    <div class="content-item-date-vertical-white" v-if="index == 0"></div>
    <div class="content-item-date-row"></div>
    <div class="content-item-line-radius"></div>
    <div class="content-item-date" v-if="news.showDayAndMonth">
      <text class="content-text-day">{{news.numDay}}</text>
      <text class="content-text-month">{{news.month}}月</text>
    </div>
    <text class="content-text-time">{{news.shoreTime}}</text>
  </div>
  <div style="width: 750px;backgroundColor:#ffffff">
    <div class="content-item-content">
      <text :class=" [(news.importance == '高')?'content-item-content-text-red':'content-item-content-text'] ">{{news.title}}</text>
    </div>
    <div v-if="'Calender' == news.newsType" class="content-item-content flexRow alignCenter">
      <text class="content-text-value">前值:</text>
      <text class="content-item-content-text-red content-text-width">{{news.forcastValue}}</text>
      <text class="content-text-value">预期:</text>
      <text class="content-item-content-text-red content-text-width">{{news.predictedValue}}</text>
      <text class="content-text-value">公布:</text>
      <text class="content-item-content-text-red content-text-width">{{news.publishedValue}}</text>
    </div>
    <div v-if="'Calender' == news.newsType" class="content-item-content flexRow alignCenter spaceBetween">
      <div style="height:50px;flex-direction:row;align-items:center;">
        <image class="content-image" :src="news.star>0?starSolid:starWhite"></image>
        <image class="content-image" :src="news.star>1?starSolid:starWhite"></image>
        <image class="content-image" :src="news.star>2?starSolid:starWhite "></image>
        <image class="content-image" :src="news.star>3?starSolid:starWhite "></image>
        <image class="content-image" :src="news.star>4?starSolid:starWhite "></image>
      </div>
      <div v-if="news.bullishOrBearish" class="content-right">
        <text :class="['content-text-size','content-text-'+news.color]">{{news.bullishOrBearish}}{{news.symbol?' '+news.symbol:''}}</text>
      </div>
    </div>
  </div>
</div>
</template>

<script>
const assetsUrl = require('../include/base-url.js').assetsUrl();
export default {
  props: {
    news: {
      default: []
    },
    index: 0,
  },

  data() {
    return {
      string: require('../include/string.js'),
      starWhite: assetsUrl + 'calendar_star_white.png',
      starSolid: assetsUrl + 'calendar_star_solid.png',
    }
  },
  mounted() {},

  created() {

  },
  methods: {

  }
}
</script>

<style scoped>
.flexRow{
  flex-direction: row;
}

.alignCenter{
  align-items: center;
}

.spaceBetween{
  justify-content: space-between;
}

.content-item-date {
  position: absolute;
  width: 60px;
  height: 60px;
  top: 20px;
  left: 20px;
  border-width: 2px;
  border-color: #e8e8e8;
  background-color: white;
}

.content-text-day {
  font-size: 24px;
  /*color: #e9302e;*/
  color: #2e74e9;
  text-align: center;
}

.content-text-month {
  font-size: 20px;
  /*color: #e9302e;*/
  color: #2e74e9;
  text-align: center;
}

.content-item-line-radius {
  position: absolute;
  top: 41px;
  left: 41px;
  width: 18px;
  height: 18px;
  border-radius: 18px;
  border-width: 4px;
  border-style: solid;
  border-color: #e8e8e8;
  /*background-color: #e9302e;*/
  background-color: #2e74e9;
}

.content-item-date-vertical-white {
  position: absolute;
  left: 49px;
  top: 0px;
  bottom: 0px;
  height: 20px;
  width: 2px;
  background-color: white;
}

.content-item-date-vertical {
  position: absolute;
  left: 49px;
  top: 0px;
  bottom: 0px;
  height: 80px;
  width: 2px;
  background-color: #f1f1f1;
}

.content-item-date-row {
  position: absolute;
  height: 2px;
  width: 36px;
  left: 50px;
  top: 49px;
  /*margin-right: 0px;*/
  background-color: #f1f1f1;
}

.content-text-time {
  position: absolute;
  left: 86px;
  top: 32px;
  height: 36px;
  width: 126px;
  /*padding-left: 10px;*/
  /*padding-right: 10px;*/
  padding-top: 5px;
  /*padding-bottom: 10px;*/
  background-color: #f7f7f7;
  border-radius: 28px;
  font-size: 24px;
  color: #9ba1ab;
  text-align: center;
  /*align-items: center;*/
}

.content-item-content-vartical {
  flex: 1;
  width: 2px;
  margin-left: 49px;
  background-color: #f1f1f1;
}

.content-item-content{
  width: 671px;
  margin-left: 49px;
  border-left-color: #f1f1f1;
  border-left-width: 2px;
  padding-left: 40px;
}

.content-text-width{
  margin-left: 20px;
  width: 100px;
}

.content-text-value{
  font-size: 28px;
  line-height: 48px;
  color: #666666;
}

.content-item-content-text{
  font-size: 28px;
  line-height: 36px;
  color: #454950;
}

.content-item-content-text-red{
  font-size: 28px;
  line-height: 36px;
  /*color: #e9302e;*/
  color: #2e74e9;
}

.content-image {
  margin-right: 8px;
  width: 24px;
  height: 24px;
  align-items: center;
  overflow: hidden;
}

.content-right{
  width: 100px;
  height: 32px;
  background-color: white;
  border-radius: 5px;
  border-width: 1px;
  border-color: #d4d4d4;
  justify-content: center;
  align-items: center;
}

.content-text-size{
  font-size: 20px;
  line-height: 30px;
  text-overflow: ellipsis;
}

.content-text-yellow {
  color: #f8bc37;
}

.content-text-red {
  /*color: #eb290f;*/
  color: #2e74e9;
}

.content-text-green {
  color: #30b700;
}
</style>
