<template>
<div class="calendar" @appear="onappear" @disappear="viewdisappear()">
  <div class="tabbar">
    <div v-for="(item,index) in channels" :class="[(tabIndex == index)?'tabbar-item-selected':'tabbar-item']" @click="tabClick(index)">
      <text :class="[(tabIndex == index)?'tabbar-text-selected':'tabbar-text']">{{item.title}}</text>
    </div>
  </div>
  <div class="calendar-channel">
    <scroller ref="calendarChannelScroller" class="calendar-scroller wrap" show-scrollbar="false" scrollDirection="horizontal">
      <div ref="calendarChannel" class="calendarchannel-item wrap" v-for="(itemDate , index) in arrCalendar" @click="selectCalendarDateClick(index)">
        <div class="calendarchannel-day-week">
          <text :class="[index == calendarIndex?'highlight-day':'normal-day']">{{itemDate.numDay}}</text>
          <text :class="[index == calendarIndex?'highlight-week':'normal-week']">{{itemDate.weekDay}}</text>
        </div>
        <div class="calendarchannel-month">
          <text :class="[index == calendarIndex?'highlight-month':'normal-month']">{{itemDate.BigMonth}}</text>
        </div>
        <div ref="calendarmark" v-if="index == calendarIndex" style="position: absolute;  bottom: 0px;left:0px;right: 0px;height: 4px; background-color: #2e74e9;"></div>
      </div>
    </scroller>
  </div>
<!--  <cycleslider class="calendar" auto-play="false" infinite="false" scrollable="false" scroll-direction="horizontal" @change="changeEvent" :index="tabIndex">-->
    <div v-if="tabIndex==0" class="calendar">
      <list style="background-color: #e8e8e8;" show-scrollbar="false" scrollDirection="vertical" alwaysScrollableVertical="false">
        <refresh class="refresh" @refresh="onrefresh" :display="channels[0].refreshing? 'show' : 'hide'">
          <loading-indicator class="indicator"></loading-indicator>
          <text class="indicator-text">{{channels[0].refreshing?"正在刷新":"下拉刷新"}}</text>
        </refresh>
        <header style="height:2px;" ref="header"></header>
        <cell class="content-cell" v-for="(item , index) in channels[0].datas" :key="index">
          <div class="content-cell-top">
            <div class="content-cell-top-date-vertical"></div>
            <div class="content-cell-top-date-row"></div>
            <div class="content-cell-top-line-radius" v-if="index != 0"></div>
            <div class="content-cell-top-line-white" v-if="index == 0"></div>
            <div class="content-cell-top-date-bg" v-if="index == 0">
              <text class="content-cell-top-date-text-day">{{item.onlyday}}</text>
              <text class="content-cell-top-date-text-month">{{item.onlymonth}}月</text>
            </div>
            <text class="content-cell-top-date-text-time">{{item.shortTime}}</text>
          </div>
          <div class="content-cell-middle">
            <div class="content-cell-middle-content">
              <text :class="['content-text-size',(item.importance == '高')?'content-text-red' : 'content-text-normal']">{{item.title}}</text>
            </div>
          </div>
          <div class="content-cell-bottom">
            <div class="content-cell-bottom-left">
              <div class="content-cell-bottom-left-up">
                <text class="content-cell-bottom-left-up-text">前值:{{item.forcastValue}}</text>
                <text class="content-cell-bottom-left-up-text">预期:{{item.predictedValue}}</text>
                <div class="content-cell-bottom-left-up-text-public">
                  <text class="content-cell-bottom-left-up-text-p">公布:</text>
                  <text :class="['content-bulltext-size','content-text-color-'+item.color]">{{item.publishedValue}}</text>
                </div>
              </div>
              <div class="content-cell-bottom-left-down">
                <image class="content-star" :src="item.star>0?starSolid:starWhite"></image>
                <image class="content-star" :src="item.star>1?starSolid:starWhite"></image>
                <image class="content-star" :src="item.star>2?starSolid:starWhite"></image>
                <image class="content-star" :src="item.star>3?starSolid:starWhite"></image>
                <image class="content-star" :src="item.star>4?starSolid:starWhite"></image>
                <div class="content-cell-bottom-left-down-right" >
                  <text :class="['content-bullbear-size','content-text-color-'+item.color]">{{item.bullAndBear}}{{item.symbol?' '+item.symbol:''}}</text>
                </div>
              </div>
            </div>
            <div class="content-cell-bottom-right">
              <image class="content-cell-bottom-right-image" :src="item.country"></image>
            </div>
          </div>
        </cell>
        <loading v-if="channels[0].loadinging && channels[0].datas.length>8" class="refresh" @loading="onloading" :display="channels[1].loadinging ? 'show' : 'hide'">
          <loading-indicator class="indicator"></loading-indicator>
          <text class="indicator-text">{{channels[0].loadinging?"正在加载":"上拉加载"}}</text>
        </loading>
      </list>
    </div>
    <div v-if="tabIndex==1" class="calendar">
      <list style="flex:1;width:750px;background-color: #e8e8e8;" show-scrollbar="false" scrollDirection="vertical" alwaysScrollableVertical="false">
        <refresh  class="refresh" @refresh="onrefresh" :display="channels[1].refreshing? 'show' : 'hide'">
          <loading-indicator class="indicator"></loading-indicator>
          <text class="indicator-text">{{channels[1].refreshing?"正在刷新":"下拉刷新"}}</text>
        </refresh>
        <cell class="content-cell flexRow" v-if="channels[1].datas.length>0">
          <div class="flexRow" style="margin-left:20px;margin-top:20px;width:90px;height:80px;background-color:#f5f5f5;justify-content: center;align-items: center;">
            <text  style="font-size:26px;line-height:39px;color:#454950;">时间</text>
          </div>
          <div class="flexRow" style="margin-top:20px;height:80px;width:120px;justify-content:center;align-items:center;background-color:#f5f5f5;">
            <text style="font-size:26px;line-height:39px;color:#454950;">国家/地区</text>
          </div>
          <div class="flexRow" style="margin-top:20px;height:80px;width:170px;justify-content:center;align-items:center;background-color:#f5f5f5;">
            <text style="font-size:26px;line-height:39px;color:#454950;text-align:center;">重要性</text>
          </div>
          <div class="flexRow" style="margin-top:20px;height:80px;width:330px;justify-content:center;align-items:center;background-color:#f5f5f5;">
            <text style="font-size:26px;line-height:39px;color:#454950;">事件</text>
          </div>
        </cell>
        <cell class="content-cell" v-for="(item , index) in channels[1].datas">
          <div class="flexRow alignCenter bottomBorder" style="margin-left:20px;width:710px;">
            <text class="textCenter" style="width:90px;font-size:26px;line-height:39px;color:#454950;">{{item.calenderTime}}</text>
            <text class="textCenter" style="width:120px;font-size:26px;line-height:39px;color:#454950;">{{item.countryName}}</text>
            <div  class="flexRow" style="width:170px;padding-left:8px;align-items:center;">
              <image class="content-star" :src="item.star>0?starSolid:starWhite"></image>
              <image class="content-star" :src="item.star>1?starSolid:starWhite"></image>
              <image class="content-star" :src="item.star>2?starSolid:starWhite "></image>
              <image class="content-star" :src="item.star>3?starSolid:starWhite "></image>
              <image class="content-star" :src="item.star>4?starSolid:starWhite "></image>
            </div>
            <div class="leftBorder flexRow" style="min-height:80px;width:330px;margin-right:20px;align-items:center;">
              <text style="padding-left:10px;width:330px;font-size:26px;line-height:39px;color:#454950;">{{item.title}}</text>
            </div>
            <div class="leftBorder rightBorder" style="position:absolute;left:90px;width:120px;height:350px;"></div>
          </div>
        </cell>
        <loading v-if="channels[1].loadinging && channels[1].datas.length>8" class="refresh" @loading="onloading" :display="channels[1].loadinging ? 'show' : 'hide'">
          <loading-indicator class="indicator"></loading-indicator>
          <text class="indicator-text">{{channels[1].loadinging?"正在加载":"上拉加载"}}</text>
        </loading>
      </list>
    </div>
    <div v-if="tabIndex==2" class="calendar">
      <list style="flex:1;width:750px;background-color: #e8e8e8;" show-scrollbar="false" scrollDirection="vertical" alwaysScrollableVertical="false">
        <refresh  class="refresh" @refresh="onrefresh" :display="channels[2].refreshing? 'show' : 'hide'">
          <loading-indicator class="indicator"></loading-indicator>
          <text class="indicator-text">{{channels[2].refreshing?"正在刷新":"下拉刷新"}}</text>
        </refresh>
        <cell class="content-cell flexRow" v-if="channels[2].datas.length>0">
          <div style="margin-left:20px;margin-top:20px;width:145px;height:80px;background-color:#f5f5f5;justify-content: center;align-items: center;">
            <text style="font-size:26px;line-height:39px;color:#454950;">国家/地区</text>
          </div>
          <div style="margin-top:20px;height:80px;width:210px;justify-content:center;align-items:center;background-color:#f5f5f5;">
            <text style="font-size:26px;line-height:39px;color:#454950;">市场</text>
          </div>
          <div style="margin-top:20px;height:80px;width:210px;justify-content:center;align-items:center;background-color:#f5f5f5;">
            <text  style="font-size:26px;line-height:39px;color:#454950;">节日名称</text>
          </div>
          <div style="margin-top:20px;height:80px;width:145px;justify-content:center;align-items:center;background-color:#f5f5f5;">
            <text style="font-size:26px;line-height:39px;color:#454950;">详细安排</text>
          </div>
        </cell>
        <cell class="content-cell flexRow" v-for="(item , index) in channels[2].datas">
          <div class="flexRow alignCenter bottomBorder" style="margin-left:20px;width:710px;">
            <text class="textCenter" style="width:145px;font-size:26px;line-height:39px;color:#454950;">{{item.countryName}}</text>
            <text class="textCenter" style="width:210px;font-size:26px;line-height:39px;color:#454950;">{{item.exchangeName}}</text>
            <text class="textCenter" style="width:210px;font-size:26px;line-height:39px;color:#454950;">{{item.holidayName}}</text>
            <div class="leftBorder flexRow " style="min-height:80px;width:145px;margin-right:20px;align-items:center;">
              <text style="padding-left:10px;width:145px;font-size:26px;line-height:39px;color:#454950;">{{item.title}}</text>
            </div>
            <div class="leftBorder rightBorder" style="position:absolute;left:145px;width:210px;height:350px;"></div>
          </div>
        </cell>
        <loading v-if="channels[2].loadinging && channels[2].datas.length>8" class="refresh" @loading="onloading" :display="channels[2].loadinging ? 'show' : 'hide'">
          <loading-indicator class="indicator"></loading-indicator>
          <text class="indicator-text">{{channels[2].loadinging?"正在加载":"上拉加载"}}</text>
        </loading>
      </list>
    </div>
<!--  </cycleslider>-->
  <div v-if="isEmptyData" class="tips" @longpress ="OnLongPress()" @click ="onSwipe()" >
    <image class="tipsIcon" resize="contain" :src="tipsIcon"></image>
    <text class="tipsText">{{channels[tabIndex].tips}}</text>
  </div>
</div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var dom = weex.requireModule('dom')
var navigator = weex.requireModule('navigator')
var app = weex.requireModule('app')
var storage = require('../include/storage.js');
var http = require('../include/http.js');
var url = require('../include/url.js');
var strings = require('../include/string.js');
var modal = weex.requireModule('modal');
const Network = new BroadcastChannel('financialNetworkError');

export default {
  name: "financialCalendar",
  props: {
    calendars: {
      default: []
    },
    filterParams: {},
  },
  watch: {
    filterParams() {
      this.publishType = this.filterParams.type;
      this.country = this.filterParams.country;
      this.importantLevel = this.filterParams.level;
      this.star = this.filterParams.star;
      this.onrefresh();
    },
  },
  computed: {},

  data() {
    return {
      string: require('../include/string.js'),
      assets: assetsUrl,
      // flagOne: assetsUrl + 'calendar_flag_one.png',
      // flagTwo: assetsUrl + 'calendar_flag_two.png',
      // flagThree: assetsUrl + 'calendar_flag_three.png',
      starWhite: assetsUrl + 'calendar_star_white.png',
      starSolid: assetsUrl + 'calendar_star_solid.png',
      tipsIcon: assetsUrl + 'calendar.png',
      // calendarWidth: 115, //日历单个日期item的宽度
      // calendarPosition: 10, //日历单个日期item的起始位置
      calendarIndex: -1, //日历中点击的日期
      mySelectedDate: new Date(), //选中的日期值（用于数据请求）默认当前日期
      calendarIndexNow: -2, //首次进入默认选中的当天日期值（当前日期）

      arrCalendar: [], //顶部日期日历的数组
      loadingData: false, //加载中
      refreshing: false, //刷新中
      loadinging: true, //加载

      total: -1, //数据的条数
      isFirstInCalendar: false, //是否首次进入财经日历
      isEmptyData:false,
      publishType: '', //是否发布
      star:0,//星级
      importantLevel: '', //重要度
      country: '', //国家地区 以逗号分隔
      updateCount:0,
      tid:0,
      tabIndex:0,
      cmsApiHost:'',
      channels:[{title:'数据',type:'日历',datas:[],tips:'今日无重要经济数据',refreshing:false,loadinging:false,loadingData:false},{title:'事件',type:'事件',datas:[],tips:'今日无财经大事',refreshing:false,loadinging:false,loadingData:false},{title:'假期',type:'假期',datas:[],tips:'今日无假期休市安排',refreshing:false,loadinging:false,loadingData:false}]
    }
  },
  mounted() {
    // setTimeout(this.selectCalendarDateClick.bind(this), 500); //延迟0.3秒执行默认值（默认选中当前日期）
  },
  created: function() {
    var selfThis = this;
    storage.getItem('commonUrl',function(value) {
      if ('' == value || value == undefined || value.length <= 0) {
        return
      }
      var commonUrl = JSON.parse(value);
      if (commonUrl) {
        selfThis.cmsApiHost = commonUrl.cmsApi; //接口基址
      }
    });
    selfThis.isFirstInCalendar = true;

    selfThis.arrCalendar = selfThis.getDayCountsByMonth(selfThis.mySelectedDate); //得到顶部日历的数组
    for (var i = 0; i < selfThis.arrCalendar.length; i++) {
      selfThis.arrCalendar[i].pageIndex = 0;
      selfThis.arrCalendar[i].contents = [];
    }
    var dicDate = selfThis.getNowDate(selfThis.mySelectedDate);
    selfThis.calendarIndexNow = dicDate.day - 1; //顶部日历默认选中当前天(顶部日历从0开始即0-30，所以需要减一)

    // 接收日历选择的日期广播的值
    const calendar = new BroadcastChannel('selectCalendarDayNumber');
    calendar.onmessage = function(event) {
      var selectDay = new Date(event.data);
      selfThis.arrCalendar = selfThis.getDayCountsByMonth(selectDay); //得到顶部日历的数组
      for (var i = 0; i < selfThis.arrCalendar.length; i++) {
        selfThis.arrCalendar[i].pageIndex = 0;
        selfThis.arrCalendar[i].contents = [];
      }
      var dicDate = selfThis.getNowDate(selectDay);
      selfThis.calendarIndexNow = dicDate.day - 1; //顶部日历默认选中当前天(顶部日历从0开始即0-30，所以需要减一)
      selfThis.selectCalendarDateClick(selfThis.calendarIndexNow);
    }
    // 接收资讯页选择财经快讯的广播
    const androidBroadcast = new BroadcastChannel('androidDefaultCalendarDate');
    androidBroadcast.onmessage = function(event) {
      var selectDay = new Date(event.data);
      selfThis.arrCalendar = selfThis.getDayCountsByMonth(selectDay); //得到顶部日历的数组
      for (var i = 0; i < selfThis.arrCalendar.length; i++) {
        selfThis.arrCalendar[i].pageIndex = 0;
        selfThis.arrCalendar[i].contents = [];
      }
      var dicDate = selfThis.getNowDate(selectDay);
      selfThis.calendarIndexNow = dicDate.day - 1; //顶部日历默认选中当前天(顶部日历从0开始即0-30，所以需要减一)
      setTimeout(() => {
        selfThis.selectCalendarDateClick(selfThis.calendarIndexNow);
      }, 300);
    }
  },

  methods: {
    // 接收网络错误的点击事件的回调
    refreshNetWorkError: function() {
      this.onrefresh();
    },
     tabClick:function(index){
       if (index >= this.channels.length || index == this.tabIndex) {
         return;
       }
       this.channels[1].datas = [];
       this.channels[2].datas = [];
       this.tabIndex = index;
       this.selectCalendarDateClick(this.calendarIndex);
     },
    //参数index为选中的日期（0-30）  参数strDate为选中日期的真实年月日2018-05-25
    getTheCalendarData: function(index, strDate) {
      let selfThis = this;
      let channelItem = this.channels[this.tabIndex];
      if (channelItem.loadingData) {
        return;
      }

      channelItem.loadingData = true;
      let url = `${selfThis.cmsApiHost}/News/Calender?format=json&CalenderType=${this.channels[this.tabIndex].type}&OrderBy=AddDate&date=${strDate}&Countrys=${this.country}&IsPublished=${this.publishType}`;
      if (this.star > 0) {
        url = url+'&Star='+this.star
      }
      http.get(encodeURI(url), function(response) {
        selfThis.channels[selfThis.tabIndex].refreshing = false;
        selfThis.channels[selfThis.tabIndex].loadinging = false;
        selfThis.channels[selfThis.tabIndex].loadingData = false;
        // 广播传递财经日历的网络状态是否正常的状态到咨询页面(财经日历和咨询不在同一个页面)

        if (response.status >= 200) {
          Network.postMessage('no'); //网络正常
        } else {
          Network.postMessage('yes'); //网络异常
        }

        if (response.ok && response.data) {
          var results = response.data.Results;
          if (results && results.length > 0) {
            channelItem.datas.splice(0,channelItem.datas.length);
            if (0 == selfThis.tabIndex) {
              selfThis.gotoFirstCell();
            }
            for (let i = 0; i < results.length; i++) {
              var item = {};
              item.nodeId = results[i].ID;
              item.nationality = results[i].nationality;
              item.Influence = results[i].Influence; //
              item.place = results[i].place; //
              item.predictedValue = results[i].PredictedValue; ////预测值
              item.forcastValue = results[i].ForcastValue; //前值
              item.title = results[i].Title; //指标内容
              item.publishedValue = results[i].PublishedValue; //公布值
              // item.calenderTime = results[i].CalenderTime; //时间
              item.holidayName = results[i].HolidayName; //节日名称
              item.exchangeName = results[i].ExchangeName; //交易商名称
              item.published = results[i].IsPublished //是否已公布
              if (results[i].RelationSymbol) {
                item.symbol = results[i].RelationSymbol.replace(/-/g,'');
              }

              if (results[i].Country) {
                item.countryName = results[i].Country;
                item.country = assetsUrl + 'flags/' + strings.country[results[i].Country] + '.png'; //国家（判断国旗）
              }
              if (results[i].CalenderOn) {
                var stamp = results[i].CalenderOn.replace('/Date(', '').replace(')/', '').substring(0, 13);
                item.time = parseInt(stamp); //日期值
              }


              var date = new Date(item.time);
              item.onlyyear = date.getFullYear();
              item.onlymonth = date.getMonth() + 1;
              item.onlyday = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
              var onlyhour = date.getHours();
              onlyhour = onlyhour < 10 ? '0' + onlyhour : onlyhour;
              var onlyminute = date.getMinutes();
              onlyminute = onlyminute < 10 ? '0' + onlyminute : onlyminute;
              var onlysecond = date.getSeconds();
              onlysecond = onlysecond < 10 ? '0' + onlysecond : onlysecond;
              item.shortTime = onlyhour + ':' + onlyminute + ':' + onlysecond;
              item.calenderTime = onlyhour + ':' + onlyminute;

              item.importance = results[i].Importance; //重要性100-3心(字体红色)  101-2心 102-1心

              if (results[i].Star) {
                item.star = results[i].Star;
              }else {
                item.star = 0;
              }

              item.bullAndBear = results[i].BullishOrBearish;
              if (results[i].BullishOrBearish == '利空') {
                item.color = 'red';
              } else if (results[i].BullishOrBearish == '利多') {
                item.color = 'green';
              } else if (results[i].BullishOrBearish == '影响较小') {
                item.color = 'yellow';
              }else {
                item.color = 'common';
              }
              channelItem.datas.push(item);
            }
            channelItem.pageIndex++;
          } else {
            channelItem.datas.splice(0, channelItem.datas.length);
            channelItem.loadinging = false;
            channelItem.refreshing = false;
            channelItem.loadingData = false;
          }
          if (channelItem.datas.length==0){
              selfThis.isEmptyData =true;
          }else{
            selfThis.isEmptyData =false;
          }
        }
      });
    },
    //日历数据滚动到首条
    gotoFirstCell: function() {
      if (this.$refs.header) {
        dom.scrollToElement(this.$refs.header, {
          offset: 0
        });
      }
    },
     OnLongPress:function(){
        return;
     },
       onSwipe:function(){
        return;
     },

    selectCalendarDateClick: function(index = this.calendarIndexNow) {
      if (index >= this.arrCalendar.length || index < 0) {
        return;
      }
      this.calendarIndex = index;
      this.highlight();
      this.arrCalendar[this.calendarIndex].pageIndex = 0;
      if (this.arrCalendar[this.calendarIndex].pageIndex <= 0) {
        this.arrCalendar[this.calendarIndex].pageIndex = 1;
        var nowCalendar = this.arrCalendar[index];
        var str_date = nowCalendar.calendarYear + '-' + nowCalendar.numMonth + '-' + nowCalendar.numDay;
        this.getTheCalendarData(index, str_date);
      }

      //storage存储 财经日历 选择的日历的日期值
      var nowCalendar = this.arrCalendar[index];
      var str_date = nowCalendar.calendarYear + '/' + nowCalendar.numMonth + '/' + nowCalendar.numDay;
      storage.setItem("financialCalendarSelectDayNumber", str_date);
    },

    //高亮选中的栏目
    highlight: function() {
      var that = this;
      if (undefined == this.$refs.calendarChannel) {
        return;
      }
      var el = this.$refs.calendarChannel[this.calendarIndex];
      if (el == undefined) {
        return;
      }
      this.$refs.calendarChannelScroller.getContentOffset(function(contentOffset) {
        dom.getComponentRect(el, function(callBack) {
          if (callBack.result == true) {
            if (contentOffset.x <= 0) {
              that.arrCalendar[that.calendarIndex].left = callBack.size.left - contentOffset.x;
            } else {
              that.arrCalendar[that.calendarIndex].left = callBack.size.left;
            }
            that.arrCalendar[that.calendarIndex].width = callBack.size.width;
            that.arrCalendar[that.calendarIndex].right = callBack.size.right;
            var itemWidth = that.arrCalendar[that.calendarIndex].width;
            var offset = -that.arrCalendar[that.calendarIndex].left;
            if ((that.arrCalendar[that.calendarIndex].left + itemWidth / 2) > 375) {
              offset = (that.arrCalendar[that.calendarIndex].width - 750) / 2;
            }
            if (el) {
              dom.scrollToElement(el, {
                offset: offset,
                animated: false
              });
            }
          }
        });
      });
    },

    onappear: function() {

    },
    viewdisappear: function() {

    },
    onrefresh: function(e) {

      var channelItem = this.arrCalendar[this.calendarIndex];
      if (false == this.channels[this.tabIndex].refreshing) {
        this.channels[this.tabIndex].refreshing = true;
        setTimeout(() => {
          channelItem.pageIndex = 0;
          var str_date = channelItem.calendarYear + '-' + channelItem.numMonth + '-' + channelItem.numDay;
          this.getTheCalendarData(this.calendarIndex, str_date);
        }, 500)
      }
    },
    onloading: function(e) {
      var channelItem = this.arrCalendar[this.calendarIndex];
      if (false == this.channels[this.tabIndex].loadinging && false == this.channels[this.tabIndex].loadingData) {
        this.channels[this.tabIndex].loadinging = true;
        setTimeout(() => {
          //没有加载更多数据 但需要加载更多的效果
          this.channels[this.tabIndex].refreshing = false;
          this.channels[this.tabIndex].loadinging = false;
          this.channels[this.tabIndex].loadingData = false;
        }, 500)
      }
    },

    //计算当前日期值（1-31）
    getNowDate: function(date = new Date()) {
      // var date = new Date();
      var year = date.getFullYear(); //获取完整的年份(4位,1970-????)
      var month = date.getMonth() + 1; //获取当前月份(0-11,0代表1月 加1后正常)
      var numMonth = month < 10 ? '0' + month : month;
      var day = date.getDate(); //当前月份的日期（1-31）（不同月份日期值不同）
      var numDay = day < 10 ? '0' + day : day;
      var hour = date.getHours();
      var numHour = hour < 10 ? '0' + hour : hour;
      var minute = date.getMinutes();
      var numMinute = minute < 10 ? '0' + minute : minute;
      var second = date.getSeconds();
      var numSecond = second < 10 ? '0' + second : second;
      var week = date.getDay();
      var YMD = year + '-' + month + '-' + day;
      var numYMD = year + '-' + numMonth + '-' + numDay;
      var HMS = hour + ':' + minute + ':' + second;
      var numHMS = numHour + ':' + numMinute + ':' + numSecond;
      var dic = {
        year: year,
        month: month,
        numMonth: numMonth,
        day: day,
        numDay: numDay,
        hour: hour,
        numHour: numHour,
        minute: minute,
        numMinute: numMinute,
        second: second,
        numSecond: numSecond,
        week: week,
        YMD: YMD,
        numYMD: numYMD,
        HMS: HMS,
        numHMS: numHMS,
      };
      return dic;
    },
    changeEvent:function(e){
        if(this.tabIndex!= e.index) {
          this.tabClick(e.index);
        }
    },
    //根据年月  得到指定的整个月份的所有日期和星期
    getDayCountsByMonth: function(date = new Date()) {
      var datearr = [];

      var year = date.getFullYear(); //获取完整的年份(4位,1970-????)
      var month = date.getMonth(); //获取当前月份(0-11,0代表1月)
      var numMonth = month + 1;
      numMonth = numMonth < 10 ? '0' + numMonth : numMonth;
      // var day = date.getDate();//当前月份的日期（1-31）（不同月份日期值不同）
      // var hour = date.getHours();
      // var minute = date.getMinutes();
      // var second = date.getSeconds();
      // var week = date.getDay();//星期（0-6）

      //此Date方法中的参数代表year年第month+1月的第0天 但是这个方法会自动将其转换为 year年第month月的最后一天 最后一天的数值就为month月的总天数
      var newDays = new Date(year, month + 1, 0);
      var dayCounts = newDays.getDate(); //得到指定月份的总天数

      for (var i = 1; i <= dayCounts; i++) {
        var newDate = new Date(year, month, i);
        var numDay = i;
        var newDay = numDay < 10 ? '0' + numDay : numDay; //天数不足10的在前面加0
        var newMonth = month; //将月份转成大写
        if (newMonth == 0) {
          newMonth = '一月';
        } else if (newMonth == 1) {
          newMonth = '二月';
        } else if (newMonth == 2) {
          newMonth = '三月';
        } else if (newMonth == 3) {
          newMonth = '四月';
        } else if (newMonth == 4) {
          newMonth = '五月';
        } else if (newMonth == 5) {
          newMonth = '六月';
        } else if (newMonth == 6) {
          newMonth = '七月';
        } else if (newMonth == 7) {
          newMonth = '八月';
        } else if (newMonth == 8) {
          newMonth = '九月';
        } else if (newMonth == 9) {
          newMonth = '十月';
        } else if (newMonth == 10) {
          newMonth = '十一月';
        } else if (newMonth == 11) {
          newMonth = '十二月';
        }

        var newWeek = newDate.getDay(); //将星期转成周
        if (newWeek == 0) {
          newWeek = '周日';
        } else if (newWeek == 1) {
          newWeek = '周一';
        } else if (newWeek == 2) {
          newWeek = '周二';
        } else if (newWeek == 3) {
          newWeek = '周三';
        } else if (newWeek == 4) {
          newWeek = '周四';
        } else if (newWeek == 5) {
          newWeek = '周五';
        } else if (newWeek == 6) {
          newWeek = '周六';
        }
        datearr.push({
          calendarYear: year,
          calendarMonth: month + 1,
          numMonth: numMonth,
          BigMonth: newMonth,
          calendarDay: numDay,
          numDay: newDay,
          weekDay: newWeek,
        });
      }
      return datearr;
    },
    showTips:function(count){
      if (count<=0) {
        return;
      }
      var that = this;
      this.updateCount = count;
      if (this.tid != 0) {
          clearTimeout(this.tid);
      }
      this.tid = setTimeout(() => {
        that.updateCount = 0;
      }, 2000);
    },
    //进入日历
    onclickcalendar: function() {

    },
  },
}
</script>

<style scoped>
.wrap {
  overflow: hidden;
}

.calendar {
  flex: 1;
  width: 750px;
  background-color: #e8e8e8;
}

.calendar-channel {
  width: 750px;
  border-bottom-width: 2px;
  border-bottom-color: #e8e8e8;
  background-color: #ffffff;
}

.calendar-scroller {
  height: 88px;
  flex-direction: row;
  padding-left: 10px;
  padding-right: 10px;
  background-color: white;
  /* margin-right: 5px; */
}

.calendarchannel-item {
  /*margin-left: 5px;*/
  /*margin-right: 5px;*/
  height: 88px;
  width: 115px;
  /*background-color: gold;*/
}

.calendarchannel-day-week {
  flex-direction: row;
  width: 115px;
  height: 48px;
  justify-content: center
}

.calendarchannel-month {
  flex-direction: row;
  justify-content: center;
  align-items: center;
  width: 115px;
  height: 36px;
}

.normal-day {
  font-size: 34px;
  margin-top: 8px;
  text-align: center;
  color: #454950;
}

.highlight-day {
  font-size: 34px;
  margin-top: 8px;
  text-align: center;
  /*color: #e9302e;*/
  color: #2e74e9;
}

.normal-week {
  position: relative;
  font-size: 16px;
  margin-left: 8px;
  margin-top: 28px;
  color: #454950;
  /*background-color: gray;*/
}

.highlight-week {
  position: relative;
  font-size: 16px;
  margin-left: 8px;
  margin-top: 28px;
  /*color: #e9302e;*/
  color: #2e74e9;
}

.normal-month {
  font-size: 16px;
  color: #454950;
}

.highlight-month {
  font-size: 16px;
  /*color: #e9302e;*/
  color: #2e74e9;
}

.refresh {
  width: 750px;
  height: 80px;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  background-color: #e8e8e8;
}

.indicator-text {
  color: #888888;
  font-size: 30px;
  margin-left: 8px;
  text-align: center;
}

.indicator {
  height: 50px;
  width: 50px;
  color: gray;
}

.content-cell {
  width: 750px;
  background-color: #ffffff;
  overflow: hidden;
  /*height: 200px;*/
  /*background-color: purple;*/
  /*height: 240px;*/
  /*padding-left: 30px;*/
  /*padding-right: 30px;*/
  /*padding-top: 40px;*/
  /*padding-bottom: 40px;*/
  /*border-bottom-width: 1px;*/
  /*border-bottom-color: sandybrown;*/
}

.content-cell-top {
  flex-direction: row;
  height: 80px;
  width: 750px;
  align-items: center;
  /*background-color: powderblue;*/
}

.content-cell-top-date-vertical {
  position: absolute;
  left: 49px;
  top: 0px;
  bottom: 0px;
  height: 80px;
  width: 2px;
  background-color: #f1f1f1;
  /*flex-direction: row;*/
}

.content-cell-top-date-row {
  position: absolute;
  height: 2px;
  width: 36px;
  left: 50px;
  top: 49px;
  /*margin-right: 0px;*/
  background-color: #f1f1f1;
  /*background-color: blue;*/
  /*flex-direction: row;*/
}

.content-cell-top-line-white {
  position: absolute;
  left: 49px;
  top: 0px;
  bottom: 0px;
  height: 20px;
  width: 2px;
  background-color: white;
}

.content-cell-top-line-radius {
  position: absolute;
  top: 41px;
  left: 41px;
  width: 18px;
  height: 18px;
  border-radius: 18px;
  border-width: 4px;
  border-style: solid;
  border-color: #e8e8e8;
  /*background-color: #e9302e;*/
  background-color: #2e74e9;
}

.content-cell-top-date-bg {
  position: absolute;
  width: 60px;
  height: 60px;
  top: 20px;
  left: 20px;
  border-width: 2px;
  border-color: #e8e8e8;
  background-color: white;
}

.content-cell-top-date-text-day {
  font-size: 24px;
  /*color: #e9302e;*/
  color: #2e74e9;
  text-align: center;
  background-color: white;
}

.content-cell-top-date-text-month {
  font-size: 20px;
  /*color: #e9302e;*/
  color: #2e74e9;
  background-color: white;
  text-align: center;
}

.content-cell-top-date-text-time {
  position: absolute;
  left: 86px;
  top: 32px;
  height: 36px;
  width: 126px;
  /*padding-left: 10px;*/
  /*padding-right: 10px;*/
  padding-top: 5px;
  /*padding-bottom: 10px;*/
  background-color: #f7f7f7;

  border-radius: 28px;
  font-size: 24px;
  color: #9ba1ab;
  text-align: center;
}

.content-cell-middle {
  width: 750px;
  flex-direction: row;
  /*background-color: papayawhip;*/
}

.content-cell-middle-content-vartical {
  width: 2px;
  flex: 1;
  margin-left: 49px;
  background-color: #f1f1f1;
}

.content-cell-middle-content {
  width: 562px;
  margin-right: 136px;
  margin-left: 49px;
  border-left-color: #f1f1f1;
  border-left-width: 2px;
  padding-left: 44px;
  overflow: hidden;
}

.content-text-size{
  font-size: 28px;
  line-height: 36px;
}

.content-text-normal {
  color: #454950;
}

.content-text-red {
  /*color: #e9302e;*/
  color: #2e74e9;
}

.content-cell-bottom {
  flex: 1;
  width: 750px;
  flex-direction: row;
  align-items: center;
  /*background-color: gold;*/
}

.content-cell-bottom-content-vartical {
  width: 2px;
  flex: 1;
  margin-left: 49px;
  background-color: #f1f1f1;
}

.content-cell-bottom-left {
  flex-direction: column;
  /*margin-left: 44px;*/
  margin-top: 0px;
  margin-right: 24px;
  padding-bottom: 10px;

  margin-left: 49px;
  border-left-color: #f1f1f1;
  border-left-width: 2px;
  padding-left: 44px;
  /*background-color: purple;*/
}

.content-cell-bottom-left-up {
  flex-direction: row;
  margin-left: 0px;
  margin-top: 16px;
  margin-right: 0px;
  /*justify-content: center;*/
  align-items: center;
  /*background-color: gold;*/
}

.content-cell-bottom-left-up-text {
  width: 172px;
  /*margin-right: 10px;*/
  font-size: 24px;
  /*line-height: 36px;*/
  /*text-align: center;*/
  vertical-align: center;
  color: #9ba1ab;
}

.content-cell-bottom-left-up-text-public {
  flex-direction: row;
  margin-left: 0px;
  width: 172px;
  align-items: center;
}



.content-cell-bottom-left-up-text-p {
  margin-top: 1px;
  /*width: 75px;*/
  font-size: 24px;
  color: #9ba1ab;
  /*text-align: center;*/
  vertical-align: center;
  /*background-color: powderblue;*/
}

.content-bulltext-size{
  font-size: 24px;
  text-align: center;
  vertical-align: center;
}

.content-text-color-common{
  color: #9ba1ab;
}

.content-text-color-yellow{
  color: #f8bc37;
}

.content-text-color-red{
  /*color: #eb290f;*/
  color: #2e74e9;
}

.content-text-color-green{
  color: #30b700;
}

.content-cell-bottom-left-down {
  flex-direction: row;
  margin-left: 0px;
  margin-top: 12px;
  width: 516px;
  height: 34px;
  /*margin-right: 0px;*/
  align-items: center;
  /*background-color: gray;*/
}

.content-star {
  margin-right: 8px;
  width: 24px;
  height: 24px;
  align-items: center;
  overflow: hidden;
  /*background-color: powderblue;*/
}

.content-cell-bottom-left-down-right {
  position: absolute;
  margin-top: 1px;
  right: 72px;
  width: 100px;
  height: 32px;
  background-color: white;
  border-radius: 5px;
  border-width: 1px;
  border-color: #d4d4d4;

  justify-content: center;
  align-items: center;
  text-align: center;
  vertical-align: center;

  /*background-color: blueviolet;*/
}

.content-bullbear-size{
  flex-direction: row;
  font-size: 20px;
  line-height: 30px;
  text-align: center;
  vertical-align: center;
}

.content-cell-bottom-right {
  margin-right: 52px;
  /*flex: 2;*/
  /*flex-direction: row;*/
  /*justify-content: flex-end;*/
  /*align-items: center;*/
  overflow: hidden;
  /*background-color: blue;*/
}

.content-cell-bottom-right-image {
  width: 60px;
  height: 60px;
}

.tips {
  position: absolute;
  top: 160px;
  bottom: 0px;
  left: 0px;
  right: 0px;
  justify-content: center;
  align-items: center;
  background-color: #ffffff;
}

.tipsIcon {
  width: 142px;
  height: 124px;
}

.tipsText {
  margin-top: 24px;
  font-size: 26px;
  line-height: 38px;
  text-align: center;
  color: #999999;
}

.modulCalendar {
  position:absolute;
  left:185px;
  bottom:60px;
  width: 400px;
  height: 74px;
  border-radius: 37px;
  align-items: center;
  justify-content: center;
  padding-left: 60px;
  padding-right: 60px;
  background-color: rgba(0, 0, 0, 0.7);
  /* margin-bottom: 60px; */
}

.tabbar{
  width: 750px;
  height: 70px;
  padding-left: 21px;
  flex-direction: row;
  align-items: center;
  background-color: #F1F1F1;
}

.tabbar-item{
  width: 236px;
  height: 70px;
  align-items: center;
  justify-content: center;
  background-color: #f5f5f5;
  border-top-width: 4px;
  border-top-color: #f5f5f5;
}

.tabbar-item-selected{
  width: 236px;
  height: 70px;
  align-items: center;
  justify-content: center;
  background-color: #ffffff;
  border-top-width: 4px;
  /*border-top-color: red;*/
  border-top-color: #2e74e9;
}

.tabbar-text{
  font-size: 28px;
  line-height: 42px;
  color: #454950;
  text-align: center;
}

.tabbar-text-selected{
  font-size: 28px;
  line-height: 42px;
  /*color: #e9302e;*/
  color: #2e74e9;
  text-align: center;
}

.flexRow{
  flex-direction: row;
}

.leftBorder{
  border-left-color: #f5f5f5;
  border-left-width: 1px;
}

.rightBorder{
  border-right-color: #f5f5f5;
  border-right-width: 1px;
}

.bottomBorder{
  border-bottom-color: #f5f5f5;
  border-bottom-width: 1px;
}

.border{
  border-color: red;
  border-width: 1px;
}

.border1{
  border-color: blue;
  border-width: 2px;
}

.justifyCenter{
  justify-content: center;
}

.alignCenter{
  align-items: center;
}

.textCenter
{
  text-align: center;
}
</style>
