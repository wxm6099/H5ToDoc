<template>
  <div class="avatar-bg" @click="cancel">
    <div ref="test2" class="avatar-controller">
      <div class="avatar-view">
          <div v-for="item in avatarArr" class="item" @click="selectAvatar(item)">
            <image class="item-img" :src="item.src"></image>
            <image v-if="item.select" class="select-img" resize="contain" :src="assets + 'avatar_select.png'"></image>
          </div>
      </div>
      <div class="action-view">
        <div class="button" @click="cancel">
          <text class="font34" style="color: #ffffff">取消</text>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  const http = require('../include/http.js');
  var storage = require('../include/storage.js');
  var assetsUrl = require('../include/base-url.js').assetsUrl();
  let select = assetsUrl + 'avatar_select.png';

  const modal = weex.requireModule('modal');
  const animation = weex.requireModule('animation')

  module.exports = {
    props: {
      show: { default : false }
    },
    name: "chooseAvatar",
    data: function () {
      return {
        assets: assetsUrl,
        user:{},
        avatarArr: [],
      }
    },
    watch:{
      show(){
        let that = this;
        if (this.show) {
          // *****
          // 若不用延时操作，则 test1 刚被渲染出来，则子视图test2的动画相当于同时进行，则动画失败
          // 这里 setTimeout 相当于队列的作用，即便设置延时0秒后执行动画，但仍然有效
          // *****
          setTimeout(function () {
            that.move(-600);
          },100)
        }else{
          this.move(0);
        }
      }
    },
    created() {
      var that = this;
      storage.getItem('userInfo', function(data) {
        if (data) {
          that.user = JSON.parse(data);
          that.headUrl = that.user.headUrl;
        }
      });
      storage.getItem('commonUrl',function(value) {
        if ('' == value || value == undefined || value.length <= 0) {
          return
        }
        var commonUrl = JSON.parse(value);
        if (commonUrl) {
          that.cmsApiHost = commonUrl.cmsApi; //接口基址
          that.imageBaseUrl = commonUrl.imageBaseUrl; //图片基址
        }
      });

      storage.getItem('headImageInfo',function(value) {
        if ('' == value || value == undefined || value.length <= 0) {
          return
        }
        var dic = JSON.parse(value);
        if (dic) {
          let arr = [];
          if (that.user.sex > 1) {
              arr = dic.womanImgUrls;
            }else {
              arr = dic.manImgUrls;
          }
          for (let i = 0; i < arr.length; i++){
              let dic = {id : i, src : arr[i], select: false};
              that.avatarArr.push(dic);
            }
            // TO DO 放入头像数据源 avatarArr
            for (var i = 0; i < that.avatarArr.length; i++) {
              if (that.avatarArr[i].src == that.user.headUrl) {
                that.avatarArr[i].select = true;
              }
            }
        }
      });
      this.show = true;
    },
    methods:{
      move (bottom) {
        var testEl = this.$refs.test2;
        animation.transition(testEl, {
          styles: {
            transform: `translate(0, ${bottom}px)`,
            transformOrigin: 'center center'
          },
          duration: 300, //ms
          timingFunction: 'ease',
          delay: 0, //ms
          needLayout: true,
        })
      },
      cancel:function () {
        this.$emit('cancel');
      },
      selectAvatar:function (item) {
        let id = item.id;
        let arr = this.avatarArr;
        for (let i = 0; i < arr.length; i++){
          if (arr[i].id === id){
            arr[i].select = true;
          }else {
            arr[i].select = false;
          }
        }
        this.avatarArr = arr;
        this.setAvatar();
      },
      setAvatar:function(){
        let that = this;
        let url = that.cmsApiHost+'/UserAccountDetails?format=json';
        let token = that.user.token;
        let headUrl;
        for (let i = 0; i < that.avatarArr.length;i++){
          if (that.avatarArr[i].select == true){
            headUrl = that.avatarArr[i].src;
          }
        }
        let body = {
          HeaderUrl: headUrl,
          IsUpdate: true,
          Channel: 'bibfx',
        }
        http.putFormToken(token, url, body, function (resp) {
          if (resp.ok && resp.data) {
            if (true == resp.data.IsOK){
              // 提示文字
              that.user.headUrl = headUrl;
              storage.setItem('userInfo',JSON.stringify(that.user));
              modal.toast({ message: '更换成功', duration: 0.5})
            }else {
              modal.toast({ message: '更换失败', duration: 0.5})
            }
          }
        })

      },

    }
  }
</script>
<style src="../style/common.css" scoped></style>
<style scoped>
  .avatar-bg{
    position: fixed;
    left: 0px;
    top: 0px;
    right: 0px;
    bottom: 0px;
    /*兼容H5异常*/
    z-index: 99999;
    justify-content: center;
    align-items: center;
    background-color: rgba(0, 0, 0, 0.6);
  }
  .avatar-controller{
    position: absolute;
    bottom: -600px;
    width: 750px;
    height: 600px;
    align-items: center;
    background-color: white;
    flex: 1;

    padding-top: 70px;
    padding-bottom: 70px;

  }
  .avatar-view{
    /*height: 290px;*/
    padding-left: 16px;
    padding-right: 16px;
    width: 750px;

    /*width: 658px;*/
    /*margin-left: 16px;*/
    /*margin-right: 16px;*/
    /*margin-top: 70px;*/
    /*margin-bottom: 70px;*/

    flex-direction:row;
    flex-wrap: wrap;
  }
  .item{
    width: 120px;
    height: 120px;
    justify-content: center;
    align-items: center;

    /*margin-right: 40px;*/
    /*margin-bottom: 40px;*/
    margin-bottom: 50px;
    margin-left: 29px;
    margin-right: 29px;
  }
  .list{
    width: 658px;
    height: 106px;
    margin-bottom: 70px;

    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .list-item{
    width: 106px;
    height: 106px;
  }
  .item-img{
    /*width: 106px;*/
    /*height: 106px;*/
    /*border-radius: 53px;*/
    width: 120px;
    height: 120px;
    border-radius: 100%;
  }

  .select-img{
    position: absolute;
    right: 0px;
    bottom: 0px;
    width: 38px;
    height: 40px;
  }

  .action-view{
    width: 750px;
    height: 84px;
    align-items: center;
    margin-top: 20px;
  }
  .button{
    width: 522px;
    height: 84px;
    background-color: #2e74e9;
    border-radius: 8px;
    align-items: center;
    justify-content: center;
  }

</style>
