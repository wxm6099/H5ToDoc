<template>
  <div class="chat-container chat-container-height bg-color2 horizontalPadding32 "  ref="test2" @click="onEmptyViewClick">
    <div class="chat-container horizontalPadding32 view-bg boderTop" style="left: 0px;" @click="click">
      <div class="chat-view horizontalCenter flexH ">
      <div class="chat-bar center-view flexH flexView wrapNowrap " :style=chatBarStyle>
        <div v-if="inputState" class="chat-box horizontalMargin20 flexH flexView wrapNowrap verticalCenter" style="justify-content: flex-start;padding-left:10px;">
          <template v-for="item in inputTextArr">
            <text v-if="!item.type" class="font24 color2">{{item.text}}</text>
            <text v-else class="font24 horizontalMargin5 color3"  @click="touchText(item.type)">{{item.text}}</text>
          </template>
        </div>
        <template v-if="!inputState">
          <chatBox
                   class="chat-box horizontalMargin20 flexView"
                   @click="tapChatBox"
                   ref="inputmsg"
                   maxLineNum=1
                   textColor="#808DA5"
                   atTextColor="#2e74e9"
                   placeholderColor="#666A77"
                   singleline=false
                   :placeholder="inputTextArr[0].text"
                   :disabled="inputState"
                   :keyboardShow="keyboardShow"
                   :value="messageStr"
                   @keyboard="keyboard"
                   @input="oninput"
                   @inputHeight="oninputheight"></chatBox>
        </template>

      </div>
      <div class="chat-send center-view send-color"  @click="sendTextMessage()">
        <text class="colorWhite font24" >发送</text>
      </div>
    </div>
      <div class="bottom-view verticalCenter flexH">
      <div class="flexH wrapNowrap" @click="selectEmoji">
        <div class="bottom-img flexH flexView" style="margin-right: 40px">
          <image class="flexView" :src="emoji" resize="contain"></image>
        </div>
        <div class="bottom-img flexH flexView" style="margin-right: 40px" @click="selectPhoto">
          <image class="flexView" :src="photo"  resize="contain"></image>
        </div>
        <div class="bottom-img flexH flexView" @click="selectAt">
          <image class="flexView"  :src="aiteimg" resize="contain"></image>
        </div>
      </div>
      <div class="flexH wrapNowrap">
        <div class="bottom-div flexH verticalCenter flexView" @click="selectLock">
          <template v-if="lock">
            <image class="bottom-icon flexH flexView" :src="unlockimg" resize="contain"></image>
            <text class="font24 btn-color" >锁屏</text>
          </template>
          <template v-else>
            <image class="bottom-icon flexH flexView" :src="lockimg" resize="contain"></image>
            <text class="font24 btn-color" >滚屏</text>
          </template>

        </div>
        <div class="bottom-div flexH verticalCenter flexView" style="margin-left: 30px" @click="selectUnlock">
          <image class="bottom-icon flexH flexView" :src="trashimg" resize="contain"></image>
          <text class="font24 btn-color">清屏</text>
        </div>
      </div>

    </div>
    </div>

    <div v-if="isShowAt" class="at-container">
      <div class="at-view bg-color-white">
        <div class="verticalPadding20 center-view flexView horizontalPadding30">
          <text class="font28 color4" @click="selectAtItem('helper')">@ 助理</text>
        </div>
        <div class="verticalPadding20 center-view flexView horizontalPadding30" style="border-top-color: #dddddd;border-top-width: 1px;">
          <text class="font28 color4"  @click="selectAtItem('teacher')">@ 讲师</text>
        </div>
      </div>
    </div>
  </div>

</template>

<script>
  const inputTextType = {
  	0: [{text: '立即', type: ''},
        {text: '登录', type: 'login'},
        {text: '或', type: ''},
        {text: '注册', type: 'register'},
        {text: '皇御直播间，无限时观看精彩课程！', type: ''}],
  	1: [{text: '立即注资', type: ''},
        {text: '激活', type: 'active'},
        {text: '账户，和各位名师沟通交流吧！', type: ''}],
  	2: [{text: '您暂时无法发言，请咨询在线客服！', type: ''}],
    3: [{text: '因本时段无直播课程，开放关闭', type: ''}],
    4: [{text: '正在连接,请稍候...', type: ''}],
    5: [{text: '想说点什么...', type: ''}],
    6: [{text: '', type: ''}],
  };
  const assetsUrl = require('../include/base-url.js').assetsUrl();
  const bundleUrl = require('../include/base-url.js').bundleUrl();
  const animation = weex.requireModule('animation');
  const modal = weex.requireModule('modal');
  const utils = require('../include/utils.js')
  module.exports = {
    props: {
      isShowEmoji: { default: false },
      isShowAt: { default: false },
      keyboardHeight : {default: 0},
      keyboardShow : {default : false},
      value: {default: ''},
      inputTips: {default: 0},
      inputState: {default: true}
    },
    data: function () {
      return {

        aiteimg: assetsUrl + 'live_aite.png',
        emoji: assetsUrl + 'emoji.png',
        photo: assetsUrl + 'chatu.png',
        trashimg: assetsUrl + 'trash.png',
        unlockimg: assetsUrl + 'unlock.png',
        lockimg: assetsUrl + 'lock.png',

        inputTips: 0,
        inputState: true,
        messageStr:'',
        lock: true,

        chatBarStyle : {'background-color': '#d2d3d6'},

        inputTextArr: inputTextType[0],

        isAndroid: utils.isAndroid(),

        atalertimg: assetsUrl + 'live_img_at.png',


      }
    },
    watch: {
      isShowEmoji(){

        let that = this;
        if (that.isShowEmoji) {
          setTimeout(function () {
            if (that.isAndroid) {
              that.moveForEmoji(-350+2);//安卓会有缝隙
            }else {
              that.moveForEmoji(-350);
            }

          },100)
        }else{
          that.moveForEmoji(0);
        }
      },

      value(){
        this.messageStr = this.value;
      },
      inputTips(){
        console.log('this.inputTipssss-2:' + this.inputTips);
        this.inputTextArr = inputTextType[this.inputTips];
        if (this.isShowEmoji || this.keyboardHeight > 0){
          this.moveForEmoji(0);
        }
      },
      inputState(){
        if (this.inputState) {
          // this.chatBarStyle = {'background-color': '#d2d3d6'}
          this.chatBarStyle = {'background-color': 'rgba(46,116,233,0.08)'}
        }else {
          this.chatBarStyle = {'background-color': 'rgba(46,116,233,0.08)'}
        }
      }
    },
    created() {
      if (this.inputState) {
        // this.chatBarStyle = {'background-color': '#d2d3d6'}
        this.chatBarStyle = {'background-color': 'rgba(46,116,233,0.08)'}
      }else {
        this.chatBarStyle = {'background-color': 'rgba(46,116,233,0.08)'}
      }

      console.log('this.inputTipssss-1:' + this.inputTips);
      this.inputTextArr = inputTextType[this.inputTips];
      //   var that = this;
      //  setTimeout(function(){
      //   that.$emit("ref",that.$refs.inputmsg);
      // },50)
    },
     beforeMount(){
      this.$emit("ref",this.$refs.inputmsg);
    },
    methods:{

      keyboard: function (event) {
        let that = this
        let height = event.height
        that.keyboardHeight = parseInt(height)

        setTimeout(function () {
          if (that.isAndroid) {
            that.moveForKeyboard(-height+2);//安卓会有缝隙
          }else {
            that.moveForKeyboard(-height);
          }
        },0)

        // that.moveForKeyboard(-height);
        this.$emit('keyboard',event);
      },
      oninput:function(event){
        this.$emit('oninput',event);
      },
      oninputheight: function (event) {
        this.$emit('oninputheight',event);
      },

      sendTextMessage:function(){
        this.$emit('sendTextMessage');
      },
      selectAt:function() {
        this.$emit('selectAt');
      },
      selectAtItem:function(e){
        this.$emit('selectAtItem', e);
      },
      selectPhoto:function(){
        this.$emit('selectPhoto');
      },
      selectEmoji:function(){
        this.$emit('selectEmoji');
      },
      selectLock:function(){
        this.lock = !this.lock;
        this.$emit('selectLock');
      },
      selectUnlock:function(){
        this.$emit('selectUnlock');
      },
      touchText:function(type){
        switch (type) {
          case 'login':
            this.login();
            break;
          case 'register':
            this.register();
            break;
          case 'active':
            this.active();
            break;
        }
      },
      onEmptyViewClick:function(){
         this.$emit('emptyClick');
      },
      login:function(){
        this.$emit('login');
      },
      register:function(){
        this.$emit('register');
      },
      active:function () {
        this.$emit('active');
      },

      // 显示
      moveForKeyboard (bottom) {
        var testEl = this.$refs.test2;
        animation.transition(testEl, {
          styles: {
            transform: `translate(0, ${bottom}px)`,
            transformOrigin: 'center center'
          },
          duration: 400, //ms
          timingFunction: 'ease',
          delay: 0, //ms
          needLayout: true,
        })
      },
      click:function(){

      },
      moveForEmoji (bottom) {
        console.log('XXXXXXXXXX:' + bottom);
        var testEl = this.$refs.test2;
        animation.transition(testEl, {
          styles: {
            transform: `translate(0, ${bottom}px)`,
            transformOrigin: 'center center'
          },
          duration: 300, //ms
          timingFunction: 'ease',
          delay: 0, //ms
          needLayout: true,
        })
      },

    }

  }
</script>
<style src="../style/common.css"></style>
<style src="../style/font.css"></style>
<style src="../style/color.css"></style>
<style scoped>
  .chat-container{
    position: absolute;
    bottom: 0;
    width: 750px;
    padding-top: 30px;
    padding-bottom: 20px;
  }
  .chat-container-height{
    height: 245px;
  }
  .chat-view{
    height: 62px;
  }
  .chat-bar{
    border-top-left-radius: 5px;
    border-bottom-left-radius: 5px;
    justify-items: center;
    display: flex;
  }
  .chat-box{
    height: 40px;
  }
  .chat-send {
    width: 80px;
    height: 62px;
    border-top-right-radius: 5px;
    border-bottom-right-radius: 5px;
  }

  .bottom-view{
    height:36px;
    margin-top: 30px;
    justify-content: space-between;
  }
  .bottom-img{
    width: 38px;
    height: 36px;
  }
  .bottom-div{
    height: 36px;
  }
  .bottom-icon{
    width: 20px;
    height: 24px;
    margin-right: 10px;
  }
  .at-container{
    position:absolute;
    left:170px;
    bottom: 80px;
  }
  .at-view{
    border-radius: 10px;
  }
  .send-color{
    background-color: #2e74e9;
  }
  .btn-color{
    color: #6b95ea;
  }
  .view-bg{
    background-color: white;
  }
  .boderTop{
    border-top-color: rgba(46,116,233,0.08);
    border-top-width: 2px;
  }
  .color2{
      color:#666666
  }
  .color3{
      color:#2e74e9
  }
</style>
