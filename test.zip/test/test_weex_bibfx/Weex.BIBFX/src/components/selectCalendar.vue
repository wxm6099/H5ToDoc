<template>
  <scroller>
    <div class="calendar-bg" @click="onDiv()">
        <div class="calendar-top">
            <div class="calendar-top-pro" @click="clickPreMonth()">
                <image style="width: 16px; height: 24px" resize="contain" :src="calendar_pro"></image>
            </div>
            <div class="calendar-top-title">
                <text class="calendar-top-title-month">{{dateTopMonth}}</text>
                <text class="calendar-top-title-year">{{dateTopYear}}</text>
            </div>
            <div class="calendar-top-next" @click="clickNextMonth()">
                <image style="width: 16px; height: 24px" resize="contain" :src="calendar_next"></image>
            </div>
        </div>

        <!--星期-->
        <div class="calendar-week">
            <div class="calendar-week-title" v-for="week in TopTextWeeks">
                <text style="text-align: center;color: #2e74e9;font-size: 28px">{{week}}</text>
            </div>
        </div>
        <!--日历值-->
        <div class="calendar-dates">
            <div class="calendar-dates-bg" v-for="(item,index) in calendarlist" @click="clickCalendarDay(item,index)">
                <!--非当前月-->
                <text v-if="item.otherMonth != 100" class="calendar-dates-not-month">{{item.id}}</text>
                <!--当前月-->
                <text v-else-if="item.isToday" class="calendar-dates-month-today">{{item.id}}</text>
                <!--当前月的当前日期-->
                <text v-else class="calendar-dates-month">{{item.id}}</text>
                <!--&lt;!&ndash;非当前月&ndash;&gt;-->
                <!--<text v-if="(isHideOtherday&&item.nextDayShow)||item.otherMonth||item.dayHide" class="calendar-dates-not-month">{{item.id}}</text>-->
                <!--&lt;!&ndash;当前月&ndash;&gt;-->
                <!--<text v-else="(isHideOtherday&&item.nextDayShow)||item.otherMonth||item.dayHide" class="calendar-dates-month">{{item.id}}</text>-->
            </div>
        </div>
        <!--回到今天-->
        <div class="calendar-bottom">
            <div class="calendar-bottom-bg" @click="clickBackToday()">
                <text style="text-align: center;font-size: 26px;color: #2e74e9;line-height:30px;">回到今天</text>
            </div>
        </div>

    </div>
</scroller>
</template>

<script>
    var assetsUrl = require('../include/base-url.js').assetsUrl();
    var storage = require('../include/storage.js');
    export default {
        data() {
            return {

                calendar_next: assetsUrl + 'calendar_next.png',
                calendar_pro: assetsUrl + 'calendar_pro.png',
                dateTopYear: '',//标题栏的年份
                dateTopMonth: '',//标题栏的月份
                TopTextWeeks: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
                calendarlist: [],
                myData: [],//默认当前日历时间
                selectedDay: '',//选中的日历日期
            };
        },
        props: {
            agoDayHide: {default: '0'},
            futureDayHide: {default: '15181550670000'},
            isHideOtherday: {default: false}
        },
        created() {
            this.myData = new Date();
            // this.getList(this.myData,false);
            var selfThis = this;
            // 接收财经日历选择的日期storage存储的值
            storage.getItem("financialCalendarSelectDayNumber", function (e) {
                selfThis.selectedDay = selfThis.dateFormat(e);
                selfThis.myData = new Date(e);
                //处理财经日历默认选中的时间值
                selfThis.getList(selfThis.myData, true);
            })
        },

        mounted() {
            // this.getList(this.myData,false);
        },

        methods: {
            //得到指定月的日历数据
            getList: function (date, isSelected) {
                const mygetMonth = date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1;
                this.dateTopYear = date.getFullYear();
                if (mygetMonth == 1) {
                    this.dateTopMonth = '一月';
                } else if (mygetMonth == 2) {
                    this.dateTopMonth = '二月';
                } else if (mygetMonth == 3) {
                    this.dateTopMonth = '三月';
                } else if (mygetMonth == 4) {
                    this.dateTopMonth = '四月';
                } else if (mygetMonth == 5) {
                    this.dateTopMonth = '五月';
                } else if (mygetMonth == 6) {
                    this.dateTopMonth = '六月';
                } else if (mygetMonth == 7) {
                    this.dateTopMonth = '七月';
                } else if (mygetMonth == 8) {
                    this.dateTopMonth = '八月';
                } else if (mygetMonth == 9) {
                    this.dateTopMonth = '九月';
                } else if (mygetMonth == 10) {
                    this.dateTopMonth = '十月';
                } else if (mygetMonth == 11) {
                    this.dateTopMonth = '十一月';
                } else if (mygetMonth == 12) {
                    this.dateTopMonth = '十二月';
                }

                let array = [];
                const onMonthDays = this.getDaysInOneMonth(date);
                for (let i = 0; i < onMonthDays; i++) {
                    const nowTime = date.getFullYear() + '/' + (date.getMonth() + 1) + '/' + (i + 1);
                    let listObj = {
                        id: i + 1,
                        date: nowTime,
                        dayHide: new Date(nowTime).getTime() / 1000 < parseInt(this.agoDayHide) || new Date(nowTime).getTime() / 1000 > parseInt(this.futureDayHide),
                        nextDayShow: new Date(nowTime).getTime() > new Date().getTime(),
                        otherMonth: 100,//此处不能赋值0   if无法判断
                    }

                    var today = this.dateFormat(new Date());//今天的日期时间
                    var numDay = this.dateFormat(new Date(nowTime));//日历上的循环日期时间
                    if (isSelected) {
                        if (this.selectedDay == numDay) {//判断日历上的一天是否是当前时间
                            this.selectedDay = numDay;
                            listObj = Object.assign(listObj, {
                                isTodayNow: true,
                                isToday: true,
                            })
                            // this.$emit(
                            //     'isToday',
                            //     this.dateFormat(nowTime)
                            // );
                        } else {
                            listObj = Object.assign(listObj, {
                                isTodayNow: false,
                                isToday: false,
                            });
                        }
                    } else {
                        if (today == numDay) {//判断日历上的一天是否是当前时间
                            this.selectedDay = numDay;
                            listObj = Object.assign(listObj, {
                                isTodayNow: true,
                                isToday: true,
                            })
                            // this.$emit(
                            //     'isToday',
                            //     this.dateFormat(nowTime)
                            // );
                        } else {
                            listObj = Object.assign(listObj, {
                                isTodayNow: false,
                                isToday: false,
                            });
                        }
                    }

                    array.push(listObj);
                }
                const leftArr = this.getLeftArr(date);//本月需要补齐的前一个月的数据
                array = [...leftArr, ...array];
                const rightArr = this.getRightArr(date, array);//本月需要补齐的后一个月的数据
                array = [...array, ...rightArr];
                this.calendarlist = array;
                // console.log('+++@juber输出日历123值：'+JSON.stringify(this.calendarlist));
            },

            //点击了日历上的日期时间（选中日期时间值）
            clickCalendarDay: function (item, index) {
                if (!(this.isHideOtherday && item.nextDayShow) && !item.dayHide) {
                    this.$emit('choseDay', item.date);
                }
                if (item.otherMonth) {
                    if (item.otherMonth == -1) {
                        // this.clickPreMonth(item.date);//点击前一个月的灰色日期数据
                        return;
                    } else if (item.otherMonth == 100) {

                        if (!(this.isHideOtherday && item.nextDayShow) && !item.dayHide) {
                            for (let i = 0; i < this.calendarlist.length; i++) {
                                if (i == index) {
                                    this.selectedDay = this.calendarlist[i].date;
                                    this.calendarlist[i].isToday = true;
                                } else {
                                    this.calendarlist[i].isToday = false;
                                }
                            }
                        }
                    } else if (item.otherMonth == 1) {
                        // this.clickNextMonth(item.date);//点击下一个月的灰色日期数据
                        return;
                    }
                }
                // //storage存储选择的日历的日期值
                // storage.setItem("calendarSelectDayNumber",this.selectedDay);
                // 广播传递选择的日历的日期值
                const calendar = new BroadcastChannel('selectCalendarDayNumber')
                calendar.postMessage(this.selectedDay);
            },

            //点击上一个月按钮 选择上一个月的日历数据
            clickPreMonth: function () {
                this.myData = this.getPreMonth(this.myData);
                // this.$emit('changeMonth', this.dateFormat(this.myData));
                this.getList(this.myData, true);
            },
            onDiv: function () {

            },
            //点击下一个月按钮 选择下一个月的日历数据
            clickNextMonth: function () {
                this.myData = this.getNextMonth(this.myData);
                // this.$emit('changeMonth', this.dateFormat(this.myData));
                this.getList(this.myData, true);
            },

            //点击 返回今天 按钮
            clickBackToday: function () {
                this.getList(new Date(), false);
                // 广播传递选择的日历的日期值
                const calendar = new BroadcastChannel('selectCalendarDayNumber')
                calendar.postMessage(this.selectedDay);
                this.$emit('selectCalendar',this.selectedDay);
            },


            //计算得到指定月的前一个月的date
            getPreMonth: function (date) {
                let timeArray = this.dateFormat(date).split('/');
                let year = timeArray[0];
                let month = timeArray[1];
                let day = timeArray[2];
                // let days = new Date(year, month, 0);
                // days = days.getDate();
                let year2 = year;
                let month2 = parseInt(month) - 1;
                if (month2 == 0) {
                    year2 = parseInt(year2) - 1;
                    month2 = 12;
                }
                let day2 = day;
                let days2 = new Date(year2, month2, 0);
                days2 = days2.getDate();
                if (day2 > days2) {
                    day2 = days2;
                }
                if (month2 < 10) {
                    month2 = '0' + month2;
                }
                if (day2 < 10) {
                    day2 = '0' + day2;
                }
                let t2 = year2 + '/' + month2 + '/' + day2;
                return new Date(t2);
            },
            //计算得到指定月的后一个月的date
            getNextMonth: function (date) {
                let arr = this.dateFormat(date).split('/');
                let year = arr[0]; //获取当前日期的年份
                let month = arr[1]; //获取当前日期的月份
                let day = arr[2]; //获取当前日期的日
                // let days = new Date(year, month, 0);
                // days = days.getDate(); //获取当前日期中的月的天数
                let year2 = year;
                let month2 = parseInt(month) + 1;
                if (month2 == 13) {
                    year2 = parseInt(year2) + 1;
                    month2 = 1;
                }
                let day2 = day;
                let days2 = new Date(year2, month2, 0);
                days2 = days2.getDate();
                if (day2 > days2) {
                    day2 = days2;
                }
                if (month2 < 10) {
                    month2 = '0' + month2;
                }
                if (day2 < 10) {
                    day2 = '0' + day2;
                }
                let t2 = year2 + '/' + month2 + '/' + day2;
                return new Date(t2);
            },

            //返回指定月的总天数
            getDaysInOneMonth: function (date) {
                let getyear = date.getFullYear();
                let getmonth = date.getMonth() + 1;
                let d = new Date(getyear, getmonth, 0);
                var days = d.getDate();
                return days;
            },

            //本月需要补齐的前一个月的数据
            getLeftArr: function (date) {
                let array = [];
                const leftNum = this.getPreMonthweek(date);//需要前一个月补充几个日历日期值
                const preDate = this.getPreMonth(date);//当前月向前推一个月的日期（2018/05/29  到 2018/04/29 ）
                const num = this.getDaysInOneMonth(preDate) - leftNum + 1;//前一个月从哪里开始
                for (let i = 0; i < leftNum; i++) {
                    const nowTime = preDate.getFullYear() + '/' + (preDate.getMonth() + 1) + '/' + (num + i);
                    array.push(
                        {
                            id: num + i,
                            date: nowTime,
                            dayHide: new Date(nowTime).getTime() / 1000 < parseInt(this.agoDayHide) || new Date(nowTime).getTime() / 1000 > parseInt(this.futureDayHide),
                            nextDayShow: new Date(nowTime).getTime() > new Date().getTime(),
                            otherMonth: -1,
                        });
                }
                return array;
            },

            //根据星期计算前一个月需要补充几个数据
            getPreMonthweek: function (date) {
                let getyear = date.getFullYear();
                let getmonth = date.getMonth() + 1;
                let dateOne = new Date(getyear + '/' + getmonth + '/1');
                //dateOne.getDay()的值为0-6 分别对应周日，周一，周二。。。周六
                var num = dateOne.getDay() == 0 ? 6 : dateOne.getDay() - 1;
                return num;
            },

            //本月需要补齐的后一个月的数据
            getRightArr: function (date, arr) {
                let array = [];
                const nextDate = this.getNextMonth(date);//当前月向前推一个月的日期（2018/05/29  到 2018/04/29 ）
                const _length = 7 - arr.length % 7;//需要前一个月补充几个日历日期值
                // var rightNum = this.getNextMonthweek(date);//需要前一个月补充几个日历日期值
                //向后添加数据
                if (_length < 7) {
                    for (let i = 0; i < _length; i++) {
                        const nowTime = nextDate.getFullYear() + '/' + (nextDate.getMonth() + 1) + '/' + (i + 1);
                        array.push({
                            id: i + 1,
                            date: nextDate.getFullYear() + '/' + (nextDate.getMonth() + 1) + '/' + (i + 1),
                            dayHide: new Date(nowTime).getTime() / 1000 < parseInt(this.agoDayHide) || new Date(nowTime).getTime() / 1000 > parseInt(this.futureDayHide),
                            nextDayShow: new Date(nowTime).getTime() > new Date().getTime(),
                            otherMonth: 1
                        });
                    }
                }
                return array;
            },


            //根据星期计算本月需要补充几个数据
            getNextMonthweek: function (date) {
                let getyear = date.getFullYear();
                let getmonth = date.getMonth() + 1;
                var allDays = this.getDaysInOneMonth(date);

                let dateOne = new Date(getyear + '/' + getmonth + '/' + allDays);
                //dateOne.getDay()的值为0-6 分别对应周日，周一，周二。。。周六
                var num = dateOne.getDay() == 0 ? 0 : 7 - dateOne.getDay();
                return num;
            },


            dateFormat: function (date) {
                date = new Date(date)
                return date.getFullYear() + '/' + (date.getMonth() + 1) + '/' + date.getDate();
            }

        },

    };
</script>

<style scoped>

    .calendar-bg {
        background-color: #f5f5f5;
        flex: 1;
        max-width: 750px;
    }

    .calendar-top {
        width: 750px;
        height: 88px;
        margin-top: 0px;
        flex-direction: row;
        justify-content: center;
        align-items: center
    }

    .calendar-top-pro {
        position: absolute;
        left: 40px;
        height: 88px;
        width: 50px;
        justify-content: center;
        align-items: center;
    }

    .calendar-top-title {
        justify-content: center;
        align-items: center;
        flex-direction: row;
    }

    .calendar-top-title-month {
        text-align: center;
        font-size: 28px;
        line-height: 32px;
        padding-right: 14px;
        /*color: #e9302e;*/
        color: #2e74e9;
    }

    .calendar-top-title-year {
        text-align: center;
        font-size: 28px;
        line-height: 32px;
        padding-left: 14px;
        /*color: #e9302e;*/
        color: #2e74e9;
    }

    .calendar-top-next {
        position: absolute;
        right: 40px;
        height: 88px;
        width: 50px;
        justify-content: center;
        align-items: center;
    }

    .calendar-week {
        display: flex;
        flex-wrap: nowrap;
        width: 750px;
        flex-direction: row;
        background-color: white;
    }

    .calendar-week-title {
        margin-top: 34px;
        margin-bottom: 24px;
        overflow: hidden;
        justify-content: center;
        align-items: center;
        flex: 1;
    }

    .calendar-dates {
        /*display: flex;*/
        flex-wrap: wrap;
        width: 750px;
        flex-direction: row;
        background-color: white;
    }

    .calendar-dates-bg {
        overflow: hidden;
        justify-content: center;
        align-items: center;

    }

    .calendar-dates-not-month {
        font-size: 28px;
        color: #9ba1ab;
        width: 106.5px;
        height: 90px;
        text-align: center;
        line-height: 90px;
    }

    .calendar-dates-month {
        font-size: 28px;
        color: #454950;
        width: 106.5px;
        height: 90px;
        text-align: center;
        line-height: 90px;
    }

    .calendar-dates-month-today {
        font-size: 28px;
        color: white;
        width: 106.5px;
        height: 90px;
        text-align: center;
        line-height: 90px;
        /*background-color: #e9302e;*/
        background-color: #2e74e9;
    }

    .calendar-bottom {
        justify-content: flex-end;
        /* align-items: center; */
        flex-direction: row;
        background-color: white;
        padding-top: 22px;
        padding-bottom: 42px;
    }

    .calendar-bottom-bg {
        margin-right: 40px;
        width: 146px;
        height: 70px;
        border-width: 2px;
        /*border-color: #e9302e;*/
        border-color: #2e74e9;
        border-radius: 10px;
        justify-content: center;
        align-items: center;
    }


</style>
