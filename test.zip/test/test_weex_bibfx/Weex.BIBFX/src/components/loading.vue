<template>
<div class='loading-box' :aria-hidden="true">
  <image v-if="url" :src="url" class="loading-trip-image" resize="contain" quality="original"></image>
  <text v-if="loadingText" class="loading-text">{{loadingText}}</text>
</div>
</template>

<style scoped>
.loading-box {
  align-items: center;
  justify-content: center;
  border-radius: 20px;
  width: 150px;
  height: 150px;
  background-color: rgba(0, 0, 0, .5);
}

.trip-loading {
  background-color: rgba(0, 0, 0, .2);
}

.loading-trip-image {
  height: 50px;
  width: 50px;
}

.loading-text {
  color: #ffffff;
  font-size: 30px;
  /* line-height: 30px; */
  /* height: 30px; */
  margin-top: 20px;
  text-overflow: ellipsis;
  width: 140px;
  text-align: center;
}
</style>

<script>
var Utils = require('../include/utils.js');
var assetsUrl = require('../include/base-url.js').assetsUrl();
export default {
  props: {
    loadingText: {
      type: String,
      default: ''
    },
  },
  data: () => ({
    showLoading: false,
    tid: 0,
    url: assetsUrl + 'loading.gif',
  }),
  created() {
  },
  methods: {
  }
};
</script>
