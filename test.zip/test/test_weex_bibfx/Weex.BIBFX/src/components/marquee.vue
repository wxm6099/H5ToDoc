<template>
  <div
    class="wrap"
    @appear="appeared"
    @disappear="disappeared">
    <div
      ref="anim"
      class="anim">
      <slot></slot>
    </div>
  </div>
</template>

<style scoped>
  .wrap {
    overflow: hidden;
    position: relative;
  }
  .anim {
    flex-direction: column;
    position: absolute;
    transform: translateX(0) translateY(0) translateZ(0);
  }
</style>

<script>
  var animation = weex.requireModule('animation')

  module.exports = {
    props: {
      step: { default: 0 },
      count: { default: 0 },
      index: { default: 1 },
      duration: { default: 0 },
      interval: { default: 0 },
      directionRow:{ default:false},
      outofview: { default: false }
    },
    created: function () {
      if (this.interval > 0 && this.step > 0 && this.duration > 0) {
        this.run()
      }
    },
    methods: {
      run: function () {
        if (this.outofview) {
          setTimeout(this.run.bind(this), this.interval)
        } else {
          setTimeout(function () {
            this.animation(this.run.bind(this))
          }.bind(this), this.interval)
        }
      },
      animation: function (cb) {
        let offsetX = 0;
        let offsetY = 0;
        if (true == directionRow) {
          offsetX = -this.step * this.index;
        }else {
          offsetY = -this.step * this.index;
        }
        let transform = 'translateX(' + offsetX + 'px) translateY(' + offsetY + 'px) translateZ(0)'
        animation.transition(this.$refs.anim, {
          styles: {
            transform: transform
          },
          timingFunction: 'linear',
          duration: this.duration
        }, function () {
          this.index = (this.index + 1) % (this.count);
          this.$emit('change', {
            index: this.index,
            count: this.count
          });
          if (0 == this.index) {
            animation.transition(this.$refs.anim, {
              styles: {
                transform: 'translateX(0) translateY(0) translateZ(0)'
              },
              timingFunction: 'linear',
              duration: 0
            },function () {
              this.index = (this.index + 1) % (this.count);
              this.$emit('change', {
                index: this.index,
                count: this.count
              });
              this.run();
            }.bind(this));
          }else {
            cb && cb();
          }
        }.bind(this));
      },
      appeared: function() {
        this.outofview = false
      },
      disappeared: function() {
        this.outofview = true
      }
    }
  }
</script>
