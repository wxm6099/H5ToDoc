<template>
  <div style="flex:1;flex-direction:row; justify-content: center;align-items: center;" :style="{backgroundColor: backgroundColor }">
    <loading-indicator class="loading-indicator"></loading-indicator>
    <text class="loading-indicator-text" :style="{ color: titleColor }"> {{title}} </text>
  </div>
</template>

<script>
module.exports = {
  props: {
    //条背景色
    backgroundColor: { default: 'white' },
    //条标题
    title: { default: '正在加载,请稍候' },
    //条标题颜色
    titleColor: { default: 'black' },
    //指示器颜色
    indicatorColor: { default: 'black' }
  },
  methods: {

  }
}
</script>

<style scoped>
.loading-indicator {
  height: 50px;
  width: 50px;
}

.loading-indicator-text {
  font-size: 30px;
  margin-left: 8px;
  text-align: center;
}
</style>
