<template>
  <div class="container" @click="maskClick">
    <div class="content">
      <div class="title">
        <text class="color title-size">{{title}}</text>
      </div>
      <image v-if="src" class="icon" :src="src"></image>
      <div class="margin">
        <text class="color text-size lines">{{content}}</text>
      </div>
      <div class="footer">
        <div class="footer-btn border" @click="cancel">
          <text class="btn-text cancel"> 以后再说 </text>
        </div>
        <div class="footer-btn" @click="confirm">
          <text class="btn-text confirm"> 立即开启 </text>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var globalEvent = weex.requireModule('globalEvent');
var app = weex.requireModule('app');
var storage = require('../include/storage.js');

module.exports = {
  props: {
    title: '',
    src:'',
    content: '',
  },
  data: function() {
    return {
      type: '',
      data: '',
    }
  },
  methods: {
    cancel: function() {
      this.message = 0;
      this.$emit('cancel');
    },
    confirm: function() {
      this.message = 0;
      this.$emit('confirm');
    },
    maskClick:function(){

    }
  }
}
</script>

<style scoped>
.container {
  position: fixed;
  left: 0px;
  top: 0px;
  right: 0px;
  bottom: 0px;
  /*兼容H5异常*/
  z-index: 99999;
  justify-content: center;
  align-items: center;
  background-color: rgba(0, 0, 0, 0.6);
}

.icon{
  width: 326px;
  height: 270px;
}

.content {
  width: 570px;
  align-items: center;
  background-color: #FFFFFF;
  padding-top: 30px;
  padding-left: 30px;
  padding-right: 30px;
  border-radius: 10px;
}

.title {
  margin-top: 25px;
  justify-content: center;
  align-items: center;
  margin-left: 36px;
  margin-right: 36px;
}

.title-size {
  font-size: 32px;
  line-height: 48px;
  lines: 3;
}

.margin {
  margin-top: 30px;
  margin-bottom: 30px;
}

.color {
  color: #666666;
}

.text-size {
  font-size: 30px;
  line-height: 42px;
  text-align: left;
}

.lines {
  lines: 15;
  text-overflow: ellipsis;
}

.footer {
  width: 570px;
  flex-direction: row;
  align-items: center;
  border-top-color: #eeeeee;
  border-top-width: 1px;
}

.footer-btn {
  flex-direction: row;
  align-items: center;
  justify-content: center;
  flex: 1;
  height: 88px;
}

.border {
  border-right-color: #eeeeee;
  border-right-width: 1px;
}

.cancel {
  color: #9ba1ab;
}

.confirm {
  color: #e9302e;
}

.btn-text {
  font-size: 28px;
  text-align: center;
}
</style>
