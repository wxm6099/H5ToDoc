<template>
  <div class="wrapper" bubble="true">
    <embed
      v-for="(item , i) in tabItems"
      :src="item.src"
      :key="i"
      type="weex"
      :style="{ visibility: item.visibility ,'margin-bottom': iphonex?'134px':'100px'}"
      class="content"
      ></embed>
    <div class="tabbar" :style="{height: iphonex?'134px':'100px'}" append="tree">
      <tabitem
        v-for="item in tabItems"
        :key="item.index"
        :index="item.index"
        :icon="item.icon"
        :title="item.title"
        :top="item.top"
        :titleColor="item.titleColor"
        @tabItemOnClick="tabItemOnClick"
        ></tabItem>
    </div>
  </div>
</template>

<style scoped>
  .wrapper {
    width: 750;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
  }
  .content {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin-top: 0;
    margin-bottom: 100;
  }
  .tabbar {
    flex-direction: row;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: 100;
    /* background-color: #F1F1F1; */
    border-top-color: #F1F1F1;
    border-top-style: solid;
    border-top-width: 1px;
  }
</style>

<script>
  module.exports = {
    props: {
      tabItems: { default: [] },
      selectedColor: { default: '#e9302e' },
      unselectedColor: { default: '#9ba1ab' }
    },
    computed: {
      iphonex: function() {
        return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' || weex.config.env.deviceModel === 'iPhone11,2' || weex.config.env.deviceModel === 'iPhone11,4'|| weex.config.env.deviceModel === 'iPhone11,6'|| weex.config.env.deviceModel === 'iPhone11,8');
      }
    },
    data: function () {
      return {
        selectedIndex: 0
      }
    },
    components: {
      tabitem: require('./tabitem.vue')
    },
    created: function () {
      this.select(this.selectedIndex);
      this.$emit('tabBarOnClick', {index:this.selectedIndex});
    },
    methods: {
      tabItemOnClick: function (e) {
        this.selectedIndex = e.index;
        this.select(e.index);
        this.$emit('tabBarOnClick', e);
      },
      select: function(index) {
        for(var i = 0; i < this.tabItems.length; i++) {
          var tabItem = this.tabItems[i];
          if(i == index){
            tabItem.icon = tabItem.selectedImage;
            tabItem.titleColor = this.selectedColor;
            tabItem.visibility = 'visible';
          }
          else {
            tabItem.icon = tabItem.image;
            tabItem.titleColor = this.unselectedColor;
            tabItem.visibility = 'hidden';
          }
        }
      },
    }
  }
</script>
