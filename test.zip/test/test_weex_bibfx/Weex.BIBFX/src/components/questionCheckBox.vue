<template>
  <div style="flex-direction: column;">
    <div style="flex:1;margin-bottom:14px;margin-top:10px;">
        <text :style="{color:questionTextColor}" class="problem">{{dataItem.problem}}</text>
        <div style="flex-direction: row; flex-wrap: wrap;align-items: center;margin-left:24px;" v-if="dataItem.isShowTip">
            <image style="width: 24px;height: 24px;margin-right: 10px;margin-bottom:2px" :src="tipImg"></image>
            <text class="font24" :style="{color:tipTextColor}">{{tipText}}</text>
        </div>
    </div>
    <div v-if="dataItem.isAnswersH" style="flex-direction: row;">
      <div style="width:350px">
        <div class="answer" v-for="(ans,index) in dataItem.answers" v-if="index%2 == 0" @click ="wxcCellClicked(ans,index)">
          <div style="margin-left: 22px;margin-right: 10px;">
            <image :src="ans.isSelected ? checkImg : uncheckImg" class="checkbox"></image>
          </div>
          <div style="flex:1">
            <text :style="{color:answerTextColor}" style="width: 270px" class="title-text">{{ans.answer}}</text>
          </div>
        </div>
      </div>
      <div style="width:350px">
        <div class="answer" v-for="(ans,index) in dataItem.answers" v-if="index%2 == 1" @click ="wxcCellClicked(ans,index)">
          <div style="margin-left: 22px;margin-right: 10px;">
            <image :src="ans.isSelected ? checkImg : uncheckImg" class="checkbox"></image>
          </div>
          <div style="flex:1">
            <text :style="{color:answerTextColor}" style="width: 270px"  class="title-text">{{ans.answer}}</text>
          </div>
        </div>
      </div>
    </div>
    <div v-if="!dataItem.isAnswersH" class="answer"  v-for="(ans,index) in dataItem.answers" @click ="wxcCellClicked(ans,index)">
      <div style="margin-left: 22px;margin-right: 10px;">
        <image :src="ans.isSelected ? checkImg : uncheckImg" class="checkbox"></image>
      </div>
      <div style="flex:1">
        <text :style="{color:answerTextColor}" class="title-text">{{ans.answer}}</text>
      </div>
    </div>
  </div>
</template>

<script scoped>
var assetsUrl = require('../include/base-url.js').assetsUrl();

module.exports = {
  props: {
    //问题以及答案的字典
    dataItem: {
      type: Object,
      default: () => ({})
    },
    //配置信息
    config: {
      type: Object,
      default: () => ({})
    }
  },
  data:function(){
    return{

    }
  },
  computed: {
    tipText () {
      const {dataItem, config } = this;
      if (dataItem.isShowTip) {
        return config.tipText;
      } else {
        return '';
      }
    },
    tipImg () {
      const {dataItem, config } = this;
      if (dataItem.isShowTip) {
        return config.tipImg;
      } else {
        return '';
      }
    },
    checkImg () {
      const {dataItem, config } = this;
      if (dataItem.isSelectMore) {
        return config.checkedMoreIcon;
      } else {
        return config.checkedIcon;
      }
    },
    uncheckImg () {
      const {dataItem, config } = this;
      if (dataItem.isSelectMore) {
        return config.unCheckedIcon;
      } else {
        return config.unCheckedIcon;
      }
    },
    tipTextColor () {
      const { config } = this;
      return config.tipTextColor;
    },
    questionTextColor () {
      const { config } = this;
      return config.questionColor;
    },
    answerTextColor () {
      const {config} = this;
      if (config.isChangeSelectedColor) {
        return config.answerSelectedColor;
      }else {
        return config.answerColor;
      }
    }
  },
  watch: {
    // checked (newChecked) {
    //   this.innerChecked = newChecked;
    //   console.log("rdddd newChecked:"+this.innerChecked);
    // }
  },
  created () {
    // const { checked } = this;
  },
  methods: {
    wxcCellClicked (event,index) {
      const {dataItem} = this;
      for (var i = 0; i < dataItem.answers.length; i++) {
        if (i == index) {//选中
          if (dataItem.answers[i].isSelected && dataItem.isSelectMore) {//多选中  已选中的答案再次选中即为取消
            dataItem.answers[i].isSelected = false;
            this.$emit('checkBoxItemChecked', { questionId:dataItem.id,question:dataItem.problemCode, answer: dataItem.answers[i]});
          }else {//单选或者多选中选中
            if (dataItem.isSelectMore) {//多选中选中
              if (dataItem.answers[i].answerCode=='nothing') {//多选中选中答案nothing 已选中的其他答案要取消选中
                for (var j = 0; j < dataItem.answers.length; j++) {
                  dataItem.answers[j].isSelected = false;
                }
              }else {//多选中未选中答案nothing
                for (var j = 0; j < dataItem.answers.length; j++) {
                  if (dataItem.answers[j].isSelected && dataItem.answers[j].answerCode=='nothing') {//已选中的nothing答案要取消选中
                    dataItem.answers[j].isSelected = false;
                  }
                }
              }
            }
            dataItem.answers[i].isSelected = true;
            this.$emit('checkBoxItemChecked', { questionId:dataItem.id,question:dataItem.problemCode, answer: dataItem.answers[i]});
          }
        }else {//未选中
          if (!dataItem.isSelectMore) {//单选中未选中的答案（多选不作处理）
            dataItem.answers[i].isSelected = false;
          }
        }
      }
    }
  }
}
</script>
<style  src="../style/common.css" scoped></style>
<style scoped>
.problem {
    text-align: left;
    /* color: #333333; */
    font-size: 28px;
    line-height: 36px;
}
.answer{
  flex-direction: row;
  align-items: flex-start;
  margin-bottom: 20px;
}
.checkbox {
  width: 34px;
  height: 34px;
}

.title-text {
  line-height: 34px;
  text-align: left;
  font-size: 28px;
  margin-left: 10px;
  /* color: #666666; */
}
</style>
