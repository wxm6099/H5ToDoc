<template>
  <div v-if="showLoading" class="loading-need-mask "@click="maskClicked" :style="maskStyle">
    <div class="wxc-loading" :style="{ top: topPosition +'px'}" v-if="showLoading">
      <div  v-if="showLoading" class='loading-box' :aria-hidden="true">
        <image v-if="url && indicator" :src="url"
               class="loading-trip-image"
               resize="contain"
               quality="original"></image>
        <text v-if="loadingText"
              class="loading-text">{{loadingText}}</text>
      </div>
    </div>
  </div>
</template>

<style scoped>

  .loading-need-mask {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.2);
  }

  .wxc-loading {
    position: fixed;
    left: 300px;
    top: 500px;
    z-index: 9999;
  }

  .loading-box {
    align-items: center;
    justify-content: center;
    border-radius: 20px;
    width: 150px;
    height: 150px;
    background-color: rgba(0, 0, 0, 0.8);
  }

  .trip-loading {
    background-color: rgba(0, 0, 0, .2);
  }

  .loading-trip-image {
    height: 50px;
    width: 50px;
  }

  .loading-text {
    color: #ffffff;
    font-size: 30px;
    /* line-height: 30px; */
    /* height: 30px; */
    margin-top: 20px;
    text-overflow: ellipsis;
    width: 140px;
    text-align: center;
  }
</style>

<script>
  var Utils = require('../include/utils.js');
  var assetsUrl = require('../include/base-url.js').assetsUrl();
  export default {
    props: {
      show: {
        type: Boolean,
        default: false
      },
      indicator:{
        type: Boolean,
        default: true
      },
      loadingText: {
        type: String,
        default: ''
      },
      interval: {
        type: [Number, String],
        default: 0
      },
      needMask: {
        type: String,
        default: ''
      },
      maskStyle: {
        type: Object,
        default: () => ({})
      }
    },
    data: () => ({
      showLoading: false,
      tid: 0,
      url:assetsUrl+'loading.gif',
    }),
    watch: {
      show () {
        this.setShow();
      }
    },
    computed: {
      topPosition () {
        return (Utils.getPageHeight() - 128) / 2;
      }
    },
    created () {
      this.setShow();
    },
    methods: {
      maskClicked () {
        if ('true' == this.needMask) {
          this.$emit('wxcLoadingMaskClicked', {})
        }
      },
      setShow () {
        const { interval, show, showLoading } = this;
        const stInterval = parseInt(interval);
        if (this.tid !=0 ) {
          clearTimeout(this.tid);
        }
        if (show) {
          if (showLoading) {
            return;
          }
          if (stInterval === 0) {
            this.showLoading = true;
          } else {
            this.tid = setTimeout(() => {
              this.showLoading = true;
            }, stInterval);
          }
        } else {
          this.showLoading = false;
        }
        // console.log("-------this.showLoading:"+this.showLoading);
      }
    }
  };
</script>
