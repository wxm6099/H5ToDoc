<template>
  <!-- v-if="isShowEmoji" -->
  <!-- :style="{'bottom':(isShowEmoji) ? 0 : -350}" -->
     <div ref="test" class="emoji-controller" >
       <slider class="emoji-slider" show-indicators="true" infinite="false" bounces="false">
            <div v-for="(item,index) in emojiArr">
              <div class="emoji-view">
                <template v-for="(subItem, index) in item">
                  <div v-if="index != 23" class="emoji-item" @click="selectEmojiItem(subItem)">
                    <image style="width:60px;height:60px;" autoBitmapRecycle=true :src="`${assetPath}emoji/${subItem.face_name}.png`"></image>
                  </div>
                </template>
                <div class="emoji-item" @click="deleteEmoji(subItem)">
                  <image style="width:60px;height:60px;" :src="assetPath+'delete_emoji.png'"></image>
                </div>
              </div>
            </div>
            <indicator class="indicator"></indicator>
       </slider>
     </div>
</template>

<script>
const animation = weex.requireModule('animation')
const modal = weex.requireModule('modal')
var assets = require('../include/base-url.js').assetsUrl()
const emojiDataSource = require('../include/emoji.js').emoji
var navigator = weex.requireModule('navigator')
module.exports = {
  props: {
    isShowEmoji: { default: false }
  },
  components: {
  },
  data: function () {
    return {
      assetPath: assets,
      emojiArr: []
    }
  },
  watch: {
    isShowEmoji(){
      if (this.isShowEmoji) {
        this.move(-350);
      }else{
        this.move(0);
      }
    }
  },
  created: function () {
    // this.isShowEmoji = !this.isShowEmoji;
    let dataSource = emojiDataSource
    let emojiArr = []
    // 若一行 8个表情，则一屏 23个 和 一个 减号
    // TO DO 添加空表情填充数据源，使每一屏都有24个位置
    let num = 23
    for (let i = 0; i < dataSource.length; i += num) {
      let arrTmp = []
      for (let j = 0; j < num; j++) {
        let dic = dataSource[i + j]
        if (dic === undefined) {
          dic = {
            'face_text': 'empty',
            'face_name': 'empty',
            'face_id': ''
          }
        }
        arrTmp.push(dic)
      }
      emojiArr.push(arrTmp)
    }
    this.emojiArr = emojiArr
  },
  methods: {
    deleteEmoji: function (subItem) {
      this.$emit('deleteEmoji', subItem)
    },
    selectEmojiItem: function (subItem) {
      this.$emit('selectEmojiItem', subItem)
    },
    move (bottom) {
        var testEl = this.$refs.test;
        animation.transition(testEl, {
          styles: {
            color: '#FF0000',
            transform: `translate(0, ${bottom}px)`,
            transformOrigin: 'center center'
          },
          duration: 300, //ms
          timingFunction: 'ease',
          delay: 0 //ms
        })
    },
  }
}
</script>

<style scoped>
  .emoji-controller {
    width: 750px;
    height: 350px;
    position: absolute;
    bottom: -350px;
    /*bottom: 0px;*/
    background-color:#EBEDF2;
  }
  .emoji-slider{
    /*margin: 10px;*/
    width: 750px;
    height: 350px;
  }
  .emoji-view{
    width: 750px;
    flex: 1;
    padding: 10px;
    flex-direction: row;
    flex-wrap: wrap;
  }
  .emoji-item{
    width: 70px;
    height: 70px;
    margin: 10px;
    justify-content: center;
    align-items: center;
  }
   .indicator{
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    height: 50px;
    background-color: rgba(0, 0, 0, 0);
    item-color: #ddd;
    item-selected-color: rgb(0, 180, 255);
  }
</style>
