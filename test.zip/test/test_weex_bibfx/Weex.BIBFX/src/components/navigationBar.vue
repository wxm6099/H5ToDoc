<template>
  <div class="navbar" :style="{'border-bottom-color': bottomColor,'background-color': bgColor}">
    <div v-if="leftImg" @click="leftClick" class="navbar-button-l">
      <image style="width: 20px; height: 36px" resize="contain" :src="leftImg"></image>
    </div>
    <text class="navbar-title" :style="{color: textColor}"> {{title}} </text>
    <div v-if="rightImg" @click="rightClick" class="navbar-button-r">
      <image style="width: 36px; height: 36px" resize="contain" :src="rightImg"></image>
    </div>
  </div>
</template>

<script>
import instance from '../include/instance'
var utils = require('../include/utils.js');
var app = weex.requireModule('app');
module.exports = {
  props: {
    bgColor: {
      default: '#FFFFFF'  //默认白色 导航栏背景色
    },
    bottomColor: {
      default: '#F1F1F1'  //默认白色 导航栏底部线条色
    },
    title: {
      default: ''
    },
    textColor: {
      default: '#000000'  //默认黑色  导航栏标题字体颜色
    },
    leftImg: {
      default:''   //导航栏左侧图标
    },
    rightImg: {
      default:''  //导航栏右侧图标
    }
  },
  computed: {

  },
  data: function() {
    return {
      isIOSX: utils.iphonex()
    }
  },
  methods:{
     leftClick:function(){
       this.$emit('leftClick');
     },
     rightClick:function(){
       this.$emit('rightClick');
     },
  }
}
</script>
<style scoped>
.navbar {
  width: 750px;
  height: 88px;
  border-bottom-width: 1px;
  align-items: center;
  justify-content: center;
}

.navbar-title {
  width: 590px;
  font-size: 36px;
  line-height: 54px;
  text-align: center;
  lines:1;
  text-overflow: ellipsis;
}

.navbar-button-l {
  position: absolute;
  top: 0px;
  left: 0px;
  bottom: 0px;
  width: 80px;
  justify-content: center;
  align-items: center;
}
.navbar-button-r {
  position: absolute;
  top: 0px;
  right: 0px;
  bottom: 0px;
  width: 80px;
  justify-content: center;
  align-items: center;
}
</style>
