<template>
  <div class="cover" v-if="isShow" :key="keyname" @click="maskClick">
    <div class="alertview-bg">
      <image style="width:500px;height:224px;" resize="contain" :src="bgIcon"></image>
      <text class="tips-text">亲爱的用户，请补全以下信息：</text>
      <input ref="nickNameRef" @input="onInputName" class="inputText" maxlength="16" placeholder="填写昵称，请勿使用个人真实信息哦！" return-key-type="done"></input>
      <text class="font20 color3" style="width:500px;padding-left:48px;margin-top:5px;">{{nickNameTips}}</text>
      <div class="sex-select-bg">
        <div class="sex-select">
          <div class="row-left" @click="maleClick">
            <div class="sex-select-kuang"></div>
            <text class="sex-text">男士</text>
            <image v-if="1== selectSex" class="sex-select-icon" resize="contain" :src="gouIcon"></image>
          </div>
          <div class="row-right" @click="femaleClick">
            <div class="sex-select-kuang"></div>
            <text class="sex-text">女士</text>
            <image v-if="2== selectSex" class="sex-select-icon" resize="contain" :src="gouIcon"></image>
          </div>
        </div>
      </div>
      <div @click="updateNickName" class="button-submit">
        <text class="font28 color2 bold">确定</text>
      </div>
      <image class="close-icon" resize="contain" :src="closeIcon" @click="close"></image>
    </div>
  </div>
</template>

<script>
var assets = require('../include/base-url.js').assetsUrl()
var navigator = weex.requireModule('navigator')
module.exports = {
  props: {
    isShow: { default: false },
    isSelectSex: { default: false },
    sexy: { default: 0},
    nickNameTips: { default: ''},
    keyname:{ default:''}
  },
  components: {
    statusbar: require('../components/statusbar.vue')
  },
  data: function () {
    return {
      selectSex:0,
      bgIcon: assets + 'live_nickname_bg.png', // 背景图标
      gouIcon: assets + 'live_nickname_gou.png', // 选中状态图标
      closeIcon: assets + 'live_nickname_close.png', // 关闭图标
    }
  },
  created: function () {
  },
  watch:{
    'sexy' : {
      handler(){
        this.selectSex = this.sexy;
      },
      deep:true,
      immediate:true
    },
  },
  methods: {
    maskClick:function(){
    },
    maleClick:function(){
      if (this.isSelectSex) {
        this.selectSex = 1
      }
    },
    femaleClick:function(){
      if (this.isSelectSex) {
        this.selectSex = 2
      }
    },
    updateNickName: function () {
      this.$refs.nickNameRef.blur()
      this.$emit('updateNickName',this.selectSex)
    },
    onInputName: function (event) {
      this.$emit('onInputName', event)
    },
    close: function () {
      this.$emit('onClose')
    },
  }
}
</script>

<style scoped>
 .cover {
  background-color: rgba(0, 0, 0, 0.5);
  position: fixed;
  left: 0px;
  top: 0px;
  right: 0px;
  bottom: 0px;
  align-items: center;
  justify-content: center;
}
.alertview-bg{
  width:500px;
  background-color:#ffffff;
  border-radius:5px;
  overflow:hidden;
  /* align-items: center; */
}
.tips-text{
  margin-left:48px;
  margin-top:34px;
  margin-bottom:30px;
  margin-right:48px;
  font-size: 26px;
  line-height: 39px;
  color: #666666;
}
.button {
  width: 630px;
  height: 90px;
  align-items: center;
  justify-content: center;
  border-radius: 40px;
}
.inputText{
  margin-left:48px;
  width:404px;
  height:56px;
  padding-left:5px;
  font-size: 22px;
  background-color:#eeeeee;
  border-radius:6px;
  color:#999999;
}
.sex-select-bg{
  width:500px;
  margin-top:24px;
  height: 40px;
  align-items: center;
  justify-content: center;
}
.sex-select{
  flex-direction:row;
  align-items: center;
  justify-content: center;
}
.sex-select-kuang{
  width: 30px;
  height: 30px;
  border-radius: 5px;
  margin-right: 20px;
  border-width: 1px;
  border-color: #6494ec;
}
.sex-select-icon{
  position: absolute;
  top:8px;
  left: 3px;
  width: 35px;
  height: 24px;
}
.sex-text{
  font-size: 26px;
  line-height: 39px;
  color: #666666;
}
.button-submit {
  width:500px;
  height:80px;
  margin-top: 20px;
  border-top-color: #dedede;
  border-top-width: 1px;
  align-items: center;
  justify-content: center;
  background-color: #FFFFFF;
}
.row-left {
  height: 40px;
  flex-direction: row;
  align-items: center;
}
.row-right {
  margin-left: 80px;
  height: 40px;
  flex-direction: row;
  align-items: center;
}
.bold{
  font-weight: bold;
}
.black{
  color: black;
}

.color2{
  color: #6494ec;
}
.color3{
  color: #ee726e;
}

.color4{
  color: #999999;
}
.font20{
  font-size: 20px;
  line-height: 30px;
}
.font26{
  font-size: 26px;
  line-height: 39px;
}
.font28{
  font-size: 28px;
  line-height: 42px;
}
.close-icon{
  position: absolute;
  top:20px;
  right: 20px;
  width: 40px;
  height: 40px;
}
</style>
