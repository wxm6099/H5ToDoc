<template>
  <div v-if="enable && message>0" class="container" @click="maskClick">
    <div class="content">
      <div class="title">
        <text class="color title-size">{{title}}</text>
      </div>
      <div class="margin">
        <text class="color text-size lines">{{content}}</text>
      </div>
      <div class="footer">
        <div class="footer-btn border" @click="cancel">
          <text class="btn-text cancel"> 稍后再看 </text>
        </div>
        <div class="footer-btn" @click="confirm">
          <text class="btn-text confirm"> 立即查看 </text>
        </div>
      </div>
      <div class="close" @click="close">
        <image class="close-icon" :src="assets+'close.png'"></image>
      </div>
    </div>
  </div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var globalEvent = weex.requireModule('globalEvent');
var app = weex.requireModule('app');
var storage = require('../include/storage.js');

module.exports = {
  props: {
    enable: { default: true },
  },
  data: function() {
    return {
      assets: assetsUrl,
      message: 0,
      type: '',
      title: '',
      content: '',
      data: '',
    }
  },
  created:function() {
    var that = this;
    globalEvent.addEventListener("notification", function(e) {
      that.type = e.type
      that.title = e.title;
      that.articleTitle = e.articleTitle;
      that.content = e.content;
      that.data = e.data;
      if (that.content && that.content.length > 0) {
        that.message = 1;
      }
    });
  },
  methods: {
    close: function() {
      this.message = 0;
      this.$emit('close');
    },
    cancel: function() {
      this.message = 0;
      this.$emit('cancel');
    },
    confirm: function() {
      this.message = 0;
      this.$emit('confirm');
      if ('Active' == this.type || 'Article' == this.type) {
          var url = this.data;
          var title = this.articleTitle;

          var para = {
            title: title,
            url: url,
            type:this.type
          }
          storage.setItem('app-url', JSON.stringify(para));
          navigator.push({
            url: bundleUrl + 'webview.js',
            animated: "true",
            swipePop: "true",
          }, event => {})
      }else if('Video' == this.type || 'video' == this.type){
        if (weex.supports('@module/app.disableStatusBar')) {
          app.disableStatusBar(false);
        }
        //进入直播
        navigator.push({
          url: bundleUrl + 'live.js',
          animated: "true",
          swipePop: "true",
        }, event => {})
      }
    },
    maskClick:function(){

    }
  }
}
</script>

<style scoped>
.container {
  position: fixed;
  left: 0px;
  top: 0px;
  right: 0px;
  bottom: 0px;
  /*兼容H5异常*/
  z-index: 99999;
  justify-content: center;
  align-items: center;
  background-color: rgba(0, 0, 0, 0.6);
}

.content {
  width: 500px;
  background-color: #FFFFFF;
  padding-top: 20px;
  border-radius: 10px;
}

.title {
  margin-top: 25px;
  justify-content: center;
  align-items: center;
  margin-left: 36px;
  margin-right: 36px;
}

.title-size {
  font-size: 32px;
  line-height: 48px;
  lines: 3;
}

.margin {
  margin-top: 20px;
  margin-bottom: 20px;
  margin-left: 36px;
  margin-right: 36px;
}

.color {
  color: #454950;
}

.text-size {
  font-size: 28px;
  line-height: 42px;
  text-align: left;
}

.lines {
  lines: 15;
  text-overflow: ellipsis;
}

.footer {
  flex-direction: row;
  align-items: center;
  border-top-color: #F3F3F3;
  border-top-width: 1px;
}

.footer-btn {
  flex-direction: row;
  align-items: center;
  justify-content: center;
  flex: 1;
  height: 88px;
}

.border {
  border-right-color: #F3F3F3;
  border-right-width: 1px;
}

.cancel {
  color: #9ba1ab;
}

.confirm {
  color: #e9302e;
}

.btn-text {
  font-size: 28px;
  text-align: center;
}

.close {
  position: absolute;
  top: 0px;
  right: 0px;
  width: 100px;
  height: 80px;
  flex-direction: row;
  justify-content: flex-end;
}

.close-icon {
  width: 38px;
  height: 38px;
  margin-top: 14px;
  margin-right: 14px;
}
</style>
