<template>
  <div v-if="show" class="container" @click="maskClick">
    <div class="content">
      <div class="title">
        <text class="color title-size">{{title}}</text>
      </div>
      <div class="margin">
        <text class="color text-size lines">{{content}}</text>
      </div>
      <div class="footer">
        <div  v-if="!single" class="footer-btn border" @click="cancelClick">
          <text class="btn-text cancel"> {{cancel}} </text>
        </div>
        <div class="footer-btn" @click="confirmClick">
          <text class="btn-text confirm"> {{confirm}} </text>
        </div>
      </div>
      <div v-if="close" class="close" @click="closeClick">
        <image class="close-icon" :src="assets+'close.png'"></image>
      </div>
    </div>
  </div>
</template>

<script>
var bundleUrl = require('../include/base-url.js').bundleUrl();
var assetsUrl = require('../include/base-url.js').assetsUrl();
var navigator = weex.requireModule('navigator');
var globalEvent = weex.requireModule('globalEvent');
var app = weex.requireModule('app');
var storage = require('../include/storage.js');

module.exports = {
  props: {
    show: { default: false },
    single: { default: false },
    close: { default: true },
    title: '',
    content: '',
    confirm: { default: '确定' },
    cancel: { default: '取消' },
  },
  data: function() {
    return {
      assets: assetsUrl,
    }
  },
  created:function() {

  },
  methods: {
    closeClick: function() {
      this.show = false;
      this.$emit('close');
    },
    cancelClick: function() {
      this.show = false;
      this.$emit('cancel');
      this.$emit('close');
    },
    confirmClick: function() {
      this.show = false;
      this.$emit('confirm');
      this.$emit('close');
    },
    maskClick:function(){

    }
  }
}
</script>

<style scoped>
.container {
  position: fixed;
  left: 0px;
  top: 0px;
  right: 0px;
  bottom: 0px;
  /*兼容H5异常*/
  z-index: 99999;
  justify-content: center;
  align-items: center;
   background-color: rgba(0, 0, 0, 0.6);
}

.content {
  width: 500px;
  background-color: #FFFFFF;
  padding-top: 20px;
  border-radius: 10px;
}

.title {
  margin-top: 25px;
  justify-content: center;
  align-items: center;
  margin-left: 36px;
  margin-right: 36px;
}

.title-size {
  font-size: 32px;
  line-height: 48px;
  lines: 3;
}

.margin {
  margin-top: 20px;
  margin-bottom: 20px;
  margin-left: 36px;
  margin-right: 36px;
  justify-content: center;
  align-items: center;
}

.color {
  color: #454950;
}

.text-size {
  font-size: 28px;
  line-height: 42px;
  text-align: left;
}

.lines {
  lines: 15;
  text-overflow: ellipsis;
}

.footer {
  flex-direction: row;
  align-items: center;
  border-top-color: #F3F3F3;
  border-top-width: 1px;
}

.footer-btn {
  flex-direction: row;
  align-items: center;
  justify-content: center;
  flex: 1;
  height: 88px;
}

.border {
  border-right-color: #F3F3F3;
  border-right-width: 1px;
}

.cancel {
  /* color: #9ba1ab; */
  color: #e9302e;
}

.confirm {
  color: #9ba1ab;
  /* color: #e9302e; */
}

.btn-text {
  font-size: 28px;
  text-align: center;
}

.close {
  position: absolute;
  top: 0px;
  right: 0px;
  width: 100px;
  height: 80px;
  flex-direction: row;
  justify-content: flex-end;
}

.close-icon {
  width: 38px;
  height: 38px;
  margin-top: 14px;
  margin-right: 14px;
}
</style>
