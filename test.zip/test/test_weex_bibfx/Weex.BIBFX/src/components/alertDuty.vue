<template>
  <div v-if="show && canShow" class="bg">
    <div class="container">

      <div style="position: absolute;top: 0;left: 0;right: 0;bottom: 0;overflow: hidden">
        <image style="width: 688px;height: 634px;" :src="alert_bg"></image>
      </div>

      <div class="content">
        <div class="title">
          <text class="font36" style="color: #333333;font-weight: bold;">{{dataSource.title}}</text>
        </div>
        <div class="desc">
          <scroller show-scrollbar="false">
            <text class="font28" style="color: #666666;line-height: 50px;letter-spacing: 1px">{{dataSource.desc}}</text>
          </scroller>
        </div>
      </div>
      <div class="button" @click="sure">
        <text class="font32" style="color: #ffffff">确定</text>
      </div>
    </div>
  </div>


</template>

<script>
  const assetsUrl = require('../include/base-url.js').assetsUrl();
  var storage = require('../include/storage.js');
  var utils = require('../include/utils.js');
  export default {
    props: {
      show: { default: false }
    },
    data(){
      return{
        canShow: false,
        alert_bg: assetsUrl + 'alert_bg.png',
        dataSource: {
          title: '免责声明',
          desc:'直播间分析师关于某种产品的未来趋势或操作建议，仅为个人观点，不能代表铸博皇御官方立场。本直播间所载资料仅做参考，并不构成任何买卖建议、邀请或游说，客户据此操作，风险自担。'
        }
      }
    },
    created(){
      let that = this;
      storage.getItem('showDuty', function(value) {
        if (utils.isBlankString(value)) {
          that.canShow = true;
        }
      });
    },
    methods:{
      sure:function () {
        this.canShow = false;
        storage.setItem('showDuty',"false");
      }
    }
  }
</script>
<style src="../style/common.css" scoped></style>
<style scoped>
  .bg{
    position: fixed;
    left: 0px;
    top: 0px;
    right: 0px;
    bottom: 0px;
    /*兼容H5异常*/
    z-index: 99999;
    justify-content: center;
    align-items: center;
    background-color: rgba(0, 0, 0, 0.5);
  }
  .container{
    background-color: white;
    /*position: absolute;*/
    width: 688px;
    height: 554px;
    padding-top: 46px;
    padding-bottom: 60px;
    padding-left: 50px;
    padding-right: 50px;

    border-radius: 8px;

  }
  .content{

  }
  .title{

    height: 60px;
    line-height: 60px;
    margin-bottom: 12px;

    justify-content: center;
    align-items: center;
  }
  .desc{
    height: 250px;
    overflow: hidden;
  }
  .button{
    height: 80px;
    /*width: 586px;*/
    background-color: #2e74e9;
    border-radius: 8px;
    margin-top: 48px;

    justify-content: center;
    align-items: center;
  }

</style>
