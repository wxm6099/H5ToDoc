<template>
  <div class="container">
    <image :src="leftItemSrc" class="left-image" v-on:click="onclickleftitem"></image>
    <image :src="centerItemSrc" class="center-image"></image>
    <image :src="rightItemSrc" class="right-image" v-on:click="onclickrightitem"></image>
  </div>
</template>

<style scoped>
.container {
  flex-direction: row;
  top: 0;
  left: 0;
  right: 0;
  width: 750;
  height: 88;
  justify-content: space-between;
  align-items: center;
}

.left-image {
  width: 88;
  height: 88;
}

.right-image {
  width: 88;
  height: 88;
}

.center-image {
  width: 212;
  height: 72;
}
</style>

<script>
module.exports = {
  props: {
    //导航条背景色
    leftItemSrc: {
      default: ''
    },
    centerItemSrc: {
      default: ''
    },
    rightItemSrc: {
      default: ''
    },
  },
  methods: {
    onclickrightitem: function(e) {
      this.$emit('naviBarRightItemClick');
    },
    onclickleftitem: function(e) {
      this.$emit('naviBarLeftItemClick');
    }
  }
}
</script>
