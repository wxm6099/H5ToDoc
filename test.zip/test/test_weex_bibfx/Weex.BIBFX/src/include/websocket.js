var webSocket =weex.requireModule('webSocket');
var timeout = 15000;
var path= "";
exports.connect = function(){

}
exports.send = function(){

};

exports.oninput = function(){

};
exports.close = function(){

};