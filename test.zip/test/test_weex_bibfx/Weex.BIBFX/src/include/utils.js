/**
 * CopyRight (C) 2017-2022 Alibaba Group Holding Limited.
 * Created by Tw93 on 17/11/01
 */

import UrlParser from 'url-parse';


exports.clone = function(object) {
  return JSON.parse(JSON.stringify(object))
}
exports._typeof = function(obj) {
  return Object.prototype.toString.call(obj).slice(8, -1).toLowerCase();
};

exports.isPlainObject = function(obj) {
  return this._typeof(obj) === 'object';
};

exports.isString = function(obj) {
  return typeof(obj) === 'string';
};

exports.isNonEmptyArray = function(obj = []) {
  return obj && obj.length > 0 && Array.isArray(obj) && typeof obj !== 'undefined';
};

exports.isObject = function(item) {
  return (item && typeof item === 'object' && !Array.isArray(item));
};

exports.isEmptyObject = function(obj) {
  return Object.keys(obj).length === 0 && obj.constructor === Object;
};

exports.isBlankString = function(obj) {
  if (undefined == obj || obj == '' || obj.length <= 0) {
    return true
  }
  return false
}
exports.checkNickName = function(name = '') {
  return /^[\u4E00-\u9FA5a-zA-Z]{1,16}$/.test(name)
}
//数组去重函数
exports.unique = function(arr) {
  let newArr = [];
  let hash = {};
  for (let i = 0; i < arr.length; i++) {
    if (!hash[JSON.stringify(arr[i])]) {
      hash[JSON.stringify(arr[i])] = true
      newArr.push(arr[i])
    }
  }
  return newArr;
}

//数组 差集
exports.diffrence = function(arrA, arrB) {
  let a = arrA.map(JSON.stringify);
  let b = arrB.map(JSON.stringify);
  let c = a.concat(b).filter(v => {
    return a.includes(v) && !b.includes(v);
  }).map(JSON.parse);
  return c;
}

exports.decodeIconFont = function(text) {
  // 正则匹配 图标和文字混排 eg: 我去上学校&#xe600;,天天不&#xe600;迟到
  const regExp = /&#x[a-z|0-9]{4,5};?/g;
  if (regExp.test(text)) {
    return text.replace(new RegExp(regExp, 'g'), function(iconText) {
      const replace = iconText.replace(/&#x/, '0x').replace(/;$/, '');
      return String.fromCharCode(replace);
    });
  } else {
    return text;
  }
};

exports.mergeDeep = function(target, ...sources) {
  if (!sources.length) return target;
  const source = sources.shift();
  if (this.isObject(target) && this.isObject(source)) {
    for (const key in source) {
      if (this.isObject(source[key])) {
        if (!target[key]) {
          Object.assign(target, {
            [key]: {}
          });
        }
        this.mergeDeep(target[key], source[key]);
      } else {
        Object.assign(target, {
          [key]: source[key]
        });
      }
    }
  }
  return this.mergeDeep(target, ...sources);
};

exports.appendProtocol = function(url) {
  if (/^http/.test(url)) {
    return url;
  }
  const {
    bundleUrl
  } = weex.config;
  return 'http' + (/^https:/.test(bundleUrl) ? 's://' : '://') + url;
};

exports.encodeURLParams = function(url) {
  const parsedUrl = new UrlParser(url, true);
  return parsedUrl.toString();
};

exports.appendURLParams = function(url, params) {
  if (/^http[s]?:\S+\?/.test(url)) {
    return url + '&' + params;
  } else {
    return url + '?' + params;
  }
};


exports.getQueryString = function(url, param) {
  var reg = new RegExp("[?&]" + param + "=([^&]+)", "gmi");
  if (reg.test(url)) return RegExp.$1;
  return "";
};

exports.calculationSpread = function(ask, bid, size, mul) {
  return ((ask - bid) * mul).toFixed(size)
}

// 计算涨跌
exports.calculationpchange = function(bid, open, fixed = 2) {
  var o = (bid - open).toFixed(fixed)
  if (o < 0) {
    return o
  } else {
    return '+' + o
  }
}

// ask是卖出价；bid是买入价
// 计算涨跌幅
exports.calculationchange = function(bid, open, fixed) {
  if (bid >= open) {
    return '+' + ((bid - open) / bid * 100).toFixed(fixed)
  } else {
    return ((bid - open) / bid * 100).toFixed(fixed)
  }
}

exports.iOS = function() {
  const {
    platform
  } = weex.config.env;
  return platform.toLowerCase() === 'ios';
};

/**
 * 是否为 iPhone X
 * @returns {boolean}
 */
exports.iphonex = function() {
  return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' || weex.config.env.deviceModel === 'iPhone11,2' || weex.config.env.deviceModel === 'iPhone11,4' || weex.config.env.deviceModel === 'iPhone11,6' || weex.config.env.deviceModel === 'iPhone11,8');
};

exports.ipad = function() {
  return weex && (/^iPad/.test(weex.config.env.deviceModel));
  // return weex && (weex.config.env.deviceModel.startsWith('iPad') || weex.config.env.deviceModel.startsWith('ipad'));
};

exports.isAndroid = function() {
  const {
    platform
  } = weex.config.env;
  return platform.toLowerCase() === 'android';
};


exports.isWeb = function() {
  const {
    platform
  } = weex.config.env;
  return typeof(window) === 'object' && platform.toLowerCase() === 'web';
};

exports.supportsEB = function() {
  const weexVersion = weex.config.env.weexVersion || '0';
  const isHighWeex = this.compareVersion(weexVersion, '0.10.1.4') && (this.iOS() || this.isAndroid());
  const expressionBinding = weex.requireModule('expressionBinding');
  return expressionBinding && expressionBinding.enableBinding && isHighWeex;
};

/**
 * 判断Android容器是否支持是否支持expressionBinding(处理方式很不一致)
 * @returns {boolean}
 */
exports.supportsEBForAndroid = function() {
  return (this.isAndroid()) && this.supportsEB();
};

/**
 * 判断IOS容器是否支持是否支持expressionBinding
 * @returns {boolean}
 */
exports.supportsEBForIos = function() {
  return (this.iOS()) && this.supportsEB();
};

/**
 * 获取weex屏幕真实的设置高度，需要减去导航栏高度
 * @returns {Number}
 */
exports.getPageHeight = function() {
  const {
    env
  } = weex.config;
  const navHeight = this.isWeb() ? 0 : (this.iOS() ? 176 : 132);
  return env.deviceHeight / env.deviceWidth * 750 - navHeight;
};

/**
 * 版本号比较
 * @memberOf Utils
 * @param currVer {string}
 * @param promoteVer {string}
 * @returns {boolean}
 * @example
 *
 * const { Utils } = require('@ali/wx-bridge');
 * const { compareVersion } = Utils;
 * console.log(compareVersion('0.1.100', '0.1.11')); // 'true'
 */
exports.compareVersion = function(currVer = '0.0.0', promoteVer = '0.0.0') {
  if (currVer === promoteVer) return false;
  const currVerArr = currVer.split('.');
  const promoteVerArr = promoteVer.split('.');
  const len = Math.max(currVerArr.length, promoteVerArr.length);
  for (let i = 0; i < len; i++) {
    const proVal = ~~promoteVerArr[i];
    const curVal = ~~currVerArr[i];
    if (proVal < curVal) {
      return true;
    } else if (proVal > curVal) {
      return false;
    }
  }
  return false;
};

/**
 * 分割数组
 * @param arr 被分割数组
 * @param size 分割数组的长度
 * @returns {Array}
 */
exports.arrayChunk = function(arr = [], size = 4) {
  let groups = [];
  if (arr && arr.length > 0) {
    groups = arr.map((e, i) => {
      return i % size === 0 ? arr.slice(i, i + size) : null;
    }).filter(e => {
      return e;
    });
  }
  return groups;
};

exports.truncateString = function(str, len, hasDot = true) {
  let newLength = 0;
  let newStr = '';
  let singleChar = '';
  const chineseRegex = /[^\x00-\xff]/g;
  const strLength = str.replace(chineseRegex, '**').length;
  for (let i = 0; i < strLength; i++) {
    singleChar = str.charAt(i).toString();
    if (singleChar.match(chineseRegex) !== null) {
      newLength += 2;
    } else {
      newLength++;
    }
    if (newLength > len) {
      break;
    }
    newStr += singleChar;
  }

  if (hasDot && strLength > len) {
    newStr += '...';
  }
  return newStr;
};
exports.showTime = function(time) {
  // var date = new Date(time.replace(new RegExp(/-/gm), "/"));
  //   time的格式   /Date(1509935433000-0000)/
  var date = new Date(parseInt(time.replace('/Date(', '').replace(')/', '').substring(0, 13)));
  var now = new Date();
  var duration = (now.getTime() - date.getTime()) / 1000;
  if (duration < 60) {
    return '刚刚';
  } else if (duration < 3600) {
    return Math.floor(duration / 60) + '分钟前';
  } else if (duration < 86400) {
    return Math.floor(duration / 3600) + '小时前';
  } else if (duration < 172800) {
    return '1天前';
  } else {
    return (date.getMonth() + 1) + '月' + date.getDate() + '日';
  }
};
exports.dateFormat = function(time, fmt) {
  var date = new Date(time);
  var o = {
    "M+": date.getMonth() + 1, //月份
    "d+": date.getDate(), //日
    "h+": date.getHours(), //小时
    "m+": date.getMinutes(), //分
    "s+": date.getSeconds(), //秒
    "q+": Math.floor((date.getMonth() + 3) / 3), //季度
    "S": date.getMilliseconds() //毫秒
  };
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
  return fmt;
};

exports.checkAccount = function(account = '') {
  return /^\S{6,20}$/.test(account)
}
//校验密码
exports.checkPwd = function(pwd = '') {
  return /^[0-9A-Za-z]{6,20}$/.test(pwd)
}

exports.checkName = function(name = '') {
  //姓名可以使汉字和. 或者 大小写英文和空格和.
  // let judge1 = /^[\u4e00-\u9fa5\·]{1,50}$/.test(name);
  // let judge2 = /^[a-zA-Z][a-zA-Z0-9]{1,50}$/.test(name);
  // let judge3 = /^[A-Za-z\s]{1,50}$/.test(name);
  // let judge4 = !/^[\u4e00-\u9fa5\d]{1,50}$/.test(name);
  // return !(judge1 || judge2 || judge3 || judge4);

  return /(^[a-zA-Z][a-zA-Z0-9]{1,50}$)|(^[A-Za-z\s]{1,50}$)|(^[\u4e00-\u9fa5\·]{1,50}$)/.test(name);
}

exports.localTime = function(fmt = 'yyyy-MM-dd') {
  var date = new Date()
  var o = {
    'M+': date.getMonth() + 1, // 月份
    'd+': date.getDate(), // 日
    'h+': date.getHours(), // 小时
    'm+': date.getMinutes(), // 分
    's+': date.getSeconds(), // 秒
    'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
    'S': date.getMilliseconds() // 毫秒
  }
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
  for (var k in o) {
    if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)))
  }
  return fmt
}
