export const TYPE_TEACHER = 50;//老师
export const TYPE_ANCHOR  = 51;//主播

export const TYPE_LESSION_NORMAL  = 0;// 正常模式
export const TYPE_LESSION_TEACHERS  = 1;//双老师模式
export const TYPE_LESSION_ANCHOR  = 2;//老师+主播 模式
