
export const MT4 = 'https://itunes.apple.com/app/id413251709';
export const APPSTORE = 'https://itunes.apple.com/app/id1482728265';
export const KEY = 'UTq3wxW8VJIkfsmL8nEjpa82o0N0E1CjknM97VZILCs='; //   加解密的key
// export const INITSERVER = 'http://192.168.0.251:8080/src/bibgold.json';//开发服
// export const ClientID = "nkjE3c8nqytT2XAD";//开发服
// export const LiveClientID = 'dagsY4Lq6PSnFxiO';//开发服 直播间

// export const QUOTESERVER = 'http://demo.fantasysz.com:16508/quote.json'
// export const INITSERVER = 'http://demo.fantasysz.com:16508/bibfx.json';//测试服
// export const ClientID = "O8sEKyfTfvUuTu12";//测试服 MC
// export const LiveClientID = '4UfALkcpLGYgU6LJ';//测试服 直播间
// export const QUOTESERVER = 'http://172.17.10.47:8081/src/quote.json'
// export const INITSERVER = 'http://172.17.10.47:8081/src/bibfx.json';//线上服
export const QUOTESERVER = 'https://app.bibfx.net/quote.json'
export const INITSERVER = 'https://app.bibfx.net/bibfx.json';//线上服
export const ClientID = "CNQ7EJe7EEBcx6pk";//线上MC
export const LiveClientID = 'eP4W9EdHNu0E8PCs';//线上直播间
