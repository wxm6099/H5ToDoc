const storage = weex.requireModule('storage');

exports.setItem = function (key, value, callback) {
    storage.setItem(key, value, callback);
};

exports.getItem = function (key, callback) {
    storage.getItem(key, e => {
        if (e.result === 'success') {
            callback(e.data);
        } else {
            callback('');
        }
    });
};

exports.getItemSync = function (key) {
  var e = storage.getItemSync(key);
  if (e.result === 'success') {
    return e.data;
  }else {
    return '';
  }
}

exports.removeItem = function (key) {
    storage.removeItem(key, event => {
        if (event.result === 'success') {
            console.log("remove Cache  success");
        } else {
            console.log("remove Cache  failure");
        }
    })
}
exports.getAllKeys = function (callback) {
    storage.getAllKeys(event => {
        if (event.result === 'success') {
            callback(event.data);
        } else {
            callback('');
        }
    })
}
exports.getAllKeys = function (callback) {
    storage.getAllKeys(event => {
        if (event.result === 'success') {
            callback(event.data);
        } else {
            callback('');
        }
    })
}
exports.totalSize = function () {
    return storage.totalSize();
}
