/**
 * @Author   : rc
 * @Data     : 2018-04-04
 * @Describe : 封装weex实例对象
 */
var stream = weex.requireModule('stream');
var timeout = 60000;
exports.setTimeout = function(millisecond){
  // if (millisecond>=5000) {
  //   timeout = millisecond
  // }else {
  //   timeout = 10000;
  // }
}
/**
* get网络请求的方法
* url 需要请求的地址
**/
exports.get = function(url,callback,timeout = 30000){
    console.log("http get url:"+url);
    return stream.fetch({
    method: 'GET',
    type: 'json',
    url: url,
    timeout:timeout,
  },  res=>{
    if(callback){
         callback(res);
    }
  });
};
/**
* get网络请求的方法
* url 需要请求的地址
**/
exports.getByHeader = function(token,url,callback,timeout = 30000){
    console.log("-----http getHeader url--------:"+url);
    return stream.fetch({
    method: 'GET',
    type: 'json',
    url: url,
    headers: {
      'Token': token,
    },
    timeout:timeout,
  },  res=>{
    if(callback){
         callback(res);
    }
  });
};

/**
* post网络请求的方法
* url 需要请求的地址
* body 请求对象(json)
**/
exports.post = function(url, body, callback){
    return stream.fetch({
      method: 'POST',
      type: 'json',
      url: url,
      headers: {
        'Content-Type': 'application/json;charset=UTF-8',
      },
      body: body,
    }, res=>{
      if(callback){
           callback(res);
      }
    });
};

/**
* post网络请求的方法
* url 需要请求的地址
* body 请求对象(form)
**/
exports.postForm = function(url, body, callback){
    return stream.fetch({
      method: 'POST',
      type: 'json',
      url: url,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
      },
      body: body,
      timeout:timeout,
    }, res=>{
      if(callback){
           callback(res);
      }
    });
};
/**
* putForm网络请求的方法
* url 需要请求的地址
* body 请求对象(form)
**/
exports.putForm = function(url, body, callback){
    return stream.fetch({
      method: 'PUT',
      type: 'json',
      url: url,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
      },
      body: body,
      timeout:timeout,
    }, res=>{
      if(callback){
           callback(res);
      }
    });
};
/**
* putFormToken网络请求的方法
* url 需要请求的地址
* body 请求对象(json)
**/
exports.putFormToken = function(token, url, body, callback){

    return stream.fetch({
      method: 'PUT',
      type: 'json',
      url: url,
      headers: {
        'Content-Type': 'application/json;charset=utf-8',
           // 'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Token': token,
      },
      body: body,
      timeout:timeout,
    }, res=>{
      if(callback){
           callback(res);
      }
    });
};
/**
* postFormToken网络请求的方法
* url 需要请求的地址
* body 请求对象(json)
**/
exports.postFormToken = function(token, url, body, callback){
    return stream.fetch({
      method: 'POST',
      type: 'json',
      url: url,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Token': token,
      },
      body: body,
      timeout:timeout,
    }, res=>{
      if(callback){
           callback(res);
      }
    });
};


exports.postFormToken2 = function(token, url, body, callback){
  return stream.fetch({
    method: 'POST',
    type: 'json',
    url: url,
    headers: {
      // 'Content-Type': 'multipart/form-data',
      // 'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
      'Content-Type': 'application/json;charset=utf-8',
      'Token': token,
    },
    body: body,
    timeout:timeout,
  }, res=>{
    if(callback){
      callback(res);
    }
  });

};
