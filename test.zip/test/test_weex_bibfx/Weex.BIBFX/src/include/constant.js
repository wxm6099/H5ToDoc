// const ATTACHMENT_STATUS = {
// 	//0:Default(默认) 1:NULL(无 None)   2:(Unprocessing)未处理  3:(Approving)审核中  4:(ApprovedPass)审核完成
// 	//  4:(ApprovedFail)审核退回
// 	0 : 'Default',
// 	1 : 'NULL',
// 	2 : 'Unprocessing',
// 	3 : 'Approving',
// 	4 : 'ApprovedPass',
// }
// 
// module.exports.ATTACHMENT_STATUS = ATTACHMENT_STATUS;

exports.ATTACHMENT_STATUS = {
	//0:Default(默认) 1:NULL(无 None)   2:(Unprocessing)未处理  3:(Approving)审核中  4:(ApprovedPass)审核完成
	//  4:(ApprovedFail)审核退回
	0 : 'Default',
	1 : 'NULL',
	2 : 'Unprocessing',
	3 : 'Approving',
	4 : 'ApprovedPass',
}

exports.MONEY_TYPE = {
	"CNY" : '人民币',
	'HKD' : '港币',
	'USD' : '美元',
	'TWD' : '新台币',
	'JPY' : '日元',
	'KRW' : '韩元',
	'SGD' : '新加坡元',
	'EUR' : '欧元',
}