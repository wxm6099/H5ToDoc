import main from './view/index.vue'
main.el = '#root'
export default new Vue(main)
