import Vue from 'vue'
import weex from 'weex-vue-render'

weex.init(Vue)
