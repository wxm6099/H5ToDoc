import home from '../view/home.vue'
home.el = '#root'
export default new Vue(home)
