import survey from '../view/survey.vue'
survey.el = '#root'
export default new Vue(survey)