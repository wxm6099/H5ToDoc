import contact from '../view/contact.vue'
contact.el = '#root'
export default new Vue(contact)
