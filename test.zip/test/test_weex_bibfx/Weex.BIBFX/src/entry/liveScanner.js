import liveScanner from '../view/liveScanner.vue'
liveScanner.el = '#root'
export default new Vue(liveScanner)
