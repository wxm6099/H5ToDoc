import home from '../view/market.vue'
home.el = '#root'
export default new Vue(home)
