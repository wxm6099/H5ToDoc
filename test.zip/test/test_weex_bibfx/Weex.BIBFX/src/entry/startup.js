import startup from '../view/startup.vue'
startup.el = '#root'
export default new Vue(startup)
