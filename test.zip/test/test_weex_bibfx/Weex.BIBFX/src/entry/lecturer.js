import lecturer from '../view/lecturer.vue'
lecturer.el = '#root'
export default new Vue(lecturer)
