import openAccount from '../view/openAccount.vue'
openAccount.el = '#root'
export default new Vue(openAccount)
