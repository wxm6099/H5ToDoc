import virtual from '../view/virtual.vue'
virtual.el = '#root'
export default new Vue(virtual)
