import liveFullScreen from '../view/liveFullScreen.vue'
liveFullScreen.el = '#root'
export default new Vue(liveFullScreen)
