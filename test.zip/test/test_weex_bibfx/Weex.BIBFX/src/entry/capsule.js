import capsule from '../view/capsule.vue'
capsule.el = '#root'
export default new Vue(capsule)
