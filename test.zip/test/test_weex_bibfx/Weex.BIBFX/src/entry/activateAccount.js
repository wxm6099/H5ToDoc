import activateAccount from '../view/activateAccount.vue'
activateAccount.el = '#root'
export default new Vue(activateAccount)
