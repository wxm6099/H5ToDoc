import playsetting from '../view/playsetting.vue'
playsetting.el = '#root'
export default new Vue(playsetting)
