import home from '../view/quote.vue'
home.el = '#root'
export default new Vue(home)
