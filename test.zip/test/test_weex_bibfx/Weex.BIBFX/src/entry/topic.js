import topic from '../view/topic.vue'
topic.el = '#root'
export default new Vue(topic)
