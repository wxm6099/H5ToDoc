import ranklist from '../view/ranklist.vue'
ranklist.el = '#root'
export default new Vue(ranklist)
