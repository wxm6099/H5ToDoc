import webview from '../view/webview.vue'
webview.el = '#root'
export default new Vue(webview)
