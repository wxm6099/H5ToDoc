import setting from '../view/account.vue'
setting.el = '#root'
export default new Vue(setting)
