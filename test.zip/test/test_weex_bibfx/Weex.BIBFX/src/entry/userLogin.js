import userLogin from '../view/userLogin.vue'
userLogin.el = '#root'
export default new Vue(userLogin)
