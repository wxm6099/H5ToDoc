import articleSetting from '../view/articleSetting.vue'
articleSetting.el = '#root'
export default new Vue(articleSetting)
