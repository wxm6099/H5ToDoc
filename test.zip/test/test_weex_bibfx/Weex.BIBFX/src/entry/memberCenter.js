import mc from '../view/memberCenter.vue'
mc.el = '#root'
export default new Vue(mc)
