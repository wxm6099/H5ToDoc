const meta = weex.requireModule('meta')
import quoteFullScreen from '../view/quoteFullScreen.vue'
quoteFullScreen.el = '#root'

// let width = Math.min(weex.config.env.deviceHeight, weex.config.env.deviceWidth);
// console.log('width:'+width);
if (/^iPad/.test(weex.config.env.deviceModel)) {
  meta.setViewport({
    width: 2048
  })
}
export default new Vue(quoteFullScreen)
