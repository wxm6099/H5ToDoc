import scanner from '../view/recognize.vue'
scanner.el = '#root'
export default new Vue(scanner)
