import qrcodeLogin from '../view/qrcodeLogin.vue'
qrcodeLogin.el = '#root'
export default new Vue(qrcodeLogin)
