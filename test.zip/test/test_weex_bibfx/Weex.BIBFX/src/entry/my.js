import my from '../view/my.vue'
my.el = '#root'
export default new Vue(my)
