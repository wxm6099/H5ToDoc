import course from '../view/course.vue'
course.el = '#root'
export default new Vue(course)
