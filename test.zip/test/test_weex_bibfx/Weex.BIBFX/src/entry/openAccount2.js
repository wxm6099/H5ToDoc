import openAccount2 from '../view/openAccount2.vue'
openAccount2.el = '#root'
export default new Vue(openAccount2)
