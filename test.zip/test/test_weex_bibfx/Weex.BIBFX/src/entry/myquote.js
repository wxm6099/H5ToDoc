import myquote from '../view/myquote.vue'
myquote.el = '#root'
export default new Vue(myquote)
