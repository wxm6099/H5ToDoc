import main from '../view/websocket.vue'
main.el = '#root'
export default new Vue(main)
