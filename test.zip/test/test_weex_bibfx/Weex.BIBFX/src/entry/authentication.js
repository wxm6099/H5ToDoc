import authentication from '../view/authentication.vue'
authentication.el = '#root'
export default new Vue(authentication)
