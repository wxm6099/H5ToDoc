import messagepush from '../view/messagepush.vue'
messagepush.el = '#root'
export default new Vue(messagepush)
