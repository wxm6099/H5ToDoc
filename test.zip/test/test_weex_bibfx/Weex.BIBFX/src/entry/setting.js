import setting from '../view/setting.vue'
setting.el = '#root'
export default new Vue(setting)
