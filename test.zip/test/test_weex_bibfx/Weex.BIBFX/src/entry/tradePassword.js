import tradePassword from '../view/tradePassword.vue'
tradePassword.el = '#root'
export default new Vue(tradePassword)
