import information from '../view/information.vue'
information.el = '#root'
export default new Vue(information)
