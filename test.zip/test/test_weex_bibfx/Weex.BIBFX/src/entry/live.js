import live from '../view/live.vue'
live.el = '#root'
export default new Vue(live)
